# 01 · Extension System Overview

This is the mental model for the whole extension platform: what an extension
is, where its code runs, how capabilities are granted, what the host does at
each lifecycle step, and which kinds of work are self-serve versus
host-coordinated. Everything later in the guide hangs off this document.

## One extension, one family, one manifest

A Cedros extension is **one installable cross-stack package family** with one
stable lowercase kebab-case `extensionId`:

- **A Rust server package** — compiled to a WebAssembly component
  (`cedros-extension.server.wasm`) when the extension has server behavior.
- **A React package** — one package serving two surfaces: the admin app
  (`./admin/register`) and the public site (`./web/register`).
- **A React Native package** — at minimum a bootstrap; mobile block renderers
  are live. Screens, stacks, and providers are self-serve in hosted App Builder
  releases and host-coordinated for other native hosts until they publish the
  same loader contract.

All three members are declared even when a member is a minimal bootstrap. The
family is described by one canonical manifest —
`cedros-extension.manifest.json` — and shipped as one ZIP archive that the
site operator uploads in the admin. The manifest declares identity,
compatibility, the package family, every surface the extension contributes,
and every capability it wants; the archive carries the compiled runtime that
makes those declarations executable.

The authoring contract is **manifest-first and package-backed**:
`cedros-extension.manifest.json`, `cedros-extension.bootstrap.json`, compiled
runtime assets, and release evidence must agree. Manifest declarations create
inventory, install gates, permissions, routing intent, and setup metadata —
**they do not execute behavior by themselves**.

## Where extension code runs

| Runtime | What runs there | Contract |
|---|---|---|
| **Server (wasm)** | Routes under `/extensions/{id}/…`, scheduled jobs, database/settings/secrets/provider/CRM calls, SEO descriptions | [`07-wasm-server-backends.md`](07-wasm-server-backends.md) |
| **Admin (browser)** | Admin pages (`AdminModule` sections), dashboard cards, content editor panels, wrappers | [`06-runtime-sdk-reference.md`](06-runtime-sdk-reference.md), [`12-admin-pages-and-dashboard-cards.md`](12-admin-pages-and-dashboard-cards.md) |
| **Public web (browser + SSR shell)** | Visual-builder blocks and templates on seeded/authored pages | [`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md) |
| **Native (React Native)** | Mobile block renderers (live); screens/stacks/providers (self-serve in hosted App Builder, otherwise host-coordinated) | [`05-package-family-and-registration.md`](05-package-family-and-registration.md), [`21-host-coordination-and-native.md`](21-host-coordination-and-native.md) |

Two facts shape everything:

1. **The server backend is a sandboxed WebAssembly component.** The host
   compiles your Rust to `wasm32-wasip2`, loads it capability-gated, and
   dispatches requests into it. The guest has no filesystem, no network, no
   environment — every effect goes through a host import the manifest granted.
   Install/enable/disable hot-swap the runtime with no server restart.
2. **Browser code loads from the ZIP through a restricted module loader.**
   Compiled ESM only, four author-facing host-resolved module specifiers
   (`react`, the JSX runtimes, and `cedros:admin`), everything else bundled. No remote code loading,
   ever.

## Capabilities: declare → review → grant → enforce

Every privileged thing an extension can do is a **capability seam** with the
same shape:

1. The manifest **declares** intent (`databaseAccess[]`, `providerAccess[]`,
   `customerTagAccess[]`, `crmSourceAccess[]`, `surfaces.server.events[]`,
   …) with operator-facing descriptions and scopes. `settingsSchemas[]` is a
   plain list of schema ids: declaring one links the `settings` import, and the
   host validates neither keys nor values against it.
2. The operator **reviews** those declarations at install — installing an
   extension is the operator granting what its manifest declares.
3. The host **grants** exactly what was declared: for the wasm runtime,
   ungranted interfaces are structurally absent, so a component that imports a
   capability it was not granted fails closed at install.
4. The host **enforces** scopes per call (verb + resource + namespacing), with
   extension attribution on every operation.

Two deliberate exceptions: `logging` and `secrets` are always granted (each is
per-extension isolated and reaches no host resource), and outbound
`http.fetch` is **operator-granted via environment allowlist**
(`CEDROS_EXTENSION_HTTP_ALLOWLIST`), not manifest-declared — it is always
linked but fails closed until the operator allowlists hosts.

## Lifecycle: what happens when

**Intake/upload** — the operator uploads the ZIP
([`22-packaging-and-upload.md`](22-packaging-and-upload.md)). The shared
publisher parses and validates the manifest (schema version, ids, namespacing,
per-surface rules), checks manifest/bootstrap equality, and enforces archive
limits. The extension-manager intake records the version in the catalog for
review/publish lifecycle; the wasm install endpoint additionally extracts the
component and verifies it loads under exactly the granted capabilities.

**Install** — before recording a Wasm runtime as installed, the host
auto-provisions every declared `surfaces.server.contentModels[]` as a JSONB
collection and treats provisioning failure as an install failure. It also
verifies **reverse binding admission**: every manifest-declared route/job id
must be exported by the guest. Boot-time activation repeats content-model
provisioning idempotently and skips binding if the declared database contract
cannot be satisfied.

**Enable** — routes bind under `/extensions/{id}` and jobs bind to the
scheduler (hot-swap, no restart). The host lifecycle reconciles page seeds and
job schedules with `autoCreateOnEnable: true`, including for headless/API
operations. The admin shell materializes extension docs drafts and policy/form
starters asynchronously
([`05-package-family-and-registration.md`](05-package-family-and-registration.md)).
Notification setup seeds provision through the published
`cedros-notifications:route-write` binding on enable. Contract-template and
email-template setup seeds are metadata only today: the host builds their
owner-system request shapes but no lifecycle step submits them, so they remain
host-coordinated until the Contracts/Email bindings are wired.

**Disable** — routes/jobs unbind, calls fail closed, contributions hide.
Owner-created content (seeded pages, forms, docs) is preserved.

**Update/reinstall** — re-upload with a bumped version; settings and enabled
state are preserved. Jobs converge via a manifest-hash stamp; seeds are
idempotent-once and never overwrite owner edits.

**Uninstall** — removes the extension; optionally purges its settings,
secrets, and namespaced database entries. Owner content is preserved unless
the operator explicitly deletes data.

The full disable/remove/re-enable/rollback matrix per surface is in
[`23-release-versioning-and-upgrades.md`](23-release-versioning-and-upgrades.md).

> **No per-tenant fan-out.** Cedros is per-SITE single-tenant. There is no
> workspace/tenant model in the extension platform and no host install
> fan-out. Multi-business behavior lives inside your own content models.

## Three classes of work

Classify every surface you plan into one of these; the classification drives
what you build versus what you hand off:

- **Self-serve today** — manifest metadata plus ZIP-contained runtime
  activates without any Cedros host code change. This now covers almost
  everything: admin pages, dashboard cards, blocks/templates, page seeds,
  starters, onboarding, analytics declarations, AI surfaces, and the entire
  server runtime (routes, jobs, database, settings, secrets, telemetry,
  providers, customer tags, CRM source events, allowlisted egress, SEO seam).
- **Metadata-first today** — Cedros can inventory/review the declaration, but
  it does not execute by itself. Examples: Scheduling/Shop setup seeds (until
  their write contracts publish), native screen/stack/provider ids, declared
  routes/jobs with no wasm component shipped.
- **Host-coordinated executable work** — Cedros needs a native loader, sidecar
  deploy/proxy, managed-provider grant, bespoke migration runner, or another
  non-wasm host process. Document an explicit handoff row
  ([`21-host-coordination-and-native.md`](21-host-coordination-and-native.md));
  never fake host behavior.

Two more vocabulary items you will meet constantly:

- **Published** means this guide or the Cedros SDK names a concrete contract.
  Anything else is a handoff item — do not invent manifest fields, SDK
  helpers, host services, or runtime behavior.
- **Install gate vs launch gate**: the install gate means the package can be
  uploaded, reviewed, installed, enabled, disabled, and removed. The launch
  gate means the live behavior actually runs in the target environment.
  Passing the install gate never implies passing the launch gate.

## Core authoring principles

These hold everywhere; surface docs add detail but never override them:

- **Metadata is not execution.** Admin execution requires compiled browser ESM
  in the ZIP; server execution requires the wasm component; native execution
  requires a published loader or host binding.
- **The ZIP is the deliverable.** No secrets, dependency caches, or
  machine-local paths inside it.
- **IDs are compatibility contracts.** `extensionId` is stable lowercase
  kebab-case; contribution ids are `${extensionId}:${local-id}`. Never rename
  or reuse a released id without migration and rollback notes.
- **Fail closed.** Missing services, providers, permissions, official
  contracts, database bindings, routes, jobs, or native loaders produce
  visible owner states, never silent successes.
- **No secrets anywhere they don't belong.** Secrets, tokens, auth headers,
  raw credentials, raw PII, and private keys do not belong in manifests,
  bootstrap files, archives, logs, analytics, site-brain records, job
  metadata, authored documents, or starter content.
- **Data through the seams.** Extension data uses `databaseAccess[]` plus the
  wasm database import; extensions never receive raw Postgres credentials.
  Site providers are host-owned and attributed through `providerAccess[]`;
  extensions do not ship their own provider keys.
- **Trust is computed, not declared.** `supplyChain` is author-supplied
  evidence; Cedros marketplace or the operator verifier computes verification
  outside the manifest.
- **Lifecycle behavior is explicit before release.** Disable, remove, upgrade,
  rollback, and host handoff behavior must be documented.

## ID rules

`extensionId`:

- lowercase kebab-case, globally stable
- no whitespace, no slash, no `:` (validated — the host reserves `:` as the
  namespace separator and prepends `{extensionId}:` for you)
- no version number; never reused for a different extension family

Contribution ids:

- format: `${extensionId}:${localId}`, lowercase kebab-case local id
- stable after release; never reused for a different semantic meaning
- never removed after release without deprecation, migration, and rollback
  notes

Example id set:

```json
{
  "extensionId": "cedros-demo-leads",
  "adminModuleId": "cedros-demo-leads:admin",
  "sectionId": "cedros-demo-leads:settings",
  "dashboardCardId": "cedros-demo-leads:health-card",
  "blockType": "cedros-demo-leads:lead-form-cta",
  "templateId": "cedros-demo-leads:landing-page",
  "pageSeedId": "cedros-demo-leads:landing",
  "formTemplateId": "cedros-demo-leads:contact-form",
  "docsArticleId": "cedros-demo-leads:getting-started",
  "eventId": "cedros-demo-leads:form-submitted",
  "skillId": "cedros-demo-leads:summarize-leads",
  "providerAccessId": "cedros-demo-leads:intelligence-summary",
  "databaseAccessId": "cedros-demo-leads:lead-db",
  "customerTagAccessId": "cedros-demo-leads:customer-tags",
  "customerTagSlug": "cedros-demo-leads:high-intent",
  "jobId": "cedros-demo-leads:nightly-sync",
  "routeId": "cedros-demo-leads:webhook-ingest"
}
```

## Surface behavior matrix

The complete author-facing seam inventory. Field-level shape is owned by
[`04-manifest-reference.md`](04-manifest-reference.md); implementation
guidance is owned by the linked surface docs.

| Surface | Manifest path | Runtime package | Self-serve? | Host coordination? |
|---|---|---|---:|---:|
| Package family and registration | `packageFamily`, `registration` | server/react/reactNative package members in ZIP; wasm server component when server surfaces execute | metadata validation yes | ZIP-contained admin runtime required when admin modules exist |
| Compatibility and dependencies | `compatibility`, `dependencies` | host install gate (`dependencies.services[]` / `dependencies.capabilities[]`) | yes | no |
| Admin install convenience | `requiredServices`, `requiredCapabilities` | `requiredServices` is admin UI gating only (opaque to the server); `requiredCapabilities[]` is also read by extension-service route validation, which requires a consumed capability to be listed there | metadata | no |
| Supply-chain evidence | `supplyChain` | package/release artifacts | metadata validation yes | marketplace verification computes status |
| Published extension capability | `capabilities[]` | operator-reviewed contract | metadata-first | yes if execution or provider binding is required |
| Admin page | `adminModules[]` (`sectionIds`, `sectionIcons`, persisted `navigation` projection), `surfaces.admin.moduleIds[]` | React admin | yes | no |
| Admin shell/section wrapper | `adminModules[].slots[]`, `surfaces.admin.slotIds[]` | React admin | yes | no |
| Content editor panel | `adminModules[].contributions.contentEditorPanels[]`, `surfaces.admin.editorSurfaceIds[]` | React admin | yes | no |
| Dashboard card | `adminModules[].contributions.dashboardCards[]` | React admin | yes | no |
| Page seed | `pageSeeds[]`, `surfaces.web.routeIds[]` | React web template if custom | yes, for Cedros page-row provisioning | no |
| Public-route SEO | `seoRoutes[]` (+ wasm `seo` export for dynamic patterns) | wasm component | yes | no |
| Content block | `contentBlocks[]`, `surfaces.web.blockTypes[]` | React web/admin; React Native via `contentBlockRenderers` | yes, with executable runtime definition and live-action/visual-parity checks | no |
| Content template | `contentTemplates[]`, `surfaces.web.templateIds[]` | React web/admin | yes, with runtime definition | no |
| Authored surface | `authoredSurfaces[]`, `surfaces.web.authoredSurfaceIds[]` | React web/admin | yes, with runtime definitions | no |
| Authored template utility | `authoredTemplateUtilities[]`, `surfaces.web.templateUtilityIds[]` | React web/admin | yes, with runtime definitions | no |
| Onboarding step | `onboardingPages[]` | Admin target page | yes | no |
| Form starter | `formTemplates[]` | none required | yes | no |
| Extension docs draft | `docsArticles[]` | none required | yes | no |
| Policy starter | `policies[]` | none required | yes | no |
| Analytics event | `analytics.events[]`, `surfaces.server.events[]` for server emission | wasm telemetry or browser helper | yes | no |
| Scheduling setup seed | `setupSeeds.scheduling[]` | Scheduling host contract | metadata-first | yes until Scheduling provisioning is published |
| Product setup seed | `setupSeeds.products[]`, `setupSeeds.productCollections[]` | Cedros Shop host contract | metadata-first | yes until Shop provisioning is published |
| Notification setup seed | `setupSeeds.notifications[]` plus matching `surfaces.server.events[]` | `cedros-notifications:route-write` | yes | no for route/preference UI; durable runtime publication uses the [notification event contract](contracts/notification-event-publication-v1.md) on Data `0.1.75+` |
| Contract template setup seed | `setupSeeds.contractTemplates[]` | none (ids `cedros-contracts:template-write` / `cedros-contracts:document-ingest` are reserved, unbound) | no: validated metadata, nothing is created | yes: create templates in the Contracts admin |
| Email template setup seed | `setupSeeds.emailTemplates[]` | none (`cedros-email:template-write` is reserved, unbound) | no: validated metadata, nothing is created | yes: create templates in the Email admin |
| Site-brain record | runtime emission + capability scope | wasm telemetry | yes for wasm routes/jobs | handoff for non-wasm/browser/admin emission |
| AI skill | `surfaces.ai.skills[]` | server metadata | yes | no |
| AI capability | `surfaces.ai.capabilities[]` | wasm route endpoint or published host endpoint | yes when endpoint is implemented by the package | yes if no endpoint/component exists |
| Provider access | `providerAccess[]` | wasm `providers` import | yes for storage/intelligence/image/voice/email/blockchain; domains managed-only | no for supported wasm providers |
| Database access declaration | `databaseAccess[]` | wasm `database` import | self-serve metadata and runtime grant | no |
| Content-model provisioning | `surfaces.server.contentModels[]` | install gate; wasm `database.migrate` registers JSONB only (`mode` `""` or `"jsonb"`; `"typed"` is rejected, and so is migrate on a host-provisioned typed model) | yes for automatic JSONB registration | yes for typed provisioning and bespoke SQL/schema |
| Migration identity | `surfaces.server.migrations[]` | ownership/review metadata; no migration-id argument exists in the public Wasm import | no executable migration by declaration alone | yes for migration-id-keyed or bespoke schema work |
| Runtime database operation | route/job references access id | wasm `database.read/count/write/delete/batch/compare-and-set/migrate` | yes inside wasm route/job | no |
| Customer tag operation | `customerTagAccess[]` + route/job call | wasm `customer-tags` import | yes inside wasm route/job | no |
| CRM source event | `crmSourceAccess[]` + route/job call | wasm `crm-source-events` import | yes inside wasm route/job | no |
| Extension dependency | `dependencies.extensions[]` | public extension contract | yes, if provider contract exists | no |
| Automation job ID | `surfaces.server.jobs[]` | wasm job export | yes when package includes `cedros-extension.server.wasm` | no |
| Automation job schedule | `jobSchedules[]` | host automation runtime | yes; `autoCreateOnEnable: true` writes the cron schedule into site automation settings on enable | no |
| Server route ID | `surfaces.server.routes[]` | wasm route export | yes when package includes `cedros-extension.server.wasm` | no |
| Server event ID | `surfaces.server.events[]` | wasm telemetry/event grant | yes | no |
| Settings schema | `surfaces.server.settingsSchemas[]` | wasm `settings` import (key/value only; no value validation) | yes | no |
| Outbound HTTP | operator env allowlist (not manifest) | wasm `http.fetch` | yes once the operator allowlists hosts | no |
| Native screen/stack/provider | `surfaces.native.*Ids[]` | React Native | self-serve in hosted App Builder; metadata-first elsewhere | yes for a target host without an equivalent published loader |
| Native block renderer | `contentBlockRenderers[]` in RN bootstrap | React Native | yes | no |

`pageSeeds[]`, `policies[]`, and `jobSchedules[]` use opt-in provisioning:
with `autoCreateOnEnable: true` the host materializes the entry on enable;
omitted entries stay owner-triggered starters where supported. Page seeds and
job schedules are provisioned by the server inside the enable request; docs,
forms, and policies are materialized by the admin shell after enable. Every
`docsArticles[]` entry and every `formTemplates[]` entry materializes as an
owner-editable draft when its extension is enabled (`autoCreateOnEnable` is
not consulted for forms). Notification seeds need no flag: active extensions'
seeds surface as configurable types in Settings → Notifications unless the
seed's `lifecycle.installMode` is `referenceOnly`.

## Do not assume

- remote code loading, arbitrary executable uploads
- a finished marketplace economy
- a second manifest format
- a private extension brain/audit feed or private per-extension scheduler
- arbitrary frontend router takeover or nested admin routing
- that `surfaces.server.routes/jobs` or `surfaces.web.routeIds` create
  executable handlers by themselves — server routes/jobs need matching wasm
  exports; web route ids need a page seed or a wasm-served route
- that unpublished official extension contracts, host services, SDK helpers,
  data model formats, or migration runners are live behavior
- that a deployed host has every loader behavior these docs describe — design
  bundles to work without newer host conveniences and verify against the
  packaged artifact ([`22-packaging-and-upload.md`](22-packaging-and-upload.md))

## First-party extensions as reference points

Cedros ships its own extensions through this same system. Reserved managed
extensions and operator-installed private extensions are maintained in separate
Cedros repositories; they are not built, tested, or packaged by cedros-data.
Sibling repos also ship cedros-login, cedros-pay, and cedros-shop. Their
published contracts are catalogued in
[`18-official-extension-integrations.md`](18-official-extension-integrations.md);
product-specific launch contracts live under [`contracts/`](contracts/README.md).

Next: [`02-quickstart.md`](02-quickstart.md).

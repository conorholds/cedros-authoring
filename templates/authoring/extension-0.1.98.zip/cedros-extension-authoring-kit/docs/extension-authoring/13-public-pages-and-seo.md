# 13 · Public Pages, Page Seeds, and SEO

Read this when an extension ships Cedros-managed public pages, serves public
routes from its backend, or renders anything a search engine can reach.

Two contracts live here:

1. **Page seeds** — how `pageSeeds[]` provision extension-owned Cedros pages.
2. **The public SEO contract** — what SEO intent you declare and what Cedros
   Core emits for you. This part is enforced executably by
   `ui/tests/extension-public-seo-contract.test.ts` and the Rust intake tests
   in `server/src/extension_platform_tests.rs`; vendor the TS test into your
   own CI to self-validate.

## Choose the right owner

The extension owns reusable capabilities and their data contracts. The site owns
its marketing pages, positioning, layout, navigation, and SEO. A commerce extension
should expose catalog prices, entitlements, and checkout APIs so any website can
build a pricing page without modifying or rebuilding the extension.

Do not claim customer routes such as `/pricing` or `/programs` through automatic
page seeds or a full-page renderer containing the extension vendor's marketing
copy. Optional blocks and templates may help an owner compose a page; they must
not require adopting the vendor's plans, brand, or route structure.

Use page seeds only for pages whose function is actually owned by the extension.
For a migration away from extension-owned marketing pages, preserve content IDs,
URLs, SEO, navigation, and any pending drafts. Publish the equivalent site-owned
authored content and transfer its ownership metadata before retiring the old
renderer. Remove the extension's route/seed claims, rebuild and reinstall it,
and verify that the site's published pages survive unchanged.

## Page seeds

- `pageSeeds[]` provision normal Cedros runtime `page` entries. Seeded pages
  appear in Pages as extension-owned entries; the page overview does not offer
  normal site-owner editing while that ownership is present.
- A page seed is not a live public route until a Cedros page row exists for
  it. Set `autoCreateOnEnable: true` to create that row on enable, and set
  `publishOnEnable: true` only when the page should publish immediately. Both
  default to `false`.
- `templateId` selects a registered template; omitted means core
  `page-default`. An extension template needs a matching `contentTemplates[]`
  entry plus the runtime template definition
  ([`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md)).
- Page seeds do not provision docs, posts, forms, or arbitrary route handlers,
  and they retain extension ownership metadata. If the extension
  needs a public route that executes extension code without creating a
  Cedros page, serve it from the wasm backend
  ([`07-wasm-server-backends.md`](07-wasm-server-backends.md)) and declare its
  SEO in `seoRoutes[]` (below).
- Route conflicts are surfaced to owners. Cedros does not overwrite or
  silently rename existing routes. Route paths normalize before comparison —
  trailing slashes and duplicate separators do not create separate routes.
- Every `surfaces.web.routeIds[]` value must be covered by a modeled
  publication seam: the same `pageSeeds[].id` for a seeded Cedros page, or
  the same `seoRoutes[].routeId` for a runtime-owned public route. Intake fails
  closed when a web route is declared without either SEO contract.

Field guidance (full reference: [`04-manifest-reference.md`](04-manifest-reference.md)):

- stable `id`, `displayName`, `title`, absolute `routePath`
- optional `description`, `slug`, `templateId`, `seo`, `chromeMode`
- `autoCreateOnEnable`, `publishOnEnable`

Use `publishOnEnable: false` when owner review is required. Use
`autoCreateOnEnable: true` only for pages that are safe and useful immediately
after install.

Starter body/content belongs in authored document fixtures or ZIP-contained
runtime metadata, not executable manifest fields. The manifest owns seed
metadata and the template id.

### Form templates

Provisioned standalone form pages fail closed to `noindex` and sitemap
exclusion. Set `formTemplates[].seoIndexable: true` only when the form is a
useful search landing page and provide a non-empty `description`. Core then
owns its canonical, WebPage JSON-LD, social metadata, robots directive, and
sitemap record for the site default locale. Other locale-prefixed variants stay
noindex until the form content model supports explicit translated title and
description availability. Embedding the same form in another page is
unaffected.

### Chrome modes

`chromeMode` on `pageSeeds[]` and `seoRoutes[]` controls the public shell:

- `default` — the normal host chrome (theme, primary nav, footer).
- `headless` — suppresses the host SiteLayout chrome; the extension owns the
  route chrome.
- `minimal` — keeps the host theme/root wrapper without the full primary
  nav/footer.

### Page-seed rules

- Keep page seed ids stable forever; never reuse an id for a different
  semantic page.
- Use absolute route paths beginning with `/`.
- If using an extension template, ship matching runtime content template
  definitions through the JS bootstrap.
- Disable/remove preserves owner-edited seeded pages unless an owner
  explicitly deletes them.
- On upgrade, existing owner-edited seeded pages must not be overwritten. New
  seed defaults apply only to newly created pages unless a host-approved
  migration exists.

## The public SEO contract

**Core principle: Cedros Core is the single source of truth for SEO output.**
Your extension **declares** SEO intent through modeled manifest fields; Core
**emits** every head tag, canonical link, `hreflang`, JSON-LD `@graph`, and
sitemap entry. An extension that hand-rolls any of those competes with Core
and will be rejected at intake.

### What you declare (and Core emits)

| You declare | Where | Core emits |
| --- | --- | --- |
| Per-page indexability | `pageSeeds[].seo.noindex` / `docsArticles[].seo.noindex` / `policies[].seo.noindex` (bool) | `<meta name="robots" content="noindex, nofollow">` **and** sitemap exclusion |
| Per-page title/description/OG | `…seo.{title,description,ogTitle,ogDescription,ogImage}` | composed `<title>`, meta description, OG/Twitter tags |
| Per-page canonical | `…seo.canonicalPath` (same-origin absolute path, one string) | `<link rel="canonical">` + matching JSON-LD `@id` |
| Public-route SEO for routes NOT backed by a seeded page | `seoRoutes[]` (below) | robots/canonical/schema-type + static sitemap entry |
| Structured data for a page | typed `seo.schema` (below) | a validated schema.org node in the shared `@graph` |
| Runtime breadcrumb trail | dynamic `describe-route` response `breadcrumbs[]` | localized visible breadcrumb navigation + `BreadcrumbList` JSON-LD |

### What you must NOT emit

These are **reserved** and rejected as top-level manifest keys
(`extension_platform_validation_seo.rs::RESERVED_SEO_EXTRA_KEYS`):
`sitemapUrls`, `hreflang`, `breadcrumbs`, `schema`, `jsonLd`.

Never emit raw `<title>`, `<link rel="canonical">`, `hreflang` alternates,
`<script type="application/ld+json">`, or your own `/sitemap.xml` entries from
extension HTML. Core owns all of them. Canonicals **must be same-origin
absolute paths** (`/foo`, not `https://other.example/foo`).

### Auth, cart, and checkout routes MUST be noindex (`SEO-NOINDEX-001`)

Set `seo.noindex: true` on every authentication and transactional page. Effect:
the page renders `noindex, nofollow` **and** is excluded from the sitemap
(`runtime_content_visibility.rs::sitemap_should_include_detail`).

In-repo seed authority (the only auth/shop seed IDs that exist in cedros-data;
the rest live in the sibling repos):

- **cedros-login** — `/login` and `/register` (`http_public.rs`). `/verify`
  and `/profile` are sibling-owned; the contract still applies — they are
  private-but-renderable and **must be `noindex`** (`/profile` is not
  access-gated by this flag; it is simply kept out of the index).
- **cedros-shop** — `/shop` is the indexable storefront index. `/cart` and
  `/checkout` are sibling-owned transactional pages and **must be `noindex`**.

Core enforces this at intake. Routes whose first path segment is a private or
transactional namespace (`login`, `register`, `account`, `profile`, `admin`, `auth`,
`oauth`, `cart`, `checkout`, `search`, `preview`, and related password/utility
paths) must declare `seo.noindex: true`. An extension `seoRoute` in one of these
namespaces must also be non-indexable and sitemap-excluded (or `utility: true`).
ZIP intake strips `canonicalPath` from `noindex` docs articles, page seeds,
and policies before validation (`extension_platform_archive.rs`); a manifest
that reaches the validator with both set is rejected. The sitemap generator
defensively excludes noindex route defaults even for legacy manifests.

### seoRoutes[] — SEO for routes not backed by a seeded page

If your extension serves a public route that is **not** a seeded CMS page,
declare it in `seoRoutes[]` so Core can render correct SEO and include it in
the sitemap. Validated at intake by
`extension_platform_validation_seo.rs::validate_extension_seo_routes`.

```jsonc
"seoRoutes": [
  {
    "routeId": "shop.storefront",        // MUST match surfaces.web.routeIds or surfaces.server.routes
    "pathPattern": "/shop",              // same-origin absolute; ":param"/"*" allowed (dynamic)
    "indexable": true,                   // default true
    "includeInSitemap": true,            // default = indexable
    "canonicalStrategy": "self",         // "self" | "none" | a same-origin absolute path
    "schemaType": "CollectionPage",      // registered Core type only
    "schemaContractVersion": 2,          // pin Core's governed adapter registry
    "servedLocales": ["en", "es"],       // exact variants this route really serves
    "parameterPolicy": {                 // optional finite indexable query variants
      "allowedValues": { "view": ["grid", "map"] },
      "maxCombinations": 2
    },
    "videos": [{                         // optional validated video sitemap data
      "thumbnailLoc": "/media/demo.webp", "title": "Demo", "description": "Product demo",
      "contentLoc": "/media/demo.mp4", "duration": 90
    }],
    "utility": false,                    // utility=true forces non-indexable + sitemap-excluded
    "chromeMode": "headless"             // optional: default | headless | minimal
  }
]
```

Intake rejects: unknown `routeId`, cross-origin `pathPattern`, duplicate
pattern, a `utility` route that is also `indexable`/sitemap-included, an
unknown `schemaType`, an empty `servedLocales` entry, an unknown `chromeMode`,
and any unknown key (unmodeled keys fail closed).

Extension route ownership is exclusive. Core reserves its home, blog, docs,
links, watch, forms, calendar, newsletter, contract-signing, and support-chat
route spaces in `shared/seo-core-route-ownership.json`; Rust admission and
generated host conformance tests consume that versioned contract. Install and
enable also reject overlaps with existing CMS routes, active redirect sources,
or another extension, including localized equivalents. CMS and redirect creates
and updates run the inverse extension check. These admissions share a database
advisory lock, so concurrent workers cannot race two owners onto the same public
URL.

Omit `servedLocales` for a default-locale-only route. When present, the
non-empty list is exact: Core does not silently add the site default. A guest
may narrow a particular record to a subset of that list but cannot add a
locale. The same resolved set drives runtime indexability, HTML hreflang, and
sitemap alternates.

**Sitemap behaviour today:** Core's Rust sitemap provider
(`sitemap_runtime_extensions.rs::collect_extension_seo_route_sitemap_entries`) emits
**static** indexable `seoRoutes` into `/sitemap.xml` automatically, deduped
against CMS URLs. **Dynamic** patterns (`/shop/:slug`, `/*`) are handled by
the runtime seam below.

### Structured data via seo.schema

Declare a `Service`, `Event`, `Product`, `Course`, `SoftwareApplication`, or
`LocalBusiness` entity on a page with `seo.schema`; Core builds
the node and folds it into the shared `@graph`
(`ui/src/react/commerceSchema.ts`).

```jsonc
"seo": {
  "schema": {
    "kind": "Service",
    "serviceType": "Consulting",
    "offers": { "price": 99, "priceCurrency": "USD", "availability": "InStock" }
  }
}
```

- `offers` is validated at package intake and live resolution (price >= 0,
  uppercase ISO-4217 currency, optional HTTPS URL and supported availability).
  Malformed extension input is rejected rather than silently losing markup.
- `Product` requires a valid `offers` object. Core emits a stable `#product`
  entity and never invents price, availability, review, or rating data.
- An indexable static commerce route must include its complete `seo.schema`
  default in the manifest. Dynamic routes may resolve schema per URL through
  `describe-route`; this prevents static sitemap entries from disagreeing with
  runtime noindex fallbacks.
- **No fabricated ratings.** Any `aggregateRating` / `ratingValue` /
  `reviewCount` / `review` causes a **hard error** — ratings can only come
  from a verified review pipeline, never authored
  (`assertNoFabricatedRating`).
- `Event` requires a real ISO-8601 `startDate` plus a physical location
  (`name`/`address`) or HTTPS virtual `url`. Physical, online, and mixed
  attendance modes are composed automatically. Invalid declarations fail
  intake/live resolution; malformed legacy CMS data is safely omitted.
- `Course` requires a truthful description. `SoftwareApplication` requires an
  `applicationCategory`. `LocalBusiness` requires a real physical address.
  Each receives a canonical page-scoped ID and may use a validated Offer.
- Route intent also supports `Article`, `NewsArticle`, and
  `SearchResultsPage`. Search-results routes are forced non-indexable and
  sitemap-excluded. Raw/custom JSON-LD remains prohibited.

`CollectionPage` + `ItemList` auto-emit for `blogIndex`/`docsIndex` modes.
Generic collection routes declare `schemaType: "CollectionPage"`; extensions
still provide the visible listing and breadcrumbs while Core owns the page node
and shared graph. Raw custom JSON-LD remains prohibited.

### SEO precedence (EXT-SEO-PRECEDENCE-01)

Final precedence, highest wins:

```
operator-edited content seo  >  extension manifest seo  >  derived defaults  >  preset base
```

At **seed time**, `buildExtensionSeo(base, seo, defaults)` spreads
`{...base, ...defaults, ...seo}` — so your **manifest `seo` wins over derived
defaults** (`ui/src/admin/extensionSeoManifest.ts`). The seed then produces an
**editable draft**, and once an **operator edits** the page, their values
become the runtime content `seo`, fully replacing the seed.

> Do **not** assume manifest SEO is authoritative at runtime. An operator's
> edit overrides it. Manifest `seo` is a *default*, not a lock.

### Faceted / filtered storefront URLs

Unknown filter/sort/search parameters remain `noindex, follow`. An extension
may opt a small, genuinely distinct set into indexing with `parameterPolicy`.
`allowedValues` accepts at most eight lowercase URL-safe parameter names and
100 unreserved values per name. `maxCombinations` must cover the complete
optional combination space and cannot exceed 1,000. Core rejects tracking
parameters, duplicate values, `page=1`, unknown values, and non-canonical
query ordering in sitemaps. Runtime canonicals sort parameter names and sitemap
entries must use those exact canonical bytes. Do not emit your own canonical.
For a static route with `parameterPolicy`, `list-sitemap-urls` must enumerate
the clean path as well as every approved variant intended for discovery. Core
publishes all of them only after the corresponding `describe-route` documents
validate as one atomic snapshot.

## Runtime SEO seam — dynamic routes (extension-seo world)

For routes whose SEO **can't be statically declared** — per-product pages like
`/product/{slug}`, per-item canonicals, dynamically-enumerated sitemap URLs —
Core invokes your wasm guest at request/regen time through an **opt-in** WIT
seam. Build the server component against the `extension-seo` world instead of
`extension` ([`07-wasm-server-backends.md`](07-wasm-server-backends.md)):

```wit
world extension-seo {
  include extension;     // all your existing imports + routes/jobs exports
  export seo;            // the opt-in SEO export
}
interface seo {
  describe-route: func(request-json: string) -> option<string>;
  list-sitemap-urls: func(request-json: string) -> string;
}
```

This is **opt-in and non-breaking**: `extension`-only guests are untouched and
need no rebuild. Only guests that `export seo` participate; everything is JSON
in/out (strings), and Core owns all head/canonical/JSON-LD/sitemap emission —
your guest returns **declarative data only**, never raw tags. Declaring
**dynamic** `seoRoutes[]` without exporting `seo` fails install.

**`describe-route(request-json) -> option<string>`** — Core calls this when a
request path matches one of your `seoRoutes[].pathPattern` entries (`:param`
matches one segment, trailing `*` the rest). Core passes
`{ "path", "locale" }`; `path` includes any approved canonical query variant.
Your guest **self-sources** the content (it has its
`database` capability) and returns a route description, or `none` (Core then
serves 404). Return shape:

```json
{ "revision": "catalog-42", "title": "Canvas tote", "description": "A durable canvas tote.", "indexable": true,
  "breadcrumbs": [{ "label": "Home", "href": "/" },
    { "label": "Canvas tote", "href": "/product/x" }],
  "seo": { "schema": { "kind": "Product", "name": "...", "image": "...", "sku": "...",
    "brand": "...", "offers": { "price": "48.50", "priceCurrency": "USD",
    "availability": "InStock" } } } }
```

`offers` is required for Product and included only when `price >= 0` and `priceCurrency` is ISO-4217;
`availability` uses schema.org values (`InStock`, not `in_stock`);
rating/review fields are rejected (Core's `assertNoFabricatedRating`).
`schemaType`, canonical strategy, and allowed locales come from the matched,
validated `seoRoutes[]` manifest entry and cannot be overridden by the guest.
Breadcrumbs use unlocalized same-origin paths, contain 2–12 unique entries, and
must end at the resolved canonical path. Core localizes them and emits both the
visible links and structured data.

> Note for commerce extensions: Core passes only route context, **not** a
> `products[]` snapshot — Core has no per-slug catalog access, and your guest
> already holds the data via its DB capability. Self-source there.

**`list-sitemap-urls(request-json) -> string`** — Core calls this each sitemap
regeneration. Core passes `{ "origin" }`; return
`{ "urls": [{ "loc": "/product/x", "revision": "catalog-42", "lastmod": "2026-07-09T12:00:00Z",
"changefreq": "daily", "priority": 0.8, "servedLocales": ["es-MX"],
"images": ["/media/product-x.webp"], "videos": [{ "thumbnailLoc":
"/media/thumb.webp", "title": "Product demo", "description": "See the product",
"playerLoc": "https://video.example/embed/x" }] }] }`.
Core validates every `loc` is a clean same-origin absolute path that matches the
extension's **exact declared dynamic route pattern**, validates the optional
timestamp/frequency/priority, restricts locales to that matched route's declared
locale policy, dedupes against CMS URLs, and merges it. Payloads over 4 MiB and
entries beyond the 45,000-URL per-provider cap are rejected or truncated.
Each image must be a same-origin path or an HTTPS URL; Core caps the list at
Google's 1,000-image-per-page limit and emits only the current required
`image:image`/`image:loc` fields (deprecated image sitemap fields are omitted).
Each video is capped and validated against the required Google video fields;
Core emits the video namespace only when complete records exist and rejects
unsafe, oversized, unknown, or partial manifest declarations.

For every listed URL and locale, Core calls `describe-route`, requires both
sides to declare the same non-empty `revision`, composes the complete SEO
document, and proves it is indexable with the identical locale set. Only then
does Core atomically activate both the sitemap entry and the Core-composed HTML
document snapshot. A partial failure preserves the previous origin snapshot;
an unsnapshotted sitemap-enabled route renders useful HTML but stays noindex.
Provider outages return 503 with no-store/Retry-After rather than a false 404.

The public resolution endpoint is `GET /content/extension-seo` on the host.
Versioning: the seam is additive, so the package stays
`cedros:extension@0.1.0`; the host capability endpoint's `wit.checksum`
advances. Rebuild against the host WIT for the coordinated release.

## Redirects are site-owner-only

Extensions **cannot register HTTP redirects**. The redirect store (`redirects`
table, `RedirectsWrite`, `/redirects/resolve`) is intentionally
**site-owner-managed only**: rules are authored in the admin Redirects surface
(or the WordPress importer) and the deployed host honours them as real
301/302/307/308 with a `Location` header. There is no manifest `redirects[]`
field, and one will not be added speculatively.

Why owner-only, not an extension seam: a redirect's `sourcePath` is a *site*
URL. An unscoped extension redirect could shadow `/` or `/about` and silently
hijack owner content, so any extension seam must enforce **namespacing** — the
`sourcePath` confined to routes the extension demonstrably owns. That
ownership model has no shipping consumer today; until one appears, route-shape
migrations belong in the owner's Redirects admin.

## Troubleshooting seeded-page 404s

If a seeded route such as `/login` 404s after enable, first confirm the route
is declared in `pageSeeds[]` at all — a route that was never seeded cannot
provision. Then verify the authoring chain: the page seed id is present in
`surfaces.web.routeIds[]`, `routePath` is absolute, `templateId` resolves to a
core or extension `contentTemplates[]` entry, `autoCreateOnEnable` is `true`,
and `publishOnEnable` is `true` when public traffic should work immediately.

Timing: the server provisions opted-in page seeds inside the enable request
(`http_extension_runtime_state.rs`), again at boot, and on marketplace install;
a provisioning error fails the enable. When enable resolves, the page row
exists. Docs, forms, and policy starters are still materialized asynchronously
by the admin shell after enable
([`05-package-family-and-registration.md`](05-package-family-and-registration.md)),
so only those can lag behind the enable action.

Template-gap failure mode: auto-provision will not create any seed whose
`templateId` does not resolve through the runtime bootstrap or the manifest
`contentTemplates[]` fallback. Instead of provisioning, that seed surfaces a
visible error ("… can't be created automatically: its page template … isn't
available. Install or enable the extension that provides this template, then
retry.") and releases the provisioning gate. If one seeded page provisions and
another does not, check that the missing page's `templateId` resolves.

When that chain is complete and provisioning has settled, the issue is host
page-seed provisioning or publishing, not an extension route-handler bug. Page
seeds create editable Cedros page rows; they do not require or imply a wasm
route handler.

## Acceptance checks

- Every manifest web route id is backed by a matching page seed id or SEO route
  id; unmodeled public routes fail intake closed.
- Seeded routes normalize consistently and reject duplicates.
- The template id resolves to a core or extension runtime template.
- Owners can find and edit the resulting page.
- Route conflict states are visible and recoverable.
- Every auth/cart/checkout/account-style page declares `seo.noindex: true`.
- Public routes not backed by a seeded page are declared in `seoRoutes[]`;
  dynamic patterns pair with the wasm `seo` export.
- No extension code emits head tags, canonicals, JSON-LD, hreflang, or sitemap
  entries.

Self-check commands:

```bash
# TypeScript — the vendorable contract test
cd ui && npx vitest run extension-public-seo-contract

# Rust — intake validation of seoRoutes[] + noindex public seeds
cd server && cargo test --lib seo_route
cd server && cargo test --lib registry_accepts_noindex_public_extension_seeds

# Rust — runtime seam (describe-route / list-sitemap-urls), needs the wasm feature
cd server && cargo test --lib --features wasm-extensions seo_seam
```

Next: [`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md).

## Signed-in page access

`pageSeeds[].access: "signed-in"` is a host-enforced access gate. Anonymous
content reads return 401 with a host-computed Login URL, and the public host
redirects the browser to Login with `returnTo`. Protected pages remain noindex
and are omitted from public lists and sitemaps. API route policies can also
declare signed-in access. `seo.noindex` alone remains an indexing setting.
See [extension visitors](contracts/extension-visitor-v1.md).

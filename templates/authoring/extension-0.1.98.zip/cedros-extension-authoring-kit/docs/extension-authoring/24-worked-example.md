# 24 · Worked Example: a Minimal Complete Extension

Read this after the core docs (`01-extension-system-overview.md` through
`23-release-versioning-and-upgrades.md`) as a worked end-to-end shape. This is
not a second schema. It is a compact example showing how the outputs from those
docs fit together for one small extension.

Example extension: `acme-stats`

Goal: show a safe admin dashboard card with aggregate stats, publish one admin
page, declare one Wasm-backed summary route, declare one Wasm-backed nightly job,
use site intelligence through host providers, declare extension-owned aggregate
data access, and package the family for local intake plus Wasm runtime
verification.

## Final Context Snapshot

```json
{
  "extensionId": "acme-stats",
  "displayName": "Acme Stats",
  "version": "1.0.0",
  "adminSurfaces": ["acme-stats:admin"],
  "dashboardCards": ["acme-stats:summary-card"],
  "providerAccess": ["acme-stats:intelligence-summary"],
  "databaseAccess": ["acme-stats:stats-db"],
  "serverRoutes": ["acme-stats:summary-route"],
  "automationJobs": ["acme-stats:nightly-rollup"],
  "hostCoordinatedItems": [],
  "liveOnInstallBehavior": [
    "admin module metadata",
    "dashboard card runtime contribution"
  ],
  "metadataOnlyBehavior": [
    "route, job, and database execution are self-serve through the Wasm runtime; they go live with the installed Wasm component, pending only smoke verification"
  ],
  "knownRisks": [
    "summary data remains unavailable until the Wasm route/job/database smoke checks pass"
  ],
  "openQuestions": []
}
```

## Canonical Manifest

`cedros-extension.manifest.json`:

```json
{
  "schemaVersion": 1,
  "extensionId": "acme-stats",
  "displayName": "Acme Stats",
  "version": "1.0.0",
  "description": "Shows safe aggregate stats for site operators.",
  "platformApiVersion": "1",
  "compatibility": {
    "platformApiVersion": "1"
  },
  "packageFamily": {
    "server": {
      "packageName": "acme-stats-server",
      "version": "1.0.0",
      "required": true
    },
    "react": {
      "packageName": "@acme/acme-stats-react",
      "version": "1.0.0",
      "required": true
    },
    "reactNative": {
      "packageName": "@acme/acme-stats-react-native",
      "version": "1.0.0",
      "required": true
    }
  },
  "surfaces": {
    "server": {
      "packageRef": "server",
      "required": true,
      "routes": ["acme-stats:summary-route"],
      "jobs": ["acme-stats:nightly-rollup"],
      "contentModels": ["acme-stats:daily-summary"],
      "migrations": ["acme-stats:daily-summary-v1"]
    },
    "admin": {
      "packageRef": "react",
      "required": true,
      "moduleIds": ["acme-stats:admin"]
    },
    "web": {
      "packageRef": "react",
      "required": true
    },
    "native": {
      "packageRef": "reactNative",
      "required": true
    }
  },
  "registration": {
    "server": {
      "entrypoint": "acme_stats_server::register_extension_family"
    },
    "admin": {
      "entrypoint": "@acme/acme-stats-react/admin/register"
    },
    "web": {
      "entrypoint": "@acme/acme-stats-react/web/register"
    },
    "native": {
      "entrypoint": "@acme/acme-stats-react-native/register"
    }
  },
  "adminModules": [
    {
      "moduleId": "acme-stats:admin",
      "extensionId": "acme-stats",
      "displayName": "Acme Stats",
      "version": "1.0.0",
      "packageName": "@acme/acme-stats-react",
      "sectionIds": ["acme-stats:overview"],
      "sectionIcons": { "acme-stats:overview": "analytics" },
      "navigation": {
        "sections": [
          {
            "id": "acme-stats:overview",
            "label": "Stats",
            "group": "Extension Settings",
            "order": 10
          }
        ]
      },
      "contributions": {
        "dashboardCards": [
          {
            "id": "acme-stats:summary-card",
            "displayName": "Stats Summary",
            "description": "Shows aggregate stat health.",
            "order": 20
          }
        ]
      }
    }
  ],
  "analytics": {
    "events": [
      {
        "id": "acme-stats:summary-opened",
        "displayName": "Stats Summary Opened",
        "description": "An operator opened the stats summary page.",
        "category": "admin",
        "visibility": "admin"
      }
    ]
  },
  "providerAccess": [
    {
      "id": "acme-stats:intelligence-summary",
      "provider": "intelligence",
      "displayName": "Stats Summary Intelligence",
      "description": "Summarizes aggregate stat health through the site's configured intelligence provider.",
      "scopes": ["chat.generate"],
      "tags": ["stats", "summary"]
    }
  ],
  "databaseAccess": [
    {
      "id": "acme-stats:stats-db",
      "displayName": "Stats Database",
      "description": "Reads and writes extension-owned aggregate stat records.",
      "contentModels": ["acme-stats:daily-summary"],
      "migrations": ["acme-stats:daily-summary-v1"],
      "scopes": [
        {
          "verb": "read",
          "resource": "aggregate stat rows",
          "summary": "Reads aggregate stats for dashboard summaries."
        },
        {
          "verb": "write",
          "resource": "aggregate stat rows",
          "summary": "Writes nightly rollup summaries."
        }
      ],
      "tags": ["stats", "aggregate"]
    }
  ]
}
```

`cedros-extension.bootstrap.json`:

```json
{
  "manifest": {
    "...": "deep-equals cedros-extension.manifest.json exactly"
  }
}
```

Generate bootstrap from the same manifest object. Do not hand-write a shortened
manifest in bootstrap.

## Package Family

Rust server package:

```toml
[package]
name = "acme-stats-server"
version = "1.0.0"
edition = "2021"

[lib]
name = "acme_stats_server"

[dependencies]
serde_json = "1"
```

```rust
const MANIFEST_JSON: &str = include_str!("../../../cedros-extension.manifest.json");

pub fn register_extension_family() -> serde_json::Value {
    serde_json::from_str(MANIFEST_JSON).expect("extension manifest should stay valid")
}
```

React package exports:

```json
{
  "name": "@acme/acme-stats-react",
  "version": "1.0.0",
  "type": "module",
  "exports": {
    "./admin/register": "./dist/admin/register.js",
    "./web/register": "./dist/web/register.js"
  }
}
```

Admin registration:

```ts
import { extensionBootstrap } from "../bootstrap";
import { AcmeStatsOverview, AcmeStatsSummaryCard } from "./surfaces";

const adminModule = {
  id: "acme-stats:admin",
  name: "Acme Stats",
  version: "1.0.0",
  manifest: {
    moduleId: "acme-stats:admin",
    extensionId: "acme-stats",
    displayName: "Acme Stats",
    version: "1.0.0",
    packageName: "@acme/acme-stats-react",
    contributions: {
      dashboardCards: [
        {
          id: "acme-stats:summary-card",
          displayName: "Stats Summary",
          description: "Shows aggregate stat health.",
          order: 20
        }
      ]
    }
  },
  sections: [
    {
      id: "acme-stats:overview",
      label: "Overview",
      icon: null,
      group: "Tools",
      order: 0
    }
  ],
  components: {
    "acme-stats:overview": AcmeStatsOverview
  },
  contributions: {
    dashboardCards: [
      {
        id: "acme-stats:summary-card",
        Component: AcmeStatsSummaryCard,
        order: 20
      }
    ]
  },
  createPluginContext: (hostContext) => ({
    hasPermission: (permission) =>
      hostContext.dashboardPermissions?.canAccess(permission) ?? false
  }),
  cssNamespace: "acme-stats"
};

export function registerCedrosAdminSurface() {
  return {
    ...extensionBootstrap,
    modules: [adminModule]
  };
}
```

Runtime contract notes:

- `manifest.moduleId` and `manifest.extensionId` must match the manifest's
  `adminModules[]` entry exactly; the host **silently drops** modules where
  they do not match.
- The host calls `createPluginContext(hostContext)` unconditionally — provide
  it; do not assume the host tolerates its absence.
- The register entry must return `{ ...bootstrap, modules: [adminModule] }`,
  not the module alone.
- Every `sections[]` entry needs an `icon` field (use `null` when no icon).

Dashboard card data access pattern:

```ts
import { HOST_SERVICE_IDS, getHostService } from "cedros:admin";

export function AcmeStatsSummaryCard({ hostContext, extensionId }) {
  const inventory = getHostService(hostContext, HOST_SERVICE_IDS.extensionInventory);
  if (!inventory) return <div>Stats unavailable</div>;
  return <div data-extension-id={extensionId}>Stats summary pending host data.</div>;
}
```

React Native package exports a minimal bootstrap unless native screens are
approved:

```json
{
  "name": "@acme/acme-stats-react-native",
  "version": "1.0.0",
  "type": "module",
  "exports": {
    "./register": "./dist/register.js"
  }
}
```

```ts
import { extensionBootstrap } from "./bootstrap";

export function registerCedrosNativeSurface() {
  return extensionBootstrap;
}
```

## Wasm Server Readiness

| Item | Manifest ID | Type | Runtime artifact | Required export/import | Status | Owner | Blocking? | Launch gate |
|---|---|---|---|---|---|---|---|---|
| Summary route | `acme-stats:summary-route` | server route | `cedros-extension.server.wasm` | route export for declared path `/summary` | ready | extension author | yes | production |
| Nightly rollup | `acme-stats:nightly-rollup` | server job | `cedros-extension.server.wasm` | job export `acme-stats:nightly-rollup` | ready | extension author | yes | production |
| Daily summary model | `acme-stats:daily-summary` | content model | `cedros-extension.server.wasm` | auto-provisioned at install; `database.read/write` | ready | extension author | yes | production |
| Daily summary migration | `acme-stats:daily-summary-v1` | migration metadata | host handoff | reviewed migration-id-keyed schema plan; the Wasm import cannot consume this id | host-coordinated | Cedros backend + extension author | yes | production |

Declared `surfaces.server.contentModels[]` are auto-provisioned at install —
no `database.migrate` call is needed for ordinary collections. `database.migrate`
can re-register the declared content-model id and mode; it does not execute
`surfaces.server.migrations[]` ids.

Route path example:

```json
{
  "method": "POST",
  "path": "/summary",
  "idempotencyKey": "header:x-idempotency-key",
  "auth": "admin bearer token",
  "databaseAccessId": "acme-stats:stats-db"
}
```

Guests declare route paths relative to their namespace; the host mounts them at
`/extensions/{id}` (here `/extensions/acme-stats/summary`), and `handle-route`
receives the full mounted path.

## Analytics, Site-Brain, And Logs

Analytics is declared in the manifest under `analytics.events[]`. This example's
only event, `acme-stats:summary-opened`, is an admin page-open event. Public-page
runtime reporting uses the host-injected
`window.cedrosAnalytics.trackExtensionEvent` API — see
`16-analytics-and-site-brain.md`. The Wasm `telemetry.emit-event` import is
the alternative for server-side routes/jobs, and is only granted when the
manifest also declares the event id under `surfaces.server.events[]` (which
this example does not).

Durable site-brain plan:

```json
{
  "category": "stats",
  "subject": "acme-stats:nightly-rollup",
  "title": "Stats rollup completed",
  "summary": "Updated aggregate stats for the dashboard.",
  "tags": ["acme-stats", "rollup"],
  "details": {
    "rowCount": 12,
    "runId": "redacted-run-ref"
  }
}
```

Transient log shape:

```json
{
  "level": "info",
  "message": "Stats rollup completed.",
  "extensionId": "acme-stats",
  "operation": "nightly-rollup",
  "runId": "redacted-run-ref"
}
```

## Validation And Packaging

Required local checks:

```sh
node --version   # v24.17.0
npm --version    # 11.13.0
npm --prefix packages/react run build
npm --prefix packages/react-native run build
npm run validate
cargo test --manifest-path packages/server/Cargo.toml
cargo build --manifest-path packages/server/Cargo.toml --release --target wasm32-wasip2
npm run package:extension
```

Validation script checks:

- manifest and bootstrap manifest deep-equality
- package names and versions match `packageFamily`
- registration entrypoints match package exports
- runtime ids match manifest ids
- declared admin modules have compiled React admin runtime included in the ZIP
- `cedros-extension.server.wasm` is present when server surfaces are declared
- archive entries are safe and deterministic
- final ZIP SHA-256 is printed in the release packet, not embedded in the
  manifest inside that ZIP

## Release Packet Summary

| Surface | Manifest IDs | Runtime package present? | Host hook bound? | Status | Smoke test | Owner |
|---|---|---:|---:|---|---|---|
| Admin page | `acme-stats:admin`, `acme-stats:overview` | yes | n/a | ready | import admin register | extension author |
| Dashboard card | `acme-stats:summary-card` | yes | n/a | ready with unavailable state | render missing service state | extension author |
| Summary route | `acme-stats:summary-route` | yes | n/a | ready | Wasm route smoke | extension author |
| Nightly job | `acme-stats:nightly-rollup` | yes | n/a | ready | Wasm job smoke | extension author |
| Database model/migration | `acme-stats:daily-summary`, `acme-stats:daily-summary-v1` | yes | n/a | ready | Wasm database smoke | extension author |

Install gate can pass when manifest/bootstrap/archive validation passes and
admin/dashboard unavailable states render safely. Launch gate stays blocked only
if the Wasm route/job/database smoke checks fail or a non-Wasm/native handoff row
remains open.

## Common Failure Checks

- `surfaces.server.routes[]` contains `acme-stats:summary-route`, and the
  handoff table also has a row for it.
- `databaseAccess[].contentModels[]` references only
  `surfaces.server.contentModels[]`.
- `registration.admin.entrypoint` is
  `@acme/acme-stats-react/admin/register`, not `/admin/register`.
- The dashboard card id matches in `adminModules[]` and runtime
  `AdminModule.contributions.dashboardCards[]`.
- React Native still builds even when it is only a minimal bootstrap.
- No analytics, site-brain, settings, secret, or content-model helper is
  imported unless it is published by the target SDK.
- If the extension labels CRM customers, every business condition that
  triggers an `assign` call maps to a slug in
  `customerTagAccess[].managedTagSlugs[]` — otherwise the validated
  client rejects the call at runtime. See `20-crm-tags-and-source-events.md`.

Next: [`25-troubleshooting-and-faq.md`](25-troubleshooting-and-faq.md).

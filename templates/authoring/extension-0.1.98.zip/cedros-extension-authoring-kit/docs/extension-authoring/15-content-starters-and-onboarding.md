# 15 · Content Starters and Onboarding

Read this when an extension ships starter forms, docs articles, or policy
pages, or needs first-run setup steps surfaced by Cedros onboarding.

## Starters: forms, docs, policies

`formTemplates`, `docsArticles`, and `policies` live on the manifest
([field reference](04-manifest-reference.md)). Policies choose one of two
behaviors via `autoCreateOnEnable`:

- **Auto-provision (`autoCreateOnEnable: true`)** — on enable the host
  materializes the entry as a real owner-editable runtime policy page, so the
  extension "just works" without an owner action. Policies publish when
  `publishOnEnable: true`. Provisioning is idempotent (once per seed) and the
  entry does not also appear as a starter card.
- **Starter (default / `autoCreateOnEnable` omitted)** — the entry appears as
  an owner-editable "Use Template" / "Start Draft" card and is not saved until
  the owner acts.

Forms do not have the starter mode: every active extension's `formTemplates`
entries are materialized once as owner-editable Forms records (live/draft per
`status`) regardless of `autoCreateOnEnable`
(`ui/src/admin/extensionContentSeedProvisioning.ts`). The flag is accepted for
schema compatibility only.

Docs articles always materialize once as owner-editable runtime Docs records
when their extension is enabled. They appear in the normal Docs table as
drafts, never as separate starter cards. `autoCreateOnEnable` and
`publishOnEnable` remain accepted only for manifest compatibility and do not
change this docs behavior.

These are metadata-backed seams, not executable code loaders. Only active
extensions contribute forms/docs/policies to owner workflows.

### Docs articles are for the public reader

Docs articles are public-facing help content for **end users** of the
extension's public pages or flows: how a visitor, customer, member, buyer,
signer, or other public actor uses what the extension ships.

Docs articles are **not** instructions for the site admin/operator on how to
install, configure, troubleshoot, or run the extension. Put those instructions
in onboarding pages, admin modules, setup copy, release notes, or handoff
docs. An operator-only article can set `internal: true`, which keeps it out of
public docs nav and forces `noindex` — but prefer the admin surfaces for
operator guidance.

`policies` is validated structurally only at UI local-package intake; the
server keeps the field in `extra` and validates or normalizes only each
entry's `seo` block (`extension_platform_validation_seo.rs`), so do not rely on
the server to reject other malformed policy fields.

### Validation rules

- Form and docs ids must be stable and namespaced; form template ids unique.
- Form templates require display name, title, and at least one valid field.
- Field keys must be stable lowercase keys and unique inside a template.
- Supported field types are `text`, `email`, `textarea`, `tel`, `select`, and
  `checkbox`. Select fields require at least one option, with label and value.
- Checkbox fields used for consent must include explicit label/help text that
  explains what the owner is asking visitors to consent to.
- Docs article ids must be unique; docs articles require display name, title,
  slug, and body markdown.
- Docs article title, excerpt, body, route, navigation, and SEO metadata must
  be written for the public reader, not the admin configuring the extension.
- Supported docs and policy markdown is conservative CommonMark-style headings,
  paragraphs, lists, links, emphasis, code, and tables. Raw HTML/script/style
  is not allowed in starter content.
- Docs route paths are docs/public route hints only when Cedros Docs supports
  them; otherwise use slug and navigation metadata.

### Starter lifecycle

- install: templates become available in inventory
- enable: docs articles are provisioned once as draft Docs records; forms and
  policies with `autoCreateOnEnable: true` are provisioned as real records,
  while other form/policy starters appear in owner creation workflows
- disable/remove: no new docs are provisioned; existing Docs records remain
  unless explicitly deleted
- upgrade: manifest changes do not overwrite an existing owner-edited Docs
  record

Provisioning timing note: like page seeds, starter auto-provisioning is
asynchronous client-side admin-shell work
([`05-package-family-and-registration.md`](05-package-family-and-registration.md)) —
it runs after enable while an owner has the admin open.

### Starter copy safety

Safe starter copy:

> Replace this section with your business-specific refund policy before
> publishing.

Unsafe starter copy:

> This form guarantees legal compliance in every jurisdiction.

- Do not include secrets, private credentials, raw PII, or unsupported claims
  in starter copy.
- Keep starter copy editable and conservative; avoid guarantees, legal claims,
  or unsafe advice.
- Use docs articles for durable public end-user help content, not transient
  setup status or admin runbooks.
- Use forms starters for owner-created forms, not hidden executable workflows.

## Onboarding

- Onboarding metadata belongs on the extension manifest as `onboardingPages[]`.
- Admin pages provide the actual setup UI
  ([`12-admin-pages-and-dashboard-cards.md`](12-admin-pages-and-dashboard-cards.md)).
- Each onboarding page points at a manifest-owned admin module and leaf
  section.
- Cedros resolves incomplete onboarding steps only for active extensions.
- Completed onboarding page ids are stored with extension management state.
- Completion persistence is host-coordinated unless the SDK exports an
  onboarding completion helper
  ([`09-settings-secrets-and-state.md`](09-settings-secrets-and-state.md)).
- Onboarding links only work when the target admin module and component are
  present in the ZIP-contained admin runtime.

Supported manifest fields today: `id`, `moduleId`, `sectionId`, `displayName`,
and optional `description`. Ordering, required/skippable flags, blocked
reasons, and reset workflows are product/runtime guidance unless Cedros
publishes manifest fields for them.

### Onboarding plan

For each step, define:

- first-run setup steps and required external account/API setup
- required permissions and seeded pages/forms/docs
- required verification before going live
- skipped/blocked states and completion criteria
- recovery path after a failed setup step
- site-brain records for setup completion/failure when operationally important

### Validation rules

- Keep onboarding ids stable; duplicates are rejected at UI local-package
  intake.
- `moduleId` must reference a same-extension admin module
  (`adminModules[].moduleId`).
- The target admin module MUST declare `sectionIds[]` containing the target
  `sectionId`. UI local-package intake hard-fails a target module without
  `sectionIds` ("module … must declare sectionIds"); this is not conditional
  on the list being present (`ADMIN-MODULE-001`).
- These onboarding checks run in the admin UI intake and the authoring
  validator only. The server keeps `onboardingPages` and `adminModules` as
  opaque extra fields, so the server/MCP install endpoints do not enforce
  them; run the validator before upload.
- That target also needs the matching `sectionIcons` and
  `navigation.sections` entries required for every admin section.
- Do not hide required setup in implementation code only.
- Do not log secrets or API keys during setup.
- Prefer clear owner actions over passive documentation.

## Acceptance checks

Starters:

- Local package intake accepts valid forms/docs articles and rejects malformed
  fields or empty docs bodies.
- Enabling an extension creates one editable draft Docs entry for each docs
  article in the standard Docs table.
- Generated form keys/slugs are predictable and editable.
- Starter copy is safe to publish after owner review.

Onboarding:

- Extension inventory shows a setup summary when onboarding pages exist.
- "Finish setup" routes to a real AdminShell section.
- Completed steps disappear from the incomplete onboarding list.
- Steps are hidden only when `moduleId`/`sectionId` resolve to nothing at all.
  If the manifest declares the module but the runtime bundle failed to load,
  the manifest fallback supplies the section and the step still renders —
  routing to the inert "Admin bundle not loaded" placeholder page. Verify the
  runtime bundle actually loads; do not rely on the host hiding broken steps.
- Blocked external-service states are explicit and recoverable.

Next: [`16-analytics-and-site-brain.md`](16-analytics-and-site-brain.md).

## Declaring-extension submission reads

New submissions to owner-editable forms with a matching `extensionSource`
are attributed to the declaring extension and template. A verified submitter
adds the same scoped `visitor.userId` used on that extension's account routes.
Use `cedros-data:extension-form-submissions-read-v1` through the Core service
seam; unrelated forms and legacy unattributed submissions are excluded. See
[extension visitors](contracts/extension-visitor-v1.md).

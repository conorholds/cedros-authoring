# 06 · Runtime Contract Reference

This is the runtime contract reference for extension code: vendored Wasm WIT,
the host-provided `cedros:admin` virtual module, ZIP loader rules, and native
bootstrap behavior. Cedros Data does not publish npm or Cargo dependencies for
extension authors. When a contract is not finalized, this document labels it
host-coordinated so authors do not invent working imports.

## Contract status

Platform API version `1` has no registry-resolved Cedros dependency:

- Rust server components compile against the WIT files vendored into their
  source tree and serialize the canonical archive manifest with ordinary local
  types or `serde_json`.
- Browser admin code imports runtime values from `cedros:admin`. The ZIP loader
  supplies that virtual module; extension builds keep it external.
- React Native members return the same archive bootstrap shape and use local
  declarations for compile-time types. They do not install a Cedros package.

> **Server backends run as WebAssembly components** — see the canonical
> [`07-wasm-server-backends.md`](07-wasm-server-backends.md) for the exact WIT
> interfaces and capability grants. The Rust types below describe the same
> contracts from the host's point of view.

| Runtime seam | Status | Grant / notes |
|---|---|---|
| manifest registration | published | do not ship executable behavior in it |
| server routes + jobs (wasm) | **wired** | exported by the component (`routes`, `jobs`) |
| site database (wasm `database`) | **wired** | scope via `databaseAccess[]` |
| settings (wasm `settings`) | **wired** | granted by `settingsSchemas` |
| secrets (wasm `secrets`) | **wired** | always granted, encrypted at rest |
| telemetry / analytics emit (wasm `telemetry`) | **wired** | shared interface links for server events or record write grants; each analytics event requires its exact `surfaces.server.events[]` id |
| host providers (wasm `providers`) | **wired** | storage·intelligence·image·voice·email·blockchain; scope via `providerAccess[]` (domains managed-only) |
| customer tags (wasm `customer-tags`) | **wired** | assign/unassign/read; scope via `customerTagAccess[]` |
| CRM source events (wasm `crm-source-events`) | **wired** | scope via `crmSourceAccess[]` |
| site-brain record emit (wasm `telemetry.emit-record`) | **wired** | a `site-brain-record:<category>` write scope in root `capabilities[]` links and authorizes records independently of analytics; earlier hosts needed an event declaration too ([host qualification](16-analytics-and-site-brain.md#site-brain-records)) |
| public-route SEO (wasm `seo` export) | **wired** | opt-in via `seoRoutes[]` (`extension-seo` world) |
| native (RN) screen/stack/provider loading | **wired for hosted App Builder; otherwise host-coordinated** | App Builder packages enabled native exports; other native hosts need a published equivalent loader |

## Safe implementation patterns for remaining host-coordinated seams

Use these patterns only when code needs a seam outside the documented Wasm
server runtime or React admin/web runtime. The goal is compile-ready extension
code plus an explicit handoff, not invented imports.

| Seam | Safe implementation today | Handoff output |
|---|---|---|
| Browser analytics emit without a published browser helper | Declare `analytics.events[]`; document browser trigger points and use only a host-supplied browser analytics adapter when present. | event id, trigger, redacted property shape, browser owner, staging check |
| Admin settings UI persistence | Use Wasm `settings` from server routes/jobs or a host-injected admin settings adapter; never persist authoritative settings in browser storage. | setting key, validation, storage owner, migration/default behavior |
| Operator secret entry/rotation UI | Accept only opaque host secret handles or call the Wasm `secrets` import from server code; never accept raw secret values into manifests/bootstrap/job metadata. | secret category, who enters it, rotation/delete behavior |
| Onboarding completion | Link to the real admin section and show setup state from extension management only if the helper exists; otherwise keep completion persistence host-coordinated. | onboarding id, completion criteria, reset behavior, host state owner |
| Bespoke typed SQL/schema | Use Wasm `database.migrate` only to register a declared content-model id as a host collection; keep migration-id-keyed or bespoke schema/SQL as reviewed handoff material. | fields/indexes/retention, migration ids, review owner |
| Native loader outside hosted App Builder | Export a minimal bootstrap and hide or disable native entry points until that native host publishes or binds an equivalent loader. | native id, target host, fallback behavior, device staging check |
| Domains provider | Declare only when Cedros explicitly grants the managed domains provider; third-party domains provider access is not self-serve. | provider use case, owner, fallback behavior |

For optional adapters, use dependency injection through documented host services
or props. Code should still compile and fail closed when the adapter is absent.
Do not use speculative globals such as `window.cedros`, private workspace
imports, or locally invented methods as substitutes for documented seams.

## Current self-serve runtime capabilities

| Capability | Live path today | Not live by declaration alone |
|---|---|---|
| manifest/bootstrap registration | server, admin, web, and native exports return the canonical manifest; compiled browser ESM inside the ZIP IS executed for admin and public web surfaces (intake hard-fails `adminModules` without it) | raw TS source execution (only compiled `.js`/`.mjs` runs) |
| admin pages | `AdminModule.sections` and `components` from React admin bootstrap | nested admin routers or private settings panels |
| dashboard cards | `AdminModule.contributions.dashboardCards[]` | changing host dashboard layout |
| content blocks/templates | React web/admin runtime definitions from package bootstrap | executable code inside authored documents |
| page seeds, forms, docs, onboarding | manifest metadata consumed by Cedros owner flows | arbitrary route handlers or hidden setup state |
| provider/database calls | Wasm `providers` and `database` imports inside extension routes/jobs | browser/native provider calls or raw Postgres access |
| routes/jobs | Wasm component exports matched to manifest route/job ids | ids mounting executable behavior without the package's `cedros-extension.server.wasm` |
| native hooks | first-class ids plus native host bindings | ids mounting executable behavior by themselves |

## Rust server component

Canonical export:

```rust
const MANIFEST_JSON: &str = include_str!("../../../cedros-extension.manifest.json");

pub fn register_extension_family() -> serde_json::Value {
    serde_json::from_str(MANIFEST_JSON)
        .expect("extension manifest should stay valid")
}
```

The Rust shapes below describe host-side semantics; they are not types to import
from Cedros Data. Executable extension routes and jobs implement the canonical
vendored WIT in [`07-wasm-server-backends.md`](07-wasm-server-backends.md).
If a needed WIT operation or host binding is not documented, treat it as
host-coordinated.

Route hook metadata:

```rust
pub struct CedrosExtensionServerRouteHook {
    pub extension_id: String,
    pub route_id: String,
    pub method: String,
    pub path: String,
    pub description: Option<String>,
}
```

Route request/response:

```rust
pub struct CedrosExtensionServerRouteRequest {
    pub extension_id: String,
    pub route_id: String,
    pub method: String,
    pub path: String,
    pub headers: BTreeMap<String, String>,
    pub query: Vec<(String, String)>,
    pub body: serde_json::Value,
    pub context: CedrosExtensionServerRouteContext,
}

pub struct CedrosExtensionServerRouteResponse {
    pub status_code: u16,
    pub headers: Vec<(String, String)>,
    pub body: String,
}

pub struct CedrosExtensionServerRouteContext {
    pub actor_id: Option<String>,
    pub authenticated: bool,
    pub system_admin: bool,
    pub permission_claims: Vec<String>,
    pub request_id: Option<String>,
    pub idempotency_key: Option<String>,
    pub csrf_verified: bool,
    pub site_id: Option<String>,
    pub environment: Option<String>,
}

pub trait CedrosExtensionServerRouteHandler: Send + Sync {
    fn handle<'a>(
        &'a self,
        request: CedrosExtensionServerRouteRequest,
    ) -> CedrosExtensionServerRouteFuture<'a>;
}
```

Route requests carry `context` on compatible hosts: actor id, authenticated
flag, system-admin flag, permission claims, request id, idempotency key,
CSRF/webhook-verified flag, site id, and environment. The host populates
request id, idempotency key, site id, and environment from the request and
deployment. `actor_id` / `authenticated` are resolved from the host admin
session. `system_admin` means site-wide administrator authority — gate
admin-only routes on it. `csrf_verified` is `true` for CSRF-immune bearer
(Authorization-header) auth and also for cookie-authenticated requests whose
`Origin` is the API origin or an operator-trusted admin origin; it is `false`
for bare cookie requests with no trusted `Origin`. Handlers must still fail
closed on `csrf_verified` for state-changing requests and verify external
webhook signatures themselves. In the JSON context envelope, `systemAdmin` is
always present; `permissionClaims` is omitted when empty. In self-hosted
local-admin route dispatch, the host appends the current extension's root
`capabilities[].id` values to `permissionClaims`; cedros-login-profile dispatch
uses the literal claims returned by cedros-login `/permissions`. If a route
needs a context field not in this struct, include it in the route handoff
instead of adding unsupported fields to the documented envelope.

`query` is `Vec<(String, String)>`: repeated query keys are preserved in
request order, not collapsed into a map. Response `headers` are ordered
`Vec<(String, String)>` pairs, so repeated headers (e.g. multiple
`Set-Cookie` on trust-admitted first-party routes) survive where host policy
permits them. Third-party HTTP responses cannot set site cookies; the host
sandboxes documents, restricts MIME types and redirects, and owns browser
security headers. See the [browser authority contract](07-wasm-server-backends.md#browser-authority-of-server-responses).
Response `body` is a `String` carried verbatim for accepted responses:
serialize JSON yourself and set `content-type` via `headers`; an empty body
stays empty.

Route responses should use explicit status codes and redacted JSON bodies.
Validation, auth, rate limit, downstream, and retryable errors must be
documented in the route handoff; do not rely on opaque panics or raw error
serialization.

Job execution contract:

```rust
pub struct CedrosExtensionServerJobExecution {
    pub extension_id: String,
    pub job_id: String,
    pub metadata: serde_json::Value,
    pub attempt: u32,
}

pub enum CedrosExtensionServerJobOutcomeStatus {
    Succeeded,
    Failed,
    Retryable,
}

pub trait CedrosExtensionServerJobExecutor: Send + Sync {
    fn execute<'a>(
        &'a self,
        execution: CedrosExtensionServerJobExecution,
    ) -> CedrosExtensionServerJobFuture<'a>;
}
```

Current compile-ready job executions contain the fields above. Site id,
environment, run id, schedule instance id, trigger actor, permission claims,
and idempotency key are host-coordinated context fields until Cedros documents
them in the runtime envelope.

Provider client contract:

```rust
pub struct CedrosExtensionHostProviderRequest {
    pub context: CedrosExtensionHostProviderCallContext,
    pub provider: CedrosExtensionHostProviderKind,
    pub operation: String,
    pub payload: serde_json::Value,
}

pub trait CedrosExtensionHostProviderClient: Send + Sync {
    fn execute<'a>(
        &'a self,
        request: CedrosExtensionHostProviderRequest,
    ) -> CedrosExtensionHostProviderFuture<'a>;
}

pub type CedrosExtensionHostProviderFuture<'a> = Pin<Box<
    dyn Future<Output = Result<CedrosExtensionHostProviderResponse,
        CedrosExtensionHostProviderError>> + Send + 'a,
>>;
```

`providerAccess[].scopes[]` are declared authorization/review scopes. Runtime
provider calls must name the matching access id, and `request.operation` (or the
wasm `operation` argument) must equal one of that access entry's declared scopes
unless the published provider contract explicitly allows a narrower operation
name. Current published aliases: `storage.read` permits `get`,
`storage.write` permits `put`/`delete`, and `email.send` permits `send`.
`context.feature` is product attribution; `context.description` is
human-readable and must be redacted. Wasm provider host errors include stable
`code` and `category` fields; branch on those instead of English messages.

Site database client contract:

```rust
pub struct CedrosExtensionSiteDatabaseCallContext {
    pub extension_id: String,
    pub access_id: String,
    pub feature: Option<String>,
    pub description: Option<String>,
    pub tags: Vec<String>,
}

pub struct CedrosExtensionSiteDatabaseRequest {
    pub context: CedrosExtensionSiteDatabaseCallContext,
    pub operation: String,
    pub content_model_id: Option<String>,
    pub migration_id: Option<String>,
    pub payload: serde_json::Value,
}

pub trait CedrosExtensionSiteDatabaseClient: Send + Sync {
    fn execute<'a>(
        &'a self,
        request: CedrosExtensionSiteDatabaseRequest,
    ) -> CedrosExtensionSiteDatabaseFuture<'a>;
}

pub type CedrosExtensionSiteDatabaseFuture<'a> =
    Pin<Box<dyn Future<Output = Result<CedrosExtensionSiteDatabaseResponse>> + Send + 'a>>;
```

Route, job, database, and host-provider contracts are async through boxed futures.
Provider implementations must use async clients or move unavoidable blocking work
to a bounded blocking executor; never perform blocking downstream work while
constructing or polling the provider future.

Extensions must use `databaseAccess[]` for database permissions and pass the
matching access id in `CedrosExtensionSiteDatabaseCallContext`. The host does
not expose raw Postgres credentials, raw `PgPool`, or browser/native database
access to extension code.

The host implements this operation against its content store with manifest-scope
enforcement. See the documented operation payloads in
[`08-site-database.md`](08-site-database.md).

Customer-tag client contract:

```rust
pub struct CedrosExtensionCustomerTagCallContext {
    pub extension_id: String,
    pub access_id: String,
    pub feature: Option<String>,
    pub description: Option<String>,
    pub tags: Vec<String>,
}

pub struct CedrosExtensionCustomerTagAssignRequest {
    pub context: CedrosExtensionCustomerTagCallContext,
    pub profile_id: Uuid,
    pub tag_slug: String,
    pub note: Option<String>,
    pub metadata: Option<serde_json::Value>,
}

pub struct CedrosExtensionCustomerTagUnassignRequest {
    pub context: CedrosExtensionCustomerTagCallContext,
    pub profile_id: Uuid,
    pub tag_slug: String,
}

pub struct CedrosExtensionCustomerTagReadRequest {
    pub context: CedrosExtensionCustomerTagCallContext,
    pub profile_id: Uuid,
}

pub trait CedrosExtensionCustomerTagClient: Send + Sync {
    fn assign<'a>(
        &'a self,
        request: CedrosExtensionCustomerTagAssignRequest,
    ) -> CedrosExtensionCustomerTagFuture<'a, CedrosExtensionCustomerTagAssignResponse>;

    fn unassign<'a>(
        &'a self,
        request: CedrosExtensionCustomerTagUnassignRequest,
    ) -> CedrosExtensionCustomerTagFuture<'a, CedrosExtensionCustomerTagUnassignResponse>;

    fn read<'a>(
        &'a self,
        request: CedrosExtensionCustomerTagReadRequest,
    ) -> CedrosExtensionCustomerTagFuture<'a, CedrosExtensionCustomerTagReadResponse>;
}

pub type CedrosExtensionCustomerTagFuture<'a, T> =
    Pin<Box<dyn Future<Output = Result<T>> + Send + 'a>>;
```

Extensions must declare `customerTagAccess[]` and pass the matching access
id in the call context. Production hosts wrap the concrete bridge with
`CedrosExtensionValidatedCustomerTagClient::new(manifest, client)`, which
enforces declared scopes (`read` / `assign` / `unassign`) and
`managedTagSlugs[]` on every call. Tag definitions are auto-created on the
first assign per slug — see
[`20-crm-tags-and-source-events.md`](20-crm-tags-and-source-events.md) for the
full lifecycle.

Published Wasm server seams:

- `telemetry.emit-record` for site-brain records (requires
  a `site-brain-record:<category>` write scope in
  root `capabilities[]`)
- `telemetry.emit-event` for analytics events
- `logging.log` for transient structured diagnostics
- `settings.get / set / list-all`
- `secrets.get / set / delete`
- `database.read / count / write / delete / batch / compare-and-set / migrate`
  (`compare-and-set` is the typed optimistic-concurrency seam for JSONB
  records and requires `cedros-data:extension-storage-cas-v1`)
- `providers.execute(access-id, provider, operation, payload-json)`
- `providers.resolve-default(access-id, provider, operation)` for a
  scope-checked, secret-free host intelligence default
- `customer-tags.assign / unassign / read`
- `http.fetch` for operator-allowlisted egress
- `crm-source-events.submit` (granted by `crmSourceAccess[]`; third-party
  source events use `cedros_pay`; `cedros_login` is reserved for the bundled
  `cedros-login` extension and only for account/identifier linking events)
- `seo.describe-route` / `seo.list-sitemap-urls` (exports of the opt-in
  `extension-seo` world; see [`07-wasm-server-backends.md`](07-wasm-server-backends.md))

For browser/admin helpers or non-Wasm/server sidecars outside those imports,
document the required host binding, contract, owner, launch gate, and staging
verification instead of inventing imports.

Third-party payment attribution preserves email/phone linking but cannot assert
Pay/Login account identities, replace another source's events, settle payments,
or establish commerce milestones/trusted conversions. Data records the verified
submitting extension as provenance; see the [Wasm source-event boundary](07-wasm-server-backends.md).

## Error and idempotency baseline

Use one consistent error posture across routes, jobs, provider calls, database
calls, analytics telemetry, and site-brain telemetry:

- validate external input before provider/database calls
- fail closed for missing auth, permission, provider, database access,
  official dependency, or host binding
- include an idempotency key strategy for writes, webhooks, sends, syncs,
  payments, wallet signing, storage writes, and destructive actions
- return or log redacted cause codes such as `validation_failed`,
  `permission_denied`, `dependency_missing`, `provider_unavailable`,
  `downstream_failed`, `retryable_downstream_failed`, and
  `human_review_required`
- never serialize raw downstream errors, tokens, headers, row payloads, prompts,
  or PII into responses, analytics, site-brain records, or logs
- document retryability and rollback/compensation behavior in host handoff

## React admin runtime

Manifest registration entrypoint:

- `${packageFamily.react.packageName}/admin/register`

Node package export subpath:

- `./admin/register`

Current scaffold export shape:

```ts
import type { CedrosExtensionBootstrap } from "cedros:admin";
import { extensionBootstrap } from "../bootstrap";
import { adminModule } from "./module";

export function registerCedrosAdminSurface(): CedrosExtensionBootstrap {
  return { ...extensionBootstrap, modules: [adminModule] };
}
```

The bare bootstrap (`return extensionBootstrap;`) registers zero admin pages.
Admin pages get executable components only through `modules` (`AdminModule[]`)
in the returned bootstrap.

Important runtime interfaces:

```ts
export interface AdminModule {
  id: string;
  name: string;
  version: string;
  manifest?: AdminModuleManifest;
  sections: AdminSectionConfig[];
  groups?: AdminGroupConfig[];
  components: Record<string, React.ComponentType<AdminSectionProps>>;
  createPluginContext: (hostContext: HostContext) => PluginContext;
  checkPermission: (permission: string, hostContext: HostContext) => boolean;
  cssNamespace: string;
  slots?: AdminPluginSlots;
  contributions?: AdminModuleContributions;
}
```

Admin section config:

```ts
export interface AdminSectionConfig {
  id: string;
  label: string;
  labelKey?: string;
  icon: React.ReactNode;
  group?: string;
  groupKey?: string;
  order?: number;
  hideFromNavigation?: boolean;
  requiredPermission?: string;
  badge?: React.ReactNode;
  requiredExtensionId?: string;
  replacesSectionIds?: string[];
  disabledReason?: string;
  disabledReasonKey?: string;
  disabled?: boolean;
  adminPageAccess?: {
    configurable?: boolean;
    protected?: boolean;
    routePath?: string;
  };
}
```

Manifest navigation projection:

```ts
export interface AdminModuleNavigationManifest {
  sections: Array<{
    id: string;
    label: string;
    group: string;
    order: number;
    labelKey?: string;
    groupKey?: string;
    hideFromNavigation?: boolean;
    requiredPermission?: string;
    requiredExtensionId?: string;
    replacesSectionIds?: string[];
    disabledReason?: string;
    disabledReasonKey?: string;
    disabled?: boolean;
    adminPageAccess?: {
      configurable?: boolean;
      protected?: boolean;
      routePath?: string;
    };
  }>;
  groups?: Array<{
    id: string;
    label: string;
    order: number;
    labelKey?: string;
    defaultCollapsed?: boolean;
    hideLabel?: boolean;
  }>;
}
```

### Manifest fallback icon vocabulary

`AdminModule.sections[].icon` owns the real runtime icon. When the manifest
declares `adminModules[].sectionIds[]`, it must also declare
`adminModules[].sectionIcons` for each section so manifest-only fallback pages
never render iconless. The accepted values are the 44 host aliases in
`HOST_ADMIN_ICON_NAMES` **plus any resolvable Lucide icon name** (accepted in
`lucide:kebab-name`, PascalCase, or bare form):

```
account, analytics, archive, assistant, backups, brain, collections,
communications, contractVerify, customers, customData, dashboard, dataOps,
docs, email, emailCampaigns, emailInbox, emailLists, emailTemplates,
extensions, faq, heatmap, help, history, layout, media, memory, mobile,
monetization, navigation, pages, policies, posts, products, providers,
redirects, scheduledJobs, schemaDesigner, security, siteHealth, siteSettings,
storefront, subscriptions, team
```

The same module must declare `adminModules[].navigation.sections[]` with every
runtime page's exact `id`, `label`, `group`, `order`, and optional
translation/gating/replacement/disabled/page-access fields. If runtime
`groups[]` is non-empty, mirror the full array in `navigation.groups[]`.
Cedros persists this JSON-safe projection in the installed manifest, copies it
into the active admin registry on enable, and uses it for the first sidebar
paint. When the executable admin bundle loads, its sections/groups must match
or the host keeps the manifest fallback instead of moving, relabeling, or
regating an entry.

(Source: `ui/src/admin/adminIconVocabulary.ts`; Lucide names resolve through
`resolveHostAdminIconName`, which tries the exact string, PascalCase, and the
`...Icon` suffix.)

Admin section props:

```ts
export interface AdminSectionProps {
  pluginContext: PluginContext;
  pageSize: number;
  refreshInterval: number;
}
```

Admin runtime context contract:

- The host mounts each extension section inside AdminShell and passes
  `AdminSectionProps`.
- Safe inputs are the `pluginContext` prop, `cedros:admin` helpers that take
  `pluginContext`, and published host services reachable through
  `AdminHostContext`/`getHostService`.
- The host does not mount the extension's standalone provider tree. Admin
  components must not call standalone full-provider hooks such as
  `useCedrosLogin()` unless the extension supplies the required provider through
  an approved admin wrapper/slot.
- The host wraps each section in an error boundary, but authors should still
  render explicit loading, disabled, empty, and error states for missing services
  or failed route responses.

Dashboard card contribution:

```ts
export interface DashboardCardContribution {
  id: string;
  Component: React.ComponentType<DashboardCardContributionProps>;
  order?: number;
}

export interface DashboardCardContributionProps {
  hostContext: AdminHostContext;
  pluginContext: PluginContext;
  extensionId: string;
  refreshInterval: number;
  isLoading: boolean;
  analyticsSnapshot: RuntimeAnalyticsSnapshot | null;
  analyticsError: string;
}
```

`analyticsError` is a required string. The host passes `""` when there is no
analytics error — treat the empty string as no-error and any non-empty string
as the error message.

Content editor panel contribution:

```ts
export interface ContentEditorPanelContribution {
  id: string;
  Component: React.ComponentType<ContentEditorPanelProps>;
  order?: number;
  contentTypes?: RuntimeContentType[];
}
```

Host service access:

```ts
import { HOST_SERVICE_IDS, getHostService } from "cedros:admin";

const service = getHostService<MyService>(
  hostContext,
  HOST_SERVICE_IDS.siteIntelligenceProvider
);
```

Host service id mapping:

| Manifest/service id | Host-module constant |
|---|---|
| `site-intelligence-provider` | `HOST_SERVICE_IDS.siteIntelligenceProvider` |
| `site-image-generation-provider` | `HOST_SERVICE_IDS.siteImageGenerationProvider` |
| `site-voice-provider` | `HOST_SERVICE_IDS.siteVoiceProvider` |
| `site-storage-provider` | `HOST_SERVICE_IDS.siteStorageProvider` |
| `site-email-provider` | `HOST_SERVICE_IDS.siteEmailProvider` |
| `site-blockchain-provider` | `HOST_SERVICE_IDS.siteBlockchainProvider` |

Host provider service shape:

```ts
export interface CedrosExtensionHostProviderService<TPayload = unknown, TResult = unknown> {
  request: (request: CedrosExtensionHostProviderRequest<TPayload>) => Promise<TResult>;
}
```

Permission names are strings. Prefer existing Cedros permissions and required
host capabilities over inventing extension-specific permission systems.

Official admin group labels are exact merge keys. The registered group configs
are `""` (dashboard), `Site`, `Users`, `Email`, `Grow`, `Assistant`,
`Settings`, `Extension Settings`, `Tools`, `Build`, and `Control Plane`
(`ui/src/admin/plugin.tsx` `groups`, plus the Extension Settings seed in
`AdminShell`). `Content` is a section label inside `Grow`, and `Monetization`
is only a label constant; neither is a registered group.
Extension-owned settings/setup/policy/configuration pages should use
`group: "Extension Settings"` so they land between host `Settings` and `Tools`.
The labels `Appearance`,
`Observability`, `Data Model`, and `Operations` exist as host section labels
but are NOT registered group configs — a section targeting them creates a new
group sorted last (order 99) unless the module ships its own
`AdminGroupConfig`. Sections with no `group` land in a literal `Menu` group.
Custom groups are allowed only when no official group fits and must be
documented in the feature brief.

Built-in Cedros capability names are `manage_settings`, `manage_users`,
`manage_extensions`, `manage_themes`, `create_content`, `edit_own_content`,
`edit_all_content`, `publish_content`, `schedule_content`, `manage_media`,
`manage_redirects`, `manage_links`, `view_audit_log`, `manage_comments`, and
`manage_taxonomies`. Legacy `data:*` permissions may appear in host contexts
for compatibility, but new extension docs should prefer capability names or
published host capability ids. Hiding an admin section is not authorization;
server routes must perform their own auth and permission checks.

## React web runtime

Manifest registration entrypoint:

- `${packageFamily.react.packageName}/web/register`

Node package export subpath:

- `./web/register`

Current scaffold export shape:

```ts
import type { CedrosExtensionBootstrap } from "cedros:admin";
import { extensionBootstrap } from "../bootstrap";

export function registerCedrosWebSurface(): CedrosExtensionBootstrap {
  return extensionBootstrap;
}
```

ZIP-contained runtime bootstrap can publish:

- `manifest`
- `modules` (`AdminModule[]` — how admin pages get executable components)
- `contentBlocks`
- `contentTemplates`
- `contentBlockRenderers` (`{type, render}` — first-class public renderer
  seam; takes precedence over `contentBlocks[].Component`)
- `hostServices`

Content block/template runtime types come from the authoring-kit declarations
and should not be imported from a registry package or re-invented in extension
code.

Web runtime rules:

- block props must be serializable authored-document data
- no raw HTML/script/style payloads
- block visuals ship as archive stylesheets (not document props) and style
  colors through the host runtime theme tokens; see
  [`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md)
- public analytics must use Cedros browser/reporting seams when available
- theme/media/link/form helpers should come from documented host bindings when available
- custom public routes beyond page seeds require host coordination

## ZIP runtime loader rules

The host loads compiled ZIP runtimes with its own module loader. These rules
are enforced at load time; violating any of them fails the load.

- Author-facing bare-import allowlist: `react`, `react/jsx-runtime`,
  `react/jsx-dev-runtime`, `cedros:admin`.
  Anything else throws "is not bundled". Notably `react-dom` is NOT shimmed, in
  admin **and** public host-mounted chunks — `createPortal` or
  `react-dom/client` (often pulled in transitively by `sonner` or Radix portal
  primitives) makes the chunk unloadable: a static import fails the whole load
  with "is not bundled"; a dynamic import survives to the browser and throws at
  mount. Public chunks must externalize `react-dom` (bundling it drags
  `process.env` into the browser) and never import it; see
  [`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md).
  No Cedros npm package is resolvable from a ZIP runtime.
- Admin and web graphs run as browser ESM through blob/module URLs. Neither
  surface has `process`, `Buffer`, `require`, `module`, `global`, `__dirname`,
  `__filename`, or other Node globals. Production builds must statically
  replace `process.env.NODE_ENV` and validate every resolved dependency/lazy
  chunk, not only the registration entrypoint.
- The loader retains one deprecated package-shaped admin specifier solely so
  archives built before the virtual-module migration continue to load. It is
  not part of the authoring contract and must not appear in new source.
- The `cedros:admin` shim exports exactly: `HOST_SERVICE_IDS`,
  `buildAdminHostServiceBag`, `createAdminHostServiceBag`, `getHostService`,
  `getServiceFromBag`, `requestAdminJson`, `buildIntelligenceRoutingSections`,
  `findIntelligenceRoutingFeature`, `toast`, `useCedrosAutoRefresh`, the
  autosave suite — `CedrosAutosaveProvider`, `useCedrosAutosave`,
  `useCedrosAutosaveProvider`, `AutosaveConflictDialog`, `AutosaveRetryBanner`,
  `AutosaveStatusIndicator` — plus the default bag. Value-importing anything
  else fails module linking — keep type imports type-only. The retained kit's
  `cedros-admin-runtime.d.ts` is a frozen compatibility snapshot that declares
  the shared types and only the `toast` value; it is pinned byte-for-byte by
  `server/compatibility/extension-host-matrix.json` across every retained
  host version, so it cannot grow with the shim. Declare the other shim
  values in your own ambient `declare module "cedros:admin"` augmentation
  using the shared types from the kit until a new kit revision
  publishes an expanded declaration. The toast decision
  and lifecycle contract is in
  [`reference/admin-notifications.md`](reference/admin-notifications.md).
- Only `.js`/`.mjs`/`.css`/`.json` files become runtime files; `.map` and all
  other assets (svg/png/fonts) are silently dropped — importing them fails
  with "missing runtime file".
- Chunk resolution candidates: the exact path, the path plus `.js` or `.mjs`,
  and the path plus `/index.js` or `/index.mjs`. Files outside the React
  package root are excluded; circular chunk imports are rejected.
- Dynamic `import()` must use a static string literal.
  `document.createElement("script")` anywhere in an ADMIN module fails the
  load (only public web hydration allows it).
- Runtime failures are isolated per extension. A broken or timed-out bundle
  does not remove extensions that already loaded successfully and does not
  block unrelated extension pages.
- Admin loads the graph reachable from `./admin/register`; the public site
  loads the graph reachable from `./web/register`. Web chunks must not import
  from `dist/admin/`.
- When an entry module exports both registration functions, the admin loader
  selects `registerCedrosAdminSurface` and the public loader selects
  `registerCedrosWebSurface`. Legacy default registration remains supported.
  The returned bootstrap must match the installed extension id/version. Its
  executable contributions are combined with the **installed** manifest and
  enablement state; bootstrap metadata cannot change that authority. Public
  renderer declaration checks use the installed manifest too.
- Conditional exports are supported for registration keys with precedence
  `browser` → `import` → `default` → `module`.

### Loading order, surface projection, and compatibility

The admin host keeps executable runtime archives out of the initial installed-
extension state. That state carries compact archive references; the host fetches
the referenced archive only when runtime loading begins. When the current route
belongs to an extension, that extension's request starts first. Other enabled
extension runtimes load progressively, and each successful registration becomes
available without waiting for every other candidate to settle.

Each extension archive has independent fifteen-second fetch and start limits
(`RUNTIME_ARCHIVE_FETCH_TIMEOUT_MS` / `RUNTIME_ARCHIVE_START_TIMEOUT_MS`). A validation,
fetch, import, identity, or timeout failure is recorded against that extension.
The targeted route replaces its loading state with an explicit error and Retry
action; Retry preserves already loaded runtimes and retries only unresolved
candidates. Authors must not depend on a dashboard card mounting first, another
extension loading first, or a global all-extension warmup side effect.

The host owns the outer route loading state. After an extension component
mounts, it still owns loading, empty, disabled, and error states for its own
data. Avoid adding a second application-wide bootstrap skeleton inside the
extension page; use stable, page-shaped placeholders only for extension-owned
requests that remain pending after mount.

When the host builds a ZIP runtime archive, it derives these internal fields:

- `surfaceEntryPaths.admin` and `.web` from the existing
  `exports["./admin/register"]` and `exports["./web/register"]` targets
- `surfaceFilePaths.admin` and `.web` from the exact relative ESM graph
  reachable from each entrypoint

These are host-owned archive metadata, not manifest fields. Authors must not
hand-author them. Static imports and dynamic imports with static string
literals participate in the graph; unsupported computed dynamic imports still
fail validation. Keep the admin and web graphs separately rooted so the host
can omit surface-specific files from the other response; neutral shared chunks
may be reachable from both. A literal lazy import can defer module evaluation,
but its reachable chunk remains part of the current surface archive response,
so it does not by itself reduce transferred archive bytes.

Archives created before surface graphs were published remain compatible. If an
older persisted archive lacks entry or file-graph metadata, the host serves the
complete archive instead of failing it. Re-uploading or reinstalling the same
built package through an upgraded host regenerates the graph and enables full
admin/web payload projection; no source or manifest change is required. Normal
release policy still prefers a patch version, while a same-version reinstall
repeats the complete permission review. Archive responses use private ETag
revalidation, which is transparent to extension code.

## React Native runtime

Manifest registration entrypoint:

- `${packageFamily.reactNative.packageName}/register`

Node package export subpath:

- `./register`

Current scaffold export shape:

```ts
import type { CedrosExtensionBootstrap } from "cedros:admin";
import { extensionBootstrap } from "./bootstrap";

export function registerCedrosNativeSurface(): CedrosExtensionBootstrap {
  return extensionBootstrap;
}
```

Native metadata can declare:

- `surfaces.native.screenIds[]`
- `surfaces.native.stackIds[]`
- `surfaces.native.providerIds[]`

Custom mobile content blocks are loaded by the private host runtime. Extension
authors declare and ship their renderer contribution in the archive; they do
not install the host's React Native workspace. The host delegates only blocks
the core renderer reports as `supportStatus === "unsupported"` (so an extension
cannot hijack a core block) and lifecycle-gates rendering to enabled
extensions/contributions. See
[`05-package-family-and-registration.md`](05-package-family-and-registration.md)
and [`21-host-coordination-and-native.md`](21-host-coordination-and-native.md).

Generic native screen, stack, and provider loading is self-serve for hosted App
Builder releases. Package the compiled `./register` export and every module
reachable through the package's public exports. Cedros vendors the enabled
package from the installed extension artifact, validates declared contribution
ids, composes providers, and mounts `metadata.nativePrimaryStackId`. Missing or
inconsistent executable contributions stop the build before EAS is queued.

## Testing helpers and smoke tests

Minimum runtime smoke checks:

- Rust `register_extension_family()` returns the archive manifest
- React admin registration imports and returns the same manifest identity
- React web registration imports and returns the same manifest identity
- React Native registration imports and returns the same manifest identity
- runtime contribution ids match manifest ids
- disabled/missing host service states fail closed

## Placeholder contract rule

If a needed helper is not listed here or exposed by the host contract, do
not invent it. Mark the behavior as host-coordinated, add it to the handoff
table ([`21-host-coordination-and-native.md`](21-host-coordination-and-native.md)),
and ask Cedros for a documented host binding.

Next: [`07-wasm-server-backends.md`](07-wasm-server-backends.md).

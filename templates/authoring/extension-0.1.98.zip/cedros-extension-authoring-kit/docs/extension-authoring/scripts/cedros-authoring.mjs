#!/usr/bin/env node

import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { basename, dirname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const EXIT_VALIDATION = 1;
const EXIT_USAGE = 2;
const OBSOLETE_HOST = `${"cedroscloud.com/"}${"skill.md"}`;
const skillRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const guideRoot = existsSync(resolve(skillRoot, "schemas"))
  ? skillRoot
  : resolve(skillRoot, "references/extension-authoring");
const MODE_DOCUMENTS = {
  "create-extension": ["README.md", "01-extension-system-overview.md", "03-planning-an-extension.md", "04-manifest-reference.md", "05-package-family-and-registration.md", "06-runtime-sdk-reference.md", "22-packaging-and-upload.md"],
  "convert-application": ["README.md", "00-cedros-platform-primer.md", "03-planning-an-extension.md", "04-manifest-reference.md", "05-package-family-and-registration.md", "21-host-coordination-and-native.md", "22-packaging-and-upload.md"],
  "audit-repair-extension": ["README.md", "03-planning-an-extension.md", "04-manifest-reference.md", "05-package-family-and-registration.md", "06-runtime-sdk-reference.md", "23-release-versioning-and-upgrades.md", "25-troubleshooting-and-faq.md"],
  "add-released-feature": ["README.md", "03-planning-an-extension.md", "04-manifest-reference.md", "23-release-versioning-and-upgrades.md"],
  "complete-product-ux": ["README.md", "03-planning-an-extension.md"],
  "prepare-release": ["README.md", "22-packaging-and-upload.md", "23-release-versioning-and-upgrades.md"],
  "upgrade-or-rollback": ["README.md", "23-release-versioning-and-upgrades.md", "25-troubleshooting-and-faq.md"],
  "operate-live-site": []
};
const MODE_PRESERVATION_RULES = {
  "create-extension": ["CED-AUTH-001", "CED-AUTH-002", "CED-AUTH-004"],
  "convert-application": ["CED-AUTH-001", "CED-AUTH-003", "CED-AUTH-004"],
  "audit-repair-extension": ["CED-AUTH-003", "CED-AUTH-005", "CED-AUTH-007"],
  "add-released-feature": ["CED-AUTH-003", "CED-AUTH-007"],
  "complete-product-ux": ["CED-AUTH-003"],
  "prepare-release": ["CED-AUTH-006", "CED-AUTH-007", "CED-AUTH-008"],
  "upgrade-or-rollback": ["CED-AUTH-003", "CED-AUTH-007"],
  "operate-live-site": ["CED-AUTH-004", "CED-AUTH-005", "CED-AUTH-006"]
};
const MODE_SKIP_CONDITIONS = {
  "complete-product-ux": ["Skip manifest and runtime references only when repository inventory proves no platform contract changes."],
  "operate-live-site": ["Skip the authoring corpus unless an extension artifact or platform contract changes."]
};
const args = process.argv.slice(2).filter((value) => value !== "--json");
const command = args.shift();

try {
  if (!command) usage("a command is required");
  const report = run(command, args);
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  if (report.status !== "pass") process.exitCode = EXIT_VALIDATION;
} catch (error) {
  process.stderr.write(`${JSON.stringify({ status: "error", message: error.message }, null, 2)}\n`);
  process.exitCode = error.exitCode ?? EXIT_USAGE;
}

function run(name, inputArgs) {
  const options = parseOptions(inputArgs);
  if (name === "resolve-path") return resolvePath(options);
  if (name === "validate-context") return validateContext(requiredTarget(options));
  if (name === "validate-manifest") return validateManifest(requiredTarget(options));
  if (name === "validate-package") return validatePackage(requiredTarget(options));
  if (name === "check-runtime-alignment") return checkRuntimeAlignment(resolve(options.repo ?? options._[0] ?? "."));
  if (name === "check-doc-consistency") return checkDocConsistency(resolve(options.repo ?? options._[0] ?? guideRoot));
  if (name === "evaluate-routing") return evaluateRouting(requiredTarget(options), options);
  if (name === "evaluate-execution") return evaluateExecution(requiredTarget(options), options);
  if (name === "compare-evals") return compareEvals(requiredTargets(options, 2));
  if (name === "validate") return validateRepository(resolve(options.repo ?? options._[0] ?? "."), options.package);
  usage(`unknown command: ${name}`);
}

function parseOptions(inputArgs) {
  const options = { _: [] };
  for (let index = 0; index < inputArgs.length; index += 1) {
    const value = inputArgs[index];
    if (!value.startsWith("--")) {
      options._.push(value);
      continue;
    }
    const key = value.slice(2);
    const next = inputArgs[index + 1];
    if (!next || next.startsWith("--")) usage(`${value} requires a value`);
    options[key] = next;
    index += 1;
  }
  return options;
}

function requiredTarget(options) {
  const target = options._[0];
  if (!target) usage("a file or package path is required");
  return resolve(target);
}

function requiredTargets(options, count) {
  if (options._.length !== count) usage(`exactly ${count} file paths are required`);
  return options._.map((target) => resolve(target));
}

function resolvePath(options) {
  const repo = resolve(options.repo ?? options._[0] ?? ".");
  const manifestPath = resolve(repo, "cedros-extension.manifest.json");
  const requestedMode = options.mode;
  const mode = requestedMode ?? (existsSync(manifestPath) ? "audit-repair-extension" : "create-extension");
  const paths = MODE_DOCUMENTS[mode];
  if (!paths) usage(`unsupported task mode: ${mode}`);
  const commonPaths = mode === "operate-live-site"
    ? []
    : ["schemas/extension-context.schema.json", "reference/rules.json", "schemas/extension-manifest.schema.json"];
  const allDeclaredSurfaces = requestedSurfaces(options, manifestPath, repo);
  const unsupportedSurfaces = surfaceDocuments(allDeclaredSurfaces).unsupported;
  if (unsupportedSurfaces.length > 0) {
    usage(`unsupported surface selector(s): ${unsupportedSurfaces.join(", ")}`);
  }
  const declaredSurfaces = mode === "prepare-release"
    ? new Set([...allDeclaredSurfaces].filter((surface) => surface === "wasm"))
    : allDeclaredSurfaces;
  const conditional = mode === "operate-live-site"
    ? { documents: [], reasons: [], unsupported: [] }
    : surfaceDocuments(declaredSurfaces);
  const authoringPaths = mode === "operate-live-site"
    ? [resolveOperatorSkill()]
    : [...paths, ...commonPaths, ...conditional.documents]
      .filter((path, index, all) => all.indexOf(path) === index)
      .map((path) => resolve(guideRoot, path));
  if (mode !== "operate-live-site" && declaredSurfaces.has("wasm")) authoringPaths.push(resolveWitContract());
  if (mode !== "operate-live-site" && declaredSurfaces.has("admin")) authoringPaths.push(resolveDesignAdmin());
  const requiredDocuments = authoringPaths.filter((path, index, all) => all.indexOf(path) === index);
  const missingDocuments = requiredDocuments.filter((path) => !existsSync(path));
  if (missingDocuments.length > 0) {
    return blockedReport(
      "resolve-path",
      "CED-AUTH-001",
      "A required version-matched authoring reference is missing",
      missingDocuments,
      ["Repository inventory and task-mode classification"],
      "Install or fetch the complete checksummed authoring skill bundle"
    );
  }
  return {
    status: "pass",
    command: "resolve-path",
    mode,
    entryDocument: mode === "operate-live-site" ? requiredDocuments[0] : resolve(guideRoot, "README.md"),
    requiredDocuments,
    preservationRules: MODE_PRESERVATION_RULES[mode],
    skipConditions: MODE_SKIP_CONDITIONS[mode] ?? [],
    evidence: [
      `repository=${repo}`,
      `manifest=${existsSync(manifestPath) ? "present" : "absent"}`,
      `surfaces=${[...declaredSurfaces].sort().join(",") || "none"}`
    ],
    conditionalReasons: conditional.reasons
  };
}

function validateContext(path) {
  const context = readJson(path);
  const schema = readJson(resolve(guideRoot, "schemas/extension-context.schema.json"));
  const issues = validateSchema(schema, context);
  return report("validate-context", path, issues, "CONTEXT-STATE-001", "Validated against schemas/extension-context.schema.json");
}

function validateManifest(path) {
  const manifest = readJson(path);
  const issues = validateManifestValue(manifest);
  return report("validate-manifest", path, issues, "MANIFEST-SCHEMA-001", "Validated the canonical schema-version-1 manifest contract and cross-field package versions");
}

function checkRuntimeAlignment(repo) {
  const manifestPath = resolve(repo, "cedros-extension.manifest.json");
  if (!existsSync(manifestPath)) return report("check-runtime-alignment", repo, ["cedros-extension.manifest.json is missing"], "RUNTIME-ALIGNMENT-001", "No manifest to align");
  const manifestReport = validateManifest(manifestPath);
  const manifest = readJson(manifestPath);
  const issues = manifestReport.rows.filter((row) => row.status === "fail").map((row) => row.issue);
  const expected = {
    server: `${manifest.packageFamily?.server?.packageName?.replaceAll("-", "_")}::register_extension_family`,
    admin: `${manifest.packageFamily?.react?.packageName}/admin/register`,
    web: `${manifest.packageFamily?.react?.packageName}/web/register`,
    native: `${manifest.packageFamily?.reactNative?.packageName}/register`
  };
  for (const [surface, entrypoint] of Object.entries(expected)) {
    if (manifest.registration?.[surface]?.entrypoint !== entrypoint) issues.push(`registration.${surface}.entrypoint must equal ${entrypoint}`);
  }
  const packageChecks = [
    ["packages/react/package.json", manifest.packageFamily?.react, ["./admin/register", "./web/register"]],
    ["packages/react-native/package.json", manifest.packageFamily?.reactNative, ["./register"]]
  ];
  for (const [relativePath, member, exports] of packageChecks) {
    const packagePath = resolve(repo, relativePath);
    if (!existsSync(packagePath)) continue;
    const packageJson = readJson(packagePath);
    if (packageJson.name !== member?.packageName) issues.push(`${relativePath} name does not match packageFamily`);
    if (packageJson.version !== manifest.version) issues.push(`${relativePath} version does not match manifest`);
    for (const exportName of exports) {
      const exportPath = packageJson.exports?.[exportName];
      if (typeof exportPath !== "string" || !exportPath.startsWith("./")) {
        issues.push(`${relativePath} ${exportName} export must be a package-relative string`);
        continue;
      }
      const compiledPath = resolve(dirname(packagePath), exportPath);
      if (!existsSync(compiledPath)) issues.push(`${relativePath} ${exportName} compiled runtime is missing at ${exportPath}`);
    }
  }
  const cargoPath = resolve(repo, "packages/server/Cargo.toml");
  if (existsSync(cargoPath)) {
    const cargo = readCargoIdentity(readFileSync(cargoPath, "utf8"));
    if (cargo.packageName !== manifest.packageFamily?.server?.packageName) issues.push("packages/server/Cargo.toml package name does not match packageFamily.server.packageName");
    if (cargo.version !== manifest.version) issues.push("packages/server/Cargo.toml version does not match manifest version");
    const expectedCrate = cargo.packageName?.replaceAll("-", "_");
    if (cargo.libName !== expectedCrate) issues.push(`packages/server/Cargo.toml library name must be ${expectedCrate}`);
    if (manifest.registration?.server?.entrypoint !== `${expectedCrate}::register_extension_family`) issues.push("registration.server.entrypoint does not match the Cargo library identity");
  }
  const executableIds = [...(manifest.surfaces?.server?.routes ?? []), ...(manifest.surfaces?.server?.jobs ?? [])];
  if (executableIds.length > 0 && !existsSync(resolve(repo, "cedros-extension.server.wasm"))) {
    issues.push("declared server routes/jobs require a built cedros-extension.server.wasm at the repository root");
  }
  const bootstrapPath = resolve(repo, "cedros-extension.bootstrap.json");
  if (existsSync(bootstrapPath) && JSON.stringify(readJson(bootstrapPath).manifest) !== JSON.stringify(manifest)) {
    issues.push("cedros-extension.bootstrap.json manifest projection is stale");
  }
  return report("check-runtime-alignment", repo, issues, "RUNTIME-ALIGNMENT-001", "Compared declarations with package identities, compiled exports, component, and generated bootstrap");
}

function validatePackage(path) {
  const issues = [];
  let entries = [];
  try {
    entries = execFileSync("unzip", ["-Z1", path], { encoding: "utf8" }).trim().split(/\r?\n/).filter(Boolean);
  } catch (error) {
    issues.push(`package is not a readable ZIP: ${error.message}`);
  }
  for (const required of ["cedros-extension.manifest.json", "cedros-extension.bootstrap.json"]) {
    if (!entries.includes(required)) issues.push(`${required} is missing from package root`);
  }
  for (const entry of entries) {
    if (entry.startsWith("/") || entry.split("/").includes("..")) issues.push(`unsafe archive entry: ${entry}`);
    if (/(^|\/)(?:\.env|node_modules|target|\.git)(?:\/|$)/.test(entry)) issues.push(`forbidden package entry: ${entry}`);
  }
  if (entries.includes("cedros-extension.manifest.json")) {
    try {
      const manifest = JSON.parse(execFileSync("unzip", ["-p", path, "cedros-extension.manifest.json"], { encoding: "utf8" }));
      const temporaryIssues = validateManifestValue(manifest);
      issues.push(...temporaryIssues);
      if (entries.includes("cedros-extension.bootstrap.json")) {
        const bootstrap = JSON.parse(execFileSync("unzip", ["-p", path, "cedros-extension.bootstrap.json"], { encoding: "utf8" }));
        if (!deepEqual(bootstrap.manifest, manifest)) issues.push("cedros-extension.bootstrap.json manifest must exactly match cedros-extension.manifest.json");
      }
      const executable = [...(manifest.surfaces?.server?.routes ?? []), ...(manifest.surfaces?.server?.jobs ?? [])];
      if (executable.length > 0 && !entries.includes("cedros-extension.server.wasm")) issues.push("declared server routes/jobs require cedros-extension.server.wasm");
      validatePackagedClient(
        path,
        entries,
        manifest.packageFamily?.react,
        "workspace/react",
        [
          ...((manifest.adminModules?.length ?? 0) > 0 || (manifest.surfaces?.admin?.moduleIds?.length ?? 0) > 0 ? ["./admin/register"] : []),
          "./web/register"
        ],
        issues
      );
      validatePackagedClient(
        path,
        entries,
        manifest.packageFamily?.reactNative,
        "workspace/react-native",
        ["./register"],
        issues
      );
    } catch (error) {
      issues.push(`packaged manifest is invalid: ${error.message}`);
    }
  }
  for (const entry of entries) {
    if (/(^|\/)(?:id_(?:rsa|dsa|ecdsa|ed25519)|[^/]+\.(?:pem|key|p12|pfx))$/iu.test(entry)) {
      issues.push(`credential-like file is forbidden: ${entry}`);
    }
    if (!/\.(?:json|md|txt|js|mjs|cjs|ts|tsx|rs|toml|css|html|yaml|yml)$/iu.test(entry)) continue;
    try {
      const text = execFileSync("unzip", ["-p", path, entry], { encoding: "utf8", maxBuffer: 8 * 1024 * 1024 });
      if (text.includes(OBSOLETE_HOST)) issues.push(`${entry} emits the obsolete Cedros skill hostname`);
    } catch (error) {
      issues.push(`could not inspect packaged text entry ${entry}: ${error.message}`);
    }
  }
  return {
    ...report("validate-package", path, issues, "PACKAGE-ARCHIVE-001", `Inspected ${entries.length} archive entries`),
    sha256: existsSync(path) ? sha256(readFileSync(path)) : null,
    entryCount: entries.length
  };
}

function checkDocConsistency(root) {
  const files = walk(root).filter((path) => /\.(?:md|json|mjs|js|ts|tsx)$/u.test(path));
  const issues = [];
  for (const path of files) {
    const text = readFileSync(path, "utf8");
    if (text.includes(OBSOLETE_HOST)) issues.push(`${relative(root, path)} emits https://${OBSOLETE_HOST}`);
    if (path.endsWith(".md")) {
      for (const target of markdownFileTargets(text)) {
        const resolvedTarget = resolve(dirname(path), target);
        if (!existsSync(resolvedTarget)) {
          issues.push(`${relative(root, path)} links to missing local file ${target}`);
        }
      }
      for (const paragraph of normativeParagraphs(text)) {
        if (!/\b[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+-\d{2,3}\b/u.test(paragraph)) {
          issues.push(`${relative(root, path)} contains an unregistered normative statement: ${paragraph.replace(/\s+/gu, " ").slice(0, 160)}`);
        }
      }
    }
  }
  const localGuideRoot = existsSync(resolve(root, "schemas")) ? root : guideRoot;
  for (const [mode, paths] of Object.entries(MODE_DOCUMENTS)) {
    for (const path of paths) {
      if (!existsSync(resolve(localGuideRoot, path))) issues.push(`${mode} routes to missing document ${path}`);
    }
  }
  const rulesPath = resolve(localGuideRoot, "reference/rules.json");
  if (existsSync(rulesPath)) {
    const registry = readJson(rulesPath);
    const ruleIds = new Set((registry.rules ?? []).map((rule) => rule.id));
    if (ruleIds.size !== (registry.rules ?? []).length) issues.push("reference/rules.json contains duplicate rule IDs");
    const referencedRuleIds = new Set(files.flatMap((path) => readFileSync(path, "utf8").match(/\b[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+-\d{2,3}\b/gu) ?? []));
    for (const ruleId of referencedRuleIds) if (!ruleIds.has(ruleId)) issues.push(`${ruleId} is referenced but absent from reference/rules.json`);
  }
  return report("check-doc-consistency", root, issues, "DOC-CONSISTENCY-001", `Scanned ${files.length} active documentation and prompt files`);
}

function evaluateRouting(responsePath, options) {
  const expected = readJsonLines(resolve(guideRoot, "evals/routing-eval.jsonl"))
    .filter((item) => !options.split || item.split === options.split);
  const responses = readJsonLines(responsePath);
  const issues = [];
  const rows = [];
  const expectedById = new Map(expected.map((item) => [item.id, item]));
  for (const response of responses) {
    const fixture = expectedById.get(response.id);
    const run = response.run ?? 1;
    const runIssues = fixture ? routingEvalIssues(fixture, response) : [`unknown routing eval id ${String(response.id)}`];
    rows.push(evalRow("EVAL-ROUTING-001", response.id, run, runIssues, responsePath));
  }
  for (const fixture of expected) {
    if (!responses.some((response) => response.id === fixture.id)) {
      issues.push(`missing routing response for ${fixture.id}`);
      rows.push(evalRow("EVAL-ROUTING-001", fixture.id, "missing", [issues.at(-1)], responsePath));
    }
  }
  return evalReport("routing", responsePath, options, rows);
}

function routingEvalIssues(expected, actual) {
  const issues = [];
  const documents = Array.isArray(actual.documents) ? actual.documents : [];
  const includesDocument = (expectedDocument) => documents.some((document) =>
    document === expectedDocument || document.endsWith(`/${expectedDocument}`) || basename(document) === expectedDocument
  );
  if ((actual.shouldActivate ?? actual.mode !== null) !== (expected.shouldActivate ?? true)) issues.push("skill activation does not match expected routing");
  if ((actual.mode ?? null) !== (expected.expectedMode ?? null)) issues.push(`mode must be ${String(expected.expectedMode)}`);
  for (const document of [...(expected.requiredDocuments ?? []), ...(expected.conditionalDocuments ?? [])]) {
    if (!includesDocument(document)) issues.push(`required document is missing: ${document}`);
  }
  if (expected.mustNotRouteTo && actual.mode === expected.mustNotRouteTo) issues.push(`must not route to ${expected.mustNotRouteTo}`);
  if (expected.entryDocument && actual.entryDocument !== expected.entryDocument) issues.push(`entryDocument must be ${expected.entryDocument}`);
  if (expected.mustNotLoadAuthoringCorpus && actual.loadedAuthoringCorpus !== false) issues.push("authoring corpus must remain unloaded");
  if (expected.preserveExistingIntent && actual.preservedExistingIntent !== true) issues.push("existing intent preservation was not recorded");
  if (expected.expectedSkill && actual.skill !== expected.expectedSkill) issues.push(`skill must be ${expected.expectedSkill}`);
  return issues;
}

function evaluateExecution(responsePath, options) {
  const expected = readJsonLines(resolve(guideRoot, "evals/execution-eval.jsonl"))
    .filter((item) => !options.split || item.split === options.split);
  const responses = readJsonLines(responsePath);
  const rows = [];
  const expectedById = new Map(expected.map((item) => [item.id, item]));
  for (const response of responses) {
    const fixture = expectedById.get(response.id);
    const run = response.run ?? 1;
    const runIssues = fixture ? executionEvalIssues(fixture, response) : [`unknown execution eval id ${String(response.id)}`];
    rows.push(evalRow("EVAL-EXECUTION-001", response.id, run, runIssues, responsePath, response.metrics));
  }
  for (const fixture of expected) {
    if (!responses.some((response) => response.id === fixture.id)) {
      rows.push(evalRow("EVAL-EXECUTION-001", fixture.id, "missing", [`missing execution response for ${fixture.id}`], responsePath));
    }
  }
  return evalReport("execution", responsePath, options, rows);
}

function executionEvalIssues(expected, actual) {
  const issues = [];
  const ruleIds = new Set(actual.ruleIds ?? []);
  for (const ruleId of expected.expectedRuleIds ?? []) if (!ruleIds.has(ruleId)) issues.push(`expected rule ID is missing: ${ruleId}`);
  if (!isObject(actual.metrics)) return [...issues, "assessor metrics are missing"];
  for (const [metric, expectedValue] of Object.entries(expected.metrics ?? {})) {
    if (actual.metrics[metric] !== expectedValue) issues.push(`${metric} must equal ${expectedValue}`);
  }
  for (const metric of ["tokenUse", "unnecessaryQuestions"]) {
    if (!Number.isFinite(actual.metrics[metric]) || actual.metrics[metric] < 0) issues.push(`${metric} must be a non-negative number`);
  }
  return issues;
}

function compareEvals([baselinePath, candidatePath]) {
  const baseline = readJson(baselinePath);
  const candidate = readJson(candidatePath);
  const issues = [];
  if (baseline.evalKind !== candidate.evalKind) issues.push("evalKind differs between reports");
  if (baseline.model !== candidate.model) issues.push("model differs between reports");
  if (baseline.variant !== "without-skill") issues.push("baseline variant must be without-skill");
  if (candidate.variant !== "with-skill") issues.push("candidate variant must be with-skill");
  if (baseline.summary?.runs !== candidate.summary?.runs) issues.push("reports must contain the same number of runs");
  if (!deepEqual(baseline.caseRuns, candidate.caseRuns)) issues.push("reports must contain the same case/run matrix");
  if ((candidate.summary?.passRate ?? 0) < (baseline.summary?.passRate ?? 0)) issues.push("with-skill pass rate regressed");
  const lowerIsBetter = ["inventedManifestFields", "inventedSdkImports", "incorrectSelfServeAssumptions", "mismatchedIds", "skippedLifecycleHandling", "unsupportedCompletionClaims", "unnecessaryQuestions"];
  const higherIsBetter = ["packageValidationSuccess"];
  for (const metric of lowerIsBetter) {
    if ((candidate.metricTotals?.[metric] ?? 0) > (baseline.metricTotals?.[metric] ?? 0)) issues.push(`${metric} regressed`);
  }
  for (const metric of higherIsBetter) {
    if ((candidate.metricTotals?.[metric] ?? 0) < (baseline.metricTotals?.[metric] ?? 0)) issues.push(`${metric} regressed`);
  }
  const baseRow = evalRow("EVAL-COMPARISON-001", baseline.evalKind ?? "unknown", 1, issues, `${baselinePath} -> ${candidatePath}`);
  const output = evalReport("comparison", `${baselinePath} -> ${candidatePath}`, { model: candidate.model, variant: "comparison" }, [baseRow]);
  output.deltas = {
    passRate: (candidate.summary?.passRate ?? 0) - (baseline.summary?.passRate ?? 0),
    metrics: Object.fromEntries([...new Set([...Object.keys(baseline.metricTotals ?? {}), ...Object.keys(candidate.metricTotals ?? {})])].map((metric) => [metric, (candidate.metricTotals?.[metric] ?? 0) - (baseline.metricTotals?.[metric] ?? 0)]))
  };
  return output;
}

function evalRow(ruleId, caseId, run, issues, evidence, metrics = undefined) {
  return {
    rule_id: ruleId,
    case_id: caseId,
    run,
    applicability: "applicable",
    status: issues.length === 0 ? "pass" : "fail",
    evidence: [String(evidence)],
    issue: issues.length === 0 ? null : issues.join("; "),
    required_fix: issues.length === 0 ? null : "Correct the assessed response or the documentation/routing behavior, then rerun the eval.",
    verification: "Scored against the version-matched checked-in eval fixture.",
    ...(isObject(metrics) ? { metrics } : {})
  };
}

function evalReport(evalKind, target, options, rows) {
  const passedRuns = rows.filter((row) => row.status === "pass").length;
  const metricTotals = {};
  for (const row of rows) for (const [metric, value] of Object.entries(row.metrics ?? {})) {
    if (Number.isFinite(value)) metricTotals[metric] = (metricTotals[metric] ?? 0) + value;
  }
  return {
    status: rows.every((row) => row.status === "pass") ? "pass" : "fail",
    command: `evaluate-${evalKind}`,
    evalKind,
    target: String(target),
    model: options.model ?? "unspecified",
    variant: options.variant ?? "unspecified",
    split: options.split ?? "all",
    rows,
    metricTotals,
    caseRuns: rows.filter((row) => row.run !== "missing").map((row) => `${row.case_id}#${row.run}`).sort(),
    summary: { ...summarize(rows), runs: rows.length, passedRuns, passRate: rows.length === 0 ? 0 : passedRuns / rows.length }
  };
}

function validateRepository(repo, packagePath) {
  const manifestPath = resolve(repo, "cedros-extension.manifest.json");
  const reports = [checkRuntimeAlignment(repo), checkDocConsistency(repo)];
  if (existsSync(manifestPath)) {
    reports.unshift(validateManifest(manifestPath));
  } else {
    reports.unshift(report("validate-manifest", manifestPath, ["cedros-extension.manifest.json is missing"], "MANIFEST-SCHEMA-001", "Create the canonical extension manifest and rerun validation"));
  }
  const contextPath = resolve(repo, "extension-context.json");
  if (existsSync(contextPath)) {
    reports.push(validateContext(contextPath));
  } else {
    reports.push(notVerifiedReport("validate-context", contextPath, "CONTEXT-STATE-001", "extension-context.json is missing", "Create and validate the shared extension context before claiming release readiness"));
  }
  let resolvedPackagePath = packagePath ? resolve(packagePath) : null;
  if (!resolvedPackagePath) {
    try {
      const manifest = readJson(resolve(repo, "cedros-extension.manifest.json"));
      const expected = resolve(repo, "dist", `${manifest.extensionId}-${manifest.version}.cedros-extension.zip`);
      if (existsSync(expected)) resolvedPackagePath = expected;
      else reports.push(notVerifiedReport("validate-package", expected, "CED-AUTH-006", "final extension ZIP is missing", "Build the package and validate the final ZIP, not only the source tree"));
    } catch {
      // validateManifest already reports the missing or malformed manifest.
    }
  }
  if (resolvedPackagePath) reports.push(validatePackage(resolvedPackagePath));
  const rows = reports.flatMap((item) => item.rows);
  return {
    status: rows.some((row) => row.status === "fail")
      ? "fail"
      : rows.some((row) => row.status === "blocked" || row.status === "not-verified")
        ? "blocked"
        : "pass",
    command: "validate",
    repository: repo,
    rows,
    summary: summarize(rows)
  };
}

function validateManifestValue(manifest) {
  const schema = readJson(resolve(guideRoot, "schemas/extension-manifest.schema.json"));
  const issues = validateSchema(schema, manifest);
  for (const member of ["server", "react", "reactNative"]) {
    const value = manifest.packageFamily?.[member];
    if (isObject(value) && value.version !== manifest.version) issues.push(`packageFamily.${member}.version must equal manifest version`);
  }
  for (const [moduleIndex, module] of (manifest.adminModules ?? []).entries()) {
    for (const [sectionIndex, sectionId] of (module.sectionIds ?? []).entries()) {
      const localId = typeof sectionId === "string" ? sectionId.split(":").at(-1) : null;
      if (!module.sectionIcons?.[sectionId] && (!localId || !module.sectionIcons?.[localId])) {
        issues.push(`adminModules[${moduleIndex}].sectionIcons must define an icon for sectionIds[${sectionIndex}] (${String(sectionId)})`);
      }
    }
  }
  if (JSON.stringify(manifest).includes(OBSOLETE_HOST)) issues.push("obsolete Cedros skill hostname is forbidden");
  return issues;
}

function validateSchema(rootSchema, value) {
  const issues = [];
  visitSchema(rootSchema, value, "$", rootSchema, issues);
  return issues;
}

function visitSchema(schema, value, path, rootSchema, issues) {
  if (schema.$ref) {
    const target = resolveLocalRef(rootSchema, schema.$ref);
    if (!target) {
      issues.push(`${path} references missing schema ${schema.$ref}`);
      return;
    }
    visitSchema(target, value, path, rootSchema, issues);
    return;
  }
  if (schema.anyOf && !schema.anyOf.some((candidate) => schemaMatches(candidate, value, path, rootSchema))) {
    issues.push(`${path} must match one allowed schema`);
    return;
  }
  if (schema.oneOf && schema.oneOf.filter((candidate) => schemaMatches(candidate, value, path, rootSchema)).length !== 1) {
    issues.push(`${path} must match exactly one allowed schema`);
    return;
  }
  if (schema.const !== undefined && !deepEqual(value, schema.const)) issues.push(`${path} must equal ${JSON.stringify(schema.const)}`);
  if (schema.enum && !schema.enum.some((candidate) => deepEqual(value, candidate))) issues.push(`${path} must be one of ${schema.enum.map(JSON.stringify).join(", ")}`);
  if (schema.type && !matchesType(value, schema.type)) {
    issues.push(`${path} must be ${schema.type}`);
    return;
  }
  if (typeof value === "string") {
    if (schema.minLength !== undefined && value.length < schema.minLength) issues.push(`${path} must have at least ${schema.minLength} characters`);
    if (schema.pattern && !new RegExp(schema.pattern, "u").test(value)) issues.push(`${path} must match ${schema.pattern}`);
    if (schema.maxLength !== undefined && value.length > schema.maxLength) issues.push(`${path} must have at most ${schema.maxLength} characters`);
    if (schema.format === "date-time" && Number.isNaN(Date.parse(value))) issues.push(`${path} must be an RFC 3339 date-time`);
  }
  if (typeof value === "number") {
    if (schema.minimum !== undefined && value < schema.minimum) issues.push(`${path} must be at least ${schema.minimum}`);
    if (schema.maximum !== undefined && value > schema.maximum) issues.push(`${path} must be at most ${schema.maximum}`);
  }
  if (Array.isArray(value)) {
    if (schema.minItems !== undefined && value.length < schema.minItems) issues.push(`${path} must contain at least ${schema.minItems} items`);
    if (schema.maxItems !== undefined && value.length > schema.maxItems) issues.push(`${path} must contain at most ${schema.maxItems} items`);
    if (schema.uniqueItems && new Set(value.map((item) => JSON.stringify(item))).size !== value.length) issues.push(`${path} items must be unique`);
    if (schema.items) value.forEach((item, index) => visitSchema(schema.items, item, `${path}[${index}]`, rootSchema, issues));
  }
  if (isObject(value)) {
    for (const key of schema.required ?? []) if (!(key in value)) issues.push(`${path}.${key} is required`);
    for (const [key, child] of Object.entries(schema.properties ?? {})) {
      if (key in value) visitSchema(child, value[key], `${path}.${key}`, rootSchema, issues);
    }
    if (schema.additionalProperties === false) {
      const allowed = new Set(Object.keys(schema.properties ?? {}));
      for (const key of Object.keys(value)) if (!allowed.has(key)) issues.push(`${path}.${key} is not allowed`);
    } else if (isObject(schema.additionalProperties)) {
      const declared = new Set(Object.keys(schema.properties ?? {}));
      for (const [key, child] of Object.entries(value)) {
        if (!declared.has(key)) visitSchema(schema.additionalProperties, child, `${path}.${key}`, rootSchema, issues);
      }
    }
  }
}

function schemaMatches(schema, value, path, rootSchema) {
  const candidateIssues = [];
  visitSchema(schema, value, path, rootSchema, candidateIssues);
  return candidateIssues.length === 0;
}

function resolveLocalRef(rootSchema, reference) {
  if (!reference.startsWith("#/")) return null;
  return reference.slice(2).split("/").reduce((value, token) => value?.[token.replaceAll("~1", "/").replaceAll("~0", "~")], rootSchema);
}

function matchesType(value, type) {
  if (Array.isArray(type)) return type.some((candidate) => matchesType(value, candidate));
  if (type === "object") return isObject(value);
  if (type === "array") return Array.isArray(value);
  if (type === "integer") return Number.isInteger(value);
  if (type === "number") return typeof value === "number" && Number.isFinite(value);
  if (type === "string") return typeof value === "string";
  if (type === "boolean") return typeof value === "boolean";
  if (type === "null") return value === null;
  return false;
}

function readCargoIdentity(toml) {
  const read = (sectionName, key, required = true) => {
    let section = "";
    for (const rawLine of toml.split(/\r?\n/u)) {
      const line = rawLine.trim();
      const sectionMatch = line.match(/^\[([^\]]+)\]$/u);
      if (sectionMatch) {
        section = sectionMatch[1].trim();
        continue;
      }
      if (section !== sectionName) continue;
      const match = line.match(new RegExp(`^${key}\\s*=\\s*(?:"([^"]+)"|'([^']+)')`, "u"));
      if (match) return match[1] ?? match[2];
    }
    if (required) return null;
    return undefined;
  };
  const packageName = read("package", "name");
  return {
    packageName,
    version: read("package", "version"),
    libName: read("lib", "name", false) ?? packageName?.replaceAll("-", "_")
  };
}

function deepEqual(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}

function report(commandName, target, issues, ruleId, verification) {
  const rows = issues.length === 0
    ? [{ rule_id: ruleId, applicability: "applicable", status: "pass", evidence: [String(target)], issue: null, required_fix: null, verification }]
    : issues.map((issue) => ({ rule_id: ruleId, applicability: "applicable", status: "fail", evidence: [String(target)], issue, required_fix: issue, verification }));
  return { status: issues.length === 0 ? "pass" : "fail", command: commandName, target: String(target), rows, summary: summarize(rows) };
}

function summarize(rows) {
  return {
    pass: rows.filter((row) => row.status === "pass").length,
    fail: rows.filter((row) => row.status === "fail").length,
    blocked: rows.filter((row) => row.status === "blocked").length,
    not_verified: rows.filter((row) => row.status === "not-verified").length
  };
}

function readJson(path) {
  if (!existsSync(path)) throw usageError(`${path} does not exist`);
  try {
    return JSON.parse(readFileSync(path, "utf8"));
  } catch (error) {
    throw usageError(`${path} is not valid JSON: ${error.message}`);
  }
}

function readJsonLines(path) {
  if (!existsSync(path)) throw usageError(`${path} does not exist`);
  return readFileSync(path, "utf8").split(/\r?\n/u).filter((line) => line.trim()).map((line, index) => {
    try {
      return JSON.parse(line);
    } catch (error) {
      throw usageError(`${path}:${index + 1} is not valid JSON: ${error.message}`);
    }
  });
}

function walk(root) {
  if (!existsSync(root)) return [];
  if (!statSync(root).isDirectory()) return [root];
  const paths = [];
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    if ([".git", "node_modules", "target", "dist", "build", "archive"].includes(entry.name)) continue;
    const path = resolve(root, entry.name);
    if (entry.isDirectory()) paths.push(...walk(path));
    else if (entry.isFile()) paths.push(path);
  }
  return paths;
}

function markdownFileTargets(markdown) {
  const targets = [];
  for (const match of markdown.matchAll(/!?(?:\[[^\]]*\])\(([^)]+)\)/gu)) {
    const raw = match[1].trim().replace(/^<|>$/gu, "");
    const target = raw.split(/\s+["']/u, 1)[0].split("#", 1)[0].split("?", 1)[0];
    if (!target || target.startsWith("/") || target.startsWith("#") || target.includes("{{")) continue;
    if (/^[a-z][a-z0-9+.-]*:/iu.test(target)) continue;
    try {
      targets.push(decodeURIComponent(target));
    } catch {
      targets.push(target);
    }
  }
  return targets;
}

function normativeParagraphs(markdown) {
  const paragraphs = [];
  let fenced = false;
  let current = [];
  const flush = () => {
    const paragraph = current.join("\n").trim();
    current = [];
    if (!paragraph || paragraph.startsWith("`MUST`, `MUST NOT`")) return;
    if (/\b(?:MUST NOT|MUST|SHOULD NOT|SHOULD|MAY)\b/u.test(paragraph)) paragraphs.push(paragraph);
  };
  for (const line of markdown.split(/\r?\n/u)) {
    if (/^\s*```/u.test(line)) {
      flush();
      fenced = !fenced;
      continue;
    }
    if (fenced) continue;
    if (!line.trim()) flush();
    else current.push(line);
  }
  flush();
  return paragraphs;
}

function hasWasmDeclaration(path) {
  if (!existsSync(path)) return false;
  try {
    const manifest = readJson(path);
    return [...(manifest.surfaces?.server?.routes ?? []), ...(manifest.surfaces?.server?.jobs ?? [])].length > 0;
  } catch {
    return false;
  }
}

function hasWasmImplementation(repo) {
  return walk(repo).some((path) => {
    if (basename(path) === "cedros-extension.server.wasm") return true;
    if (!/\.(?:rs|toml)$/u.test(path)) return false;
    const text = readFileSync(path, "utf8");
    return /wit[-_]bindgen|generate!\s*\(/u.test(text);
  });
}

function resolveWitContract() {
  const candidates = [
    resolve(guideRoot, "../cedros-extension.wit"),
    resolve(guideRoot, "../../wit/cedros-extension.wit"),
    resolve(guideRoot, "../../server/wit/cedros-extension.wit")
  ];
  return candidates.find((path) => existsSync(path)) ?? candidates[0];
}

function resolveDesignAdmin() {
  const candidates = [
    resolve(guideRoot, "../../assets/design-admin.md"),
    resolve(guideRoot, "../../design-admin.md")
  ];
  return candidates.find((path) => existsSync(path)) ?? candidates[0];
}

function resolveOperatorSkill() {
  const candidates = [
    resolve(skillRoot, "../admin-site-operator/SKILL.md"),
    resolve(guideRoot, "../../server/assets/assistant-skills/admin-site-operator/SKILL.md")
  ];
  return candidates.find((path) => existsSync(path)) ?? candidates[0];
}

function requestedSurfaces(options, manifestPath, repo) {
  const requested = new Set((options.surfaces ?? "").split(",").map((value) => value.trim()).filter(Boolean));
  let manifest = {};
  if (existsSync(manifestPath)) {
    try {
      manifest = readJson(manifestPath);
    } catch {
      return requested;
    }
  }
  const add = (condition, ...surfaces) => {
    if (condition) surfaces.forEach((surface) => requested.add(surface));
  };
  add(hasWasmDeclaration(manifestPath) || hasWasmImplementation(repo), "wasm");
  add((manifest.adminModules?.length ?? 0) > 0 || (manifest.surfaces?.admin?.moduleIds?.length ?? 0) > 0, "admin");
  add((manifest.databaseAccess?.length ?? 0) > 0, "database");
  add((manifest.surfaces?.server?.settingsSchemas?.length ?? 0) > 0, "settings");
  add((manifest.providerAccess?.length ?? 0) > 0, "providers");
  add((manifest.surfaces?.server?.jobs?.length ?? 0) > 0 || (manifest.jobSchedules?.length ?? 0) > 0, "jobs");
  add((manifest.pageSeeds?.length ?? 0) > 0 || (manifest.seoRoutes?.length ?? 0) > 0 || (manifest.surfaces?.web?.routeIds?.length ?? 0) > 0, "public-seo");
  add((manifest.contentBlocks?.length ?? 0) > 0 || (manifest.contentTemplates?.length ?? 0) > 0 || (manifest.authoredSurfaces?.length ?? 0) > 0, "blocks");
  add((manifest.setupSeeds && Object.keys(manifest.setupSeeds).length > 0) || (manifest.formTemplates?.length ?? 0) > 0 || (manifest.docsArticles?.length ?? 0) > 0 || (manifest.policies?.length ?? 0) > 0 || (manifest.onboardingPages?.length ?? 0) > 0, "content-starters");
  add((manifest.analytics?.events?.length ?? 0) > 0, "analytics");
  add(manifest.surfaces?.ai !== undefined, "ai");
  add((manifest.dependencies?.services?.length ?? 0) > 0 || (manifest.dependencies?.capabilities?.length ?? 0) > 0, "official-integrations");
  add((manifest.dependencies?.extensions?.length ?? 0) > 0, "composability");
  add((manifest.customerTagAccess?.length ?? 0) > 0 || (manifest.crmSourceAccess?.length ?? 0) > 0, "crm");
  add((manifest.surfaces?.native?.screenIds?.length ?? 0) > 0 || (manifest.surfaces?.native?.stackIds?.length ?? 0) > 0 || (manifest.surfaces?.native?.providerIds?.length ?? 0) > 0, "native");
  return requested;
}

function surfaceDocuments(surfaces) {
  const mapping = {
    wasm: "07-wasm-server-backends.md",
    database: "08-site-database.md",
    settings: "09-settings-secrets-and-state.md",
    providers: "10-host-providers.md",
    jobs: "11-jobs-and-scheduling.md",
    admin: "12-admin-pages-and-dashboard-cards.md",
    "public-seo": "13-public-pages-and-seo.md",
    blocks: "14-blocks-templates-and-styling.md",
    "content-starters": "15-content-starters-and-onboarding.md",
    analytics: "16-analytics-and-site-brain.md",
    ai: "17-ai-skills-and-capabilities.md",
    "official-integrations": "18-official-extension-integrations.md",
    composability: "19-composability-and-relying-party-contracts.md",
    crm: "20-crm-tags-and-source-events.md",
    native: "21-host-coordination-and-native.md"
  };
  const documents = [];
  const reasons = [];
  const unsupported = [];
  for (const surface of [...surfaces].sort()) {
    const document = mapping[surface];
    if (!document) {
      unsupported.push(surface);
      continue;
    }
    documents.push(document);
    reasons.push(`${surface} -> ${document}`);
  }
  return { documents, reasons, unsupported };
}

function validatePackagedClient(archivePath, entries, member, packageRoot, requiredExports, issues) {
  const packageEntry = `${packageRoot}/package.json`;
  if (!entries.includes(packageEntry)) {
    issues.push(`${packageEntry} is missing`);
    return;
  }
  try {
    const packageJson = JSON.parse(execFileSync("unzip", ["-p", archivePath, packageEntry], { encoding: "utf8" }));
    if (packageJson.name !== member?.packageName) issues.push(`${packageEntry} name does not match packageFamily`);
    if (packageJson.version !== member?.version) issues.push(`${packageEntry} version does not match packageFamily`);
    for (const exportName of requiredExports) {
      const exportPath = packageJson.exports?.[exportName];
      if (typeof exportPath !== "string" || !exportPath.startsWith("./")) {
        issues.push(`${packageEntry} ${exportName} export must be a package-relative string`);
        continue;
      }
      const compiledEntry = `${packageRoot}/${exportPath.slice(2)}`;
      if (!entries.includes(compiledEntry)) issues.push(`${exportName} compiled runtime is missing at ${compiledEntry}`);
    }
  } catch (error) {
    issues.push(`${packageEntry} is invalid: ${error.message}`);
  }
}

function blockedReport(commandName, blockingRule, reason, evidence, workStillCompleted, requiredResolution) {
  return {
    status: "blocked",
    command: commandName,
    blockingRule,
    reason,
    evidence,
    workStillCompleted,
    requiredResolution,
    rows: [{
      rule_id: blockingRule,
      applicability: "applicable",
      status: "blocked",
      evidence,
      issue: reason,
      required_fix: requiredResolution,
      verification: "Fetch the missing reference and rerun path resolution"
    }],
    summary: { pass: 0, fail: 0, blocked: 1 }
  };
}

function notVerifiedReport(commandName, target, ruleId, issue, requiredFix) {
  const rows = [{
    rule_id: ruleId,
    applicability: "applicable",
    status: "not-verified",
    evidence: [String(target)],
    issue,
    required_fix: requiredFix,
    verification: requiredFix
  }];
  return { status: "blocked", command: commandName, target: String(target), rows, summary: summarize(rows) };
}

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function isObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function usage(message) {
  throw usageError(`${message}. Commands: resolve-path, validate-context, validate-manifest, validate-package, check-runtime-alignment, check-doc-consistency, evaluate-routing, evaluate-execution, compare-evals, validate`);
}

function usageError(message) {
  const error = new Error(message);
  error.exitCode = EXIT_USAGE;
  return error;
}

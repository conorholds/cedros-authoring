import assert from "node:assert/strict";
import { execFileSync, spawnSync } from "node:child_process";
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const guideRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const command = resolve(guideRoot, "scripts/cedros-authoring.mjs");
const minimal = resolve(guideRoot, "examples/minimal-extension");

test("resolve-path selects the audit path without over-routing a UI-only extension to Wasm", () => {
  const report = run("resolve-path", "--repo", minimal);
  assert.equal(report.status, "pass");
  assert.equal(report.mode, "audit-repair-extension");
  assert(!report.requiredDocuments.some((path) => basename(path) === "07-wasm-server-backends.md"));
  assert(report.requiredDocuments.every(existsSync));
});

test("resolve-path emits existing local Wasm references only when Wasm is present", () => {
  const wasm = resolve(guideRoot, "examples/extension-with-server-wasm");
  const report = run("resolve-path", "--repo", wasm);
  assert.equal(report.status, "pass");
  assert(report.requiredDocuments.some((path) => basename(path) === "07-wasm-server-backends.md"));
  assert(report.requiredDocuments.some((path) => basename(path) === "cedros-extension.wit"));
  assert(report.requiredDocuments.every(existsSync));
});

test("operate-live-site never loads authoring documents even for a Wasm repository", () => {
  const wasm = resolve(guideRoot, "examples/extension-with-server-wasm");
  const report = run("resolve-path", "--repo", wasm, "--mode", "operate-live-site");
  assert.equal(report.status, "pass");
  assert.match(report.entryDocument, /admin-site-operator\/SKILL\.md$/);
  assert.deepEqual(report.requiredDocuments, [report.entryDocument]);
  assert(!report.requiredDocuments.some((path) => path.includes("extension-authoring")));
});

test("validate-manifest accepts the canonical minimal example", () => {
  const report = run("validate-manifest", resolve(minimal, "cedros-extension.manifest.json"));
  assert.equal(report.status, "pass");
  assert.equal(report.summary.fail, 0);
});

test("validate-manifest rejects invented fields inside a normative surface", () => {
  const fixture = resolve(mkdtempSync(resolve(tmpdir(), "cedros-authoring-")), "cedros-extension.manifest.json");
  const manifest = JSON.parse(readFileSync(resolve(minimal, "cedros-extension.manifest.json"), "utf8"));
  manifest.surfaces.server.inventedRuntime = true;
  writeFileSync(fixture, `${JSON.stringify(manifest, null, 2)}\n`);
  const result = spawnSync(process.execPath, [command, "validate-manifest", fixture], { encoding: "utf8" });
  assert.equal(result.status, 1);
  assert.match(result.stdout, /inventedRuntime is not allowed/);
});

test("validate-manifest rejects incomplete admin fallback metadata", () => {
  const fixture = resolve(mkdtempSync(resolve(tmpdir(), "cedros-authoring-")), "cedros-extension.manifest.json");
  const manifest = JSON.parse(readFileSync(resolve(guideRoot, "examples/extension-with-admin-ui/cedros-extension.manifest.json"), "utf8"));
  delete manifest.adminModules[0].sectionIcons;
  writeFileSync(fixture, `${JSON.stringify(manifest, null, 2)}\n`);
  const result = spawnSync(process.execPath, [command, "validate-manifest", fixture], { encoding: "utf8" });
  assert.equal(result.status, 1);
  assert.match(result.stdout, /sectionIcons must define an icon/);
});

test("validate-context fails closed on incomplete state", () => {
  const result = spawnSync(process.execPath, [command, "validate-context", resolve(guideRoot, "schemas/extension-manifest.schema.json")], { encoding: "utf8" });
  assert.equal(result.status, 1);
  const report = JSON.parse(result.stdout);
  assert.equal(report.status, "fail");
  assert(report.rows.some((row) => row.rule_id === "CONTEXT-STATE-001"));
});

test("check-doc-consistency rejects the obsolete canonical skill host", () => {
  const fixture = resolve(mkdtempSync(resolve(tmpdir(), "cedros-authoring-")), "obsolete-host.md");
  writeFileSync(fixture, `${"https://cedroscloud.com/"}${"skill.md"}\n`);
  const result = spawnSync(process.execPath, [command, "check-doc-consistency", fixture], { encoding: "utf8" });
  assert.equal(result.status, 1);
  assert.match(result.stdout, /cedroscloud\.com\/skill\.md/);
});

test("check-doc-consistency rejects broken relative Markdown links", () => {
  const fixture = resolve(mkdtempSync(resolve(tmpdir(), "cedros-authoring-docs-")), "broken.md");
  writeFileSync(fixture, "[missing](./does-not-exist.md)\n");
  const result = spawnSync(process.execPath, [command, "check-doc-consistency", fixture], { encoding: "utf8" });
  assert.equal(result.status, 1);
  assert.match(result.stdout, /links to missing local file/);
});

test("check-doc-consistency rejects normative statements without stable rule IDs", () => {
  const fixture = resolve(mkdtempSync(resolve(tmpdir(), "cedros-authoring-rules-")), "untagged.md");
  writeFileSync(fixture, "An extension MUST invent nothing.\n");
  const result = spawnSync(process.execPath, [command, "check-doc-consistency", fixture], { encoding: "utf8" });
  assert.equal(result.status, 1);
  assert.match(result.stdout, /unregistered normative statement/);
});

test("evaluate-routing scores repeated positive and negative cases", () => {
  const fixture = resolve(mkdtempSync(resolve(tmpdir(), "cedros-routing-eval-")), "responses.jsonl");
  writeFileSync(fixture, [
    JSON.stringify({ id: "route-live-operator", run: 1, shouldActivate: true, mode: "operate-live-site", documents: [], entryDocument: "https://cedros.ai/skills/admin-site-operator.md", loadedAuthoringCorpus: false }),
    JSON.stringify({ id: "negative-generic-react", run: 1, shouldActivate: false, mode: null, documents: [] }),
    JSON.stringify({ id: "negative-theme-only", run: 1, shouldActivate: false, mode: null, documents: [], skill: "cedros-theme-authoring" })
  ].join("\n") + "\n");
  const report = runAllowFailure("evaluate-routing", fixture, "--split", "validation", "--model", "fixture-model", "--variant", "with-skill");
  assert.equal(report.status, "fail");
  assert.equal(report.model, "fixture-model");
  assert(report.rows.some((row) => row.run === "missing"));
  assert(report.rows.some((row) => row.case_id === "route-live-operator" && row.status === "pass"));
});

test("evaluate-execution requires assessor metrics and compares with/without-skill reports", () => {
  const directory = mkdtempSync(resolve(tmpdir(), "cedros-execution-eval-"));
  const responses = resolve(directory, "responses.jsonl");
  writeFileSync(responses, JSON.stringify({
    id: "exec-denied-provider",
    run: 1,
    ruleIds: ["CED-AUTH-004", "CED-AUTH-006"],
    metrics: { incorrectSelfServeAssumptions: 0, unsupportedCompletionClaims: 0, tokenUse: 900, unnecessaryQuestions: 0 }
  }) + "\n");
  const candidate = runAllowFailure("evaluate-execution", responses, "--split", "validation", "--model", "fixture-model", "--variant", "with-skill");
  assert.equal(candidate.status, "fail");
  assert(candidate.rows.some((row) => row.case_id === "exec-denied-provider" && row.status === "pass"));

  const baselinePath = resolve(directory, "baseline.json");
  const candidatePath = resolve(directory, "candidate.json");
  const caseRuns = ["exec-denied-provider#1"];
  const baseline = { ...candidate, status: "pass", variant: "without-skill", rows: [candidate.rows.find((row) => row.case_id === "exec-denied-provider")], metricTotals: { incorrectSelfServeAssumptions: 1, unsupportedCompletionClaims: 1, tokenUse: 700, unnecessaryQuestions: 1 }, caseRuns, summary: { pass: 0, fail: 1, blocked: 0, not_verified: 0, runs: 1, passedRuns: 0, passRate: 0 } };
  const improved = { ...candidate, status: "pass", variant: "with-skill", rows: [candidate.rows.find((row) => row.case_id === "exec-denied-provider")], caseRuns, summary: { pass: 1, fail: 0, blocked: 0, not_verified: 0, runs: 1, passedRuns: 1, passRate: 1 } };
  writeFileSync(baselinePath, JSON.stringify(baseline));
  writeFileSync(candidatePath, JSON.stringify(improved));
  const comparison = run("compare-evals", baselinePath, candidatePath);
  assert.equal(comparison.status, "pass");
  assert.equal(comparison.deltas.passRate, 1);
});

test("validate-package rejects a bootstrap projection that differs from its manifest", () => {
  const fixture = mkdtempSync(resolve(tmpdir(), "cedros-authoring-package-"));
  const manifest = JSON.parse(readFileSync(resolve(minimal, "cedros-extension.manifest.json"), "utf8"));
  writeFileSync(resolve(fixture, "cedros-extension.manifest.json"), `${JSON.stringify(manifest)}\n`);
  manifest.displayName = "Stale bootstrap";
  writeFileSync(resolve(fixture, "cedros-extension.bootstrap.json"), `${JSON.stringify({ manifest })}\n`);
  execFileSync("zip", ["-q", "fixture.zip", "cedros-extension.manifest.json", "cedros-extension.bootstrap.json"], { cwd: fixture });
  const result = spawnSync(process.execPath, [command, "validate-package", resolve(fixture, "fixture.zip")], { encoding: "utf8" });
  assert.equal(result.status, 1);
  assert.match(result.stdout, /manifest must exactly match/);
});

test("aggregate validation reports a missing manifest without crashing", () => {
  const fixture = mkdtempSync(resolve(tmpdir(), "cedros-authoring-repo-"));
  const result = spawnSync(process.execPath, [command, "validate", "--repo", fixture], { encoding: "utf8" });
  assert.equal(result.status, 1);
  const report = JSON.parse(result.stdout);
  assert.equal(report.status, "fail");
  assert(report.rows.some((row) => row.rule_id === "MANIFEST-SCHEMA-001" && row.status === "fail"));
});

function run(...args) {
  return JSON.parse(execFileSync(process.execPath, [command, ...args], { encoding: "utf8" }));
}

function runAllowFailure(...args) {
  const result = spawnSync(process.execPath, [command, ...args], { encoding: "utf8" });
  assert.equal(result.status, 1);
  return JSON.parse(result.stdout);
}

# 03 · Planning an Extension

Read this before writing manifest fields or package code. It turns a product
idea (or an existing codebase) into a concrete surface plan: which surfaces
the extension needs, how each is classified (self-serve / metadata-first /
host-coordinated), which dependencies and capabilities it requires, and what
stays open. The classifications come from
[`01-extension-system-overview.md`](01-extension-system-overview.md).

For a bounded repair or feature edit, inspect the affected behavior and update
an existing brief/host-seam record where needed. Preserve decisions for untouched
surfaces. Do not restart product discovery or inventory the entire application
unless the request is a conversion, a broad audit, or its scope is genuinely unknown.
If the user already supplied the needed decisions, proceed without an interview.

For new extensions and conversions, choose the matching entry path:

- **Greenfield**: you have a product goal and no code. Produce a feature
  brief.
- **Existing codebase**: you are adapting a project into an extension. Audit
  the code first, then produce the same brief grounded in evidence.

## Greenfield: the feature brief

Work in two passes.

**Pass 1 — resolve only material gaps.** Use the supplied context and sensible
Cedros defaults. Ask concise questions only when their answers change design, manifest,
surfaces, permissions, data model, or host handoff. Mark every non-blocking
assumption "Assumed unless corrected". If a surface is probably not needed,
say so and let the owner correct you. Do not ask about database access,
official extension integrations, or composability unless the product idea
indicates persistent extension-owned data, dependency on another extension, or
reusable cross-extension behavior.

Cover only the gaps that remain across:

- core outcome: problem solved and success signal
- users: owner, admin/operator, visitor, authenticated user, AI agent, mobile
  user
- workflows: top happy paths and the most important failure path
- surfaces: admin pages, dashboard cards, public pages, visual builder
  content, onboarding, form starters/docs drafts, analytics, site-brain/logging, AI
  skills/capabilities, host-provider usage, automation jobs, server APIs,
  native surfaces
- data and permissions: records owned, external data read/written,
  capabilities requested, sensitive data boundaries
- integrations: downstream APIs, services, credentials, webhooks, events,
  scheduled work
- trust posture: open source / source-available / private; repository and
  revision evidence; SBOM/provenance/signature goals
- launch behavior: install defaults, seeded content, publish/review behavior,
  rollout, rollback, host-coordinated work

**Pass 2 — produce the brief.** Use answers already available and make reasonable
decisions where details are still missing; bounce back only when a missing
answer blocks manifest correctness, security, permissions, route ownership, or
host integration. The brief contains:

- feature summary, user stories, design decisions made, open assumptions,
  blocking unknowns
- the **surface inventory table**:

  | Surface | Needed? | Classification | Manifest path | Runtime package | Host handoff | Acceptance check |
  |---|---:|---|---|---|---|---|

- the **dependency table** (for official/composable extension dependencies,
  `Published status` must be one of `published`, `draft`, `planned`,
  `host-coordinated`, or `unavailable`; non-published required dependencies go
  to host handoff and release risk, never treated as live):

  | Dependency | Type | Required? | Published status | Owner enters/configures | Failure state |
  |---|---|---:|---|---|---|

- data and permission model; source/provenance plan (or "not provided for
  this release"); manifest contribution list; ZIP-contained runtime
  contribution list; host handoff list; acceptance tests; rollout/rollback
  notes; versioning notes

## Existing codebase: the audit

Do not start by asking product-discovery questions — inspect the repository
first, then ask only what inspection cannot answer. The output is the same
brief as above, grounded in evidence: describe the real implemented product,
not the intended product.

Work in four passes:

**Pass 1 — repository inventory.** App/package structure, frameworks,
build/test commands, public routes/pages, admin routes/pages, API handlers,
jobs, database models/migrations, forms/actions, provider/API clients,
auth/session assumptions, permission checks, analytics, logs, AI behavior,
native code, docs/form-policy starter content, config/env/secrets assumptions,
tests/fixtures/mocks.

**Pass 2 — core functionality verification.** Classify every discovered
feature: `complete-wired`, `complete-needs-formatting`, `partial`,
`present-not-wired`, `placeholder`, `mock-only`, `broken`,
`dead-code-candidate`, `host-coordinated`, `unknown`. For each core workflow,
trace entry point → UI → data path → action → backend → persistence →
success/error states → permission boundary → external service boundary →
verification evidence. Do not mark a workflow complete just because a
component or handler exists.

**Pass 3 — Cedros surface mapping.** Map existing functionality onto the
surface inventory (manifest/package, admin pages, dashboard cards, page
seeds, blocks/templates, onboarding, starters, analytics, site-brain, AI,
providers, database, official integrations, jobs, routes, native, archive,
release) and classify each as self-serve / metadata-first / host-coordinated /
not needed.

**Pass 4 — gap and risk review.** Broken workflows, missing wiring/handlers/
persistence, unsafe secret handling, raw-PII logging, direct database access
that must become host-mediated, provider keys that must become host provider
access or host secrets, private host-app assumptions, mock/demo code in
production paths, missing states/permission checks/idempotency/tests, and
unclear package/deploy requirements.

## Required host-seam decision record

The detailed contracts are intentionally split by responsibility, but the
decision cannot be. For a new extension or conversion, record one row for every seam below,
including an explicit `not needed` row. This prevents a conversion from
quietly dropping an existing feature because its provider, identity, audit, or
storage boundary lives in a different guide.

| Seam | Evidence that makes it applicable | Self-serve host path | Required failure/lifecycle decision | Read |
|---|---|---|---|---|
| Managed intelligence and other providers | AI/image/voice/email/storage clients, BYOK UI, direct third-party calls | namespaced `providerAccess[]` + Wasm `providers.execute`; site owns provider/model/credentials | provider missing/disabled/denied; timeout, retry/idempotency, cost and safe usage tags | [`10`](10-host-providers.md) |
| Host identity, login, authorization, CSRF | sessions, user/team roles, private/admin routes, owner-only actions | host route `contextJson`; require `authenticated`, then system-admin or declared permission claim; require `csrfVerified` for mutations | 401 vs 403; stale/malformed context; optional/required Login dependency and degraded mode | [`06`](06-runtime-sdk-reference.md), [`18`](18-official-extension-integrations.md) |
| Logs, observability, analytics, durable audit | console/server logs, operational history, security decisions, usage events | Wasm `logging.log` for transient diagnostics; declared analytics; `telemetry.emit-record` plus event/category scope for durable site-brain records | redaction, retention channel, denied audit emission, correlation/request id | [`16`](16-analytics-and-site-brain.md) |
| Payments and entitlements | checkout, plans, subscriptions, paid content/features, billing webhooks | published Cedros Pay/relying-party capability and entitlement contracts | deny by default on missing/invalid/ungranted entitlement; refund/cancel and dependency version behavior | [`18`](18-official-extension-integrations.md), [`contracts`](contracts/README.md) |
| Database and storage | IndexedDB/localStorage, ORM/models, files/blobs, shared records | `databaseAccess[]` + Wasm database import; storage provider access where applicable | site vs device ownership; idempotency/concurrency; export, retention, migration, uninstall choice | [`08`](08-site-database.md), [`10`](10-host-providers.md) |
| Settings and secrets | env vars, API keys, provider profiles, operator config | `settingsSchemas[]`; Wasm settings/secrets imports; site provider config for shared providers | defaults/validation; encryption availability; rotation/delete/redaction; update compatibility | [`09`](09-settings-secrets-and-state.md) |
| External egress | fetch/HTTP/webhook clients or remote imports | manifest allowlist + Wasm `http.fetch`, or a published managed provider/official extension contract | exact HTTPS hosts, timeout/body cap, SSRF-safe validation, retry/idempotency, disabled state | [`07`](07-wasm-server-backends.md), [`09`](09-settings-secrets-and-state.md) |
| Lifecycle | any durable data, schedule, route, seed, provider call, or external registration | normal install/enable/disable/update/uninstall host lifecycle | preserve stable ids; stop active behavior on disable; migration/rollback; explicit retain/delete on uninstall | [`23`](23-release-versioning-and-upgrades.md) |

For an existing browser application, “it currently uses IndexedDB/localStorage”
is evidence to decide ownership, not an automatic Cedros design. Keep it
browser-local only when the product is intentionally device/profile-local and
the owner accepts that Cedros cannot enforce operator-wide retention or
uninstall deletion. Otherwise use a same-host authenticated route and the
host-owned database/settings seam. Likewise, direct browser AI calls and raw
provider-key screens are evidence for managed `intelligence` provider access,
not a reason to omit the AI workflow.

For each applicable row, trace: browser/admin action → same-host route → host
identity/permission check → granted Wasm import or published dependency →
redacted diagnostic/audit outcome → disable/update/uninstall behavior. A
manifest declaration alone does not complete that trace.

## Default decisions

Use these unless the owner gives a reason not to:

- One shared `extensionId`; keep server, React, and React Native packages in
  the family.
- Put setup and operator controls in shared Cedros admin pages; put
  high-level health/stats in dashboard cards only when owners need them on
  the main dashboard.
- Use `pageSeeds` only for canonical public pages the extension should own;
  blocks/templates only for owner-editable content; `onboardingPages[]` only
  for steps that route to real admin pages.
- Declare analytics events only for product questions the owner can act on;
  publish site-brain records for durable operator-visible activity; use
  structured logs for diagnostics.
- Use AI skills/capabilities only when AI discovery or shared execution is
  part of the product.
- Use `providerAccess[]` for site-owned providers and `databaseAccess[]` for
  site Postgres — never raw credentials, raw pools, or browser/native
  database access.
- Treat dependencies on Cedros Login, Pay, Shop, Wallet, Compliance, or
  another extension family as official/composable contracts with required or
  optional dependency metadata, version bounds, and degraded modes.
- Treat server routes/jobs as wasm-backed by default; treat arbitrary native
  screens, bespoke typed SQL, and generic web routes as host-coordinated.
- Use `supplyChain` metadata only when real evidence exists; otherwise say
  "source evidence not provided for this release".
- Preserve released ids by default; treat id removals, required dependency
  changes, route ownership changes, and incompatible data changes as upgrade
  risks needing explicit versioning/migration/rollback notes.

Do not let the brief smuggle executable code into manifest metadata, page
seeds, logs, analytics payloads, or authored document props.

## Implementation mode

Planning is one step, not the deliverable. Once classification is done, do
the concrete work that is possible now — source files, manifests, package
exports, registration modules, validation scripts, tests, fail-closed states
— and reserve only true host-bound behavior for handoff:

| Situation | Required behavior |
|---|---|
| Self-serve and local code is available | Implement it now and validate it. |
| Self-serve but local code is missing | Create the minimal correct fail-closed state, schema, or validation path needed for later completion. |
| Metadata-first | Add the manifest/bootstrap/schema metadata now and clearly mark runtime behavior as not executable yet. |
| Host-coordinated | Implement the local side now — manifest ids, package exports, minimal fail-closed handlers, validation tests — plus a precise handoff row ([`21-host-coordination-and-native.md`](21-host-coordination-and-native.md)). |
| Blocked by missing owner input | Make the safest reasonable default, document the assumption, and continue — unless the missing answer creates a security, data-loss, or manifest-correctness risk. |
| Blocked by unavailable host access | Do not fake host behavior. Add the exact handoff row, local fail-closed behavior, and validation proving the extension side is ready for binding. |

When reporting results, separate: **implemented now**, **validated now**,
**host-coordinated and ready for binding**, **blocked by missing owner
input**, **deferred intentionally**. "Host-coordinated" is never a reason to
skip the local side.

## The shared context object (for agent-driven authoring)

When an AI agent drives authoring across multiple sessions, carry one context
object forward so later steps never re-ask answered questions. Update only
the fields a step owns; use empty arrays or `null` for unknowns and put
blocking unknowns in `openQuestions`.

```json
{
  "extensionId": "",
  "displayName": "",
  "version": "",
  "businessGoal": "",
  "targetUsers": [],
  "primaryWorkflows": [],
  "publicSurfaces": [],
  "adminSurfaces": [],
  "dashboardCards": [],
  "visualBuilderNeeds": [],
  "onboardingSteps": [],
  "formsDocsStarters": [],
  "analyticsEvents": [],
  "setupSeeds": { "scheduling": [], "productCollections": [], "products": [], "notifications": [], "contractTemplates": [], "emailTemplates": [] },
  "siteBrainLoggingNeeds": [],
  "aiSkillsCapabilities": [],
  "providerAccess": [],
  "databaseAccess": [],
  "customerTagAccess": [],
  "sourceProvenanceTrustEvidence": { "repositoryUrl": null, "revision": null, "license": null, "sbom": null, "provenance": null, "signatures": [], "artifactDigests": [], "rebuildCommand": null, "computedVerificationStatus": null },
  "officialExtensionDependencies": [],
  "extensionComposabilityContracts": [],
  "automationJobs": [],
  "serverRoutes": [],
  "nativeSurfaces": [],
  "settings": [],
  "secrets": [],
  "permissions": [],
  "dependencies": [],
  "hostCoordinatedItems": [],
  "liveOnInstallBehavior": [],
  "metadataOnlyBehavior": [],
  "rolloutAssumptions": [],
  "rollbackAssumptions": [],
  "knownRisks": [],
  "openQuestions": []
}
```

## Acceptance checks for the plan

- Every requested surface is classified as self-serve, metadata-first,
  host-coordinated executable work, or not needed.
- Every required downstream API/service/secret is listed.
- Any live-on-install behavior has an explicit runtime path.
- Any metadata-only behavior is clearly labeled so no one expects it to
  execute by itself.
- Later implementation blockers are limited to real security, data-loss,
  manifest-correctness, unavailable-host-access, or missing-owner-input
  risks.

Next: [`04-manifest-reference.md`](04-manifest-reference.md).

### Keep marketing pages site-owned

Expose reusable data and actions for customer websites to consume. Pricing and
program marketing pages belong to the site, even when their prices and checkout
come from an extension. Do not automatically claim those routes or require a
customer to customize the extension to change page content. See
[public-page ownership](13-public-pages-and-seo.md#choose-the-right-owner).

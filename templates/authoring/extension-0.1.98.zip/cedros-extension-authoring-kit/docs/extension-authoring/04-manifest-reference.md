# 04 · Manifest Reference

This is the field-level source of truth for `cedros-extension.manifest.json`.
Every manifest field an extension can declare is defined here — the root
manifest, package family, surfaces, contributions, setup seeds, starters, AI
surfaces, provider/database/customer-tag/CRM access, and the SEO metadata
contract. Surface guides add usage guidance, but field names and validation
rules resolve back to this document.

Universal rule: if a field, SDK method, contract, content-model format,
migration runner, official extension capability, or host service is not
explicitly documented here or in
[`07-wasm-server-backends.md`](07-wasm-server-backends.md) /
[`06-runtime-sdk-reference.md`](06-runtime-sdk-reference.md), treat it as
host-coordinated and document the handoff
([`21-host-coordination-and-native.md`](21-host-coordination-and-native.md))
instead of using it as live behavior. Do not invent manifest fields.

Status labels used in this reference:

- **Manifest field**: accepted in `cedros-extension.manifest.json`.
- **Runtime/bootstrap field**: returned by package registration, not manifest
  metadata.
- **Handoff guidance**: documented in plans or host tickets, not accepted as
  manifest JSON.

Fields marked `stable string` are extension-defined unless this document lists
an enum. Use lowercase kebab-case where the value is machine-joinable. Use
operator-facing labels only in `displayName`, `title`, or `description`.

## Field reference: manifest root

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `schemaVersion` | number | yes | none | `1` | Intake rejects unsupported versions. |
| `extensionId` | string | yes | none | ID rules | Stable lowercase ASCII family slug. Must not contain `:`, use the host-owned `render-catalog` route namespace, or claim the `cedros-` first-party namespace without exact artifact admission. |
| `displayName` | string | yes | none | non-empty | Operator-facing name. |
| `version` | string | yes | none | plain dot-separated numeric version | Align with package versions unless documented. Host admission uses the dependency comparator's numeric grammar; prerelease/build suffixes are rejected. See Version Comparison Rules. |
| `description` | string | no | omitted | non-empty | Operator-facing summary. |
| `platformApiVersion` | string | yes in UI contract | `"1"` | `"1"` | UI compatibility marker only; the server never reads the root field and gates install on `compatibility.platformApiVersion`. Keep both equal. |
| `compatibility.platformApiVersion` | string | yes | none | `"1"` | Server validation requires it. |
| `compatibility.minCedrosDataVersion` | string | no | omitted | plain dot-separated numeric version | Optional lower bound. Enforced at install against the live host release; it is not a package version. Do not copy a minimum higher than the seams you actually need. |
| `compatibility.maxCedrosDataVersion` | string | no | omitted | plain dot-separated numeric version | Optional upper bound. |
| `compatibility.witChecksum` | string | no | omitted | hex sha256 | Optional pin of the host WIT; mismatch rejects wasm install up front. This is the reliable ABI pin — the WIT version string has lagged. |
| `packageFamily` | object | yes | none | server/react/reactNative | Required cross-stack package family. |
| `dependencies` | object | no | empty lists | services/capabilities/extensions | Installability and review metadata. |
| `capabilities` | object[] | no | empty | see below | Extension-published operator-reviewed capabilities/trust scopes. |
| `surfaces` | object | yes | none | server/admin/web/native/ai | Surface ownership metadata. |
| `registration` | object | yes | generated | fixed entrypoints | Runtime registration subpaths. |
| `requiredServices` | string[] | no | derived or explicit | service ids | Admin install gating convenience. |
| `requiredCapabilities` | string[] | no | derived or explicit | capability ids | Admin install gating convenience. |
| `supplyChain` | object | no | omitted | see below | Optional source, provenance, SBOM, signature, and reproducible-build metadata. |
| `adminModules` | object[] | no | empty | see below | Admin inventory plus the JSON-safe first-paint navigation projection; executable UI remains in the React runtime. |
| `contentBlocks` | object[] | no | empty | see below | Visual-builder block metadata. |
| `contentTemplates` | object[] | no | empty | see below | Visual-builder template metadata. |
| `authoredSurfaces` | object[] | no | empty | see below | Authored surface metadata consumed by the React admin runtime; the server keeps it as an opaque extra field. |
| `authoredTemplateUtilities` | object[] | no | empty | see below | Template utility metadata consumed by the React admin runtime; the server keeps it as an opaque extra field. |
| `pageSeeds` | object[] | no | empty | see below | Cedros-managed runtime pages. |
| `seoRoutes` | object[] | no | empty | see below | SEO intent for public routes not backed by a seeded page; dynamic patterns require the wasm `seo` export. Semantics in [`13-public-pages-and-seo.md`](13-public-pages-and-seo.md). |
| `formTemplates` | object[] | no | empty | see below | Form starters; `autoCreateOnEnable` auto-provisions a real form on enable. |
| `docsArticles` | object[] | no | empty | see below | Each active extension article materializes once as a draft runtime Docs record. |
| `policies` | object[] | no | empty | see below | Legal/policy page starters; `autoCreateOnEnable`/`publishOnEnable` auto-provision a runtime policy page. |
| `jobSchedules` | object[] | no | empty | see below | Cron schedules for declared server jobs; optional `autoCreateOnEnable` writes the schedule into site automation settings on enable (via the focused `/admin/runtime/site/automation` endpoint — does not re-save the whole site). Convenience only; do not make your own validator require it. |
| `analytics.events` | object[] | no | empty | see below | Shared analytics declarations. |
| `i18nCatalogs` | object[] | no | empty | see below | Extension-owned translation catalogs for admin/public React surfaces. |
| `pwaShortcuts` | object[] | no | empty | see below | Same-origin public web app manifest shortcuts. |
| `setupSeeds` | object | no | omitted | see below | First-run setup metadata for Scheduling, Shop, Notifications, Contracts, and Email. Provisioning uses owning-system bindings when published. |
| `providerAccess` | object[] | no | empty | see below | Site-owned provider access. |
| `databaseAccess` | object[] | no | empty | see below | Host-mediated site Postgres access. Each entry must reference at least one declared `surfaces.server.contentModels[]` or `surfaces.server.migrations[]` id; intake rejects entries that reference neither. |
| `customerTagAccess` | object[] | no | empty | see below | Host-mediated CRM customer tag assign/unassign/read. |
| `crmSourceAccess` | object[] | no | empty | see below | Host-mediated CRM source-event ingestion. |
| `onboardingPages` | object[] | no | empty | see below | Setup page metadata. |

## Field reference: package family and registration

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `packageFamily.server.packageName` | string | yes | none | package name | Rust crate package. |
| `packageFamily.server.version` | string | yes | none | version | Usually equals manifest version. |
| `packageFamily.server.subpath` | string | no | omitted | export path | Only if SDK supports it. |
| `packageFamily.server.required` | boolean | no | true | `true` | Effectively constant `true`; intake rejects `required: false` for all three package family members. |
| `packageFamily.react.packageName` | string | yes | none | package name | Shared admin/web package. |
| `packageFamily.react.version` | string | yes | none | version | Usually equals manifest version. |
| `packageFamily.react.subpath` | string | no | omitted | export path | Only if SDK supports it. |
| `packageFamily.react.required` | boolean | no | true | `true` | Effectively constant `true`; intake rejects `required: false`. |
| `packageFamily.reactNative.packageName` | string | yes | none | package name | Native package. |
| `packageFamily.reactNative.version` | string | yes | none | version | Usually equals manifest version. |
| `packageFamily.reactNative.subpath` | string | no | omitted | export path | Only if SDK supports it. |
| `packageFamily.reactNative.required` | boolean | no | true | `true` | Effectively constant `true`; intake rejects `required: false`. |
| `registration.server.entrypoint` | string | yes | generated | `${crate}::register_extension_family` | Rust crate export path. |
| `registration.admin.entrypoint` | string | yes | generated | `${reactPackage}/admin/register` | React admin package entry. |
| `registration.web.entrypoint` | string | yes | generated | `${reactPackage}/web/register` | React web package entry. |
| `registration.native.entrypoint` | string | yes | generated | `${nativePackage}/register` | React Native package entry. |

### Registration subpath normalization

Manifest registration entrypoints are full Cedros canonical entrypoints derived
from `packageFamily`:

- server: `crate_name::register_extension_family`
- admin: `${packageFamily.react.packageName}/admin/register`
- web: `${packageFamily.react.packageName}/web/register`
- native: `${packageFamily.reactNative.packageName}/register`

For Rust, `crate_name` is the effective Cargo library name. With no
`[lib].name`, Cargo derives it from `[package].name` by converting hyphens to
underscores. Prefer that default in copied scaffolds. If `[lib].name` is
explicit, it must equal that derived name; otherwise the manifest can name a
crate that the built package does not expose.

Node package exports use package export form:

- `./admin/register`
- `./web/register`
- `./register`

Cedros maps manifest package entrypoints to package exports. Do not put bare
`/admin/register`, `/web/register`, `/register`, or Node-style
`./admin/register` values in the manifest.

## Field reference: dependencies and capabilities

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `dependencies.services[].serviceId` | string | yes | none | service id | Host service dependency. |
| `dependencies.services[].required` | boolean | no | true | true/false | Required blocks install/enable if missing. |
| `dependencies.services[].reason` | string | no | omitted | non-empty | Operator-facing explanation. |
| `dependencies.capabilities[].capabilityId` | string | yes | none | capability id | Host capability dependency. |
| `dependencies.capabilities[].required` | boolean | no | true | true/false | Required blocks install/enable if missing. |
| `dependencies.capabilities[].reason` | string | no | omitted | non-empty | Operator-facing explanation. |
| `dependencies.extensions[].extensionId` | string | yes | none | extension id | Extension family dependency. Self-dependency (naming the manifest's own `extensionId`) is rejected. |
| `dependencies.extensions[].minVersion` | string | no | omitted | plain dot-separated numeric version | Optional lower bound. See Version Comparison Rules. |
| `dependencies.extensions[].maxVersion` | string | no | omitted | plain dot-separated numeric version | Optional upper bound. See Version Comparison Rules. |
| `dependencies.extensions[].required` | boolean | no | true | true/false | Required blocks install/enable if missing. |
| `dependencies.extensions[].reason` | string | no | omitted | non-empty | Operator-facing explanation. |
| `capabilities[].id` | string | yes | none | namespaced id | Extension-published operator-reviewed capability. |
| `capabilities[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `capabilities[].description` | string | yes | none | non-empty | Operator-facing purpose. Required by both UI and server intake. |
| `capabilities[].category` | string | yes | none | admin/editor/content/runtime/commerce | Inventory grouping. The enum is published vocabulary; intake validates non-empty only. |
| `capabilities[].requestedScopes[]` | object[] | yes | none | read/write/trigger/send/call/expose | At least one scope is required. |
| `capabilities[].requestedScopes[].verb` | string | yes | none | read/write/trigger/send/call/expose | Review verb. |
| `capabilities[].requestedScopes[].resource` | string | yes | none | non-empty | Resource being accessed or exposed. Use `site-brain-record:<category>` with `verb: write` to allow wasm `telemetry.emit-record` for one durable record category. |
| `capabilities[].requestedScopes[].summary` | string | yes | none | non-empty | Operator review copy. |

**Version Comparison Rules:** `compatibility.minCedrosDataVersion`,
`compatibility.maxCedrosDataVersion`, `dependencies.extensions[].minVersion`,
`dependencies.extensions[].maxVersion`, and the `version` of any depended-on
extension must be plain dot-separated numeric versions (for example `1.2.3`).
Prerelease/build suffixes such as `1.0.0-beta` fail the host comparator and
reject intake/enable. `minCedrosDataVersion` is enforced at install against the
live host release — do not copy a minimum higher than the seams you
actually need.

`requiredServices` and `requiredCapabilities` should be treated as a flattened
install-gating view of `dependencies.services` and `dependencies.capabilities`.
If both are present, keep them aligned.

`dependencies.capabilities[]` means capabilities this extension consumes from
Cedros, the host, or another extension. Root `capabilities[]` means
operator-reviewed capabilities or trust scopes this extension publishes as part
of its own contract. `providerAccess[]` is only for site-owned provider
services. Do not use root `capabilities[]` for ordinary host service
dependencies or provider access.

When a capability id is owned by an entry in `dependencies.extensions[]`, the
host links the Wasm `extension-services` import. Each call is still authorized
at runtime: the caller must declare that provider and capability, satisfy its
version range, keep every required capability in `requiredCapabilities[]`, and
the active provider must publish the capability in root `capabilities[]` and
bind the target route. Declaring metadata does not let a caller mint claims.

A published Cedros Data Core service capability also links
`extension-services` without a `dependencies.extensions[]` row. The caller
still declares the exact capability, aligns `requiredCapabilities[]`, pins the
documented minimum Cedros Data version, and uses target `cedros-data` plus the
published route/method/path. Unknown or unavailable Core capability ids fail
installation and invocation closed.

`capabilities[].requestedScopes[]` are operator-review scopes for the
capability this extension publishes. They are not consumed capability
dependencies. The field name is historical in the published schema; do not
rename it to `scopes`, `publishedScopes`, or `reviewScopes` unless Cedros
publishes an alias.

## Field reference: optional supply chain metadata

`supplyChain` is optional marketplace trust metadata. It lets authors provide
source and build evidence, but it does not make the extension trusted by
itself. Cedros marketplace or another verifier must compute any verification
status from the evidence. Do not add fake evidence to examples or private
packages; omit this object when the release cannot publish source/provenance
yet.

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `supplyChain.source.repositoryUrl` | string | yes when `source` exists | none | HTTPS URL | Public or source-available repository URL; validated unconditionally whenever `source` is present. |
| `supplyChain.source.vcs` | string | no | `git` | `git` | Version control system. |
| `supplyChain.source.revision` | string | yes when `source` exists | none | full 40- or 64-character commit SHA | Immutable source revision for this release. |
| `supplyChain.source.tag` | string | no | omitted | tag/ref | Release tag when used. |
| `supplyChain.source.directory` | string | no | repository root | repo-relative path | Monorepo directory; never a machine-local path. |
| `supplyChain.source.license` | string | no | omitted | SPDX expression | Declared source license. |
| `supplyChain.source.commitSigned` | boolean | no | false | true/false | Author claim; verifier must confirm. |
| `supplyChain.source.tagSigned` | boolean | no | false | true/false | Author claim; verifier must confirm. |
| `supplyChain.build.provenanceFormat` | string | no | omitted | `slsa-provenance`, `in-toto-attestation`, `sigstore-bundle`, `custom` | Provenance attestation format. |
| `supplyChain.build.provenanceUrl` | string | no | omitted | HTTPS URL | Immutable provenance or attestation location. |
| `supplyChain.build.provenanceSha256` | string | yes when URL exists | omitted | hex sha256 | Digest of provenance artifact. |
| `supplyChain.build.builderId` | string | no | omitted | URI/string | Build platform or workflow identity. |
| `supplyChain.build.workflowRef` | string | no | omitted | non-empty | CI workflow or builder reference. |
| `supplyChain.build.reproducible` | boolean | no | false | true/false | Author claims deterministic rebuild is possible. |
| `supplyChain.build.rebuildCommand` | string | no | omitted | non-empty | Command or script name for verifier rebuild. |
| `supplyChain.build.environment` | string | no | omitted | non-empty | Container/toolchain/runner description. |
| `supplyChain.sbom.format` | string | no | omitted | `spdx`, `cyclonedx` | SBOM format. |
| `supplyChain.sbom.url` | string | no | omitted | HTTPS URL | Immutable SBOM location. |
| `supplyChain.sbom.sha256` | string | yes when URL exists | omitted | hex sha256 | Digest of SBOM artifact. |
| `supplyChain.artifacts[].name` | string | yes when listed | none | non-empty | Package artifact name. |
| `supplyChain.artifacts[].packageRef` | string | no | omitted | server/react/reactNative | Package member reference. Do not use this for the enclosing upload ZIP. |
| `supplyChain.artifacts[].sha256` | string | yes | none | hex sha256 | Digest of built artifact. |
| `supplyChain.artifacts[].signatureUrl` | string | no | omitted | HTTPS URL | Detached signature or Sigstore bundle. |
| `supplyChain.artifacts[].signatureSha256` | string | yes when URL exists | omitted | hex sha256 | Digest of signature artifact. |
| `supplyChain.artifacts[].provenanceUrl` | string | no | omitted | HTTPS URL | Artifact-specific provenance. |
| `supplyChain.artifacts[].provenanceSha256` | string | yes when URL exists | omitted | hex sha256 | Digest of artifact provenance. |
| `supplyChain.artifacts[].sbomUrl` | string | no | omitted | HTTPS URL | Artifact-specific SBOM. |
| `supplyChain.artifacts[].sbomSha256` | string | yes when URL exists | omitted | hex sha256 | Digest of artifact SBOM. |

Do not add `verified`, `marketplaceVerified`, `trusted`, `slsaLevel`, or
similar self-asserted trust fields to the manifest — host intake (UI and
server) rejects them at **every nesting level** of `supplyChain`. The package
declares evidence; the marketplace computes verification.

Marketplace verification outputs live outside the author-supplied manifest —
in an operator review record or marketplace listing:

```json
{
  "supplyChainVerification": {
    "status": "rebuild-matched",
    "summary": "Cedros marketplace verified source revision, provenance, signature, and rebuild evidence.",
    "verifiedAt": "2026-05-05T14:00:00Z",
    "verifiedBy": "cedros-marketplace",
    "sourceRepositoryUrl": "https://github.com/example/cedros-pay",
    "sourceRevision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    "sourceDirectory": "extensions/cedros-pay",
    "archiveSha256": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "checks": [
      {
        "checkId": "source-revision",
        "label": "Source revision",
        "status": "passed",
        "summary": "The submitted package source resolves to the manifest revision."
      },
      {
        "checkId": "rebuild",
        "label": "Rebuild",
        "status": "passed",
        "summary": "The verifier rebuild produced matching package artifacts."
      }
    ]
  }
}
```

Allowed `supplyChainVerification.status` values:

| Status | Meaning |
|---|---|
| `not-provided` | The author manifest did not declare source/provenance evidence. |
| `provided-unverified` | Evidence exists but Cedros has not verified it. |
| `source-unreachable` | The declared source URL or revision could not be reached. |
| `source-revision-matched` | The declared repository revision matches the submitted release source. |
| `signed-source-verified` | Commit and/or tag signature checks passed. |
| `provenance-verified` | Build provenance or attestation checks passed. |
| `sbom-present` | Required SBOM evidence is present and digest-matched. |
| `artifact-signature-verified` | Artifact signature or Sigstore bundle checks passed. |
| `rebuild-matched` | A clean verifier rebuild produced matching package artifacts. |
| `verification-failed` | One or more required verification checks failed. |
| `not-applicable` | Supply-chain verification is not required for this release channel. |

Allowed `checks[].status` values are `passed`, `failed`, `warning`,
`not-run`, and `not-applicable`. Each check should include a stable `checkId`,
human label, status, optional summary/detail, optional evidence URL, optional
evidence SHA-256, and optional `verifiedAt`. Never let an author write this
record into `cedros-extension.manifest.json`; Cedros marketplace or the
operator verifier attaches it after review.

## Field reference: surfaces

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `surfaces.server.packageRef` | string | yes | none | `server` | Server package owner. |
| `surfaces.server.required` | boolean | no | true | `true` | Effectively constant `true`; intake rejects `required: false` for all four core surfaces. |
| `surfaces.server.routes[]` | string | no | empty | namespaced ids or absolute route ids | Wasm route export ids; package must include `cedros-extension.server.wasm` when declared. Routes returned by Wasm `list-routes()` under `/extensions/{extension-id}` are also reachable through the public site server; no second public-route manifest field is required. |
| `surfaces.server.jobs[]` | string | no | empty | namespaced ids | Wasm job export ids; package must include `cedros-extension.server.wasm` when declared. |
| `surfaces.server.events[]` | string | no | empty | namespaced ids | Exact Wasm telemetry event grant and notification seed reference ids; undeclared ids are rejected per call. |
| `surfaces.server.migrations[]` | string | no | empty | namespaced ids | Ownership/review metadata. The public Wasm `database.migrate` call accepts a content-model id, not a migration id; declaration alone executes nothing. |
| `surfaces.server.settingsSchemas[]` | string | no | empty | namespaced ids | Grants Wasm settings read/write for per-extension JSON settings. The host does not validate values against these ids. |
| `surfaces.server.contentModels[]` | string | no | empty | namespaced ids | Extension-owned JSONB content model ids. The server hard-enforces `{extensionId}:` namespacing on these ids (security boundary on collection names). |
| `surfaces.admin.packageRef` | string | yes | none | `react` | Admin package owner. |
| `surfaces.admin.required` | boolean | no | true | `true` | Effectively constant `true`; intake rejects `required: false`. |
| `surfaces.admin.moduleIds[]` | string | no | empty | namespaced ids | Keep aligned with `adminModules[].moduleId` by convention; intake validates uniqueness only, no cross-check against `adminModules[]`. |
| `surfaces.admin.slotIds[]` | string | no | empty | namespaced ids | Shell/section wrapper slots. |
| `surfaces.admin.editorSurfaceIds[]` | string | no | empty | namespaced ids | Content editor panels. |
| `surfaces.web.packageRef` | string | yes | none | `react` | Web package owner. |
| `surfaces.web.required` | boolean | no | true | `true` | Effectively constant `true`; intake rejects `required: false`. |
| `surfaces.web.routeIds[]` | string | no | empty | page seed or SEO route ids | Every id must match `pageSeeds[].id` or `seoRoutes[].routeId`; unmodeled public web routes fail intake closed. |
| `surfaces.web.blockTypes[]` | string | no | empty | block ids | Match runtime definitions. |
| `surfaces.web.templateIds[]` | string | no | empty | template ids | Match runtime definitions. |
| `surfaces.web.authoredSurfaceIds[]` | string[] | no | empty | authored surface ids | Must match `authoredSurfaces[].id`. |
| `surfaces.web.templateUtilityIds[]` | string[] | no | empty | template utility ids | Must match `authoredTemplateUtilities[].id`. |
| `surfaces.native.packageRef` | string | yes | none | `reactNative` | Native package owner. |
| `surfaces.native.required` | boolean | no | true | `true` | Effectively constant `true`; intake rejects `required: false`. |
| `surfaces.native.screenIds[]` | string | no | empty | namespaced ids | Executable and fail-closed in hosted App Builder; host-coordinated elsewhere unless an equivalent loader exists. |
| `surfaces.native.stackIds[]` | string | no | empty | namespaced ids | Executable and fail-closed in hosted App Builder; host-coordinated elsewhere. |
| `surfaces.native.providerIds[]` | string | no | empty | namespaced ids | Executable and fail-closed in hosted App Builder; host-coordinated elsewhere. |

Empty server/admin/web/native surface objects are still part of the canonical
family shape. Use `packageRef` plus empty arrays when no functionality exists.

## Field reference: admin and dashboard

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `adminModules[].moduleId` | string | yes | none | namespaced id | Runtime `AdminModule.id` should match. |
| `adminModules[].extensionId` | string | yes | none | extension id | Must match manifest owner. |
| `adminModules[].displayName` | string | yes | none | non-empty | Operator-facing. |
| `adminModules[].version` | string | yes | none | version | Usually manifest version. |
| `adminModules[].packageName` | string | yes | none | package name | React package name. |
| `adminModules[].packageSubpath` | string | no | omitted | export path | Optional runtime export. |
| `adminModules[].requiredServices[]` | string | no | empty | service ids | Runtime gating. |
| `adminModules[].requiredCapabilities[]` | string | no | empty | capability ids | Runtime gating. |
| `adminModules[].sectionIds[]` | string | no | empty | section ids | Leaf admin pages. Each declared section needs matching `sectionIcons` and `navigation.sections` entries. |
| `adminModules[].sectionIcons` | object | yes when `sectionIds[]` is non-empty | none | any host admin icon alias or any Lucide icon name (`lucide:store`, PascalCase, or bare) | Keys may be exact section ids or local ids; values are the host admin icon vocabulary (44 aliases in `HOST_ADMIN_ICON_NAMES` plus any resolvable Lucide name). See [`12-admin-pages-and-dashboard-cards.md`](12-admin-pages-and-dashboard-cards.md) for the full alias list. |
| `adminModules[].navigation.sections[]` | object[] | yes when `sectionIds[]` is non-empty | none | JSON-safe section metadata | Exact first-paint projection of every runtime `sections[]` entry, including hidden sections. Install persists it in the canonical manifest; enable copies it into the active admin registry. Array order is irrelevant; ids and projected values must match runtime exactly. |
| `adminModules[].navigation.sections[].id` | string | yes | none | same-extension section id | Must appear exactly once in `sectionIds[]` and exactly match runtime `sections[].id`. |
| `adminModules[].navigation.sections[].label` | string | yes | none | non-empty | Exact fallback/runtime navigation label. |
| `adminModules[].navigation.sections[].group` | string | yes | none | registered group label or declared custom group label | Exact case-sensitive merge key. Never infer this value from the page or extension id. |
| `adminModules[].navigation.sections[].order` | number | yes | none | finite number | Exact within-group runtime order. |
| `adminModules[].navigation.sections[].labelKey` | string | no | omitted | non-empty translation key | Must match runtime when present. |
| `adminModules[].navigation.sections[].groupKey` | string | no | omitted | non-empty translation key | Must match runtime when present. |
| `adminModules[].navigation.sections[].hideFromNavigation` | boolean | no | false | boolean | Must match runtime; hidden/direct-route sections are still declared. |
| `adminModules[].navigation.sections[].requiredPermission` | string | no | omitted | permission/capability id | Sidebar gating projection; server authorization remains mandatory. Must match runtime. |
| `adminModules[].navigation.sections[].requiredExtensionId` | string | no | omitted | extension id | Dependency gating projection. Must match runtime. |
| `adminModules[].navigation.sections[].replacesSectionIds[]` | string[] | no | empty | section ids | Replacement projection. Array values/order must match runtime. |
| `adminModules[].navigation.sections[].disabledReason` | string | no | omitted | non-empty | Must match runtime when present. |
| `adminModules[].navigation.sections[].disabledReasonKey` | string | no | omitted | non-empty translation key | Must match runtime when present. |
| `adminModules[].navigation.sections[].disabled` | boolean | no | false | boolean | Must match runtime. |
| `adminModules[].navigation.sections[].adminPageAccess` | object | no | omitted | `configurable`, `protected`, `routePath` | Each optional value must match runtime. |
| `adminModules[].navigation.sections[].adminPageAccess.configurable` | boolean | no | true | boolean | Whether host page-visibility settings can configure the page. |
| `adminModules[].navigation.sections[].adminPageAccess.protected` | boolean | no | false | boolean | Whether the page remains protected from normal visibility customization. |
| `adminModules[].navigation.sections[].adminPageAccess.routePath` | string | no | host-derived | non-empty route path | Exact runtime page-access route override. |
| `adminModules[].navigation.groups[]` | object[] | required when runtime `groups[]` is non-empty | omitted | JSON-safe group metadata | Exact projection of runtime `groups[]`; array order is irrelevant. Custom section groups require a matching group entry. Do not declare this array if runtime has no groups. |
| `adminModules[].navigation.groups[].id` | string | yes | none | non-empty | Must be unique and match runtime. |
| `adminModules[].navigation.groups[].label` | string | yes | none | non-empty | Must be unique, match runtime, and match the section `group` merge key. |
| `adminModules[].navigation.groups[].order` | number | yes | none | finite number | Exact runtime group order. |
| `adminModules[].navigation.groups[].labelKey` | string | no | omitted | non-empty translation key | Must match runtime when present. |
| `adminModules[].navigation.groups[].defaultCollapsed` | boolean | no | false | boolean | Must match runtime. |
| `adminModules[].navigation.groups[].hideLabel` | boolean | no | false | boolean | Must match runtime. |
| `adminModules[].slots[]` | string | no | empty | slot ids | Wrapper contributions. |
| `adminModules[].contributions.dashboardCards[].id` | string | yes | none | namespaced id | Match runtime dashboard card id. |
| `adminModules[].contributions.dashboardCards[].displayName` | string | yes | none | non-empty | Card label. |
| `adminModules[].contributions.dashboardCards[].description` | string | no | omitted | non-empty | Concise operator-facing purpose. |
| `adminModules[].contributions.dashboardCards[].order` | number | no | 0 | integer | Lower sorts earlier. |

React `icon`, `badge`, page components, group icons, and other executable/node
values are deliberately excluded from `navigation`; `sectionIcons` supplies
the first-paint section icon vocabulary. Keep navigation JSON-safe.

## Field reference: content, pages, onboarding, analytics

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `contentBlocks[].type` | string | yes | none | namespaced id | Match runtime block type. |
| `contentBlocks[].displayName` | string | yes | none | non-empty | Builder label. |
| `contentBlocks[].description` | string | no | omitted | non-empty | Builder help text. |
| `contentBlocks[].category` | string | yes | none | stable string | Builder grouping. |
| `contentBlocks[].order` | number | yes | none | integer | Sort order. |
| `contentTemplates[].id` | string | yes | none | namespaced id | Match runtime template id. |
| `contentTemplates[].displayName` | string | yes | none | non-empty | Builder label. |
| `contentTemplates[].description` | string | no | omitted | non-empty | Builder help text. |
| `contentTemplates[].order` | number | yes | none | integer | Sort order. |
| `contentTemplates[].contentTypes[]` | string[] | yes | none | page/blog/docs/course/airdrop/faq/directory/collection | Template availability. |
| `contentTemplates[].surfaceId` | string | no | omitted | built-in or namespaced surface | Authored surface grouping. |
| `authoredSurfaces[].id` | string | yes | none | authored route surface | Surface metadata. |
| `authoredSurfaces[].displayName` | string | yes | none | non-empty | Surface label. |
| `authoredSurfaces[].description` | string | no | omitted | non-empty | Surface help text. |
| `authoredSurfaces[].eyebrow` | string | no | omitted | non-empty | Short UI label. |
| `authoredSurfaces[].templateIds[]` | string[] | no | empty | template ids | Templates available for the surface. |
| `authoredTemplateUtilities[].id` | string | yes | none | namespaced id | Helper/preset metadata. |
| `authoredTemplateUtilities[].displayName` | string | yes | none | non-empty | Utility label. |
| `authoredTemplateUtilities[].description` | string | no | omitted | non-empty | Utility help text. |
| `authoredTemplateUtilities[].order` | number | no | 0 | integer | Sort order. |
| `authoredTemplateUtilities[].templateIds[]` | string[] | yes | none | template ids | Related templates. |
| `authoredTemplateUtilities[].contentTypes[]` | string[] | no | empty | runtime content types | Availability filter. |
| `authoredTemplateUtilities[].surfaceIds[]` | string[] | no | empty | surface ids | Surface filter. |
| `authoredTemplateUtilities[].suggestedBlockTypes[]` | string[] | no | empty | block ids | Suggested blocks. |
| `pageSeeds[].id` | string | yes | none | namespaced id | Also in `surfaces.web.routeIds`. |
| `pageSeeds[].displayName` | string | yes | none | non-empty | Owner-facing seed label. |
| `pageSeeds[].title` | string | yes | none | non-empty | Initial page title. |
| `pageSeeds[].routePath` | string | yes | none | route path | Normalized at intake: a leading `/` is prepended if missing and duplicate slashes are collapsed. Intake rejects duplicate page seed ids and duplicate normalized routes; conflicts require owner resolution. |
| `pageSeeds[].description` | string | no | omitted | non-empty | Operator-facing summary. |
| `pageSeeds[].slug` | string | no | derived | slug | Initial slug for the seeded page. |
| `pageSeeds[].templateId` | string | no | `page-default` | core or namespaced template id | Must resolve at runtime. |
| `pageSeeds[].seo` | object | no | omitted | see SEO Metadata Contract | Initial SEO defaults for auto-created runtime page content. |
| `pageSeeds[].chromeMode` | string | no | `default` | `default`, `headless`, or `minimal` | Public shell contract. `headless` suppresses the host SiteLayout chrome so the extension owns the route chrome; `minimal` keeps the host theme/root without the full primary nav/footer. |
| `pageSeeds[].autoCreateOnEnable` | boolean | no | false | true/false | Create page on enable. |
| `pageSeeds[].publishOnEnable` | boolean | no | false | true/false | Publish created page. |
| `onboardingPages[].id` | string | yes | none | namespaced id | Stable setup step id. |
| `onboardingPages[].displayName` | string | yes | none | non-empty | Owner-facing setup label. |
| `onboardingPages[].moduleId` | string | yes | none | admin module id | Must target a same-extension admin module. Checked by the authoring validator and admin UI intake only; the server keeps `onboardingPages` as an opaque extra field. |
| `onboardingPages[].sectionId` | string | yes | none | admin section id | Must target a declared `sectionIds[]` entry of that module. Same validator/UI-only enforcement. |
| `onboardingPages[].description` | string | no | omitted | non-empty | Setup summary. |
| `analytics.events[].id` | string | yes | none | namespaced id | Stable reporting id. |
| `analytics.events[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `analytics.events[].description` | string | yes | none | non-empty | Owner-facing meaning. |
| `analytics.events[].category` | string | yes | none | stable free string | Reporting grouping. |
| `analytics.events[].kind` | string | no | empty | purchase_intent_view/purchase_completion/subscription_start/subscription_cancellation/signup_completion/lead_capture/free string | Optional semantic rollup hint. |
| `analytics.events[].visibility` | string | yes | none | public/authenticated/admin | Actor visibility. |

`pageSeeds[]` provision extension-owned Cedros page rows; they are public only
once provisioned and published. Keep customer marketing pages site-owned, as
explained in [public-page ownership](13-public-pages-and-seo.md#choose-the-right-owner).
A runtime-owned public handler must declare the corresponding `seoRoutes[]`
contract as well as its `surfaces.web.routeIds[]` entry.

Analytics property schemas are currently runtime trigger-map handoff
documentation unless Cedros publishes a validated `properties` manifest field.
Use recognized `kind` values when an event should roll up into Cedros analytics
conversion tiles; unrecognized values are preserved as metadata and treated as
`other` by dashboards.

## Field reference: job schedules

Each entry provisions one cron schedule for a declared server job. The `jobId`
must reference a `surfaces.server.jobs[]` id. See
[`11-jobs-and-scheduling.md`](11-jobs-and-scheduling.md) for runtime semantics
(concurrency, retries, catch-up).

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `jobSchedules[].id` | string | yes | none | namespaced id | Stable seed id; the idempotency key for provisioning. |
| `jobSchedules[].jobId` | string | yes | none | declared job id | Must reference `surfaces.server.jobs[]`. |
| `jobSchedules[].label` | string | yes | none | non-empty | Human-readable automation label. |
| `jobSchedules[].cron` | string | yes | none | 5- or 6-field cron | Cadence expression. |
| `jobSchedules[].timezone` | string | no | host default | IANA timezone | e.g. `America/Los_Angeles`. |
| `jobSchedules[].catchUp` | boolean | no | false | true/false | Run a missed occurrence on next start. |
| `jobSchedules[].enabled` | boolean | no | true | true/false | Schedule starts enabled unless set false. |
| `jobSchedules[].timeoutSeconds` | number | no | host default | positive integer | Per-run timeout. |
| `jobSchedules[].maxRetries` | number | no | 0 | 0–10 | Retries only an explicit `retryable` outcome. Timeouts and ownership-loss ambiguity remain terminal. See [`11`](11-jobs-and-scheduling.md). |
| `jobSchedules[].channelIds[]` | string[] | no | empty | notification channel ids | Alert on failure. |
| `jobSchedules[].autoCreateOnEnable` | boolean | no | false | true/false | Write the schedule into site automation settings on enable. |

## SEO metadata contract

`pageSeeds[]`, `docsArticles[]`, and `policies[]` may declare an optional
`seo` object. Cedros treats it as initial runtime content metadata when the
seed auto-creates content; owners may edit SEO later in the normal content
editor. The full SEO contract (what Core owns, what you must never emit, and
the `seoRoutes[]`/wasm-seam model) is
[`13-public-pages-and-seo.md`](13-public-pages-and-seo.md).

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `seo.title` | string | no | content title | 1-120 chars | Search title override. Page Builder may still compose the public title with the site name. |
| `seo.description` | string | no | excerpt/description | 1-320 chars | Meta description and Open Graph fallback. |
| `seo.canonicalPath` | string | no | content route | same-origin absolute path | Must start with `/`, must not start with `//`, and must not contain whitespace. Do not use external canonical URLs. |
| `seo.ogTitle` | string | no | `seo.title` | 1-120 chars | Optional Open Graph title override. |
| `seo.ogDescription` | string | no | `seo.description` | 1-320 chars | Optional Open Graph description override. |
| `seo.ogImage` | string | no | omitted | 1-1024 chars | Public image path/URL or host-recognized media reference used by runtime renderers. |
| `seo.noindex` | boolean | no | false | true/false | Requests that public renderers hide the auto-created content from search results. |

Unsupported keys inside `seo` are rejected by validators. Keep SEO values
truthful to the starter content and avoid stuffing keywords or claims that the
seeded page does not substantiate.

## Field reference: seoRoutes

`seoRoutes[]` declares SEO intent for public routes that are **not** backed by
a seeded page row — typically routes your wasm backend or web runtime serves
directly. Only the keys below are permitted; an unmodeled key fails intake
closed. A **dynamic** pattern (one containing `:param` or `*`) additionally
requires the wasm component to implement the `extension-seo` world's `seo`
export ([`07-wasm-server-backends.md`](07-wasm-server-backends.md)); install
fails otherwise.

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `seoRoutes[].routeId` | string | yes | none | declared route id | Must match a `surfaces.web.routeIds[]` or `surfaces.server.routes[]` id. |
| `seoRoutes[].pathPattern` | string | yes | none | same-origin absolute path | `:param` and `*` segments are allowed. Must not overlap a Core-owned route, an existing CMS route, or another extension route, including locale-prefixed equivalents. |
| `seoRoutes[].indexable` | boolean | no | true | true/false | Whether the route may be indexed. |
| `seoRoutes[].includeInSitemap` | boolean | no | = `indexable` | true/false | Sitemap inclusion. |
| `seoRoutes[].canonicalStrategy` | string | no | `self` | `self`, `none`, or `/path` | Canonical link strategy. |
| `seoRoutes[].schemaType` | string | no | `WebPage` | `WebPage`/`CollectionPage`/`ProfilePage`/`ItemPage`/`Service`/`Event`/`Product` | JSON-LD node type Core emits. |
| `seoRoutes[].schemaContractVersion` | positive integer | no | current | current Core contract version | Pins the Core-reviewed adapter registry. Unknown/future versions fail intake. |
| `seoRoutes[].servedLocales[]` | non-empty string[] | no | omitted | BCP 47 locales | Exact locales the route serves. Omit for default-only; Core never inserts the default into an explicit list. |
| `seoRoutes[].parameterPolicy.allowedValues` | object | no | omitted | 1-8 URL-safe parameter names with finite value arrays | The only query variants eligible for indexing; unknown values remain noindex. |
| `seoRoutes[].parameterPolicy.maxCombinations` | integer | with policy | none | 1-1000 | Must be at least the complete optional combination count. |
| `seoRoutes[].utility` | boolean | no | false | true/false | `true` forces non-indexable + sitemap-excluded. |
| `seoRoutes[].seo` | object | no | omitted | SEO Metadata Contract minus `canonicalPath`, plus `schema` | Per-route SEO defaults; use `canonicalStrategy` for canonical behavior. |
| `seoRoutes[].videos[]` | object[] | no | omitted | validated video sitemap records | Each record requires `thumbnailLoc`, `title`, `description`, and `contentLoc` or `playerLoc`; URLs are same-origin paths or HTTPS. |
| `seoRoutes[].chromeMode` | string | no | `default` | `default`/`headless`/`minimal` | Public shell contract for the route. |

`seo.schema` is a declarative `Service`, `Event`, or `Product` object. Its
`kind` must match a route's commerce `schemaType`; Product requires a valid
offer, Event requires an ISO-8601 start date plus physical or HTTPS virtual
location, and authored ratings/reviews are rejected. Core composes the final
single JSON-LD graph. Private/transactional route namespaces must be noindex;
`noindex` cannot be combined with `canonicalPath` or sitemap inclusion.

The adapter registry lives in `shared/seo-schema-contract.json`. Each route
type has a version, accepted input-fact family, stable ID strategy,
visible-data projection policy, and localization policy. Adding a type requires
a reviewed registry entry, entity validator, projection implementation, and
positive/negative conformance fixtures; raw JSON-LD is never an escape hatch.

## Field reference: setup seeds

`setupSeeds` lets an extension describe turnkey first-run resources without
directly mutating Scheduling, Shop, Notifications, Contracts, or Email tables.
Scheduling and Shop seeds remain handoff-only until their first-party write
contracts are published. Only notification seeds have a host binding
(`cedros-notifications:route-write`). Contract and Email template seeds are
validated metadata that nothing provisions: the ids
`cedros-contracts:template-write`, `cedros-contracts:document-ingest`, and
`cedros-email:template-write` are reserved for bindings that do not exist yet.
Default lifecycle behavior is `createIfMissing`, `preserveOperatorEdits`, and
`leaveCreated`.

Capacity ownership rule: Cedros Shop owns purchasable/event capacity through
inventory. Cedros Scheduling owns appointment availability and appointment
slot capacity. Use `external` only when a named third-party provider remains
the source of truth.

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `setupSeeds.scheduling[].id` | string | yes | none | namespaced id | Stable seed id. |
| `setupSeeds.scheduling[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `setupSeeds.scheduling[].title` | string | yes | none | non-empty | Appointment type title. |
| `setupSeeds.scheduling[].description` | string | no | omitted | non-empty | Operator review context. |
| `setupSeeds.scheduling[].publicSlug` | string | yes | none | slug | Appointment URL slug. |
| `setupSeeds.scheduling[].durationMinutes` | number | yes | none | positive integer | Appointment duration. |
| `setupSeeds.scheduling[].slotIntervalMinutes` | number | no | host default | positive integer | Slot grid. |
| `setupSeeds.scheduling[].profileSlug` | string | no | site profile | slug | Suggested scheduling profile. |
| `setupSeeds.scheduling[].location` | string | no | omitted | non-empty | Initial appointment location. |
| `setupSeeds.scheduling[].bookingQuestions[]` | object[] | no | empty | see below | Starter booking questions. |
| `setupSeeds.scheduling[].availability[]` | object[] | no | empty | weekday windows | Suggested weekly availability. |
| `setupSeeds.scheduling[].paymentPolicy` | object | no | omitted | see below | Paid scheduling binding. |
| `setupSeeds.scheduling[].tags[]` | string[] | no | empty | stable strings | Review/search metadata. |
| `setupSeeds.*[].lifecycle.installMode` | string | no | `createIfMissing` | `createIfMissing`/`referenceOnly` | Whether a host should provision or only expose guidance. Only notification seeds are provisioned today; contract, email, document, scheduling, and product seeds are validated metadata with no lifecycle caller. A notification seed with `referenceOnly` is skipped; every other notification seed materializes on enable as a configurable notification route (keyed by the seed `id`, matched to events by `eventId`) in Settings → Notifications. Delivery still requires the owner to configure a channel target (the extension cannot supply one). |
| `setupSeeds.*[].lifecycle.updatePolicy` | string | no | `preserveOperatorEdits` | `preserveOperatorEdits`/`replaceIfUnmodified` | Declared intent only: validated, but no host lifecycle applies it. |
| `setupSeeds.*[].lifecycle.disablePolicy` | string | no | `leaveCreated` | `leaveCreated`/`disableIfUnmodified` | Applied to notification seeds only: with `disableIfUnmodified`, disabling the extension turns its still-enabled route off and re-enabling turns it back on; a route the operator already turned off is left alone. Other seed kinds: validated only. |
| `setupSeeds.scheduling[].bookingQuestions[].key` | string | yes | none | key | Unique within seed. |
| `setupSeeds.scheduling[].bookingQuestions[].label` | string | yes | none | non-empty | Field label. |
| `setupSeeds.scheduling[].bookingQuestions[].type` | string | yes | none | text/email/textarea/tel/select/checkbox | Select requires options. |
| `setupSeeds.scheduling[].bookingQuestions[].required` | boolean | no | false | true/false | Required marker. |
| `setupSeeds.scheduling[].bookingQuestions[].options[]` | string[] | no | empty | non-empty | Select options. |
| `setupSeeds.scheduling[].availability[].weekday` | number | yes | none | 0-6 | Sunday is 0. |
| `setupSeeds.scheduling[].availability[].startTime` | string | yes | none | `HH:MM` | Local 24-hour time. |
| `setupSeeds.scheduling[].availability[].endTime` | string | yes | none | `HH:MM` after start | Local 24-hour time. |
| `setupSeeds.scheduling[].paymentPolicy.required` | boolean | yes | none | true/false | Whether payment is required. |
| `setupSeeds.scheduling[].paymentPolicy.timing` | string | yes | none | `notRequired`/`beforeBooking`/`depositBeforeBooking`/`afterApproval` | Required payment cannot use `notRequired`. |
| `setupSeeds.scheduling[].paymentPolicy.productSeedId` | string | no | omitted | product seed id | Preferred paid scheduling binding. |
| `setupSeeds.scheduling[].paymentPolicy.checkoutCapabilityId` | string | no | omitted | capability id | Usually `cedros-pay:checkout`. |
| `setupSeeds.scheduling[].paymentPolicy.refundPolicy` | string | no | omitted | non-empty | Operator-facing refund/cancel rule. |
| `setupSeeds.productCollections[].id` | string | yes | none | namespaced id | Stable collection seed id. |
| `setupSeeds.productCollections[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `setupSeeds.productCollections[].title` | string | yes | none | non-empty | Collection title. |
| `setupSeeds.productCollections[].description` | string | no | omitted | non-empty | Operator review context. |
| `setupSeeds.productCollections[].slug` | string | no | derived | slug | Suggested collection slug. |
| `setupSeeds.productCollections[].productSeedIds[]` | string[] | no | empty | product seed ids | Must reference `setupSeeds.products[]`. |
| `setupSeeds.productCollections[].schedule` | object | no | omitted | event schedule | Shared event/session schedule. |
| `setupSeeds.productCollections[].capacity` | object | no | omitted | `shopInventory` or `external` owner | Event collection capacity. |
| `setupSeeds.productCollections[].tags[]` | string[] | no | empty | stable strings | Review/search metadata. |
| `setupSeeds.products[].id` | string | yes | none | namespaced id | Stable product seed id. |
| `setupSeeds.products[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `setupSeeds.products[].title` | string | yes | none | non-empty | Product title. |
| `setupSeeds.products[].productType` | string | yes | none | standard/service/ticket/eventSession/campSession/pass/addon | Product family. |
| `setupSeeds.products[].description` | string | no | omitted | non-empty | Operator review context. |
| `setupSeeds.products[].slug` | string | no | derived | slug | Suggested product slug. |
| `setupSeeds.products[].collectionSeedIds[]` | string[] | no | empty | collection ids | Must reference `productCollections[]`. |
| `setupSeeds.products[].variants[]` | object[] | no | empty | see below | Purchasable variants. |
| `setupSeeds.products[].variants[].id` | string | yes | none | stable id | Unique within product. |
| `setupSeeds.products[].variants[].displayName` | string | yes | none | non-empty | Variant label. |
| `setupSeeds.products[].variants[].sku` | string | no | omitted | non-empty | Suggested SKU. |
| `setupSeeds.products[].variants[].price.amountCents` | number | yes when price exists | none | positive integer | Minor units. |
| `setupSeeds.products[].variants[].price.currency` | string | yes when price exists | none | uppercase ISO-4217 | Example `USD`. |
| `setupSeeds.products[].variants[].price.billingInterval` | string | no | omitted | non-empty | Subscription/recurring interval when host supports it. |
| `setupSeeds.products[].variants[].inventory.capacity` | number | no | omitted | positive integer | Max purchasable quantity. |
| `setupSeeds.products[].variants[].inventory.initialQuantity` | number | no | omitted | positive integer | Initial available quantity. |
| `setupSeeds.products[].variants[].inventory.lowStockThreshold` | number | no | omitted | positive integer | Suggested low-stock warning threshold. |
| `setupSeeds.products[].variants[].attributes` | object | no | empty | string map | Variant attributes such as size or session label. |
| `setupSeeds.products[].schedule` | object | no | omitted | event schedule | Product-level event/session schedule. |
| `setupSeeds.products[].capacity.owner` | string | yes when capacity exists | none | `shopInventory`/`schedulingAvailability`/`external` | Source of truth for capacity. |
| `setupSeeds.productCollections/products[].capacity.limit` | number | no | omitted | positive integer | Capacity limit. |
| `setupSeeds.productCollections/products[].capacity.sharedCapacityKey` | string | no | omitted | non-empty | Join key for variants/products sharing capacity. |
| `setupSeeds.productCollections/products[].capacity.description` | string | no | omitted | non-empty | Human-readable capacity ownership note. |
| `setupSeeds.products[].formTemplateIds[]` | string[] | no | empty | form template ids | Must reference `formTemplates[]`. |
| `setupSeeds.products[].schedulingSeedIds[]` | string[] | no | empty | scheduling seed ids | Required when capacity owner is `schedulingAvailability`. |
| `setupSeeds.products[].tags[]` | string[] | no | empty | stable strings | Review/search metadata. |
| `setupSeeds.notifications[].id` | string | yes | none | namespaced id | Stable notification route/template seed id. |
| `setupSeeds.notifications[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `setupSeeds.notifications[].title` | string | yes | none | non-empty | Notification title. |
| `setupSeeds.notifications[].description` | string | no | omitted | non-empty | Operator review context. |
| `setupSeeds.notifications[].eventId` | string | yes | none | `surfaces.server.events[]` id | Event that triggers this notification. |
| `setupSeeds.notifications[].audience` | string | yes | none | `team`/`personal` | Routing audience. |
| `setupSeeds.notifications[].severity` | string | no | `info` | `info`/`warning`/`error` | Suggested default severity. |
| `setupSeeds.notifications[].defaultChannels[]` | string[] | no | empty | `email`/`discord`/`slack`/`telegram` | Suggested channel types only; no destinations or secrets. |
| `setupSeeds.notifications[].subjectTemplate` | string | no | omitted | non-empty | Email-capable subject template. |
| `setupSeeds.notifications[].bodyTemplate` | string | yes | none | non-empty | Notification body template. |
| `setupSeeds.notifications[].tags[]` | string[] | no | empty | stable strings | Review/search metadata. |
| `setupSeeds.contractTemplates[].id` | string | yes | none | namespaced id | Stable contract template seed id. |
| `setupSeeds.contractTemplates[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `setupSeeds.contractTemplates[].name` | string | yes | none | non-empty | Contract template name. |
| `setupSeeds.contractTemplates[].description` | string | no | omitted | non-empty | Operator review context. |
| `setupSeeds.contractTemplates[].status` | string | no | `draft` | `draft`/`ready` | Suggested starting status. |
| `setupSeeds.contractTemplates[].documentRefs[].path` | string | yes | none | package-relative path | Referenced PDF/artifact; no absolute paths or `..`. |
| `setupSeeds.contractTemplates[].documentRefs[].filename` | string | yes | none | non-empty | Display/download filename. |
| `setupSeeds.contractTemplates[].documentRefs[].contentType` | string | yes | none | `application/pdf` for ingestion | MIME type for the referenced artifact. |
| `setupSeeds.contractTemplates[].documentRefs[].sha256` | string | no | omitted | lowercase SHA-256 | Pins the package PDF for a future `cedros-contracts:document-ingest` binding (none exists today). |
| `setupSeeds.contractTemplates[].roles[]` | object[] | yes | none | at least one role | Intake rejects contract template seeds with zero roles. |
| `setupSeeds.contractTemplates[].roles[].id` | string | yes | none | stable id | Unique role id within template. |
| `setupSeeds.contractTemplates[].roles[].name` | string | yes | none | non-empty | Signer role label. |
| `setupSeeds.contractTemplates[].roles[].signingOrder` | number | no | host default | positive integer | Suggested signing sequence. |
| `setupSeeds.contractTemplates[].fields[].id` | string | yes | none | stable id | Unique field id within template. |
| `setupSeeds.contractTemplates[].fields[].roleId` | string | yes | none | role id | Must reference `roles[]`. |
| `setupSeeds.contractTemplates[].fields[].type` | string | yes | none | text/signature/initials/date/checkbox/number/file/radio/select/image/phone/heading | Select/radio require options. |
| `setupSeeds.contractTemplates[].fields[].name` | string | yes | none | non-empty | Machine field name. |
| `setupSeeds.contractTemplates[].fields[].label` | string | yes | none | non-empty | Signer-facing label. |
| `setupSeeds.contractTemplates[].fields[].required` | boolean | no | false | true/false | Required marker. |
| `setupSeeds.contractTemplates[].fields[].readonly` | boolean | no | false | true/false | Read-only marker. |
| `setupSeeds.contractTemplates[].fields[].options[]` | string[] | no | empty | unique non-empty strings | Required for select/radio fields. |
| `setupSeeds.contractTemplates[].preferences.requestEmailSubject` | string | no | host default | non-empty | Suggested signing request subject. |
| `setupSeeds.contractTemplates[].preferences.requestEmailBody` | string | no | host default | non-empty | Suggested signing request body. |
| `setupSeeds.contractTemplates[].preferences.completedMessageTitle` | string | no | host default | non-empty | Completion screen title. |
| `setupSeeds.contractTemplates[].preferences.completedMessageBody` | string | no | host default | non-empty | Completion screen message. |
| `setupSeeds.contractTemplates[].preferences.defaultExpirationDays` | number | no | host default | positive integer | Suggested request expiration. |
| `setupSeeds.contractTemplates[].preferences.requireEmail2fa` | boolean | no | host default | true/false | Suggested signer verification posture. |
| `setupSeeds.contractTemplates[].tags[]` | string[] | no | empty | stable strings | Review/search metadata. |
| `setupSeeds.emailTemplates[].id` | string | yes | none | namespaced id | Stable campaign template seed id. |
| `setupSeeds.emailTemplates[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `setupSeeds.emailTemplates[].name` | string | yes | none | non-empty | Template name. |
| `setupSeeds.emailTemplates[].category` | string | yes | none | general/newsletter/product/product_update/content/blog_digest/event/welcome/promotional/saved/custom | Published Email template category. |
| `setupSeeds.emailTemplates[].description` | string | no | omitted | non-empty | Operator review context. |
| `setupSeeds.emailTemplates[].status` | string | no | `draft` | `draft`/`active` | Suggested starting status. |
| `setupSeeds.emailTemplates[].subjectTemplate` | string | yes | none | non-empty | Subject with supported email tokens. |
| `setupSeeds.emailTemplates[].preheaderTemplate` | string | no | omitted | non-empty | Suggested inbox preview text. |
| `setupSeeds.emailTemplates[].htmlBodyTemplate` | string | yes | none | non-empty | HTML template body. |
| `setupSeeds.emailTemplates[].plainTextBodyTemplate` | string | yes | none | non-empty | Plain-text fallback. |
| `setupSeeds.emailTemplates[].defaultFromName` | string | no | provider default | non-empty | Suggested sender name. |
| `setupSeeds.emailTemplates[].defaultFromEmail` | string | no | provider default | non-empty | Suggested sender; not a credential. |
| `setupSeeds.emailTemplates[].defaultReplyTo` | string | no | provider default | non-empty | Suggested reply-to address. |
| `setupSeeds.emailTemplates[].defaultArchiveEnabled` | boolean | no | host default | true/false | Suggested archive setting. |
| `setupSeeds.emailTemplates[].defaultTrackingEnabled` | boolean | no | host default | true/false | Suggested tracking setting. |
| `setupSeeds.emailTemplates[].tags[]` | string[] | no | empty | stable strings | Review/search metadata. |
| `setupSeeds.productCollections/products[].schedule.startsAt` | string | no | omitted | timestamp string | Timezone required when set. |
| `setupSeeds.productCollections/products[].schedule.endsAt` | string | no | omitted | timestamp string | Timezone required when set. |
| `setupSeeds.productCollections/products[].schedule.timezone` | string | required with dates | omitted | IANA timezone | Example `America/Los_Angeles`. |
| `setupSeeds.productCollections/products[].schedule.recurrence` | string | no | omitted | non-empty | Host-interpreted recurrence expression. |

### Notification setup binding

Notification seeds are the published extension seam into the Cedros
Notifications settings surface. For each active installed extension, Cedros
Data reads `setupSeeds.notifications[]` and appends those event options to
Settings → Notifications:

- `audience: "team"` appears under Team Notifications as an operator-routed
  event. Operators can choose independent endpoint kinds and destinations for
  each event.
- `audience: "personal"` appears under My Notifications as a per-user event
  preference. It uses that user's personal delivery endpoints.
- Disabled extensions do not contribute notification options.
- The persisted settings key is `eventId`, not the seed `id`. Keep `eventId`
  stable across releases.

Every notification seed must bind to a declared `surfaces.server.events[]`
entry. The seed exposes the routing/preference option; it does not publish the
runtime event. The extension's server package must still emit the matching
event through the Wasm telemetry import or a host-coordinated dispatcher.

Use `defaultChannels[]` only as channel-kind guidance (`email`, `discord`,
`slack`, `telegram`). Never put webhook URLs, bot tokens, email credentials,
processor payloads, auth tokens, passwords, or unnecessary PII in manifest
templates. Notification `subjectTemplate` and `bodyTemplate` must be redacted
operator-safe defaults.

Example:

```json
{
  "id": "acme-orders:purchase-completed-notification",
  "displayName": "Purchase Completed Notification",
  "title": "Purchase completed",
  "description": "Team notification route for completed purchases.",
  "eventId": "acme-orders:purchase-completed",
  "audience": "team",
  "severity": "info",
  "defaultChannels": ["email"],
  "subjectTemplate": "Purchase completed",
  "bodyTemplate": "Purchase {{orderRef}} completed for {{currency}} {{amount}}.",
  "tags": ["orders", "notifications"]
}
```

## Field reference: forms, docs, policies, i18n, PWA

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `formTemplates[].id` | string | yes | none | namespaced id | Starter form id. |
| `formTemplates[].displayName` | string | yes | none | non-empty | Owner-facing starter label. |
| `formTemplates[].title` | string | yes | none | non-empty | Initial form title. |
| `formTemplates[].description` | string | no | omitted | non-empty | Starter summary. |
| `formTemplates[].defaultKey` | string | no | derived | slug/key | Default editable form key. |
| `formTemplates[].status` | string | no | active | active/draft | Starter visibility. |
| `formTemplates[].seoIndexable` | boolean | no | false | true/false | Explicitly opts the active standalone form route into Core-managed canonical, WebPage schema, and sitemap output. Requires a non-empty `description`; embedded uses are unaffected. |
| `formTemplates[].autoCreateOnEnable` | boolean | no | false | true/false | Auto-create as a real form on enable instead of a "Use Template" card. Live/draft follows `status`. |
| `formTemplates[].scope` | string | no | other | contact/other | Metadata unless host gives behavior. |
| `formTemplates[].submitLabel` | string | no | host default | non-empty | Submit button copy. |
| `formTemplates[].successTitle` | string | no | host default | non-empty | Success heading. |
| `formTemplates[].successMessage` | string | no | host default | non-empty | Success body copy. |
| `formTemplates[].fields[].key` | string | yes | none | key | Unique field key within template. |
| `formTemplates[].fields[].label` | string | yes | none | non-empty | Field label. |
| `formTemplates[].fields[].type` | string | yes | none | text/email/textarea/tel/select/checkbox | Select requires options. |
| `formTemplates[].fields[].required` | boolean | no | false | true/false | Required field marker. |
| `formTemplates[].fields[].placeholder` | string | no | omitted | non-empty | Input hint. |
| `formTemplates[].fields[].helpText` | string | no | omitted | non-empty | Short helper text. |
| `formTemplates[].fields[].options[].label` | string | yes for select | none | non-empty | Select option label. |
| `formTemplates[].fields[].options[].value` | string | yes for select | none | non-empty | Select option value. |
| `docsArticles[].id` | string | yes | none | namespaced id | Stable extension article id. |
| `docsArticles[].displayName` | string | yes | none | non-empty | Owner-facing article label. |
| `docsArticles[].title` | string | yes | none | non-empty | Public end-user article title. |
| `docsArticles[].slug` | string | yes | none | slug | Stable docs slug. |
| `docsArticles[].routePath` | string | no | omitted | absolute route | Public/docs route when supported. |
| `docsArticles[].excerpt` | string | no | omitted | non-empty | Public article summary. |
| `docsArticles[].bodyMarkdown` | string | yes | none | markdown | Public end-user help content for the extension's public pages or flows; not site-admin setup guidance. |
| `docsArticles[].category` | string | no | omitted | stable string | Docs category. |
| `docsArticles[].tags[]` | string[] | no | empty | stable strings | Docs tags. |
| `docsArticles[].productSlug` | string | no | omitted | slug | Product grouping. |
| `docsArticles[].productLabel` | string | no | omitted | non-empty | Product label. |
| `docsArticles[].sectionKey` | string | no | omitted | slug/key | Navigation grouping key. |
| `docsArticles[].sectionLabel` | string | no | omitted | non-empty | Navigation label. |
| `docsArticles[].sectionOrder` | number | no | omitted | integer | Section sort order. |
| `docsArticles[].navLabel` | string | no | omitted | non-empty | Navigation display label. |
| `docsArticles[].emoji` | string | no | omitted | emoji/string | Optional docs UI marker. |
| `docsArticles[].readingMinutes` | number | no | omitted | integer | Reading estimate. |
| `docsArticles[].order` | number | no | omitted | integer | Sort order. |
| `docsArticles[].aliases[]` | string[] | no | empty | route/slug strings | Redirect/search aliases. |
| `docsArticles[].seo` | object | no | omitted | see SEO Metadata Contract | Initial SEO defaults for the draft docs record. |
| `docsArticles[].internal` | boolean | no | false | true/false | Operator-only article: kept out of public docs nav and forced `noindex` (stored as `attributes.internal` on the created record). |
| `docsArticles[].autoCreateOnEnable` | boolean | no | ignored | true/false | Deprecated compatibility field; docs records always materialize as drafts on enable. |
| `docsArticles[].publishOnEnable` | boolean | no | ignored | true/false | Deprecated compatibility field; extension docs always start as drafts. |
| `policies[].id` | string | yes | none | namespaced id | Starter policy id. |
| `policies[].kind` | string | yes | none | stable string | Policy family, e.g. `refund-returns-policy`. |
| `policies[].displayName` | string | yes | none | non-empty | Owner-facing starter label. |
| `policies[].title` | string | yes | none | non-empty | Policy page title. |
| `policies[].slug` | string | yes | none | slug | Default page slug. |
| `policies[].routePath` | string | no | derived | absolute route | Public policy route when enabled. |
| `policies[].footerLabel` | string | no | title | non-empty | Suggested footer link label. |
| `policies[].excerpt` | string | no | omitted | non-empty | Policy summary. |
| `policies[].bodyMarkdown` | string | yes | none | markdown | Owner-reviewed starter body. |
| `policies[].category` | string | no | legal | stable string | Content grouping. |
| `policies[].tags[]` | string[] | no | empty | stable strings | Search/review tags. |
| `policies[].order` | number | no | 0 | integer | Sort order. |
| `policies[].seo` | object | no | omitted | see SEO Metadata Contract | Initial SEO defaults for auto-created policy content. |
| `policies[].autoCreateOnEnable` | boolean | no | false | true/false | Auto-create as a runtime content page on enable instead of a "Use Template" card. |
| `policies[].publishOnEnable` | boolean | no | false | true/false | Publish the auto-created policy page immediately; otherwise it stays a draft. |
| `i18nCatalogs[].locale` | string | yes | none | BCP 47 locale | Locale for this catalog. Duplicate locale/namespace pairs are rejected. |
| `i18nCatalogs[].namespace` | string | yes | none | extension-owned namespace | Must be `extensionId`, `extensionId:*`, or `extensionId.*`. |
| `i18nCatalogs[].catalog` | object | yes | none | strings, nested objects, plural maps | Runtime translations used by `LocaleProvider`. Any object containing an `other` key is treated as a plural map; plural maps may only use `zero`/`one`/`two`/`few`/`many`/`other`. |
| `pwaShortcuts[].id` | string | yes | none | namespaced id | Review and dedupe key; not emitted into the public manifest. |
| `pwaShortcuts[].name` | string | yes | none | non-empty | Public shortcut label. |
| `pwaShortcuts[].shortName` | string | no | omitted | non-empty | Compact shortcut label. |
| `pwaShortcuts[].description` | string | no | omitted | non-empty | Public shortcut summary. |
| `pwaShortcuts[].url` | string | yes | none | same-origin absolute path | Must start with `/`, not `//`; external origins are rejected. |
| `pwaShortcuts[].icons[].src` | string | yes | none | same-origin absolute path | Shortcut icon path. |
| `pwaShortcuts[].icons[].sizes` | string | no | omitted | non-empty | Web manifest image size hint. |
| `pwaShortcuts[].icons[].type` | string | no | omitted | MIME type | Web manifest image type hint. |
| `pwaShortcuts[].icons[].purpose` | string | no | omitted | non-empty | Web manifest icon purpose hint. |

## Field reference: AI surfaces

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `surfaces.ai.packageRef` | string | yes when `ai` exists | none | `server` | AI metadata owner. When `surfaces.ai` exists it must publish at least one skill or capability; an empty AI surface is rejected. |
| `surfaces.ai.skills[].id` | string | yes | none | namespaced id | Skill discovery metadata. Must not contain `/` or whitespace. |
| `surfaces.ai.skills[].name` | string | yes | none | non-empty | Skill name. |
| `surfaces.ai.skills[].description` | string | yes | none | non-empty | Skill summary. |
| `surfaces.ai.skills[].category` | string | yes | none | stable string | Discovery grouping. |
| `surfaces.ai.skills[].tags[]` | string[] | no | empty | stable strings | Discovery tags. |
| `surfaces.ai.skills[].visibility` | string | yes | none | public/authenticated/admin | Discovery audience. |
| `surfaces.ai.skills[].docs.markdown` | string | yes | none | markdown | Skill docs. |
| `surfaces.ai.capabilities[].id` | string | yes | none | namespaced id | Capability id. Must not contain `/` or whitespace. |
| `surfaces.ai.capabilities[].name` | string | yes | none | non-empty | Capability name. |
| `surfaces.ai.capabilities[].description` | string | yes | none | non-empty | Capability summary. |
| `surfaces.ai.capabilities[].kind` | string | yes | none | tool/action | Execution contract type. |
| `surfaces.ai.capabilities[].tags[]` | string[] | no | empty | stable strings | Discovery tags. |
| `surfaces.ai.capabilities[].visibility` | string | yes | none | public/authenticated/admin | Execution audience. |
| `surfaces.ai.capabilities[].endpoint.method` | string | yes | none | POST/PUT/PATCH | Downstream method. |
| `surfaces.ai.capabilities[].endpoint.path` | string | yes | none | absolute path | Does not create a route by itself. Must not start with the reserved `/ai/capabilities` prefix. |
| `surfaces.ai.capabilities[].auth.schemes[]` | string[] | only when `visibility: "public"` may it be omitted | empty | `bearer-token` | For `authenticated`/`admin` visibility at least one scheme is required; `bearer-token` is the only accepted value. |
| `surfaces.ai.capabilities[].inputSchema` | object | yes | none | JSON object schema | Input schema. |
| `surfaces.ai.capabilities[].outputSchema` | object | no | omitted | JSON object schema | Output schema. |

AI safety/approval fields such as `requiresApproval`, `destructive`,
`idempotent`, `riskLevel`, and `humanReview` are currently handoff
documentation, not validated manifest fields. Do not invent unsupported fields.

## Field reference: provider, database, customer-tag, CRM access

| Path | Type | Required | Default | Allowed values | Notes |
|---|---|---:|---|---|---|
| `providerAccess[].id` | string | yes | none | namespaced id | One provider use case. |
| `providerAccess[].provider` | string | yes | none | intelligence/imageGeneration/voice/storage/email/blockchain | Site-owned provider family. `domains` parses for catalog display only and is managed-API-only — authoring validation rejects it as a guest provider grant. |
| `providerAccess[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `providerAccess[].description` | string | yes | none | non-empty | Why provider access is needed. |
| `providerAccess[].scopes[]` | string[] | yes | none | stable strings | At least one required. |
| `providerAccess[].tags[]` | string[] | no | empty | stable strings | Usage/cost grouping. |
| `databaseAccess[].id` | string | yes | none | namespaced id | One database use case. |
| `databaseAccess[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `databaseAccess[].description` | string | yes | none | non-empty | Why the extension needs DB access. |
| `databaseAccess[].contentModels[]` | string[] | no | empty | declared content model ids | Must reference `surfaces.server.contentModels[]`. Each `databaseAccess[]` entry must reference at least one declared content model or migration; intake rejects entries that reference neither. |
| `databaseAccess[].migrations[]` | string[] | no | empty | declared migration ids | Must reference `surfaces.server.migrations[]`; metadata/scoping for reviewed in-process work, not an executable Wasm migration grant. See the contentModels/migrations at-least-one rule above. |
| `databaseAccess[].tags[]` | string[] | no | empty | stable strings | Observability grouping. |
| `databaseAccess[].scopes[].verb` | string | yes | none | read/count/write/delete/migrate | At least one scope is required. `batch` and `compare-and-set` are operations, not verbs: they grant no authority beyond each condition's `read` and each mutation's `write`/`delete` scope. `compare-and-set` also requires dependency capability `cedros-data:extension-storage-cas-v1`. |
| `databaseAccess[].scopes[].resource` | string | yes | none | non-empty | Operator-facing description, not a model selector. Authority comes from this access ID’s `contentModels`, `migrations`, and scope verbs; use separate access IDs for different model/operation grants. |
| `databaseAccess[].scopes[].summary` | string | yes | none | non-empty | Operator-facing purpose. |
| `customerTagAccess[].id` | string | yes | none | namespaced id | One customer-tag use case. Must start with `{extensionId}:`. |
| `customerTagAccess[].displayName` | string | yes | none | non-empty | Operator-facing label shown in install review. |
| `customerTagAccess[].description` | string | yes | none | non-empty | Operator-facing reason the extension needs the seam. |
| `customerTagAccess[].scopes[]` | string[] | yes | none | `read` / `assign` / `unassign` | At least one verb required. |
| `customerTagAccess[].managedTagSlugs[]` | string[] | yes | none | namespaced tag slugs | At least one slug required. Each slug must start with `{extensionId}:` and match `[a-z0-9:_-]+`. Slugs are lowercased on lookup. |
| `customerTagAccess[].tags[]` | string[] | no | empty | stable strings | Observability grouping. No PII. |
| `crmSourceAccess[].id` | string | yes | none | namespaced id | One CRM source-event use case. |
| `crmSourceAccess[].sourceKind` | string | yes | none | `cedros_pay`; reserved `cedros_login` only for extension id `cedros-login` | Source system accepted by the host bridge. |
| `crmSourceAccess[].displayName` | string | yes | none | non-empty | Operator-facing label. |
| `crmSourceAccess[].description` | string | yes | none | non-empty | Why CRM attribution is needed. |
| `crmSourceAccess[].scopes[]` | string[] | yes | none | `write` | At least one required. |
| `crmSourceAccess[].eventTypes[]` | string[] | yes | none | event type or `*` | Event types this access can submit. |
| `crmSourceAccess[].tags[]` | string[] | no | empty | stable strings | Redacted reporting labels. |

Access-list hygiene rules (intake-enforced across `providerAccess[]`,
`customerTagAccess[]`, `crmSourceAccess[]`, and `databaseAccess[]`): duplicate
or empty values in `scopes[]`, `tags[]`, `eventTypes[]`, and
`managedTagSlugs[]` are rejected. Each `crmSourceAccess[].eventTypes[]` value
must match `[a-z0-9._-]+` or be `*`.

`customerTagAccess[]` declares the extension's intent to mutate CRM customer
profile tags through the host bridge. Live behavior is **self-serve today**:
the host publishes a validated client that enforces manifest scopes plus
`managedTagSlugs[]` on every call, and tag definitions are auto-created on
first assign — see
[`20-crm-tags-and-source-events.md`](20-crm-tags-and-source-events.md).

## Runtime emission shapes (not manifest metadata)

### Site-brain record shape

Site-brain records are runtime emissions through `telemetry.emit-record`, not
manifest metadata. See [`16-analytics-and-site-brain.md`](16-analytics-and-site-brain.md).

| Path | Type | Required | Notes |
|---|---|---:|---|
| `category` | string | yes | Stable lowercase category. |
| `subject` | string | yes | Stable subject or namespaced extension subject. |
| `title` | string | yes | Human-readable title. |
| `summary` | string | yes | Short operator-facing summary. |
| `text` | string | no | Longer safe details. |
| `tags[]` | string[] | no | Lowercase stable tags. |
| `details` | JSON object | no | Redacted safe context. |
| `references[]` | object[] | no | Admin/public/job/provider references. |

Site-brain reference object:

| Field | Type | Required | Notes |
|---|---|---:|---|
| `kind` | string | yes | `admin-page`, `public-page`, `job`, `route`, `provider-call`, `database-operation`, `ai-capability`, or host-published kind. |
| `id` | string | no | Stable id when available. |
| `path` | string | no | Safe internal/admin/public path when available. |
| `url` | string | no | Only if safe and host-approved. |
| `label` | string | yes | Human-readable label. |
| `description` | string | no | Redacted support context. |

Example durable record:

```json
{
  "category": "sync",
  "subject": "acme-demo:nightly-sync",
  "title": "Nightly sync completed",
  "summary": "Synced 12 records with 1 skipped item.",
  "tags": ["acme-demo", "sync"],
  "details": {
    "syncedCount": 12,
    "skippedCount": 1,
    "runId": "redacted-run-ref"
  }
}
```

### Transient log shape

Logs are runtime diagnostics and should include context plus cause without
secrets or raw PII.

| Field | Required | Notes |
|---|---:|---|
| `level` | yes | debug/info/warn/error. |
| `message` | yes | Human-readable. |
| `extensionId` | yes | Extension owner. |
| `surface` | no | admin/web/server/native/job/provider. |
| `operation` | no | Stable operation name. |
| `requestId`/`runId` | no | Correlation ids. |
| `cause` | no | Redacted error cause. |
| `metadata` | no | Safe JSON only. |

## Archive and bootstrap

`cedros-extension.manifest.json` contains the canonical manifest.

`cedros-extension.bootstrap.json` contains:

```json
{
  "manifest": {
    "schemaVersion": 1
  }
}
```

The nested manifest must be the full canonical manifest. The host accepts
EITHER canonical file alone and derives the other; the UI intake even falls
back to ranked loose JSON names (`manifest.json`, `cedros-extension.json`,
`extension.json`, `bootstrap.json`). When both canonical files exist, Cedros
validates deep JSON equality of the manifest objects. Production rule: ship
both canonical files, generated from the same manifest object. Full archive
contract: [`22-packaging-and-upload.md`](22-packaging-and-upload.md).

The minimal example omits optional empty arrays for readability.
Implementation examples should prefer explicit empty arrays when generating
machine-checked manifests.

## Minimal valid example

```json
{
  "schemaVersion": 1,
  "extensionId": "cedros-demo-minimal",
  "displayName": "Cedros Demo Minimal",
  "version": "1.0.0",
  "platformApiVersion": "1",
  "compatibility": { "platformApiVersion": "1" },
  "packageFamily": {
    "server": { "packageName": "cedros-demo-minimal-server", "version": "1.0.0", "required": true },
    "react": { "packageName": "@cedros-demo/minimal", "version": "1.0.0", "required": true },
    "reactNative": { "packageName": "@cedros-demo/minimal-native", "version": "1.0.0", "required": true }
  },
  "surfaces": {
    "server": { "packageRef": "server", "required": true },
    "admin": { "packageRef": "react", "required": true, "moduleIds": ["cedros-demo-minimal:admin"] },
    "web": { "packageRef": "react", "required": true },
    "native": { "packageRef": "reactNative", "required": true }
  },
  "registration": {
    "server": { "entrypoint": "cedros_demo_minimal_server::register_extension_family" },
    "admin": { "entrypoint": "@cedros-demo/minimal/admin/register" },
    "web": { "entrypoint": "@cedros-demo/minimal/web/register" },
    "native": { "entrypoint": "@cedros-demo/minimal-native/register" }
  },
  "adminModules": [
    {
      "moduleId": "cedros-demo-minimal:admin",
      "extensionId": "cedros-demo-minimal",
      "displayName": "Demo Minimal",
      "version": "1.0.0",
      "packageName": "@cedros-demo/minimal",
      "sectionIds": ["cedros-demo-minimal:overview"],
      "sectionIcons": { "cedros-demo-minimal:overview": "extensions" },
      "navigation": {
        "sections": [
          {
            "id": "cedros-demo-minimal:overview",
            "label": "Overview",
            "group": "Extension Settings",
            "order": 10
          }
        ]
      }
    }
  ]
}
```

Note: the example declares `adminModules[]`, which makes intake require the
compiled React package (browser ESM reachable through
`exports["./admin/register"]`) inside the uploaded ZIP. For a metadata-only
smoke test, drop `adminModules` (and the `surfaces.admin.moduleIds` entry);
otherwise include the compiled React package.

## Invalid examples

- `extensionId: "Cedros Demo"`: violates the lowercase kebab-case convention.
  Convention only, not validated — intake checks non-empty only.
- `extensionId: "acme:store"`: an `extensionId` must not contain `:` (the
  reserved `<extension-id>:<model>` namespace separator). This one IS validated
  — intake rejects it. Do not mimic namespacing in the id itself; the host
  prepends `{extensionId}:` for you.
- two `pageSeeds[]` entries with the same id, or whose `routePath` values
  normalize to the same route: intake rejects duplicates. A relative
  `routePath` such as `"landing"` is not rejected; it is normalized to
  `/landing`.
- `providerAccess[].scopes: []`: provider access must declare at least one
  scope.
- `databaseAccess[].contentModels: ["missing"]`: database access must reference
  declared `surfaces.server.contentModels[]` entries.
- `databaseAccess[].scopes: []`: database access must declare at least one
  database scope.
- `customerTagAccess[].id: "customer-tags"`: customer-tag access ids must be
  namespaced with `{extensionId}:`.
- `customerTagAccess[].managedTagSlugs: ["vip-customer"]`: each managed tag
  slug must start with `{extensionId}:`.
- `customerTagAccess[].scopes: []`: customer-tag access must declare at least
  one of `read`, `assign`, `unassign`.
- `customerTagAccess[].managedTagSlugs: []`: customer-tag access must declare
  at least one managed slug; an empty list means the extension cannot mutate
  any tags.
- `crmSourceAccess[].sourceKind: "raw_payments"`: CRM source-event access is
  limited to supported source kinds. Third-party payment attribution uses
  `cedros_pay`; reserved first-party `cedros_login` is accepted only for the
  bundled `cedros-login` extension and its account/identifier linking events.
- `crmSourceAccess[].eventTypes: []`: CRM source-event access must declare at
  least one event type.
- `surfaces.ai.capabilities[].endpoint.path: "sync"`: endpoint path must be
  absolute and does not mount itself.
- `registration.admin.entrypoint: "/admin/register"`: manifest entrypoints must
  include the package name.
- root `capabilities[]` declaring `cedros-pay:checkout`: consumed
  capabilities belong in `dependencies.capabilities[]`, not root
  extension-published capabilities.
- `supplyChain.verified: true`: marketplace verification is computed by
  Cedros, not declared by the author.
- `supplyChain.source.repositoryUrl: "git@example.com:repo.git"`: source links
  must be reviewable HTTPS URLs.
- `supplyChain.source.revision: "main"`: source revisions must be immutable
  full commit SHAs, not branches.
- `supplyChain.build.provenanceUrl` without
  `supplyChain.build.provenanceSha256`: external evidence URLs need digests.
- `supplyChain.source.directory` set to an absolute filesystem path: source
  directories must be repository-relative paths, not machine-local paths.
- `pageSeeds[].seo.canonicalPath: "https://example.com/page"`: extension SEO
  canonical paths must be same-origin absolute paths such as `/page`.
- `docsArticles[].seo.robots: "index"`: unsupported SEO keys are rejected; use
  `noindex: true` when the starter content should be hidden from search.
- top-level `sitemapUrls`, `hreflang`, `breadcrumbs`, `schema`, or `jsonLd`
  keys: reserved SEO fields; route SEO through `pageSeeds[].seo`,
  `docsArticles[].seo`, or `seoRoutes[]` instead.
- `seoRoutes[].pathPattern: "/product/:slug"` without the wasm `seo` export:
  dynamic patterns require the `extension-seo` world; install fails.
- duplicate values in `surfaces.admin.moduleIds[]`: intake validates moduleIds
  uniqueness only. There is no cross-check against `adminModules[].moduleId`;
  the ZIP-runtime requirement keys on `adminModules[]` being non-empty, not on
  `surfaces.admin.moduleIds[]`.
- `setupSeeds.scheduling[].paymentPolicy.productSeedId` pointing to a missing
  product seed: paid scheduling must bind to a declared product seed or an
  explicit checkout capability.
- `setupSeeds.products[].capacity.owner: "schedulingAvailability"` without a
  `schedulingSeedIds[]` reference: appointment capacity must point at the
  scheduling seed that owns availability.
- `setupSeeds.productCollections[].capacity.owner: "schedulingAvailability"`:
  collection-level event capacity must be owned by Shop inventory or an
  external source; Scheduling capacity belongs on products with
  `schedulingSeedIds[]`.
- `setupSeeds.notifications[].eventId` pointing to a missing server event:
  notification setup must bind to a declared `surfaces.server.events[]` event.
- `setupSeeds.contractTemplates[].fields[].roleId` pointing to a missing role:
  contract fields must bind to declared signer roles.
- `setupSeeds.emailTemplates[].htmlBodyTemplate` omitted: email template seeds
  must ship complete subject, HTML body, and plain-text fallback copy.
- `jobSchedules[].jobId` pointing to a missing `surfaces.server.jobs[]` id:
  schedules must reference declared jobs.
- two `cedros-extension.manifest.json` files in one ZIP: intake rejects
  duplicate canonical entries.

## Intake validation behavior

- `schemaVersion` other than `1` is rejected at intake
- a `compatibility.platformApiVersion` mismatch is NOT rejected at intake: the
  package imports but shows as Unavailable in the UI, and is rejected
  server-side at install/enable
- required package surfaces and fixed registration entrypoints are validated
- namespaced contribution ids are validated for implemented seams
- duplicate ids are rejected where validation exists
- missing provider scopes, database scopes/references, customer-tag scopes/slugs,
  form fields, docs/policy body, AI docs/schemas, and setup seed references are
  rejected
- admin modules with sections are rejected unless `sectionIds`, `sectionIcons`,
  and `navigation.sections` have exact id coverage; malformed navigation,
  undeclared custom groups, and duplicate navigation ids/groups are rejected
- reserved top-level SEO keys are rejected; `seoRoutes[]` entries reject
  unmodeled keys
- manifest/bootstrap mismatch in archives is rejected

## Runtime behavior

Manifest metadata can make a surface visible to inventory and review. If an
extension declares admin modules, executable admin behavior must ship as
compiled browser ESM inside the uploaded ZIP and must be reachable through the
React package `exports["./admin/register"]` entry. If an extension declares
server routes, jobs, settings schemas, content models, database access,
provider access, customer-tag access, telemetry, or AI capability endpoints, the
package must include the compiled `cedros-extension.server.wasm` component that
implements those exports/calls. Native hooks and non-Wasm/sidecar server
surfaces without a published self-serve contract should produce a host handoff
row instead of inventing a manifest field or SDK method. Do not encode
executable runtime behavior in the manifest or archive JSON.

`adminModules[].navigation` is intentionally not executable behavior. It is the
JSON-safe projection Cedros persists for the first sidebar paint. The loaded
runtime must expose the same sections and groups; a mismatch keeps the stable
manifest fallback instead of moving or relabeling navigation after hydration.

Next: [`05-package-family-and-registration.md`](05-package-family-and-registration.md).

## Visitor routes and isolated blocks

`routePolicies[]` declares `{ routeId, endUserAuth: "required" | "optional",
access?: "signed-in", emailPurpose?: string }` for a declared server route.
Signed-in access requires required auth. `pageSeeds[].access: "signed-in"`
gates authored pages and forces noindex. `interactiveBlocks[]` declares
`{ blockType, renderRouteId, routeIds }`; all referenced routes must opt into
visitor authentication. Declare `cedros-data:extension-visitor-v1` in
`requiredCapabilities` so older hosts fail activation closed. See
[the complete contract](contracts/extension-visitor-v1.md).

# 05 · Package Family, Registration, and Bootstrap

Every Cedros extension is one **package family**: a Rust server crate, a React
admin/web package, and a React Native package, declared by one canonical
manifest and shipped together in one ZIP. This document covers the concrete
files, exports, build commands, bootstrap generation, and cross-package
alignment checks for that family.

## Hard requirements

- one shared `extensionId`
- `schemaVersion: 1`
- `platformApiVersion: "1"` and `compatibility.platformApiVersion: "1"`
- server package, React package, and React Native package — all three members,
  even when a member is a minimal bootstrap
- server/admin/web/native surfaces declared (empty arrays are fine)
- fixed registration entrypoints generated from `packageFamily`:
  - server: `crate_name::register_extension_family`
  - admin: `${packageFamily.react.packageName}/admin/register`
  - web: `${packageFamily.react.packageName}/web/register`
  - native: `${packageFamily.reactNative.packageName}/register`
- no custom registration paths, no remote-code-loading assumptions

A React Native member may be a minimal bootstrap-only package for platform API
`1` unless native screens/stacks/providers have an approved host loader.

## Repository layout

ZIP layout is not enforced by directory shape. The binding contract is:
exactly one `package.json` anywhere in the ZIP whose `name` equals
`packageFamily.react.packageName`, with the registration exports resolving to
existing `.js`/`.mjs` files under that package root. Two matching
`package.json` files are rejected.

Example layout (matches the archive contract in
[`22-packaging-and-upload.md`](22-packaging-and-upload.md) and the runnable
`examples/minimal-extension`):

```txt
cedros-extension.manifest.json
cedros-extension.bootstrap.json
packages/server/            → archived as workspace/server
packages/react/             → archived as workspace/react
packages/react-native/      → archived as workspace/react-native
scripts/package-extension.*
scripts/validate-extension.*
scripts/sync-generated-manifests.*
```

## One canonical manifest source

Generate everything from one manifest object:

- `cedros-extension.manifest.json` — the canonical manifest.
- `cedros-extension.bootstrap.json` — `{ "manifest": <same object> }`. Never
  hand-edit a shortened or divergent bootstrap; the bootstrap root `manifest`
  must deep-equal the manifest file.
- `src/generated-manifest.ts` (react + react-native) and
  `src/generated_manifest.rs` (server) — generated copies the packages return
  from their registration exports.

Actual host behavior: the host accepts EITHER canonical file alone and derives
the other. When both canonical files exist they must deep-equal. Ship both
canonical files in production releases regardless.

> **Common wrong assumption:** the ranked loose-JSON fallback names
> (`manifest.json`, `cedros-extension.json`, `extension.json`,
> `bootstrap.json`) are accepted by the server. **Actually:** that ranked
> fallback is a CLIENT-SIDE UI preview convenience only
> (`ui/src/admin/extensionPackageArchive.ts`). Both server intake endpoints
> require the two canonical entry names via the shared publisher
> (`server/src/extension_platform_archive.rs`).

## Rust server package shape

Expected files:

- `Cargo.toml`
- `src/lib.rs`
- optional `src/routes.rs` for route handlers
- optional `src/jobs.rs` for job executors
- optional `src/providers.rs` / `src/database.rs` for seam helpers
- optional `tests/*` for manifest and handler contract tests

Expected `Cargo.toml` contents:

- package `name` matching `packageFamily.server.packageName`
- package `version` matching the canonical manifest version
- `edition = "2021"` unless the platform contract documents a newer requirement
- no Cedros Data Cargo dependency; use ordinary local types for manifest
  registration and the vendored WIT for executable server capabilities
- only package-local dependencies needed by the extension
- omit `[lib].name` so Cargo derives it from the package name, or make an
  explicit `[lib].name` equal the package name with hyphens converted to
  underscores; that effective crate name must prefix the manifest server
  registration entrypoint

Example: `packageFamily.server.packageName: "cedros-demo-minimal-server"` uses
crate path `cedros_demo_minimal_server` and manifest server entrypoint
`cedros_demo_minimal_server::register_extension_family`.

Minimal `src/lib.rs` template:

```rust
const MANIFEST_JSON: &str = include_str!("../../../cedros-extension.manifest.json");

pub fn register_extension_family() -> serde_json::Value {
    serde_json::from_str(MANIFEST_JSON)
        .expect("extension manifest should stay valid")
}
```

Generate or include the canonical archive manifest during scaffolding. Keep its
path package-local and verify it exists in the source and release layouts.

Server rules:

- Keep the manifest export deterministic. Do not read secrets, environment
  variables, or network state to build the manifest.
- Route handlers and job executors must reference manifest-declared route/job
  ids and be exported by `cedros-extension.server.wasm`
  ([`07-wasm-server-backends.md`](07-wasm-server-backends.md)).
- Provider calls use the Wasm `providers` import with extension attribution;
  database calls use the Wasm `database` import with a declared
  `databaseAccess[]` id. Never request raw Postgres credentials or pools.
- The in-process Rust route/job registry is for first-party host code. A
  heavyweight extension (own relational schema, large deps, or a full
  standalone server) integrates as a host-coordinated sidecar service, not
  in-process (see [`21-host-coordination-and-native.md`](21-host-coordination-and-native.md)).
  Bespoke typed migrations remain host-coordinated.

## React admin and web package shape

Expected files:

- `package.json`
- `tsconfig.json`
- `src/manifest.ts`
- `src/bootstrap.ts`
- `src/admin/register.ts`
- `src/web/register.ts`
- optional `src/admin/*` for admin modules, dashboard cards, wrappers, and
  configuration pages
- optional `src/web/*` for public runtime components
- optional `src/content/*` for block/template definitions
- optional `src/shared/*` for shared schemas, copy, fixtures, and helpers
- optional `tests/*` or `src/**/*.test.tsx`

Expected `package.json` contents:

- `name` matching `packageFamily.react.packageName`
- `version` matching the canonical manifest version
- `"type": "module"`
- `exports["./admin/register"]` and `exports["./web/register"]`
- `files` limited to built artifacts and needed metadata
- a local declaration for the host-provided `cedros:admin` virtual module when
  runtime values or shared authoring types are needed; no Cedros npm dependency
- build script such as `tsc -p tsconfig.json` or the package's chosen bundler

React package exports example:

```json
{
  "exports": {
    "./admin/register": "./dist/admin/register.js",
    "./web/register": "./dist/web/register.js"
  }
}
```

Manifest registration uses full package entrypoints such as
`@acme/demo-react/admin/register`; package exports use Node package paths such
as `./admin/register`.

Expected admin registration:

- exports `registerCedrosAdminSurface()`
- returns a Cedros bootstrap object with `modules` (`AdminModule[]`) when the
  manifest declares `adminModules[]` — the bare bootstrap registers zero admin
  pages
- includes admin modules for declared admin section ids
- derives manifest `navigation.sections`/`navigation.groups` and runtime
  `sections`/`groups` from one source of truth so first paint and runtime match
- includes dashboard card components for declared dashboard card ids
- includes shell/section wrappers only when the manifest declares those slots

Expected web registration:

- exports `registerCedrosWebSurface()`
- returns the canonical bootstrap manifest plus web/runtime contributions
- provides block/template definitions for declared visual-builder ids
- provides executable public block components or renderers for every declared
  public block type that appears in a page seed or authored page
- preserves visual parity between any static first-render shell and the
  browser-running component
- wires every visible public control to its real action or explicitly
  disables/hides it when required runtime config is missing

Do not return metadata-only `contentBlocks[]` for a block that is supposed to
work on the public site. If the public page contains `acme-shop:add-to-cart`,
`acme-shop:cart`, `acme-shop:checkout`, or `cedros-login:auth-form`, the web
registration must include the executable component/renderer that performs the
advertised action. A polished static placeholder is acceptable only as a
fallback/loading shell and must be visually equivalent to the final working
component ([`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md)).

Minimal React package templates:

```ts
// src/manifest.ts
import type { CedrosExtensionManifest } from "cedros:admin";
import { generatedManifest } from "./generated-manifest";

export const extensionManifest = generatedManifest as CedrosExtensionManifest;
```

```ts
// src/bootstrap.ts
import type { CedrosExtensionBootstrap } from "cedros:admin";
import { extensionManifest } from "./manifest";

export const extensionBootstrap: CedrosExtensionBootstrap = {
  manifest: extensionManifest
};
```

```ts
// src/admin/register.ts
import { extensionBootstrap } from "../bootstrap";
import { adminModule } from "./module";

export function registerCedrosAdminSurface() {
  return { ...extensionBootstrap, modules: [adminModule] };
}
```

```ts
// src/web/register.ts
import { extensionBootstrap } from "../bootstrap";

export function registerCedrosWebSurface() {
  return extensionBootstrap;
}
```

For any extension with public blocks, the web registration normally returns
more than the shared bootstrap:

```ts
// src/web/register.ts
import { extensionManifest } from "../manifest";
import { ProductCardBlock } from "./ProductCardBlock";
import { CartBlock } from "./CartBlock";
import { productCardBlock, cartBlock } from "./blocks";

export function registerCedrosWebSurface() {
  return {
    manifest: extensionManifest,
    contentBlocks: [
      { ...productCardBlock, Component: ProductCardBlock },
      { ...cartBlock, Component: CartBlock }
    ],
    contentTemplates: [
      // templates that seed those blocks
    ]
  };
}
```

The `Component` entries above are the public runtime components, not merely
admin previews. They must render the final styled and working block on the
public page. If a component loads browser-only provider code lazily, its
fallback shell must share the same visual contract.

React rules:

- Keep React code behind stable registration exports.
- If the manifest declares `adminModules[]`, compile the React admin entrypoint
  and every relative chunk it imports into the uploaded ZIP under
  `workspace/react/dist/**`.
- Keep block props serializable and platform-neutral.
- Keep admin configuration pages inside normal admin modules under the
  `Extension Settings` sidebar group; do not invent an extension settings-panel
  seam.
- Use `providerAccess[]` plus host services when components call site-owned
  intelligence, image, voice, storage, or email providers.
- Keep one generated manifest source of truth and import it from admin/web
  registration modules instead of hand-copying constants.

## React Native package shape

Expected files:

- `package.json`
- `tsconfig.json`
- `src/manifest.ts`
- `src/bootstrap.ts`
- `src/register.ts`
- optional `src/screens/*`, `src/providers/*`, `src/shared/*`, `tests/*`

Expected `package.json` contents:

- `name` matching `packageFamily.reactNative.packageName`
- `version` matching the canonical manifest version
- `"type": "module"`
- `exports["./register"]`
- no Cedros npm dependency; keep bootstrap types local to the extension source
- peer dependencies for React Native libraries only when truly needed

Native package exports example:

```json
{
  "exports": {
    "./register": "./dist/register.js"
  }
}
```

Minimal React Native registration:

```ts
import { extensionBootstrap } from "./bootstrap";

export function registerCedrosNativeSurface() {
  return extensionBootstrap;
}
```

### Native runtime support status

Common wrong assumption: declaring `surfaces.native.screenIds`, `stackIds`, or
`providerIds` makes them mount, and core confirms a "required native export".
Actually: the WIT `world extension` (`server/wit/cedros-extension.wit`) imports
host capabilities and exports ONLY `routes` + `jobs` (+ opt-in `seo`) — there
is no native export in the WIT. What actually runs on mobile today is narrower
than the metadata you may declare:

| Native contribution | Status | Notes |
| --- | --- | --- |
| `registerCedrosNativeSurface()` minimal bootstrap | **required & consumed** | App Builder validates the vendored package name/version against `packageFamily.reactNative`. At app startup, the generated registry loader requires the returned bootstrap's `extensionId` and extension `version` to match the installed manifest exactly, then uses the installed manifest for contribution validation. A mismatch throws; it is not silently dropped. Cedros Login uses a dedicated host binding instead of this generic registry. |
| `contentBlockRenderers` loaded by the private native host | **self-serve / live** | custom mobile content blocks are loaded from the installed archive; only blocks the core renderer reports as `supportStatus === "unsupported"` are delegated, and rendering is lifecycle-gated (`react-native/src/register.ts`, `react-native/src/components/extensionBlockRenderer.ts`) |
| `surfaces.native.screenIds` / `stackIds` / `providerIds` | **self-serve for hosted App Builder releases; otherwise host-coordinated** | App Builder packages the installed artifact; the generated app validates required/undeclared/duplicate contributions against the installed manifest at startup before mounting. This is not execution of native code during archive intake or build queueing. A different native host MUST publish the same loader contract before an author treats these declarations as executable (`NATIVE-LOADER-001`). |

`docs/native-raw-code-runtime.md` is a SEPARATE, flag-gated
(`features.nativeRawCodeRuntime`, off by default) EditAllContent page-content
feature for executing raw-code on the mobile app — it is NOT an
extension-authoring native surface, so do not treat it as a path to mount the
native ids above.

React Native rules:

- Keep web-only imports out of native code.
- Keep native ids stable and namespaced.
- Treat generic native screen/stack/provider execution as self-serve only for
  the published hosted App Builder path. For any other native host, classify it
  as host-coordinated until that host publishes the same loader contract.
- Share schemas and copy through package-local shared modules, not private
  web/admin implementation imports.
- Ship the package member even when it only returns a minimal bootstrap and
  marks native execution as host-coordinated.
- Minimal package members must still build, export their fixed registration entry,
  and return the canonical manifest identity and version.

## What the host provisions, and when

There is no guest-exported install/upgrade/enable/seed/migrate lifecycle hook.
The wasm world exports ONLY `routes` and `jobs` (+ opt-in `seo`).
`database.migrate` is an on-demand DB operation — a host import you call at
runtime — NOT a lifecycle hook the host invokes for you.

- **Content models** declared in `surfaces.server.contentModels[]` are
  auto-provisioned at install as JSONB collections. Provisioning is idempotent
  and fail-closed: the install/activation does not report ready if a declared
  model cannot be registered. You do NOT need to call `database.migrate` at
  runtime for ordinary JSONB collections. Existing host-provisioned typed
  collections retain their mode and table mapping. An explicit call can
  re-register the declared model in its existing mode; it cannot change a
  JSONB collection into typed storage. Coordinate typed provisioning before
  install and bespoke schema changes with the host owner.
- **Seeds** — the host extension lifecycle reconciles page seeds and job
  schedules, including during headless/API operations and startup. The admin
  shell materializes extension docs drafts, policy/form starters, and block
  templates asynchronously, gated by `isExtensionProvisioningBusy` in
  `ui/src/admin/extensionProvisioningActivity.ts`. Because
  `autoCreateOnEnable`/`publishOnEnable` default `false`, an opted-out page is
  not created automatically.
- **Upgrade:** jobs converge via a `manifestHash` stamp and are orphan-swept;
  page/docs/policy/form seeds are idempotent-once and intentionally do NOT
  overwrite owner edits.

> **Common wrong assumption:** Cedros has a per-business / per-tenant
> "workspace" concept, so global templates are copied into each business
> workspace and the host fans an install out across tenants. **Actually:**
> Cedros is per-SITE single-tenant. There is no per-tenant model in the
> extension platform and no host install fan-out. Reframe "global templates
> copied into each business workspace" as either (a) per-site page seeds plus
> content-model collections declared in the manifest, or (b) application-level
> multi-business rows that the extension manages itself inside its own content
> models.

## Cross-package alignment checks

- `packageFamily.server.packageName` matches the Rust crate package name.
- the effective Rust library name (explicit `[lib].name`, otherwise the Cargo
  default derived from `[package].name`) matches the crate prefix in
  `registration.server.entrypoint`
- `packageFamily.react.packageName` matches the React `package.json` name.
- `packageFamily.reactNative.packageName` matches the React Native
  `package.json` name.
- the bootstrap returned by the ZIP runtime matches the installed manifest's
  `extensionId` AND `version` EXACTLY — this is a hard load gate with no
  waiver. Browser archive loading and generated native registration throw on
  mismatch; the browser's separate trusted-bootstrap merge omits mismatches.
- package-family versions can differ from the extension version. Hosted native
  packaging checks `package.json` against `packageFamily.reactNative.version`;
  this does not substitute for the runtime bootstrap's extension-version check.
- registration entrypoints match fixed Cedros registration subpaths
- manifest ids match runtime contribution ids
- server route/job ids are paired with Wasm route/job exports or a documented
  sidecar/native host handoff
- generated archive files contain the same manifest object as package exports
- package source contains no secrets and no machine-local absolute paths
- if `supplyChain` exists, package metadata, rebuild command, source revision,
  artifact digest list, and archive output are all mutually consistent

Exact local alignment check shape:

```js
const manifest = readJson("cedros-extension.manifest.json");
const bootstrap = readJson("cedros-extension.bootstrap.json");

assertDeepEqual(bootstrap.manifest, manifest, "bootstrap manifest");
assertEqual(reactPackage.name, manifest.packageFamily.react.packageName, "react package name");
assertEqual(nativePackage.name, manifest.packageFamily.reactNative.packageName, "native package name");
const cargo = readCargoIdentity(serverToml);
assertEqual(cargo.packageName, manifest.packageFamily.server.packageName, "server package name");
const crateName = cargo.libName ?? cargo.packageName.replaceAll("-", "_");
assertEqual(
  crateName,
  manifest.packageFamily.server.packageName.replaceAll("-", "_"),
  "server Cargo library name"
);
assertEqual(
  manifest.registration.server.entrypoint,
  `${crateName}::register_extension_family`,
  "server entrypoint"
);
assertEqual(
  manifest.registration.admin.entrypoint,
  `${manifest.packageFamily.react.packageName}/admin/register`,
  "admin entrypoint"
);
```

Turn this shape into a real validation script in the extension workspace and
run it before packaging (`examples/minimal-extension/scripts/validate-extension.js`
is a working model).

## Local development and smoke loop

Run this before packaging and again after every surface is added.

1. Generate or update one canonical `cedros-extension.manifest.json`.
2. Generate `cedros-extension.bootstrap.json` from that same object.
3. Run the alignment script and fix manifest/package/version/export drift.
4. Build each package member independently.
5. Import each registration export in a smoke test and compare manifest
   identity/version.
6. Verify the package archive includes the compiled React admin runtime when
   `adminModules[]` is declared.
7. Run component tests or fixtures for admin pages, dashboard cards, blocks,
   templates, and native fallbacks that are in scope.
8. Run route/job handler unit tests with fake host requests.
9. Build the wasm component (`cargo build --release --target wasm32-wasip2`)
   when server surfaces are declared, and verify its exports match the
   manifest.

Suggested commands:

```sh
npm --prefix packages/react run build
npm --prefix packages/react-native run build
npm run validate
cargo test --manifest-path packages/server/Cargo.toml
```

Every command above must run without downloading a Cedros Data npm or Cargo
package. A missing documented host/WIT contract is a release blocker and an
explicit host handoff, not a dependency to invent.

## Marketplace source and verifiable build evidence

When the extension will be submitted to a marketplace or shared with operators
who need source trust, design the package family so a verifier can rebuild the
same artifacts from source.

Package metadata should align across Cargo and npm packages:

- package name and version match `packageFamily`
- package `repository` points at the same reviewable HTTPS source repository
  declared in `supplyChain.source.repositoryUrl`
- package `license` aligns with `supplyChain.source.license`
- release source lives at `supplyChain.source.revision`, not a moving branch
- monorepo packages document the repository-relative
  `supplyChain.source.directory`
- build scripts are deterministic enough to run from a clean checkout

Verification-ready package plan:

1. Record the source repository URL, exact commit SHA, optional tag, license,
   and source directory.
2. Record whether the release expects signed commits or signed tags, then keep
   the verification result out of the author manifest until Cedros computes it.
3. Generate SBOM evidence when the release channel requires it (SPDX or
   CycloneDX).
4. Generate build provenance/attestation evidence when the build system
   supports it (SLSA provenance, in-toto attestation, Sigstore bundle, or a
   clearly named custom format).
5. Build each package member from a clean checkout and produce SHA-256 digests
   for referenced package artifacts. The enclosing upload ZIP digest belongs
   in the release packet because the manifest is inside that ZIP.
6. If signing artifacts, create detached signatures or Sigstore bundles after
   artifact bytes are final. Do not create circular signatures that require the
   signature file to be inside the signed bytes.
7. Put only evidence links and digests in `supplyChain`; keep marketplace
   verification status in release review records, not in the manifest.

Suggested verifier steps:

```sh
git fetch --tags
git checkout <full-commit-sha>
git verify-commit <full-commit-sha>
git verify-tag <release-tag>
node --version   # v24.17.0
npm --version    # 11.13.0
npm ci
npm run build
npm run validate
npm run package:extension
shasum -a 256 <artifact>
```

Node.js `24.17.0` LTS with npm `11.13.0` is the Cedros authoring and
verification baseline. Skip commands that do not apply to the package manager
or signing method, but record the skipped reason in the release packet. A
failed signature check, missing revision, unreachable source URL, artifact
digest mismatch, or rebuild output mismatch should be treated as a marketplace
review failure unless the release explicitly records `provided-unverified`.

## UI quality baseline

- Follow host theme tokens and density; avoid hard-coded palettes and spacing
  where SDK theme helpers exist. For runtime block/surface styling, consume the
  `--cedros-runtime-*` tokens
  ([`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md));
  for admin surfaces, the `--cd-*` tokens
  ([`12-admin-pages-and-dashboard-cards.md`](12-admin-pages-and-dashboard-cards.md)).
- Provide keyboard navigation, labels, focus states, and readable empty/error
  states for admin and dashboard UI.
- Keep visible copy localizable: no string concatenation that prevents
  translation, and no text embedded in generated images.
- Keep dashboard cards fast: fetch only the data needed for the card, cache or
  debounce refreshes, and show stale/error states without blocking the page.

## Acceptance checks

- each package can build independently
- package registration exports can be imported by a smoke test
- declared admin modules have a ZIP-contained compiled React admin runtime
  reachable from `exports["./admin/register"]`
- every declared admin section has exact `sectionIds`, `sectionIcons`, and
  `navigation.sections` coverage; runtime sections/groups match the persisted
  navigation projection
- `register_extension_family()` returns the same manifest as the archive root
- React admin/web/native registrations return the same manifest identity and
  version as the archive root
- host-coordinated runtime gaps are listed in the handoff table; ordinary
  server routes/jobs are backed by the packaged Wasm component instead

Next: [`06-runtime-sdk-reference.md`](06-runtime-sdk-reference.md).

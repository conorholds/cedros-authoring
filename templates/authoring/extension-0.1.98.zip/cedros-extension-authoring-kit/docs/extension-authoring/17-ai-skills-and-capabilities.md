# 17 · AI Skills and Capabilities

Read this when an extension contributes AI-discoverable skills or executable
AI capabilities to Cedros AI surfaces (the site assistant and agent runtimes).

## Current model

- The AI surface is optional and server-owned: `surfaces.ai.packageRef` must
  be `server`, and `surfaces.ai` must publish at least one skill or capability
  when present ([field reference](04-manifest-reference.md)).
- **Skills** are discoverable documentation — markdown that teaches an agent
  what the extension can do.
- **Capabilities** become executable through Cedros's shared capability
  execution route after their downstream endpoint is implemented by the
  extension's wasm server route or by a published host endpoint.
- Capability endpoint declarations do not create arbitrary host routes by
  themselves; the downstream endpoint must exist in
  `cedros-extension.server.wasm` ([`07-wasm-server-backends.md`](07-wasm-server-backends.md))
  or host-integrated server code.
- If the extension needs to call the site's configured LLM or image generation
  providers, use `providerAccess[]` ([`10-host-providers.md`](10-host-providers.md))
  instead of extension-owned provider keys.

## Capability endpoint mapping

Every executable AI capability must map to one of:

1. a manifest-declared `surfaces.server.routes[]` id implemented by
   `cedros-extension.server.wasm`, or
2. a published host capability endpoint explicitly bound by Data to that
   declaring owner. A handoff entry alone does not install a host dispatcher.

If the extension owns the endpoint, include the route id in
`surfaces.server.routes[]` and package the wasm component. A capability
declaration alone does not mount the endpoint. Hosted Wasm admission now resolves
**each exact method/path** against the candidate executable registry and rejects
missing routes and another extension's routes before activation. The existing
Deploy, Extension Manager, Fleet Manager, and Providers Manager host dispatchers
are exceptions only for their own declared owners; arbitrary host endpoints are
not a shared extension grant. The compiled Data capabilities retain their exact
published core endpoints.

HTTP execution and background capability jobs recheck that binding against the
current runtime snapshot before forwarding a request. Missing/stale HTTP bindings
return `409` with `cedros.extension_ai.endpoint_unavailable`. HTTP and Assistant
dispatch use the same host-owner resolver and canonical owner operations, so a host binding does not depend on a matching Axum or guest
route. The host derives the principal from verified credentials; owner handlers
still enforce permissions, confirmation, and operation-specific idempotency.
Assistant dispatch independently resolves guest route owners.
These checks establish executable ownership, not caller permission: visibility,
endpoint authorization, confirmation, schema validation, and provider gates still
apply. Snapshot replacement is not an in-flight revocation barrier.

Skill-only vs executable capability:

| | Skill-only | Executable capability |
|---|---|---|
| Appears in discovery | yes | yes |
| Downstream endpoint | none | method/path declared |
| Server binding | none | wasm route or published host endpoint |
| Staging execution test | not needed | required |

Track the mapping in a table like this:

| Capability ID | Endpoint path | Owned by extension? | Server route ID | Wasm/host binding | Status |
|---|---|---:|---|---|---|

If `Owned by extension?` is true, `Server route ID` must be present and listed
in `surfaces.server.routes[]`. If the endpoint is owned outside the extension,
list the published host contract and its status.

## Validation rules

- Skill and capability ids must be namespaced with `extensionId`; no
  whitespace or `/`.
- Visibility must be `public`, `authenticated`, or `admin`.
- Capability endpoint paths must be absolute host paths; methods must be
  `POST`, `PUT`, or `PATCH`; do not target the reserved `/ai/capabilities`
  execution prefix.
- Input schemas must be JSON object schemas; output schemas, when present,
  must be JSON object schemas.
- Authenticated/admin capabilities need an auth scheme; the supported shared
  scheme is `bearer-token`. Public capabilities may omit auth only when
  genuinely safe.
- Current safe schema subset for examples: root `type: "object"`,
  `properties`, `required`, scalar types, arrays with simple `items`, nested
  objects, and `enum`. Treat `$ref`, composition keywords, custom formats, and
  remote schemas as host-coordinated unless the AI capability contract
  publishes support.
- `kind: "tool"` is read/assistive by default; `kind: "action"` can cause
  side effects and requires stricter auth, idempotency, and logging.
- AI safety/approval fields (`requiresApproval`, `destructive`, `idempotent`,
  `riskLevel`, `humanReview`) are handoff documentation, not validated
  manifest fields. Do not invent unsupported fields.

### Execution lanes are not interchangeable

The two compiled Data capabilities (`cedros-data:query-entries` and
`cedros-data:upsert-entry`) execute through authenticated HTTP and enforce the
collection's permissions there. The generic Assistant/MCP extension-capability
broker currently has no compiled Data dispatcher; those two global discovery
entries are **unreachable through that broker** and are omitted from its
executable list. Use their published HTTP surface or the Assistant's separately
authorized content tools. Data must supply a dispatcher
that preserves actor permissions, content gating, and cache invalidation before
claiming parity; substituting a raw store call or manufacturing a bearer token is
not an implementation of that contract.

Persistent owner-routine capability jobs accept only public action capabilities
with no auth schemes (`owner_agent_routine_contract_shared.rs`). They do not
replay an administrator's credentials, so authenticated capabilities being
visible in discovery does not make them runnable as unattended routines.

## Runtime plan

- Implement or coordinate the downstream endpoint.
- Validate and authorize input at the downstream endpoint — the shared
  execution route does not replace endpoint-side auth.
- Document who issues bearer tokens, intended audience, expiration, and
  validation expectations in the host handoff until the SDK publishes them.
- Emit durable site-brain records for material executions
  ([`16-analytics-and-site-brain.md`](16-analytics-and-site-brain.md)).
- Log failures with context and redaction.
- Document approval/human-review requirements.

## Agent-friendly extension guidance

Make skills and capabilities easy for Cedros agents to reason about:

- use action names that describe the user-visible outcome, not internal class
  or route names
- keep skill docs short, task-oriented, and explicit about required
  permissions, providers, dependencies, and failure states
- expose read-only tools separately from side-effecting actions
- require approval and idempotency for destructive, paid, compliance, email,
  storage, or wallet/signing operations
- emit or plan durable site-brain records for material executions so agents
  can explain what happened without reading private logs
- return redacted, structured errors that distinguish missing auth, missing
  provider, validation failure, downstream failure, retryable failure, and
  human-review-required
- never include secrets, raw prompts, PII, private keys, or payment details in
  skill docs, schemas, analytics, logs, or site-brain records

## Acceptance checks

- AI skills render in discovery with useful markdown docs.
- Capabilities reject invalid auth, paths, methods, and schemas during intake.
- Shared execution can reach the downstream endpoint in staging.
- Sensitive inputs/outputs are not logged or stored in analytics.

Next: [`18-official-extension-integrations.md`](18-official-extension-integrations.md).

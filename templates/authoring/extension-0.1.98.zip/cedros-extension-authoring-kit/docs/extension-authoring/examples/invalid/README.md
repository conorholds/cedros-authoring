# Invalid Cedros Extension Examples

Every artifact in this directory is intentionally **INVALID** and paired with
the published correction. They are negative validator fixtures, never starting
points.

| Artifact | Rule | Why invalid | Correct mechanism |
|---|---|---|---|
| `cron-metadata-without-job.json` | `CED-AUTH-002` | A schedule references no compiled, declared server job. Metadata does not register a runtime job. | Declare and compile the Wasm job, list its ID in `surfaces.server.jobs[]`, then bind `jobSchedules[].jobId` to that ID. |
| `private-extension-import.json` | `CED-AUTH-001` | An extension dependency is treated as permission to import another extension's internal module. | Consume only a published capability or route contract, declare the dependency and grant, and fail closed when unavailable. |

The canonical verifier MUST reject each fixture (`EXAMPLE-INVALID-001`). A
failure here is the expected test result, not a release failure.

# Extension with admin UI

**MINIMAL VALID MANIFEST** · Cedros documentation `0.1.66` · validated by
`cedros-authoring validate-manifest`.

The manifest declares an admin module and navigation metadata. That declaration
does not create UI: the compiled React package must export the matching module
from its registered admin bootstrap.

import type { CedrosExtensionManifest } from "cedros:admin";

export const generatedManifest = {
  "schemaVersion": 1,
  "extensionId": "cedros-demo-minimal",
  "displayName": "Cedros Demo Minimal",
  "version": "1.0.0",
  "description": "Minimal extension family with one admin page.",
  "platformApiVersion": "1",
  "compatibility": {
    "platformApiVersion": "1"
  },
  "packageFamily": {
    "server": {
      "packageName": "cedros-demo-minimal-server",
      "version": "1.0.0",
      "required": true
    },
    "react": {
      "packageName": "@cedros-demo/minimal",
      "version": "1.0.0",
      "required": true
    },
    "reactNative": {
      "packageName": "@cedros-demo/minimal-native",
      "version": "1.0.0",
      "required": true
    }
  },
  "surfaces": {
    "server": {
      "packageRef": "server",
      "required": true
    },
    "admin": {
      "packageRef": "react",
      "required": true,
      "moduleIds": [
        "cedros-demo-minimal:admin"
      ]
    },
    "web": {
      "packageRef": "react",
      "required": true
    },
    "native": {
      "packageRef": "reactNative",
      "required": true
    }
  },
  "registration": {
    "server": {
      "entrypoint": "cedros_demo_minimal_server::register_extension_family"
    },
    "admin": {
      "entrypoint": "@cedros-demo/minimal/admin/register"
    },
    "web": {
      "entrypoint": "@cedros-demo/minimal/web/register"
    },
    "native": {
      "entrypoint": "@cedros-demo/minimal-native/register"
    }
  },
  "adminModules": [
    {
      "moduleId": "cedros-demo-minimal:admin",
      "extensionId": "cedros-demo-minimal",
      "displayName": "Demo Minimal",
      "version": "1.0.0",
      "packageName": "@cedros-demo/minimal",
      "sectionIds": [
        "cedros-demo-minimal:overview"
      ],
      "sectionIcons": {
        "cedros-demo-minimal:overview": "extensions"
      },
      "navigation": {
        "sections": [
          {
            "id": "cedros-demo-minimal:overview",
            "label": "Overview",
            "group": "Extension Settings",
            "order": 10
          }
        ]
      }
    }
  ]
} as CedrosExtensionManifest;

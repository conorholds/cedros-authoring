# Minimal Cedros Extension Example

This example is intentionally boring. It proves the canonical package family,
manifest, bootstrap, and archive script shape without routes, jobs, providers,
AI, page seeds, visual-builder blocks, or native executable behavior.

> **MINIMAL VALID · authoring kit 0.1.66.** The checked-in artifact passes
> `npm run validate` and the canonical manifest/runtime-alignment checks. Code
> blocks in this file inherit that label unless explicitly marked otherwise.

## Includes

- one shared `extensionId`: `cedros-demo-minimal`
- one admin module
- one admin section id
- one persisted admin navigation projection consumed directly by runtime
- Rust server package with `register_extension_family()`
- React admin/web package bootstrap plus registration exports
- React Native bootstrap plus registration export
- manifest registration entrypoints as full package paths
- package script that creates a Cedros local intake ZIP
- validation script and regression tests that check
  manifest/bootstrap/package/Cargo-library/entrypoint version and identity
  alignment, admin navigation coverage, deterministic archive bytes, and
  server-component readiness

## Build And Package

Use Node.js `24.17.0` LTS with npm `11.13.0`. This example includes a
`.node-version` file and `packageManager` metadata so version managers and
release verifiers use the same toolchain.

```sh
node --version
npm --version
npm ci
npm run build
npm run validate
npm run package
```

When copying this scaffold, edit the canonical manifest plus the React, React
Native, and Cargo package names. Do not add a Cargo `[lib].name`; the scaffold
deliberately uses Cargo's derived underscore-normalized crate name so changing
`[package].name` cannot leave a stale library identity. After npm package
renames, refresh `package-lock.json` with
`npm install --package-lock-only --ignore-scripts --audit=false --fund=false`.
`npm run sync:manifest` regenerates the bootstrap and both package-local
manifest modules from the canonical manifest.

`npm run package` regenerates the package-local manifest modules, builds the
React and React Native packages, validates version/export alignment, and then
writes a byte-reproducible ZIP with a fixed archive timestamp. The React admin
build output is included under
`workspace/react/dist/**` because this example declares an admin module.
When `cedros-extension.server.wasm` exists at the workspace root, the package
script includes it at the archive root. Declared routes or jobs fail validation
with a component-specific remediation until that file exists.

The checked-in demo keeps optional host seams absent to stay small. A copied
scaffold is expected to grow: its validator permits valid provider, database,
settings, secrets, egress, telemetry, route, and job declarations instead of
enforcing demo minimalism. Use the host-seam decision record in
`../../03-planning-an-extension.md`, then rely on Authoring Scan or real intake
for complete manifest and compiled-component validation.

The output archive is written to `dist/cedros-demo-minimal-1.0.0.cedros-extension.zip`.

Runtime source files in this example are advisory for authoring. If this
example declares admin modules, the ZIP must also include the compiled React
admin runtime under the React package root with `exports["./admin/register"]`
pointing at the included browser ESM file.
Cedros validates and stores that graph, but the current browser host does not
execute uploaded JavaScript until the isolated-origin runtime is published;
only host-bundled first-party registrations execute today.

The React and React Native workspaces include a small local
`cedros-admin-runtime.d.ts` declaration so this docs example can type-check the
host-provided `cedros:admin` virtual module. It is not an npm dependency and
must remain external in the compiled ZIP runtime.

## Styling Scope

The minimal admin page is deliberately sparse. A production third-party
extension should still style real admin pages with AdminShell `--cd-*` tokens
and host primitives such as `cedros-data`, `cedros-data-card`, and
`cedros-data-btn`, as described in
`../../12-admin-pages-and-dashboard-cards.md`.

Do not copy public block token usage into admin pages. `--cedros-runtime-*`
tokens are for visual-builder/public blocks rendered under `.cedros-runtime`;
admin pages and dashboard cards use the `--cd-*` admin token contract.

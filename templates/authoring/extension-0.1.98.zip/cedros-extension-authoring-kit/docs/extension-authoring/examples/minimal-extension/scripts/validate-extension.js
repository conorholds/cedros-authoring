import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const manifest = readJson("cedros-extension.manifest.json");
const bootstrap = readJson("cedros-extension.bootstrap.json");
const reactPackage = readJson("packages/react/package.json");
const nativePackage = readJson("packages/react-native/package.json");
const serverToml = readFileSync(resolve(root, "packages/server/Cargo.toml"), "utf8");
const serverCargo = readCargoIdentity(serverToml);

assertEqual(manifest.schemaVersion, 1, "schemaVersion");
assertEqual(manifest.platformApiVersion, "1", "platformApiVersion");
assertEqual(manifest.compatibility?.platformApiVersion, "1", "compatibility.platformApiVersion");
assertEqual(bootstrap.manifest, manifest, "bootstrap manifest must match manifest");
assertEqual(reactPackage.name, manifest.packageFamily.react.packageName, "react package name");
assertEqual(nativePackage.name, manifest.packageFamily.reactNative.packageName, "native package name");
assertEqual(reactPackage.version, manifest.version, "react package version");
assertEqual(nativePackage.version, manifest.version, "native package version");
assertNoCedrosDataDependency(reactPackage, "react package");
assertNoCedrosDataDependency(nativePackage, "native package");
assertEqual(reactPackage.exports["./admin/register"], "./dist/admin/register.js", "react admin export");
assertEqual(reactPackage.exports["./web/register"], "./dist/web/register.js", "react web export");
assertEqual(nativePackage.exports["./register"], "./dist/register.js", "native export");
assertFileExists("packages/react/dist/admin/register.js", "compiled React admin runtime");
assertFileExists("packages/react/dist/web/register.js", "compiled React web runtime");
assertEqual(
  serverCargo.packageName,
  manifest.packageFamily.server.packageName,
  "server Cargo [package].name"
);
assertEqual(serverCargo.version, manifest.version, "server Cargo [package].version");
const expectedServerCrateName = manifest.packageFamily.server.packageName.replaceAll("-", "_");
if (serverCargo.libName !== expectedServerCrateName) {
  throw new Error(
    `server Cargo [lib].name mismatch: expected "${expectedServerCrateName}" from ` +
      `packageFamily.server.packageName "${manifest.packageFamily.server.packageName}", ` +
      `received "${serverCargo.libName}"; remove [lib].name to use Cargo's derived crate ` +
      "name or rename it with the package"
  );
}
assertEqual(
  manifest.registration.server.entrypoint,
  `${serverCargo.libName}::register_extension_family`,
  "server entrypoint for Cargo library crate"
);
assertEqual(
  manifest.registration.admin.entrypoint,
  `${manifest.packageFamily.react.packageName}/admin/register`,
  "admin entrypoint"
);
assertEqual(
  manifest.registration.web.entrypoint,
  `${manifest.packageFamily.react.packageName}/web/register`,
  "web entrypoint"
);
assertEqual(
  manifest.registration.native.entrypoint,
  `${manifest.packageFamily.reactNative.packageName}/register`,
  "native entrypoint"
);
assertAdminSurface();
assertServerArtifactReadiness();

console.log(`validated ${manifest.extensionId}@${manifest.version}`);

function readJson(path) {
  return JSON.parse(readFileSync(resolve(root, path), "utf8"));
}

function assertEqual(actual, expected, label) {
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(
      `${label} mismatch: expected ${JSON.stringify(expected)}, received ${JSON.stringify(actual)}`
    );
  }
}

function readCargoIdentity(toml) {
  const packageName = readCargoString(toml, "package", "name");
  const version = readCargoString(toml, "package", "version");
  return {
    packageName,
    version,
    libName: readCargoString(toml, "lib", "name", false) ?? packageName.replaceAll("-", "_")
  };
}

function readCargoString(toml, sectionName, key, required = true) {
  let section = "";
  for (const rawLine of toml.split(/\r?\n/)) {
    const line = rawLine.trim();
    const sectionMatch = line.match(/^\[([^\]]+)\]$/);
    if (sectionMatch) {
      section = sectionMatch[1].trim();
      continue;
    }
    if (section !== sectionName) {
      continue;
    }
    const valueMatch = line.match(
      new RegExp(`^${key}\\s*=\\s*(?:"([^"]+)"|'([^']+)')\\s*(?:#.*)?$`)
    );
    if (valueMatch) {
      return valueMatch[1] ?? valueMatch[2];
    }
  }
  if (required) {
    throw new Error(`server Cargo [${sectionName}].${key} missing or not a string`);
  }
  return undefined;
}

function assertFileExists(path, label) {
  if (!existsSync(resolve(root, path))) {
    throw new Error(`${label} missing; run npm run build before packaging`);
  }
}

function assertNoCedrosDataDependency(packageJson, label) {
  for (const field of ["dependencies", "peerDependencies", "optionalDependencies"]) {
    const dependency = Object.keys(packageJson[field] ?? {})
      .find((name) => name.startsWith("@cedros/") && name.includes("data-"));
    if (dependency) {
      throw new Error(`${label} must not depend on private Cedros Data workspace ${dependency}`);
    }
  }
}

function assertAdminSurface() {
  const adminModule = manifest.adminModules?.[0];
  assertEqual(manifest.surfaces.admin.moduleIds, [adminModule.moduleId], "admin module ids");
  assertEqual(adminModule.extensionId, manifest.extensionId, "admin module extensionId");
  assertEqual(adminModule.version, manifest.version, "admin module version");
  assertEqual(adminModule.packageName, manifest.packageFamily.react.packageName, "admin package name");

  const sectionIds = adminModule.sectionIds ?? [];
  for (const sectionId of sectionIds) {
    if (!adminModule.sectionIcons?.[sectionId]) {
      throw new Error(`${sectionId} missing sectionIcons fallback`);
    }
  }

  const navigationSections = adminModule.navigation?.sections;
  assert(Array.isArray(navigationSections), "admin navigation.sections missing");
  assertEqual(
    navigationSections.map((section) => section.id).sort(),
    [...sectionIds].sort(),
    "admin navigation section ids"
  );
  for (const section of navigationSections) {
    assert(typeof section.label === "string" && section.label.trim(), `${section.id} label missing`);
    assert(typeof section.group === "string" && section.group.trim(), `${section.id} group missing`);
    assert(Number.isFinite(section.order), `${section.id} order must be finite`);
  }
  assertEqual(adminModule.navigation.groups, undefined, "minimal runtime groups");
}

function assertServerArtifactReadiness() {
  const executableIds = [
    ...(manifest.surfaces.server.routes ?? []),
    ...(manifest.surfaces.server.jobs ?? [])
  ];
  if (executableIds.length > 0 && !existsSync(resolve(root, "cedros-extension.server.wasm"))) {
    throw new Error(
      "manifest declares server routes/jobs but cedros-extension.server.wasm is missing; " +
        "compile the WIT guest component and place it at the workspace root before validation"
    );
  }
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

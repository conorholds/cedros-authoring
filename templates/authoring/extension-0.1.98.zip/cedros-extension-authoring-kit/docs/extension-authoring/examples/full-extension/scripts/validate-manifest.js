import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const manifestPath = resolve(root, "cedros-extension.manifest.json");
const manifestText = readFileSync(manifestPath, "utf8");
const manifest = JSON.parse(manifestText);
const extensionId = manifest.extensionId;
const registeredAdminGroups = new Set([
  "Content",
  "Users",
  "Monetization",
  "Email",
  "Grow",
  "Assistant",
  "Settings",
  "Extension Settings",
  "Tools",
  "Build",
  "Control Plane"
]);

assert(manifest.schemaVersion === 1, "schemaVersion must be 1");
assert(extensionId === "cedros-demo-commerce", "extensionId drifted");
assert(manifest.platformApiVersion === "1", "platformApiVersion must be 1");
assert(manifest.compatibility?.platformApiVersion === "1", "compatibility.platformApiVersion must be 1");
assertLineBudget(manifestText, 500, "cedros-extension.manifest.json");

assertCanonicalEntrypoint("server", "cedros_demo_commerce_server::register_extension_family");
assertCanonicalEntrypoint("admin", `${manifest.packageFamily.react.packageName}/admin/register`);
assertCanonicalEntrypoint("web", `${manifest.packageFamily.react.packageName}/web/register`);
assertCanonicalEntrypoint("native", `${manifest.packageFamily.reactNative.packageName}/register`);

validateAdmin();
validateWebSurfaces();
validateJobs();
validateSetupSeeds();
validateAccessDeclarations();
validateAiSurfaces();

console.log(`validated ${extensionId}@${manifest.version}`);

function validateAdmin() {
  const adminModules = manifest.adminModules ?? [];
  const adminModuleIds = new Set(ids(adminModules, "moduleId"));
  const declaredModuleIds = manifest.surfaces?.admin?.moduleIds ?? [];
  assertRefs(declaredModuleIds, adminModuleIds, "surfaces.admin.moduleIds");
  assertUnique(declaredModuleIds, "surfaces.admin.moduleIds");

  for (const module of adminModules) {
    assertNamespaced(module.moduleId, "admin module id");
    assert(module.extensionId === extensionId, `${module.moduleId} extensionId mismatch`);
    assert(module.version === manifest.version, `${module.moduleId} version mismatch`);
    assert(module.packageName === manifest.packageFamily.react.packageName, `${module.moduleId} packageName mismatch`);
    const sectionIds = module.sectionIds ?? [];
    for (const sectionId of sectionIds) {
      assert(module.sectionIcons?.[sectionId], `${sectionId} missing sectionIcons fallback`);
    }
    validateAdminNavigation(module, sectionIds);
    assertUnique(ids(module.contributions?.dashboardCards ?? [], "id"), `${module.moduleId} dashboard cards`);
  }

  for (const page of manifest.onboardingPages ?? []) {
    assert(adminModuleIds.has(page.moduleId), `${page.id} targets missing admin module`);
    const module = adminModules.find((item) => item.moduleId === page.moduleId);
    assert((module?.sectionIds ?? []).includes(page.sectionId), `${page.id} targets missing admin section`);
  }
}

function validateAdminNavigation(module, sectionIds) {
  const sections = module.navigation?.sections;
  assert(Array.isArray(sections), `${module.moduleId} navigation.sections missing`);
  assertUnique(ids(sections, "id"), `${module.moduleId} navigation sections`);
  assert(
    JSON.stringify(ids(sections, "id").sort()) === JSON.stringify([...sectionIds].sort()),
    `${module.moduleId} navigation section ids mismatch`
  );

  const groups = module.navigation?.groups ?? [];
  assertUnique(ids(groups, "id"), `${module.moduleId} navigation group ids`);
  assertUnique(ids(groups, "label"), `${module.moduleId} navigation group labels`);
  const customGroupLabels = new Set(ids(groups, "label"));

  for (const section of sections) {
    assert(typeof section.label === "string" && section.label.trim(), `${section.id} label missing`);
    assert(typeof section.group === "string", `${section.id} group missing`);
    assert(Number.isFinite(section.order), `${section.id} order must be finite`);
    assert(
      registeredAdminGroups.has(section.group) || customGroupLabels.has(section.group),
      `${section.id} custom group ${section.group} missing navigation.groups metadata`
    );
  }

  for (const group of groups) {
    assert(typeof group.id === "string" && group.id.trim(), "admin group id missing");
    assert(typeof group.label === "string" && group.label.trim(), `${group.id} label missing`);
    assert(Number.isFinite(group.order), `${group.id} order must be finite`);
  }
}

function validateWebSurfaces() {
  const web = manifest.surfaces?.web ?? {};
  const blockTypes = new Set(ids(manifest.contentBlocks ?? [], "type"));
  const templateIds = new Set(ids(manifest.contentTemplates ?? [], "id"));
  const surfaceIds = new Set(ids(manifest.authoredSurfaces ?? [], "id"));
  const utilityIds = new Set(ids(manifest.authoredTemplateUtilities ?? [], "id"));

  assertRefs(web.blockTypes ?? [], blockTypes, "surfaces.web.blockTypes");
  assertRefs(web.templateIds ?? [], templateIds, "surfaces.web.templateIds");
  assertRefs(web.authoredSurfaceIds ?? [], surfaceIds, "surfaces.web.authoredSurfaceIds");
  assertRefs(web.templateUtilityIds ?? [], utilityIds, "surfaces.web.templateUtilityIds");

  for (const block of manifest.contentBlocks ?? []) {
    assertNamespaced(block.type, "content block type");
    assert(Number.isInteger(block.order), `${block.type} must declare integer order`);
  }

  for (const template of manifest.contentTemplates ?? []) {
    assertNamespaced(template.id, "content template id");
    assert(Number.isInteger(template.order), `${template.id} must declare integer order`);
    assert((template.contentTypes ?? []).length > 0, `${template.id} needs contentTypes`);
    if (template.surfaceId) assert(surfaceIds.has(template.surfaceId), `${template.id} references missing surface`);
  }

  for (const utility of manifest.authoredTemplateUtilities ?? []) {
    assertRefs(utility.templateIds ?? [], templateIds, `${utility.id}.templateIds`);
    assertRefs(utility.surfaceIds ?? [], surfaceIds, `${utility.id}.surfaceIds`);
    assertRefs(utility.suggestedBlockTypes ?? [], blockTypes, `${utility.id}.suggestedBlockTypes`);
  }

  for (const seed of manifest.pageSeeds ?? []) {
    assertNamespaced(seed.id, "page seed id");
    assert((web.routeIds ?? []).includes(seed.id), `${seed.id} missing from surfaces.web.routeIds`);
    assert(seed.routePath?.startsWith("/"), `${seed.id} routePath must be absolute`);
    if (seed.templateId && seed.templateId !== "page-default") assert(templateIds.has(seed.templateId), `${seed.id} templateId missing`);
    validateSeo(seed.seo, `${seed.id}.seo`);
  }

  for (const article of manifest.docsArticles ?? []) validateSeo(article.seo, `${article.id}.seo`);
  for (const policy of manifest.policies ?? []) validateSeo(policy.seo, `${policy.id}.seo`);
}

function validateJobs() {
  const jobs = new Set(manifest.surfaces?.server?.jobs ?? []);
  for (const schedule of manifest.jobSchedules ?? []) {
    assertNamespaced(schedule.id, "job schedule id");
    assert(jobs.has(schedule.jobId), `${schedule.id} references missing server job`);
    assert(isFiveOrSixFieldCron(schedule.cron), `${schedule.id} cron must be 5 or 6 fields`);
    assert(schedule.timeoutSeconds >= 1 && schedule.timeoutSeconds <= 86400, `${schedule.id} timeout out of range`);
    assert(schedule.maxRetries <= 10, `${schedule.id} maxRetries out of range`);
  }
}

function validateSetupSeeds() {
  const setup = manifest.setupSeeds ?? {};
  const productIds = new Set(ids(setup.products ?? [], "id"));
  const schedulingIds = new Set(ids(setup.scheduling ?? [], "id"));
  const eventIds = new Set(manifest.surfaces?.server?.events ?? []);

  for (const seed of setup.scheduling ?? []) {
    const productSeedId = seed.paymentPolicy?.productSeedId;
    if (productSeedId) assert(productIds.has(productSeedId), `${seed.id} paymentPolicy.productSeedId missing`);
  }

  for (const product of setup.products ?? []) {
    assertRefs(product.schedulingSeedIds ?? [], schedulingIds, `${product.id}.schedulingSeedIds`);
  }

  for (const notification of setup.notifications ?? []) {
    assert(eventIds.has(notification.eventId), `${notification.id} eventId missing from surfaces.server.events`);
  }

  for (const contract of setup.contractTemplates ?? []) {
    const roleIds = new Set(ids(contract.roles ?? [], "id"));
    for (const field of contract.fields ?? []) {
      assert(roleIds.has(field.roleId), `${contract.id}.${field.id} references missing role`);
    }
  }
}

function validateAccessDeclarations() {
  const server = manifest.surfaces?.server ?? {};
  const contentModels = new Set(server.contentModels ?? []);
  const migrations = new Set(server.migrations ?? []);

  for (const access of manifest.providerAccess ?? []) {
    assert((access.scopes ?? []).length > 0, `${access.id} provider scopes required`);
  }

  for (const access of manifest.databaseAccess ?? []) {
    assertRefs(access.contentModels ?? [], contentModels, `${access.id}.contentModels`);
    assertRefs(access.migrations ?? [], migrations, `${access.id}.migrations`);
    assert((access.scopes ?? []).length > 0, `${access.id} database scopes required`);
  }

  for (const access of manifest.customerTagAccess ?? []) {
    assert((access.scopes ?? []).length > 0, `${access.id} customer-tag scopes required`);
    for (const slug of access.managedTagSlugs ?? []) assert(slug.startsWith(`${extensionId}:`), `${access.id} has unmanaged tag slug`);
  }
}

function validateAiSurfaces() {
  for (const capability of manifest.surfaces?.ai?.capabilities ?? []) {
    assert(capability.endpoint?.path?.startsWith("/"), `${capability.id} endpoint path must be absolute`);
    assert(capability.inputSchema?.type === "object", `${capability.id} inputSchema must be object`);
    assert(capability.outputSchema?.type === "object", `${capability.id} outputSchema must be object`);
  }
}

function assertCanonicalEntrypoint(surface, expected) {
  assert(manifest.registration?.[surface]?.entrypoint === expected, `${surface} registration entrypoint mismatch`);
}

function ids(items, key) {
  return items.map((item) => item[key]).filter(Boolean);
}

function assertRefs(values, allowed, label) {
  for (const value of values) assert(allowed.has(value), `${label} references missing ${value}`);
}

function assertNamespaced(value, label) {
  assert(typeof value === "string" && value.startsWith(`${extensionId}:`), `${label} must be namespaced`);
}

function assertUnique(values, label) {
  assert(values.length === new Set(values).size, `${label} contains duplicate ids`);
}

function assertLineBudget(text, maxLines, label) {
  const count = text.split("\n").length - (text.endsWith("\n") ? 1 : 0);
  assert(count <= maxLines, `${label} exceeds ${maxLines} lines (${count})`);
}

function validateSeo(seo, label) {
  if (seo === undefined) return;
  assert(seo && typeof seo === "object" && !Array.isArray(seo), `${label} must be object`);
  const stringFields = new Set(["title", "description", "canonicalPath", "ogTitle", "ogDescription", "ogImage"]);
  for (const key of Object.keys(seo)) {
    assert(key === "noindex" || stringFields.has(key), `${label}.${key} is not supported`);
  }
  for (const key of stringFields) {
    if (seo[key] !== undefined) {
      assert(typeof seo[key] === "string" && seo[key].trim(), `${label}.${key} must be non-empty string`);
    }
  }
  if (seo.canonicalPath !== undefined) {
    assert(seo.canonicalPath.startsWith("/") && !seo.canonicalPath.startsWith("//"), `${label}.canonicalPath must be same-origin path`);
  }
  if (seo.noindex !== undefined) assert(typeof seo.noindex === "boolean", `${label}.noindex must be boolean`);
}

function isFiveOrSixFieldCron(value) {
  return typeof value === "string" && [5, 6].includes(value.trim().split(/\s+/).length);
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

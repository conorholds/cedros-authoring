# Full Cedros Extension Example Map

This example is a documentation map for a fuller extension. It is intentionally
not a runnable package; use it to see how surfaces connect before implementing
real packages.

> **FULL VALID manifest · ILLUSTRATIVE ONLY runtime · authoring kit 0.1.66.**
> The manifest passes schema and host intake validation. This directory is not
> a runnable or installable package; runtime snippets do not prove host behavior.
> Examples are normative only where explicitly marked. Do not infer unsupported
> capabilities from incidental implementation details.

The companion `cedros-extension.manifest.json` is a complete manifest example
that uses the current field names and full package registration entrypoints.
Run `node scripts/validate-manifest.js` after editing it; the script checks the
cross-references that most often drift when docs evolve.

## Extension

- `extensionId`: `cedros-demo-commerce`
- version: `1.0.0`
- purpose: ecommerce management extension with checkout stats, buyer docs, and
  nightly reconciliation

## Surface Inventory

| Surface | Manifest path | Example id | Classification |
|---|---|---|---|
| Admin page | `adminModules[]` | `cedros-demo-commerce:admin` | self-serve today |
| Dashboard card | `adminModules[].contributions.dashboardCards[]` | `cedros-demo-commerce:checkout-stats` | self-serve today |
| Page seed | `pageSeeds[]` | `cedros-demo-commerce:checkout` | self-serve today |
| Public SEO route | `seoRoutes[]` | `cedros-demo-commerce:product-detail` | indexable localized declaration reference |
| Content template | `contentTemplates[]` | `cedros-demo-commerce:checkout-page` | self-serve with runtime definition |
| Form starter | `formTemplates[]` | `cedros-demo-commerce:support-request` | self-serve today |
| Extension docs draft | `docsArticles[]` | `cedros-demo-commerce:buyer-help` | self-serve today |
| Onboarding | `onboardingPages[]` | `cedros-demo-commerce:connect-provider` | self-serve today |
| Analytics | `analytics.events[]` | `cedros-demo-commerce:checkout-started` | self-serve declaration with semantic kind |
| Job schedule | `jobSchedules[]` | `cedros-demo-commerce:nightly-reconcile-schedule` | self-serve schedule seed for declared Wasm job |
| Scheduling setup | `setupSeeds.scheduling[]` | `cedros-demo-commerce:strategy-session` | metadata-first; provisioning host-coordinated |
| Product setup | `setupSeeds.products[]` / `setupSeeds.productCollections[]` | `cedros-demo-commerce:camp-session` | metadata-first; Shop provisioning host-coordinated |
| Notification setup | `setupSeeds.notifications[]` | `cedros-demo-commerce:order-reconciled-notification` | published Notifications route binding |
| Contract template setup | `setupSeeds.contractTemplates[]` | `cedros-demo-commerce:camp-waiver-contract` | published Contracts template/document bindings |
| Email template setup | `setupSeeds.emailTemplates[]` | `cedros-demo-commerce:camp-confirmation-email` | published Email template binding |
| Site-brain | runtime record plan | `commerce.reconciliation` | self-serve through Wasm telemetry with capability scope |
| AI skill | `surfaces.ai.skills[]` | `cedros-demo-commerce:summarize-orders` | self-serve metadata |
| AI capability | `surfaces.ai.capabilities[]` | `cedros-demo-commerce:order-summary` | self-serve when endpoint is implemented by Wasm route `cedros-demo-commerce:order-summary-capability` |
| Provider access | `providerAccess[]` | `cedros-demo-commerce:receipt-email` | self-serve through Wasm provider import when host provider exists |
| Database access | `databaseAccess[]` | `cedros-demo-commerce:orders-db` | self-serve through Wasm database import |
| Customer tag access | `customerTagAccess[]` | `cedros-demo-commerce:customer-tags` | self-serve through Wasm customer-tags import + host bridge |
| Server job | `surfaces.server.jobs[]` | `cedros-demo-commerce:nightly-reconcile` | self-serve through `cedros-extension.server.wasm` |
| Server route | `surfaces.server.routes[]` | `cedros-demo-commerce:webhook-ingest` | self-serve through `cedros-extension.server.wasm` |

## Host Coordination Handoff

| Item | Manifest ID | Type | Runtime package | Host hook required | Status | Owner | Blocking? | Launch gate |
|---|---|---|---|---|---|---|---|---|
| Paid strategy session | `cedros-demo-commerce:strategy-session` | scheduling setup seed | server | Scheduling provisioning binding | host-hook-requested | Scheduling team | yes | production |
| Summer Camp 2026 collection | `cedros-demo-commerce:summer-camp-2026` | product collection seed | server | Shop provisioning binding | host-hook-requested | Shop team | yes | production |
| Camp session product | `cedros-demo-commerce:camp-session` | product seed | server | Shop inventory/product binding | host-hook-requested | Shop team | yes | production |

Server routes, jobs, database access, customer tags, telemetry, and provider
calls in this example are covered by `cedros-extension.server.wasm`; they should
appear in the release packet's Wasm build/test section, not the host handoff
table.

The contract setup seed includes `contracts/camp-waiver.pdf` with a matching
SHA-256 digest. No host binding provisions contract seeds yet, so installing the
example creates no contract template; the digest pins the document for a future
`cedros-contracts:document-ingest` binding.

## Styling And Layout Notes

This example intentionally separates public runtime styling from admin styling:

- Public visual-builder blocks render inside `.cedros-runtime` and should style
  with `--cedros-runtime-*` tokens from
  `../../14-blocks-templates-and-styling.md`.
  The `cedros-demo-commerce:checkout-cta` block metadata is not enough by
  itself; a real package must ship the working block component, equivalent
  first-render/live states, and archive CSS scoped under an extension-owned
  root class.
- Admin pages and dashboard cards render in Cedros AdminShell, not
  `.cedros-runtime`. They should use `.cedros-data`/host primitives and `--cd-*`
  tokens from `../../12-admin-pages-and-dashboard-cards.md`. Do not reuse
  public block tokens for admin UI.
- Admin pages should be compact operational screens: setup status, connection
  health, job status, safe retry/cancel actions, redacted diagnostics, and
  loading/empty/error/disabled states. Public pages should focus on the buyer
  flow and keep provider buttons disabled or hidden until required runtime
  config is present.

When turning this map into a runnable package, add browser screenshots or visual
fixtures for the seeded public page and the admin page/card at mobile and
desktop widths. Static metadata validation is not a substitute for checking the
rendered layouts.

## Validation

```sh
node scripts/validate-manifest.js
```

The validator checks:

- canonical entrypoints and package-family alignment;
- admin module, section/navigation, onboarding, and dashboard-card references;
- public page seed, template, block, authored-surface, and utility references;
- public SEO route identity, canonical, locale, sitemap, schema, and Wasm response contracts;
- finite indexable query variants, schema adapter versioning, and atomic SEO record revisions;
- `jobSchedules[]` references to `surfaces.server.jobs[]`;
- setup seed references for paid scheduling, notifications, and contracts;
- provider/database/customer-tag declaration basics;
- AI endpoint and schema basics;
- the 500-line example file budget.

The server registry test also deserializes this exact manifest and runs real
extension intake. The compiled component under
`server/tests/fixtures/wasm-extension-example/` separately exercises the real
`describe-route` and `list-sitemap-urls` WIT exports; generated-host and Caddy
contract tests prove that public dynamic paths reach Core SSR while the reserved
`/extensions` API/private namespace remains backend-only.

## Provider Access

```json
[
  {
    "id": "cedros-demo-commerce:receipt-email",
    "provider": "email",
    "displayName": "Receipt email",
    "description": "Sends order receipts through the site's configured email provider.",
    "scopes": ["email.send"],
    "tags": ["commerce", "receipt"]
  },
  {
    "id": "cedros-demo-commerce:order-summary",
    "provider": "intelligence",
    "displayName": "Order summary",
    "description": "Summarizes order history for admins through the site's intelligence provider.",
    "scopes": ["chat.generate"],
    "tags": ["commerce", "summary"]
  }
]
```

The order-summary backend is keyless. It resolves the host-selected target
before execution:

```rust
let defaults = providers::resolve_default(
    "cedros-demo-commerce:order-summary",
    "intelligence",
    "chat.generate",
)?;
// Parse only `provider` and `model`, then include them in the
// providers::execute payload. Provider credentials never reach this extension.
```

## Database Access

The manifest declares required capability
`cedros-data:extension-storage-cas-v1`. Reads return an opaque JSONB `version`;
shared order updates call `database.compare-and-set` with that version. Creates
use an `absent` condition, and conflicts are re-read/reconciled instead of
falling back to unconditional `write`.

```json
[
  {
    "id": "cedros-demo-commerce:orders-db",
    "displayName": "Orders database",
    "description": "Reads and writes extension-owned order records.",
    "contentModels": ["cedros-demo-commerce:orders"],
    "migrations": ["cedros-demo-commerce:orders-v1"],
    "scopes": [
      {
        "verb": "read",
        "resource": "order records",
        "summary": "Reads order records for dashboard stats and reconciliation."
      },
      {
        "verb": "write",
        "resource": "order records",
        "summary": "Writes order records from checkout webhooks."
      }
    ],
    "tags": ["commerce", "orders"]
  }
]
```

## Customer Tag Access

```json
[
  {
    "id": "cedros-demo-commerce:customer-tags",
    "displayName": "Customer Tags",
    "description": "Labels customers based on order activity (first purchase, repeat purchaser, VIP, at risk of churn).",
    "scopes": ["assign", "unassign", "read"],
    "managedTagSlugs": [
      "cedros-demo-commerce:first-purchase",
      "cedros-demo-commerce:repeat-customer",
      "cedros-demo-commerce:vip-customer",
      "cedros-demo-commerce:at-risk"
    ],
    "tags": ["commerce", "lifecycle"]
  }
]
```

The nightly reconcile job iterates each profile in the orders database and
calls the host customer-tag client (assign or unassign) so the chips on the
admin CRM stay in sync with order activity. Tag definitions auto-bootstrap
on first assign — see prompt `34` for the runtime envelopes.

## Release Notes Template

- install gate: manifest, archive, React admin/web imports, dashboard card smoke
- launch gate: webhook route hook and nightly job executor bound in staging
- disable behavior: admin/cards hidden, provider calls fail closed, job paused
- rollback behavior: previous dashboard card and provider scopes restored
- data policy: owner-created pages/forms/docs preserved on disable/remove

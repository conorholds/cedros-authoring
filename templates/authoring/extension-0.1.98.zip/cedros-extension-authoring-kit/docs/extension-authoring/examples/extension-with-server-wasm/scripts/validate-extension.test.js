import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import {
  cpSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  unlinkSync,
  writeFileSync
} from "node:fs";
import { tmpdir } from "node:os";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { createDeterministicExtensionArchive } from "./package-extension-archive.js";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

test("rejects a renamed server package with a stale explicit Cargo library name", () => {
  const fixture = copiedFixture();
  try {
    renameServerPackage(fixture, { keepStaleLibraryName: true });

    assert.throws(
      () => validate(fixture),
      (error) => {
        assert.match(error.stderr, /Cargo \[lib\]\.name/);
        assert.match(error.stderr, /vinescribe_server/);
        assert.match(error.stderr, /cedros_example_wasm_server/);
        return true;
      }
    );
  } finally {
    rmSync(fixture, { recursive: true, force: true });
  }
});

test("accepts a renamed server package when Cargo uses its derived library name", () => {
  const fixture = copiedFixture();
  try {
    renameServerPackage(fixture, { keepStaleLibraryName: false });
    assert.doesNotThrow(() => validate(fixture));
  } finally {
    rmSync(fixture, { recursive: true, force: true });
  }
});

test("manifest sync regenerates the bootstrap from the renamed canonical manifest", () => {
  const fixture = mkdtempSync(resolve(tmpdir(), "cedros-extension-sync-"));
  try {
    mkdirSync(resolve(fixture, "scripts"), { recursive: true });
    cpSync(
      resolve(root, "scripts/sync-generated-manifests.js"),
      resolve(fixture, "scripts/sync-generated-manifests.js")
    );
    const manifest = JSON.parse(
      readFileSync(resolve(root, "cedros-extension.manifest.json"), "utf8")
    );
    manifest.extensionId = "vinescribe";
    writeFileSync(
      resolve(fixture, "cedros-extension.manifest.json"),
      `${JSON.stringify(manifest, null, 2)}\n`
    );
    writeFileSync(resolve(fixture, "package.json"), '{"type":"module"}\n');

    execFileSync(process.execPath, ["scripts/sync-generated-manifests.js"], {
      cwd: fixture,
      encoding: "utf8",
      stdio: "pipe"
    });

    const bootstrap = JSON.parse(
      readFileSync(resolve(fixture, "cedros-extension.bootstrap.json"), "utf8")
    );
    assert.deepEqual(bootstrap.manifest, manifest);
    for (const packageDir of ["packages/react", "packages/react-native"]) {
      assert.match(
        readFileSync(resolve(fixture, packageDir, "src/generated-manifest.ts"), "utf8"),
        /"extensionId": "vinescribe"/
      );
    }
  } finally {
    rmSync(fixture, { recursive: true, force: true });
  }
});

test("scaffold build and admin runtime do not select renamed identities by demo literals", () => {
  const rootPackage = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8"));
  assert.match(rootPackage.scripts.build, /--workspace packages\/react run build/);
  assert.match(rootPackage.scripts.build, /--workspace packages\/react-native run build/);
  assert.doesNotMatch(rootPackage.scripts.build, /@cedros-demo/);

  const adminRegistration = readFileSync(
    resolve(root, "packages/react/src/admin/register.ts"),
    "utf8"
  );
  assert.doesNotMatch(adminRegistration, /cedros-example-wasm:/);
  assert.match(adminRegistration, /id: adminManifest\.moduleId/);
});

test("validator permits declared host seams instead of restricting the supported contract", () => {
  const fixture = copiedFixture();
  try {
    const manifestPath = resolve(fixture, "cedros-extension.manifest.json");
    const bootstrapPath = resolve(fixture, "cedros-extension.bootstrap.json");
    const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
    manifest.surfaces.server.contentModels = ["cedros-example-wasm:records"];
    manifest.databaseAccess = [
      {
        id: "cedros-example-wasm:records-db",
        displayName: "Extension records",
        description: "Stores extension-owned records through the host database seam.",
        contentModels: ["cedros-example-wasm:records"],
        scopes: [
          {
            verb: "read",
            resource: "extension records",
            summary: "Reads extension-owned records."
          }
        ]
      }
    ];
    writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
    writeFileSync(
      bootstrapPath,
      `${JSON.stringify({ manifest }, null, 2)}\n`
    );

    assert.doesNotThrow(() => validate(fixture));
  } finally {
    rmSync(fixture, { recursive: true, force: true });
  }
});

test("server declarations fail clearly until the component is package-ready", () => {
  const fixture = copiedFixture();
  try {
    unlinkSync(resolve(fixture, "cedros-extension.server.wasm"));
    const manifestPath = resolve(fixture, "cedros-extension.manifest.json");
    const bootstrapPath = resolve(fixture, "cedros-extension.bootstrap.json");
    const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
    manifest.surfaces.server.routes = ["cedros-example-wasm:hello"];
    writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
    writeFileSync(
      bootstrapPath,
      `${JSON.stringify({ manifest }, null, 2)}\n`
    );

    assert.throws(
      () => validate(fixture),
      (error) => {
        assert.match(error.stderr, /cedros-extension\.server\.wasm is missing/);
        assert.match(error.stderr, /WIT guest component/);
        return true;
      }
    );
    writeFileSync(resolve(fixture, "cedros-extension.server.wasm"), "fixture");
    assert.doesNotThrow(() => validate(fixture));
  } finally {
    rmSync(fixture, { recursive: true, force: true });
  }
});

test("package archive bytes are deterministic for unchanged entries", () => {
  const entries = {
    "z.txt": new Uint8Array([3, 2, 1]),
    "a.txt": new Uint8Array([1, 2, 3])
  };

  assert.deepEqual(
    createDeterministicExtensionArchive(entries),
    createDeterministicExtensionArchive(entries)
  );
});

test("package script conditionally includes the compiled server component", () => {
  const packageScript = readFileSync(
    resolve(root, "scripts/package-extension.js"),
    "utf8"
  );
  assert.match(packageScript, /existsSync\(resolve\(root, "cedros-extension\.server\.wasm"\)\)/);
  assert.match(packageScript, /entries\["cedros-extension\.server\.wasm"\]/);
  assert.match(packageScript, /workspace\/react-native\/dist/);
  assert.match(packageScript, /React web runtime export/);
  assert.match(packageScript, /React Native runtime export/);
});

function copiedFixture() {
  const fixture = mkdtempSync(resolve(tmpdir(), "cedros-extension-identity-"));
  for (const path of [
    "cedros-extension.manifest.json",
    "cedros-extension.bootstrap.json",
    "packages/react/package.json",
    "packages/react-native/package.json",
    "packages/server/Cargo.toml",
    "scripts/validate-extension.js"
  ]) {
    const destination = resolve(fixture, path);
    mkdirSync(dirname(destination), { recursive: true });
    cpSync(resolve(root, path), destination);
  }
  for (const path of [
    "packages/react/dist/admin/register.js",
    "packages/react/dist/web/register.js"
  ]) {
    const destination = resolve(fixture, path);
    mkdirSync(dirname(destination), { recursive: true });
    writeFileSync(destination, "");
  }
  writeFileSync(resolve(fixture, "cedros-extension.server.wasm"), "fixture");
  writeFileSync(resolve(fixture, "package.json"), '{"type":"module"}\n');
  return fixture;
}

function renameServerPackage(fixture, { keepStaleLibraryName }) {
  for (const path of [
    "cedros-extension.manifest.json",
    "cedros-extension.bootstrap.json"
  ]) {
    replace(
      fixture,
      path,
      /cedros_example_wasm_server::register_extension_family/g,
      "vinescribe_server::register_extension_family"
    );
  }
  replaceIfPresent(
    fixture,
    "scripts/validate-extension.js",
    /cedros_example_wasm_server::register_extension_family/g,
    "vinescribe_server::register_extension_family"
  );
  for (const path of [
    "cedros-extension.manifest.json",
    "cedros-extension.bootstrap.json"
  ]) {
    replace(
      fixture,
      path,
      /cedros-example-wasm-server/g,
      "vinescribe-server"
    );
  }
  replace(
    fixture,
    "packages/server/Cargo.toml",
    'name = "cedros-example-wasm-server"',
    'name = "vinescribe-server"'
  );
  if (keepStaleLibraryName) {
    const cargoPath = resolve(fixture, "packages/server/Cargo.toml");
    writeFileSync(
      cargoPath,
      `${readFileSync(cargoPath, "utf8")}\n[lib]\nname = "cedros_example_wasm_server"\n`
    );
  }
}

function replace(fixture, path, from, to) {
  const absolutePath = resolve(fixture, path);
  const source = readFileSync(absolutePath, "utf8");
  const output = source.replace(from, to);
  assert.notEqual(output, source, `${path} replacement must apply`);
  writeFileSync(absolutePath, output);
}

function replaceIfPresent(fixture, path, from, to) {
  const absolutePath = resolve(fixture, path);
  const source = readFileSync(absolutePath, "utf8");
  writeFileSync(absolutePath, source.replace(from, to));
}

function validate(fixture) {
  return execFileSync(process.execPath, ["scripts/validate-extension.js"], {
    cwd: fixture,
    encoding: "utf8",
    stdio: "pipe"
  });
}

import type { CedrosExtensionBootstrap } from "cedros:admin";

import { extensionManifest } from "./manifest";

export const extensionBootstrap: CedrosExtensionBootstrap = {
  manifest: extensionManifest
};

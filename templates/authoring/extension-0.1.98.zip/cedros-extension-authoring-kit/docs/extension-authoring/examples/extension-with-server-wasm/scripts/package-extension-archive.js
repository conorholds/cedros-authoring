import { zipSync } from "fflate";

// fflate encodes local DOS date fields, so construct local midnight directly
// instead of letting a negative UTC offset shift the ZIP epoch into 1979.
const ZIP_EPOCH = new Date(1980, 0, 1, 0, 0, 0);

export function createDeterministicExtensionArchive(entries) {
  return zipSync(Object.fromEntries(Object.entries(entries).sort()), {
    level: 6,
    mtime: ZIP_EPOCH
  });
}

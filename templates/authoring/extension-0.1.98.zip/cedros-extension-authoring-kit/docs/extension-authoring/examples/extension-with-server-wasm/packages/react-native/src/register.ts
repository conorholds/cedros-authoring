import type { CedrosExtensionBootstrap } from "cedros:admin";

import { extensionBootstrap } from "./bootstrap";

export function registerCedrosNativeSurface(): CedrosExtensionBootstrap {
  return extensionBootstrap;
}

export default registerCedrosNativeSurface;

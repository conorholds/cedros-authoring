const MANIFEST_JSON: &str = include_str!("../../../cedros-extension.manifest.json");

pub fn register_extension_family() -> serde_json::Value {
    serde_json::from_str(MANIFEST_JSON).expect("example manifest should stay valid")
}

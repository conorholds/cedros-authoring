import type {
  AdminModule,
  CedrosExtensionBootstrap
} from "cedros:admin";

import { extensionBootstrap } from "../bootstrap";
import { extensionManifest } from "../manifest";

const adminManifest = extensionManifest.adminModules?.[0];
const overviewNavigation = adminManifest?.navigation?.sections[0];
const overviewSectionId = overviewNavigation?.id;
if (!adminManifest || !overviewNavigation || !overviewSectionId) {
  throw new Error("Missing manifest metadata for the admin module.");
}

const adminModule: AdminModule = {
  id: adminManifest.moduleId,
  name: extensionManifest.displayName,
  version: extensionManifest.version,
  manifest: adminManifest,
  sections: [
    {
      ...overviewNavigation,
      icon: null
    }
  ],
  components: {
    [overviewSectionId]: DemoMinimalOverview
  },
  createPluginContext: (hostContext) => ({
    serverUrl: hostContext.cedrosLogin?.serverUrl ?? "",
    authenticated: hostContext.cedrosLogin?.authenticated,
    getAccessToken: hostContext.cedrosLogin?.getAccessToken ?? (() => null),
    hasPermission: (permission) =>
      hostContext.dashboardPermissions?.canAccess(permission) ?? false
  }),
  checkPermission: (permission, hostContext) =>
    hostContext.dashboardPermissions?.canAccess(permission) ?? false,
  cssNamespace: extensionManifest.extensionId
};

export function registerCedrosAdminSurface(): CedrosExtensionBootstrap {
  return {
    ...extensionBootstrap,
    modules: [adminModule]
  };
}

export default registerCedrosAdminSurface;

function DemoMinimalOverview() {
  return "Example Wasm extension admin module.";
}

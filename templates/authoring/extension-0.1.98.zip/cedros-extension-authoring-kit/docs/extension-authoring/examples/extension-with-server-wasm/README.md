# Extension With Server Wasm

> **VALIDATED · authoring kit 0.1.66.** This is a complete package family with
> one runnable route-only WebAssembly component and one packaged admin-page
> contract example. Uploaded browser JavaScript is validation-only until the
> isolated-origin runtime is published; only host-bundled first-party admin
> registrations execute today. The
> checked-in source passes the project tests, TypeScript and Rust builds, the
> canonical manifest verifier, and final ZIP validation. Host behavior remains
> **HOST-COORDINATED** until the ZIP is installed and exercised on a compatible
> Cedros runtime.

The component exports `GET /extensions/cedros-example-wasm/status` with route
ID `cedros-example-wasm:status`. It imports only the always-granted logging
interface. `packages/server-wasm/wit/cedros-extension.wit` is the unmodified
published ABI and its checksum is pinned in the manifest; the adjacent
`route-only.wit` defines the deliberately narrower guest world. Do not delete
interfaces from the canonical WIT file or import privileged seams that the
manifest does not grant.

## Build, validate, and package

```sh
rustup target add wasm32-wasip2
npm ci
npm run build
npm run validate
npm run package
node ../../scripts/cedros-authoring.mjs validate --repo . --package \
  dist/cedros-example-wasm-1.0.0.cedros-extension.zip --json
```

The Wasm build writes `cedros-extension.server.wasm` at the package root. The
packager includes that exact component at the ZIP root and writes the validated
archive to `dist/cedros-example-wasm-1.0.0.cedros-extension.zip`.

Read `07-wasm-server-backends.md` before adding a database, settings, secrets,
provider, CRM, outbound HTTP, or extension-service import. Each imported
interface beyond logging requires the matching manifest grant and a denied or
missing-dependency test.

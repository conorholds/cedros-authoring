import type { CedrosExtensionManifest } from "cedros:admin";

import { generatedManifest } from "./generated-manifest";

export const extensionManifest = generatedManifest as CedrosExtensionManifest;

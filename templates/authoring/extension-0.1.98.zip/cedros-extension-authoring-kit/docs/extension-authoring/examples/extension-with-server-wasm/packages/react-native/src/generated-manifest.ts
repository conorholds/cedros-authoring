import type { CedrosExtensionManifest } from "cedros:admin";

export const generatedManifest = {
  "schemaVersion": 1,
  "extensionId": "cedros-example-wasm",
  "displayName": "Cedros Example Wasm",
  "version": "1.0.0",
  "description": "Runnable extension family declaring one route-only server Wasm component and one admin page.",
  "platformApiVersion": "1",
  "compatibility": {
    "platformApiVersion": "1",
    "witChecksum": "5f2c9823127864b7fb7ecd4599cf0681ae2fa63c8028ae2259acb271b23c7c58"
  },
  "packageFamily": {
    "server": {
      "packageName": "cedros-example-wasm-server",
      "version": "1.0.0",
      "required": true
    },
    "react": {
      "packageName": "@cedros-example/wasm",
      "version": "1.0.0",
      "required": true
    },
    "reactNative": {
      "packageName": "@cedros-example/wasm-native",
      "version": "1.0.0",
      "required": true
    }
  },
  "surfaces": {
    "server": {
      "packageRef": "server",
      "required": true,
      "routes": [
        "cedros-example-wasm:status"
      ]
    },
    "admin": {
      "packageRef": "react",
      "required": true,
      "moduleIds": [
        "cedros-example-wasm:admin"
      ]
    },
    "web": {
      "packageRef": "react",
      "required": true
    },
    "native": {
      "packageRef": "reactNative",
      "required": true
    }
  },
  "registration": {
    "server": {
      "entrypoint": "cedros_example_wasm_server::register_extension_family"
    },
    "admin": {
      "entrypoint": "@cedros-example/wasm/admin/register"
    },
    "web": {
      "entrypoint": "@cedros-example/wasm/web/register"
    },
    "native": {
      "entrypoint": "@cedros-example/wasm-native/register"
    }
  },
  "adminModules": [
    {
      "moduleId": "cedros-example-wasm:admin",
      "extensionId": "cedros-example-wasm",
      "displayName": "Example Wasm",
      "version": "1.0.0",
      "packageName": "@cedros-example/wasm",
      "sectionIds": [
        "cedros-example-wasm:overview"
      ],
      "sectionIcons": {
        "cedros-example-wasm:overview": "extensions"
      },
      "navigation": {
        "sections": [
          {
            "id": "cedros-example-wasm:overview",
            "label": "Overview",
            "group": "Extension Settings",
            "order": 10
          }
        ]
      }
    }
  ]
} as CedrosExtensionManifest;

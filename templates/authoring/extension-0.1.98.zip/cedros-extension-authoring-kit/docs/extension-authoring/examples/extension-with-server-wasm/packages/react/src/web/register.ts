import type { CedrosExtensionBootstrap } from "cedros:admin";

import { extensionBootstrap } from "../bootstrap";

export function registerCedrosWebSurface(): CedrosExtensionBootstrap {
  return extensionBootstrap;
}

export default registerCedrosWebSurface;

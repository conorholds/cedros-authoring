import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { strToU8 } from "fflate";

import { createDeterministicExtensionArchive } from "./package-extension-archive.js";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const manifest = readJson("cedros-extension.manifest.json");
const bootstrap = { manifest };
const reactPackage = readJson("packages/react/package.json");
const nativePackage = readJson("packages/react-native/package.json");
const entries = {
  "cedros-extension.manifest.json": encode(manifest),
  "cedros-extension.bootstrap.json": encode(bootstrap),
  "workspace/README.md": readBytes("README.md"),
  "workspace/server/Cargo.lock": readBytes("packages/server/Cargo.lock"),
  "workspace/server/Cargo.toml": readBytes("packages/server/Cargo.toml"),
  "workspace/server/src/lib.rs": readBytes("packages/server/src/lib.rs"),
  "workspace/react/package.json": readBytes("packages/react/package.json"),
  "workspace/react/tsconfig.json": readBytes("packages/react/tsconfig.json"),
  "workspace/react/src/generated-manifest.ts": readBytes("packages/react/src/generated-manifest.ts"),
  "workspace/react/src/cedros-admin-runtime.d.ts": readBytes("packages/react/src/cedros-admin-runtime.d.ts"),
  "workspace/react/src/manifest.ts": readBytes("packages/react/src/manifest.ts"),
  "workspace/react/src/bootstrap.ts": readBytes("packages/react/src/bootstrap.ts"),
  "workspace/react/src/admin/register.ts": readBytes("packages/react/src/admin/register.ts"),
  "workspace/react/src/web/register.ts": readBytes("packages/react/src/web/register.ts"),
  "workspace/react-native/package.json": readBytes("packages/react-native/package.json"),
  "workspace/react-native/tsconfig.json": readBytes("packages/react-native/tsconfig.json"),
  "workspace/react-native/src/generated-manifest.ts": readBytes("packages/react-native/src/generated-manifest.ts"),
  "workspace/react-native/src/cedros-admin-runtime.d.ts": readBytes("packages/react-native/src/cedros-admin-runtime.d.ts"),
  "workspace/react-native/src/manifest.ts": readBytes("packages/react-native/src/manifest.ts"),
  "workspace/react-native/src/bootstrap.ts": readBytes("packages/react-native/src/bootstrap.ts"),
  "workspace/react-native/src/register.ts": readBytes("packages/react-native/src/register.ts")
};

addDirectoryEntries(entries, "workspace/react/dist", "packages/react/dist");
addDirectoryEntries(entries, "workspace/react-native/dist", "packages/react-native/dist");
if ((manifest.adminModules ?? []).length > 0 || (manifest.surfaces?.admin?.moduleIds ?? []).length > 0) {
  assertEntryExists(
    entries,
    packageExportArchivePath("workspace/react", reactPackage.exports?.["./admin/register"]),
    "React admin runtime export"
  );
}
assertEntryExists(
  entries,
  packageExportArchivePath("workspace/react", reactPackage.exports?.["./web/register"]),
  "React web runtime export"
);
assertEntryExists(
  entries,
  packageExportArchivePath("workspace/react-native", nativePackage.exports?.["./register"]),
  "React Native runtime export"
);
if (existsSync(resolve(root, "cedros-extension.server.wasm"))) {
  entries["cedros-extension.server.wasm"] = readBytes("cedros-extension.server.wasm");
}

assertEqual(bootstrap.manifest, manifest, "bootstrap manifest");
for (const entryName of Object.keys(entries)) validateArchivePath(entryName);

const fileName = `${manifest.extensionId}-${manifest.version}.cedros-extension.zip`;
const bytes = createDeterministicExtensionArchive(entries);
const checksum = createHash("sha256").update(bytes).digest("hex");
mkdirSync(resolve(root, "dist"), { recursive: true });
writeFileSync(resolve(root, "dist", fileName), bytes);
console.log(`${fileName} (${Object.keys(entries).length} entries, sha256 ${checksum})`);

function readJson(path) {
  return JSON.parse(readFileSync(resolve(root, path), "utf8"));
}

function readBytes(path) {
  return new Uint8Array(readFileSync(resolve(root, path)));
}

function addDirectoryEntries(target, archiveDir, localDir) {
  for (const entry of readdirSync(resolve(root, localDir), { withFileTypes: true })) {
    const localPath = `${localDir}/${entry.name}`;
    const archivePath = `${archiveDir}/${entry.name}`;
    if (entry.isDirectory()) {
      addDirectoryEntries(target, archivePath, localPath);
    } else if (entry.isFile()) {
      target[archivePath] = readBytes(localPath);
    }
  }
}

function encode(value) {
  return strToU8(JSON.stringify(value, null, 2));
}

function assertEqual(actual, expected, label) {
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(`${label} mismatch`);
  }
}

function assertEntryExists(entries, archivePath, label) {
  if (!entries[archivePath]) {
    throw new Error(`${label} missing from archive at ${archivePath}`);
  }
}

function packageExportArchivePath(packageRoot, exportPath) {
  if (typeof exportPath !== "string" || !exportPath.startsWith("./")) {
    throw new Error(`invalid package export path ${String(exportPath)}`);
  }
  return `${packageRoot}/${exportPath.slice(2)}`;
}

function validateArchivePath(path) {
  if (path.startsWith("/") || path.includes("../") || path.includes("\\")) {
    throw new Error(`archive contains unsafe path "${path}"`);
  }
}

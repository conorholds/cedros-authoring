import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const manifest = JSON.parse(
  readFileSync(resolve(root, "cedros-extension.manifest.json"), "utf8")
);
const source = [
  'import type { CedrosExtensionManifest } from "cedros:admin";',
  "",
  `export const generatedManifest = ${JSON.stringify(manifest, null, 2)} as CedrosExtensionManifest;`,
  ""
].join("\n");

writeFileSync(
  resolve(root, "cedros-extension.bootstrap.json"),
  `${JSON.stringify({ manifest }, null, 2)}\n`
);

for (const packageDir of ["packages/react", "packages/react-native"]) {
  const outputPath = resolve(root, packageDir, "src/generated-manifest.ts");
  mkdirSync(dirname(outputPath), { recursive: true });
  writeFileSync(outputPath, source);
}

console.log(`synced bootstrap and generated manifests for ${manifest.extensionId}@${manifest.version}`);

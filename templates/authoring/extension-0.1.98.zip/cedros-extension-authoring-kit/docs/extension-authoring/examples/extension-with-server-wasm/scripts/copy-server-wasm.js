import { copyFileSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const source = resolve(
  root,
  "packages/server-wasm/target/wasm32-wasip2/release/cedros_example_wasm_component.wasm"
);
const destination = resolve(root, "cedros-extension.server.wasm");

copyFileSync(source, destination);
console.log(`copied ${source} to ${destination}`);

//! Minimal route-only Cedros extension backend compiled as a Wasm component.

wit_bindgen::generate!({
    path: "wit",
    world: "route-only",
});

use crate::cedros::extension::logging;
use crate::exports::cedros::extension::jobs::{
    Guest as JobsGuest, JobExecution, JobOutcome, JobSpec, JobStatus,
};
use crate::exports::cedros::extension::routes::{
    Guest as RoutesGuest, RouteRequest, RouteResponse, RouteSpec,
};

struct Example;

impl RoutesGuest for Example {
    fn list_routes() -> Vec<RouteSpec> {
        vec![RouteSpec {
            route_id: "cedros-example-wasm:status".to_string(),
            method: "GET".to_string(),
            path: "/status".to_string(),
        }]
    }

    fn handle_route(request: RouteRequest) -> RouteResponse {
        let mount = "/extensions/cedros-example-wasm";
        let local_path = request.path.strip_prefix(mount).unwrap_or(&request.path);
        if request.method != "GET" || local_path != "/status" {
            return json_response(404, r#"{"error":"not_found"}"#);
        }

        logging::log("info", "cedros-example-wasm status route");
        json_response(200, r#"{"ok":true}"#)
    }
}

impl JobsGuest for Example {
    fn list_jobs() -> Vec<JobSpec> {
        Vec::new()
    }

    fn run_job(_execution: JobExecution) -> JobOutcome {
        JobOutcome {
            status: JobStatus::Failed,
            details_json: r#"{"error":"no_jobs_declared"}"#.to_string(),
        }
    }
}

fn json_response(status: u16, body: &str) -> RouteResponse {
    RouteResponse {
        status,
        headers: vec![("content-type".to_string(), "application/json".to_string())],
        body: body.to_string(),
    }
}

export!(Example);

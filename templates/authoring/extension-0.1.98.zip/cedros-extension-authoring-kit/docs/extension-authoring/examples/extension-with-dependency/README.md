# Extension with dependency

**MINIMAL VALID** · Cedros documentation `0.1.66` · validated by
`cedros-authoring validate-manifest`.

This manifest declares one required extension dependency. The declaration makes
the dependency visible to intake and lifecycle validation; it does **not** grant
access to private modules or bypass runtime authorization. Consume only the
dependency's published host contract.

# 12 · Admin Pages and Dashboard Cards

Read this when an extension ships pages inside the Cedros admin shell or a
status/KPI card on the shared admin dashboard.

## Current model

- Admin runtime contributions are JS `AdminModule` objects returned from the
  React admin registration bootstrap
  ([`06-runtime-sdk-reference.md`](06-runtime-sdk-reference.md)).
- The public runtime type calls leaf pages `sections`.
- Admin IA is group + leaf page, not arbitrary nested routing.
- Treat sidebar sections as broad work areas. Put closely related subviews
  inside one page as tabs or segmented navigation instead of publishing each
  subview as a sidebar section.
- Official group labels are merge keys. Match spelling and casing exactly.
- `adminModules[]` entries include the JSON-safe navigation projection used
  before executable runtime loads; the real page UI still comes from the
  runtime `AdminModule`.
- Runtime `sections[].icon` owns the real admin nav icon. Manifest-only
  fallbacks declare `adminModules[].sectionIcons` (host alias or Lucide name;
  full vocabulary in [`06-runtime-sdk-reference.md`](06-runtime-sdk-reference.md)).
- Onboarding can target admin sections through `onboardingPages[]`
  ([`15-content-starters-and-onboarding.md`](15-content-starters-and-onboarding.md)).
- Admin module slots can contribute shell wrappers and active-section wrappers
  when Cedros has approved the cross-cutting UI/provider need.

## Official groups and built-in permissions

- Registered group merge keys (exact label strings): `""` (the dashboard
  group), `Content`, `Users`, `Monetization`, `Email`, `Grow`, `Assistant`,
  `Settings`, `Extension Settings`, `Tools`, `Build`, and `Control Plane`.
  Targeting one of these merges your section into the existing host group.
- Put extension-owned settings, setup, policy, credential-reference, and
  configuration pages in `Extension Settings`. Cedros orders that group between
  `Settings` and `Tools`; keep host-owned settings pages in `Settings`.
- `Appearance`, `Observability`, `Data Model`, and `Operations` exist as host
  labels but are **not** registered group configs. Targeting them creates a
  new group sorted last (order 99) unless the module ships its own
  `AdminGroupConfig` for that label.
- A section with no `group` lands in a literal `Menu` group. Always set
  `group`.
- Built-in permission names used by host gating include `manage_settings`,
  `manage_users`, and `view_audit_log` (full capability list in
  [`06-runtime-sdk-reference.md`](06-runtime-sdk-reference.md)).

## What you declare and build

Manifest metadata:

- `adminModules[]` and `surfaces.admin.moduleIds`
- `surfaces.admin.slotIds` when slots are contributed
- `surfaces.admin.editorSurfaceIds` for content editor panels
- `adminModules[].sectionIcons` so manifest-only fallback pages have nav icons
  before the runtime admin bundle loads
- `adminModules[].navigation.sections[]` with the exact runtime page name,
  group, order, permission/dependency gating, and page-access metadata
- `adminModules[].navigation.groups[]` when using a custom group
- `adminModules[].contributions.dashboardCards[]`
- `onboardingPages[]` entries when setup should point at these pages

Runtime bootstrap:

- one or more `AdminModule` objects
- a `manifest` on each module with `moduleId`, `extensionId`, `displayName`,
  `version`, `packageName`, and mirrored `contributions` (required for ZIP
  loading; see the matching rule below)
- `sections` leaf page configs — `AdminSectionConfig` also supports `order`
  (placement within a group), `hideFromNavigation`, `labelKey`/`groupKey`
  (admin-namespace translation keys), `replacesSectionIds`, and
  `adminPageAccess`
- `components` map keyed by section id
- `createPluginContext(hostContext)` — REQUIRED. AdminShell calls it
  unconditionally; its return value is the only thing section components
  receive as `pluginContext`
- `cssNamespace` — REQUIRED. Feeds the section's `data-plugin-namespace`
  attribute
- optional custom group only when no official group fits
- content editor panel / dashboard card / wrapper contributions when needed

Runtime registration:

- The admin registration entrypoint must export executable runtime, not just
  the manifest. ZIP admin entries must export `registerCedrosAdminSurface()`
  or a default export.
- Named bootstrap exports do NOT work for ZIP-installed extensions. The
  generic archive loader never passes a bootstrap export name; only
  host-special-cased integrations (cedros-login, cedros-deploy) are wired by
  name. Do not rely on one.
- `adminModules[].sectionIds` identify the pages, while
  `adminModules[].navigation.sections[]` supplies the persisted first-paint
  label, group, order, and gating. Generate or copy this JSON-safe projection
  from the same definitions as runtime `sections[]`; the host verifies that
  both versions match and will not guess from extension ids or page names.
- Runtime `groups[]` is also exact-match metadata. If it is non-empty, mirror
  every group in `navigation.groups[]`, including registered-group overrides;
  omit both arrays when the runtime does not declare groups.

Keep a single JSON-safe navigation constant in extension source and use it to
generate the manifest plus runtime sections/groups. Add icons and components
only on the runtime side. This avoids manually maintaining two definitions.

Sidebar shape:

- Use one sidebar section for one coherent work area.
- Use in-page tabs for related workflows that share the same audience, data
  domain, and permission boundary.
- Create separate sidebar sections only when workflows belong in different
  official groups, need materially different permissions, or are used as
  independent high-frequency destinations.
- Do not split setup, settings, and diagnostics into separate sidebar sections
  by default. A login extension should usually expose one `Login` sidebar
  section with extension-owned tabs such as `Login methods`, `SSO`,
  `Session policy`, `Templates`, and `Setup`.
- Do not add tabs for host-owned surfaces such as Email provider config, Team,
  Permissions, Invites, Activity, Logs, Metrics, Server, CORS, or provider
  credentials. Use the ownership matrix in
  [`21-host-coordination-and-native.md`](21-host-coordination-and-native.md).
- Tabs should be regular UI state within the page unless the host explicitly
  asks for deep-linkable routes.

## Runtime example

Matching rule (ZIP extensions): the host only exposes runtime modules whose
`module.manifest.extensionId` equals the extension's id AND whose
`module.manifest.moduleId` is declared in the manifest's `adminModules[]`. A
module that fails either identity check, the exact version check, or the
persisted navigation sections/groups check is replaced by the "Admin bundle
not loaded" manifest fallback. `createPluginContext` and `cssNamespace` are
REQUIRED: AdminShell calls `plugin.createPluginContext(hostContext)`
unconditionally (a missing function is a TypeError at render), and sections
receive only `pluginContext` (plus `pageSize` and `refreshInterval`) — the
`createPluginContext` closure is the only way section components receive host
services.

```tsx
import { extensionManifest } from "../manifest";

function ExtensionIcon() {
  return <svg aria-hidden="true" viewBox="0 0 24 24" />;
}

function CommerceStatsCard(props) {
  if (props.analyticsError) return <div>Stats unavailable</div>;
  return <div>Checkout health: ready</div>;
}

const adminManifest = extensionManifest.adminModules?.[0];
const settingsNavigation = adminManifest?.navigation?.sections.find(
  (section) => section.id === "acme-demo:settings"
);
if (!adminManifest || !settingsNavigation) {
  throw new Error("Missing admin manifest/navigation projection.");
}

export const adminModule = {
  id: "acme-demo:admin",
  name: "Acme Demo",
  version: "1.0.0",
  // REQUIRED for ZIP loading. extensionId must equal the extension id and
  // moduleId must be declared in manifest adminModules[], or the host
  // silently drops this module and renders the manifest fallback.
  manifest: adminManifest,
  sections: [
    {
      ...settingsNavigation,
      icon: <ExtensionIcon />
    }
  ],
  components: { "acme-demo:settings": SettingsPage },
  contributions: {
    dashboardCards: [
      {
        id: "acme-demo:stats-card",
        Component: CommerceStatsCard,
        order: 20
      }
    ]
  },
  // REQUIRED. Sections receive this return value as their `pluginContext`
  // prop; there is no other channel for host services.
  createPluginContext: (hostContext) => ({
    serverUrl: hostContext.cedrosLogin?.serverUrl ?? "",
    authenticated: hostContext.cedrosLogin?.authenticated,
    getAccessToken: hostContext.cedrosLogin?.getAccessToken ?? (() => null),
    hasPermission: (permission) =>
      hostContext.org?.permissions?.includes(permission) ?? false
  }),
  // REQUIRED. Feeds the section's data-plugin-namespace attribute.
  cssNamespace: "acme-demo",
  checkPermission: (permission, hostContext) =>
    hostContext.org?.permissions?.includes(permission) ?? false
};
```

The `checkPermission` and `createPluginContext` bodies are illustrative.
Prefer a documented host permission helper or capability-check API when the
runtime contract exposes one; otherwise document permission enforcement as host-coordinated and
fail closed.

## Admin runtime React context

The host mounts extension admin sections inside Cedros AdminShell, wrapped in
`AdminSectionErrorBoundary`, and passes only `AdminSectionProps`. Safe runtime
inputs are the `pluginContext` prop, documented host helpers that take
`pluginContext`, and host services from `AdminHostContext`/the host service bag.

The internal `requestJson` / `requestText` / `requestBlob` helpers are
host-internal and are NOT exported from `cedros:admin` (see
`ui/src/admin/index.ts`). To fetch live data, either call `getHostService(...)`
or self-fetch `${pluginContext.serverUrl}/extensions/{your-id}/...` with your
own `Authorization: Bearer ${pluginContext.getAccessToken()}` header.

The host does not mount an extension's standalone app provider tree. Admin
components must not call standalone full-provider hooks such as
`useCedrosLogin()` unless the extension explicitly provides the required admin
wrapper through an approved admin module slot. A context throw becomes a
visible section error in the host, but the component should still fail closed
with loading, disabled, empty, and error states for missing services or data.

### Notifications and transient feedback

Import the host-owned toast API from the `cedros:admin` virtual module. The ZIP loader
provides this bare import through the same host shim as the other supported
admin helpers:

```tsx
import { toast } from "cedros:admin";

toast.success("Settings saved.");
```

Do not mount a toaster, bundle Sonner, import `ui/src/admin/primitives/*`, or
ship notification positioning, queue, timer, or animation CSS. Use toasts for
transient completed outcomes and non-contextual action failures. Keep field
validation, progress, load/retry errors, permission/setup blockers, autosave
recovery, and durable state inline where the operator can act on them. One
event gets one announcement—never an inline success plus a toast for the same
action.

The complete public API, timing and stable-id rules, decision table, examples,
test contract, and copy/paste implementation prompt live in
[`reference/admin-notifications.md`](reference/admin-notifications.md).

## Styling admin surfaces

**Your compiled admin entry must inject its own CSS at module evaluation. Do
not depend on the host to load a separate stylesheet file.**

The host loads compiled JavaScript from the ZIP and does not add an HTML
`<link>` tag for extension stylesheets. Newer hosts also deliver archive
`kind: "style"` files directly (inlined as critical CSS on public pages,
injected into the admin document), but that injection hook shipped in
June 2026 and **a deployed host can predate it while still reporting an
up-to-date admin version** — host version strings are bumped on release cuts,
not on every loader behavior change. An admin bundle that relies on host
archive-CSS injection renders unstyled on those hosts. Treat host delivery as
defense-in-depth, never as the primary path.

The required pattern (self-injection):

1. Inline the stylesheet into the JS bundle (for example Vite
   `import css from "./admin.css?inline"`).
2. At module evaluation of the admin register entry, append one id-guarded
   `<style id="<extension-id>-admin-styles">` (skip if the id already exists;
   no-op when `document` is undefined for SSR safety). Host dedup matches the
   `data-cedros-extension-style` attribute VALUE exactly, and the host's key
   format is `<react packageName>::<css file path inside the zip>` (e.g.
   `@acme/demo-react::packages/react/dist/admin.css`). A self-injected style
   with any other value — including the id-guarded pattern above — never
   matches, so a newer host injects a second copy. That is harmless
   duplication, not a failure; use the exact host key format only if you want
   newer hosts to skip their own archive injection.

**Vite library-mode trap:** a plain `import "./admin.css"` in source does
*not* survive compilation — library mode extracts it into a separate `.css`
asset and strips the import, leaving the compiled entry with no runtime
injection at all. The zip then contains the CSS file, intake accepts it, the
components render, and the stylesheet never enters the page on pre-hook
hosts. Use `?inline` plus an explicit injector; the extracted/shipped `.css`
file may still be packaged as `kind: "style"` for hosts that inline public
critical CSS.

**Verify the shipped artifact, not the source:** after packaging, assert the
built admin entry (the file `exports["./admin/register"]` resolves to, plus
its chunks) contains your CSS string and the injection call — ideally as a
packaging-script failure, using a sentinel selector that lives in an
`@import`-nested sheet so a Vite config regression cannot slip through. "The
CSS file is in the zip" proves nothing about whether it is ever applied.

### Admin token scope

Delivery is global, but the in-scope color **tokens differ by surface**. An
extension **block** rendered in the visual-builder preview sits inside a
`.cedros-runtime` wrapper and gets the `--cedros-runtime-*` block tokens. An
extension **admin page/section** mounts in `.cedros-admin-shell__section`, and
a **dashboard card** mounts in the `.cedros-data` dashboard region — neither
has a `.cedros-runtime` ancestor, so `--cedros-runtime-*` do **not** resolve
there. Admin surfaces theme through the AdminShell's `--cd-*` tokens instead.

- The shell root `.cedros-admin` always exposes the `--admin-*` set plus a core
  `--cd-*` subset that every admin section inherits: `--cd-bg`, `--cd-fg`,
  `--cd-muted`, `--cd-border`, `--cd-radius`, `--cd-warning`, `--cd-info`, and
  `--cd-error`.
- The fuller `--cd-*` palette is defined on `.cedros-data`, not on the bare
  section: `--cd-muted-bg`, `--cd-accent`, `--cd-card-bg`, `--cd-ring`,
  `--cd-primary`, `--cd-primary-fg`, `--cd-success`, `--cd-danger-bg`,
  `--cd-danger-border`, and `--cd-shadow`. To use these, render your section
  content inside a `<div className="cedros-data">` wrapper (or ensure a
  `.cedros-data` ancestor); otherwise `var(--cd-primary)` and the rest of the
  fuller set silently have no value. Dashboard cards already render inside
  `.cedros-data`, so they get the full set for free.
- Admin dark mode is class-driven (`.cedros-admin--dark` / `.cedros-dark`),
  not `prefers-color-scheme` — consuming `--cd-*` is what makes a page follow
  the admin theme toggle. Always provide a fallback, e.g.
  `color: var(--cd-fg, oklch(0.145 0 0))`.
- The authoritative token reference — including the Workbench additions
  (`--cd-link`, `--cd-warning-fg`, `--cd-input-bg`, the z-scale) and the
  `--motion-*` duration/easing tokens — is
  [`/design-admin.md`](../../design-admin.md) §3. Consume motion tokens rather
  than hardcoding durations.
- Namespace and scope every selector under your own roots (block/extension
  id). The host injects extension CSS globally, so unscoped rules leak into
  the host and the site.
- Avoid wrapping component CSS in `@layer`; host unlayered base/Tailwind rules
  can override layered extension CSS unexpectedly.
- Prefer reusing host primitive classes over hand-rolled CSS: `cedros-data-btn`
  (with `--primary`, `--secondary`, `--ghost`, `--danger`, and `--sm`
  modifiers), `cedros-data-grid`, and `cedros-data-card` already consume
  `--cd-*` and follow admin dark mode.

For the reusable admin UI class and accessibility contract — page title rows,
cards, setup notices, buttons, forms, toolbars, tabs, dropdown menus, tables,
row actions, status notices, chips, pills, metric tiles, empty states,
pagination, and dialogs — see
[`reference/admin-ui-patterns.md`](reference/admin-ui-patterns.md). The
design decisions behind all of it — metrics, type scale, casing, motion,
state anatomy, page templates, and copy voice — are owned by the admin design
standard, [`/design-admin.md`](../../design-admin.md) ("Workbench"); read its
§11 extension author contract before shipping admin UI.

See [`14-blocks-templates-and-styling.md`](14-blocks-templates-and-styling.md)
for the shared CSS **delivery and scoping** model (it applies to all extension
CSS). Its `--cedros-runtime-*` **token table is for visual-builder blocks
only** and does not apply to admin pages or dashboard cards — for those, use
the `--cd-*` tokens above.

## Dashboard cards

- Dashboard cards are React admin runtime contributions returned from the
  extension's `AdminModule`.
- Manifest metadata lives in `adminModules[].contributions.dashboardCards[]`.
- Runtime components live in `AdminModule.contributions.dashboardCards[]`.
- The host resolves cards from the RUNTIME module's own
  `manifest.contributions.dashboardCards` — `displayName`, `description`, and
  `requiredPermission` are read from there. Nothing merges the manifest file's
  `adminModules[].contributions` into the loaded runtime module. Mirror each
  manifest contribution entry verbatim into the runtime
  `AdminModule.manifest.contributions.dashboardCards` inside the bundle, or
  the card silently never renders.
- Cards render on the main dashboard only when the extension is installed,
  active, compatible, and the contribution is enabled. `requiredPermission`
  skips the card when `checkPermission` denies it.
- The extension owns the whole card component. Cedros does not provide layout
  hints beyond placing the component in the dashboard contribution region
  (`.cedros-data .cedros-dashboard-extension-cards`).
- The normative product and visual contract is
  [`design-admin.md` §6.1](../../design-admin.md#61-dashboard-contribution-cards):
  admission test, information hierarchy, metric semantics, chart choice, time
  controls, density, freshness, states, accessibility, and the five-second
  acceptance gate. Registration here does not authorize a different card
  language.

Runtime props the card component receives: `hostContext`, `pluginContext`,
`extensionId`, `refreshInterval`, `isLoading`, `analyticsSnapshot`,
`analyticsError` (empty string means no error — see
[`06-runtime-sdk-reference.md`](06-runtime-sdk-reference.md)).

Recommended data-fetching pattern:

```ts
import { HOST_SERVICE_IDS, getHostService } from "cedros:admin";

function StatsCard({ hostContext, extensionId }) {
  const inventory = getHostService(hostContext, HOST_SERVICE_IDS.extensionInventory);
  if (!inventory) return <div>Stats unavailable</div>;
  return <div data-extension-id={extensionId}>Stats loading</div>;
}
```

Use a documented host service id or an extension-owned server route that is
listed in host handoff. Do not call raw database/provider clients from the
browser, and do not hard-code private AdminShell URLs for actions.

State matrix:

| State | Required UI |
|---|---|
| initial loading | layout-matched card skeleton; no spinner-only card |
| background refresh | retain the last good values/plot and mark the region busy |
| empty | explain why no observations exist and when they can appear; no fake plot |
| permission denied | host omits the card through `requiredPermission`; do not render a dashboard teaser |
| missing provider / dependency | compact reason and one setup doorway; do not reserve chart-sized space |
| stale / partial | retain data, label it, and show source freshness/coverage |
| refresh failed | retain last-good data, identify the failed refresh, and add `Stale` only after maximum age |
| error | redacted retryable error and one action; never substitute zeroes |
| happy / attention | 1–3 headline metrics, ≤1 evidence region, explicit window/freshness, ≤1 action |

Historical cards should read one bounded extension-owned aggregate route. That
response must provide, under extension-owned field names:

- source generation time;
- window start/end, timezone, and bucket granularity;
- current values and equal-window comparison values;
- ordered, server-bounded series buckets when a chart is present; and
- partial-data or coverage state.

Classify each metric as a stock, flow, rate/ratio, or duration/percentile before
choosing its comparison or chart. Do not fetch raw events or PII into the
browser to build a series, issue one request per metric/bucket, interpolate
missing buckets, or poll faster than the host `refreshInterval`; `0` disables
scheduled polling. Custom date ranges, exports, thresholds, and detailed filters
belong on the extension admin page, not inside the dashboard card.

Card rules:

- Keep card ids stable and unique within the extension.
- Declare each card in all three places: manifest metadata, the runtime
  `AdminModule.manifest.contributions.dashboardCards` (verbatim mirror), and
  the runtime `AdminModule.contributions.dashboardCards`.
- Keep the card self-contained; do not assume it can change dashboard layout
  or reorder core cards.
- Do not assume card size, refresh interval, or analytics snapshot shape
  beyond the published runtime props; the card must stay useful when the
  analytics snapshot is unavailable.
- Use one outer Workbench card, one operator question, one–three primary
  metrics (four maximum for a wide card), one chart/breakdown/activity region
  maximum, and one detail/setup/retry action maximum. Do not nest titled cards.
- State the time basis for every metric and chart. Compare only equal-length
  windows with the same timezone and bucket boundaries. `0` is measured data;
  `—` is unknown; unavailable or stale is never formatted as zero.
- Card-owned configuration is limited to a useful time-range preset and,
  rarely, visibility for two–three related series. Chart type, color,
  smoothing, axis bounds, bucket density, alert policy, export, custom dates,
  and thresholds are not dashboard-card controls.
- Render extension-specific charts with namespaced markup that follows
  Workbench §4.9/§6.1. Do not import private host chart components. A chart
  needs a visible caption/window, current value and comparison, an accessible
  trend summary and structured data twin, and keyboard/touch parity for any
  point tooltip.
- Do not use dashboard cards for long workflows. Link to an extension admin
  page for setup, configuration, or detailed management; route by
  module/section ids or host navigation helpers.
- Fail closed when permissions, dependencies, services, or data are missing.
- Keep displayed metrics safe for the intended admin audience; never fetch
  secrets or raw PII into dashboard state.

## Self-serve admin route contracts

Wasm admin routes are self-serve, but they still need documented request and
response schemas. The server component and React admin UI are separate
packages, so route-id parity alone does not prove the UI can parse the route
response.

For every extension-owned admin route, document the request schema, response
schema, auth/permission requirement, and error shape. Add a cross-package
contract test that fixtures the wasm response and asserts the React parser
accepts it. Common contracts such as settings and users should use
host-published schemas or codegen when available.

Behavior plan for every page:

- permission and dependency gating
- loading/empty/error/disabled states
- site-brain records for important operator actions
- analytics events only for actionable product questions
- tests or compatibility fixtures

## Validation rules

- Keep module ids and page ids stable.
- `adminModules[].moduleId` must exactly match the runtime
  `module.manifest.moduleId`, and `module.manifest.extensionId` must equal
  the extension id; otherwise the host silently replaces the module with the
  "Admin bundle not loaded" manifest fallback.
- The ZIP runtime bootstrap's `manifest.version` must EXACTLY equal the
  installed manifest version, or the runtime module is silently ignored.
- Every manifest-declared `sectionIds[]` entry needs a matching
  `adminModules[].sectionIcons` entry (host alias or Lucide name).
- Every runtime section, including `hideFromNavigation` sections, needs exactly
  one matching `navigation.sections[]` entry. `id`, `label`, `group`, `order`,
  and every optional projected field must match runtime.
- Runtime `groups[]` and manifest `navigation.groups[]` must either both be
  absent/empty or match exactly. Every non-registered/custom group needs its
  explicit group metadata.
- Dashboard card ids must be unique within the extension and declared in both
  manifest metadata and runtime contributions.
- `onboardingPages[].moduleId` must reference a same-extension admin module,
  and that module MUST declare `sectionIds[]` containing the target
  `sectionId`. Intake hard-fails a target module without `sectionIds`
  ("module … must declare sectionIds"). Duplicate onboarding ids are rejected
  (`ADMIN-MODULE-001`).
- Gating semantics: section-level `requiredPermission` and
  `requiredExtensionId` HIDE the section from the sidebar entirely;
  `disabled` (+ `disabledReason`) keeps it visible but unmountable;
  module-level `requiredServices`/`requiredCapabilities` in the runtime
  manifest silently DROP the whole module when unmet. Pick the mechanism for
  the visibility you want.
- `requiredExtensionId` should block required dependency flows and show a
  connect/unavailable state for optional dependency flows.
- Avoid sidebar sprawl. Collapse related pages into tabs unless a separate
  sidebar section is justified by group, permission, or destination frequency.
- Do not import host-internal React primitives. Use documented host primitives
  when the runtime contract exposes them; otherwise mirror the admin class and ARIA
  contracts in [`reference/admin-ui-patterns.md`](reference/admin-ui-patterns.md).
- Extension-defined permissions are host-coordinated unless Cedros publishes a
  review and enforcement path. Prefer built-in capability names or published
  dependency capabilities. Hiding an admin section is not authorization;
  server routes must perform their own auth and permission checks.
- Admin pages that persist settings must use the planned host-approved
  settings and secrets storage path
  ([`09-settings-secrets-and-state.md`](09-settings-secrets-and-state.md));
  never store secrets in manifest metadata or UI local state.
- Do not create a nested router inside one admin page unless Cedros explicitly
  asks for it.
- Destructive actions require confirmation, permission checks, safe retry
  behavior, and a rollback or recovery note.

## Acceptance checks

- Admin pages render inside AdminShell.
- The compiled admin register entry self-injects the extension stylesheet at
  module evaluation, verified against the packaged artifact (not source), so
  pages render styled on hosts that predate archive-CSS injection.
- Admin pages and dashboard cards use the shared admin shell patterns in
  [`reference/admin-ui-patterns.md`](reference/admin-ui-patterns.md) wherever
  those UI shapes appear.
- Gating behaves as intended: sections with unmet
  `requiredPermission`/`requiredExtensionId` are hidden from the sidebar,
  `disabled` sections stay visible but unmountable with a useful
  `disabledReason`, and modules with unmet
  `requiredServices`/`requiredCapabilities` are intentionally dropped.
- Content editor panel ids, if any, appear in manifest and ZIP-contained
  runtime.
- Dashboard cards render on the main dashboard only when the extension is
  active and the card contribution is enabled; loading, empty, error,
  disabled, and happy paths are visible and tested.
- Every dashboard card passes Workbench's §6.1 five-second gate in light and
  dark: domain, current state, primary value/window, direction/comparison, and
  one next destination are evident without opening the extension.
- Historical cards use one bounded aggregate snapshot, retain last-good data
  during refresh/staleness, and test stock/flow/rate/duration comparison
  semantics, missing buckets, unknown versus zero, and reduced motion.
- Charts use the Workbench palette and density, remain legible at 320px, expose
  a non-visual data twin, and give keyboard/touch users the same exact values
  available through pointer tooltips.
- Onboarding links resolve to real module/section pairs.
- No secrets, tokens, auth headers, or raw PII are logged or displayed.

Next: [`13-public-pages-and-seo.md`](13-public-pages-and-seo.md).

# 25 · Troubleshooting and FAQ

Symptom → likely cause → fix, for everything that commonly goes wrong across
intake, loading, rendering, routing, and runtime. Deep dives live in the
linked docs.

## Start with the failing layer

Do not change manifest declarations until the evidence points to a declaration
problem. Classify the first failing boundary:

1. **Intake** — the ZIP, manifest, export graph, source preflight, or Wasm
   admission is rejected. Fix the named archive/contract error.
2. **Activation** — intake succeeded, but compatibility, permission,
   capability, reverse binding, or enablement failed. Inspect activation state
   and the capability endpoint.
3. **Module import** — install and activation succeeded, but browser ESM import
   threw. Capture the production exception/stack, identify the resolved chunk,
   and inspect that exact built file before editing the manifest.
4. **Registration export** — the module imported, but the fixed registration
   export is missing, rejects, or returns the wrong extension identity/version.
5. **React render** — registration succeeded, but one component throws.
   Reproduce through the extension-specific error boundary and inspect its
   component stack.
6. **Route call** — UI is mounted, but an extension HTTP request fails. Record
   method/path/status/request id and distinguish the host mount from the guest
   response.
7. **Host seam** — the route ran, but a Wasm import such as settings, database,
   secrets, storage, or providers rejected. Check the declared access,
   capability, input cardinality, and stable host error.

When module import fails, retain a safe diagnostic with extension id/version,
surface module (`admin` or `web`), registration entrypoint, resolved chunk,
line/column when available, archive id and SHA-256, and exception type. Redact
request bodies, settings values, secrets, tokens, and user data. Preserve the
browser exception class and safe stack location; never replace
`ReferenceError`, `TypeError`, or a loader validation error with only “bundle
failed to load.”

## Install and intake

| Symptom | Likely cause | Fix |
|---|---|---|
| "multiple `cedros-extension.manifest.json` entries" | Intake matches canonical file names **anywhere** in the ZIP, and a nested copy (e.g. under `workspace/examples/`) collided with the root copy | Keep exactly one of each canonical name anywhere in the archive ([`22`](22-packaging-and-upload.md)) |
| "manifest/bootstrap mismatch" | Hand-edited bootstrap diverged from the manifest | Generate both files from one manifest object; never hand-edit |
| Archive rejected with a UTF-8/binary error | A non-wasm binary entry (image, font, signature blob) is in the ZIP — every non-wasm entry must be UTF-8 text | Remove binary assets; ship only text + the wasm component |
| Install fails naming a route/job id | **Reverse binding admission**: a manifest-declared `surfaces.server.routes[]`/`jobs[]` id is not returned by the guest's `list-routes`/`list-jobs` | Keep manifest ids and guest exports identical — one extra declared id rejects the whole install ([`07`](07-wasm-server-backends.md)) |
| Install fails with a WIT/type-check error | Component imports a capability the manifest doesn't grant, or was built against a different WIT than the host's | Declare the capability (or drop the import); re-vendor the host WIT and check `compatibility.witChecksum` against the capability endpoint |
| Install fails mentioning dynamic `seoRoutes` | Manifest declares a dynamic (`:param`/`*`) `seoRoutes[]` pattern but the guest doesn't export `seo` | Build against the `extension-seo` world and export `seo`, or make the route static ([`13`](13-public-pages-and-seo.md)) |
| Wasm won't install / capability endpoint says disabled | The host's wasm extension runtime is off (`wasmExtensionsEnabled: false`) | Enable the `wasm-extensions` feature on the host before packaging further |
| Version mismatch accepted at intake but blocked later | `compatibility.platformApiVersion` mismatch imports but shows Unavailable and is rejected at install/enable | Set `platformApiVersion`/`compatibility.platformApiVersion` to `"1"` |
| Install blocked on `minCedrosDataVersion` | Manifest pinned a Cedros Data host release newer than the running host | Declare the **lowest host release** that provides the seams you actually use |
| Upload completes but install/enable never runs | A compatibility/dependency/permission blocker stopped the composed flow, or the imported entry disappeared from management inventory | Read the visible entry's blocker and lifecycle activity. If a local upload has no entry, treat that as a host inventory regression rather than repackaging blindly |

## Admin pages and dashboard cards

| Symptom | Likely cause | Fix |
|---|---|---|
| Section renders "Admin bundle not loaded" | Runtime module failed the matching rule: identity/version mismatch, missing runtime, or runtime `sections`/`groups` differ from persisted `adminModules[].navigation` | Mirror ids/version and every projected navigation field exactly; generate manifest/runtime navigation from one source, rebuild, and upgrade/reinstall ([`12`](12-admin-pages-and-dashboard-cards.md)) |
| One extension route ends in a runtime-load error while other extensions work | That archive failed fetch, validation, import, identity checks, or its independent five-second load limit | Read the extension-specific error, correct or disable that bundle, then use Retry; already loaded runtimes are preserved ([`06`](06-runtime-sdk-reference.md)) |
| Every extension's admin pages broke at once | A shared host state, authentication, routing, or runtime-shim regression — one bad archive no longer clears every extension runtime | Inspect the installed-state/archive requests and host logs before repackaging extensions; report a host regression if failures span unrelated extension ids ([`06`](06-runtime-sdk-reference.md)) |
| An older installed extension works but its archive response still contains both admin and web files | Its persisted legacy archive predates generated surface file graphs, so the host falls back to the complete archive | No compatibility fix is required. Re-upload or reinstall the same built ZIP through an upgraded host to regenerate projection metadata ([`22`](22-packaging-and-upload.md)) |
| Opening an extension route flashes the dashboard or cycles through multiple host skeletons | Host route/loading orchestration regressed; extension packages do not control the outer AdminShell loading sequence | Report the host behavior with the route and request timeline; do not add package-level delays or dashboard warmup code |
| "is not bundled" load error | A bare import outside the four shims (`react`, the two JSX runtimes, `cedros:admin`) — commonly `react-dom` via a portal library | Use `cedros:admin`, bundle the dependency, or drop it. Public chunks must never import `react-dom` at all ([`14`](14-blocks-templates-and-styling.md)) |
| `ReferenceError: process is not defined` | A built admin or web dependency chunk retained a Node environment branch (Motion was one observed source); blob-loaded browser ESM has no `process` | Inspect the chunk named by the production stack, add Vite `define: { "process.env.NODE_ENV": JSON.stringify("production") }`, rebuild, validate every resolved ESM chunk, and import the packaged entrypoint with `globalThis.process` absent ([`22`](22-packaging-and-upload.md)) |
| "missing runtime file" | Importing an asset the loader drops (`.svg`, `.png`, fonts, `.map`) — only `.js`/`.mjs`/`.css`/`.json` become runtime files | Inline assets into JS/CSS or serve them from your wasm routes |
| TypeError at section render | Missing `createPluginContext` — AdminShell calls it unconditionally | Export it on every `AdminModule`; it is the only channel for host services |
| Admin page renders unstyled | Bundle relied on host archive-CSS injection on a host that predates it, or a bare `import "./admin.css"` was stripped by Vite library mode | Self-inject with `?inline` + id-guarded `<style>` at module evaluation; verify the **built** artifact contains the CSS sentinel ([`12`](12-admin-pages-and-dashboard-cards.md)) |
| `var(--cd-primary)` has no value | The fuller `--cd-*` palette lives on `.cedros-data`, not the bare section | Wrap section content in `<div className="cedros-data">` |
| Dashboard card never renders | Manifest contributions were not mirrored into the runtime `AdminModule.manifest.contributions.dashboardCards` (the host reads the runtime copy) | Mirror each entry verbatim inside the bundle ([`12`](12-admin-pages-and-dashboard-cards.md)) |
| Whole module silently missing from sidebar | Module-level `requiredServices`/`requiredCapabilities` unmet — modules are dropped, not disabled | Use section-level `disabled`/`requiredPermission` when you want a visible state |
| Manifest fallback page renders iconless | Declared `sectionIds[]` without a matching `sectionIcons` entry | Add a `sectionIcons` entry per section (44 host aliases or any Lucide name) |
| Sidebar entry appears, moves, relabels, or changes gating after refresh | Installed manifest is legacy/stale or its navigation projection differs from runtime | Add exact `navigation.sections`/`navigation.groups`, rebuild, upgrade/reinstall, and verify first paint before runtime loads |

## Public routes, pages, and blocks

| Symptom | Likely cause | Fix |
|---|---|---|
| Every `/extensions/{id}/…` route returns an empty 404 | Host route not bound: install didn't run or the extension is disabled (an archive that declares routes/jobs without a component is rejected at intake; `{"installed": null}` only comes back from `stage_only` validation) | Confirm the install response and enabled state |
| A bound route returns your own JSON 404 | Handler matched against the bare subpath — the host passes the **full** mounted path | Strip `/extensions/{id}` before internal routing ([`07`](07-wasm-server-backends.md)) |
| Seeded page (e.g. `/login`) 404s after enable | Seed missing/incomplete (`autoCreateOnEnable`/`publishOnEnable`/`templateId`), host reconciliation failed, or the template doesn't resolve | Walk the seed chain in [`13`](13-public-pages-and-seo.md); check the lifecycle response and server reconciliation log; check the visible template-gap error |
| Jobs never fire after a headless/API enable | The host predates server-side `jobSchedules[]` reconciliation, the schedule is invalid, or the job was operator-disabled | Update Core, re-enable the extension, then inspect the lifecycle response and Automation schedule ([`11`](11-jobs-and-scheduling.md)) |
| Block invisible on the public page | Metadata-only extension blocks render as an invisible hydration target (not a card); or the block definition was silently dropped for missing `type`/`displayName`/`category` | Ship the component/renderer; fill all three hard-required definition fields ([`14`](14-blocks-templates-and-styling.md)) |
| Block styled in admin preview, unstyled on public page | Web chunk/CSS outside the web entry's `dist/` prefix, or CSS only delivered via admin-side injection | Keep web chunks under the web dist prefix; ship archive `kind: "style"` CSS + self-injection |
| Block ignores the site's dark-mode toggle | CSS keyed off `@media (prefers-color-scheme: dark)` | Scope dark styles under `.cedros-dark` and use the runtime tokens |
| Template offers no zone for starter blocks | `zones` omitted (defaults to `[]`) | Always declare `zones: [{ id, label, order }]` |

## Wasm runtime behavior

| Symptom | Likely cause | Fix |
|---|---|---|
| Call traps with a deadline message | 5 s guest epoch interval / 60 s whole-invocation / 55 s host-call defaults exceeded (`CEDROS_WASM_INVOCATION_TIMEOUT_MS`, `CEDROS_WASM_HOST_CALL_TIMEOUT_MS`) | Bound each run's work; paginate sweeps; carry a cursor in settings/DB ([`07`](07-wasm-server-backends.md)) |
| Sweep quietly processes only 100 rows | `database.read` default page size is 100 | Paginate with `limit`/`offset` ([`08`](08-site-database.md)) |
| Read returns rows but your fields are missing | Response keys are snake_case (`entry_key`, `updated_at`) and your data sits under `payload` | Deserialize the `EntryRecord` shape, not your input shape |
| A typo'd query returns default-ordered rows instead of erroring | Malformed guest JSON args degrade to `null`/`{}` silently | Validate your own query JSON before calling |
| `secrets.get`/`set` fail closed | Host missing `CEDROS_EXTENSION_SECRETS_PASSPHRASE` | Operator must configure the passphrase; `delete` works without it |
| Every `http.fetch` errors | Egress is operator-granted: no allowlist configured means every call fails closed | Operator sets `CEDROS_EXTENSION_HTTP_ALLOWLIST`; also: https-only, no redirects, internal IPs blocked |
| Intelligence readiness fails with `cedros.provider.not_configured` | The host has no ready selected provider/default model | Show setup-disabled UI or pause/queue optional work; never ask the extension user for a provider key ([`10`](10-host-providers.md)) |
| Provider call fails with `cedros.provider.denied` | The access id/scope is not declared or site policy/model allowlists deny the requested target | Fix the manifest grant or use `providers.resolve-default`; do not fall back to extension-owned credentials |
| Provider call fails with `cedros.provider.invalid_request` | Provider/operation/payload is malformed, including missing `provider`/`model` in an AI execute payload | Resolve the default first, copy the returned pair into `execute`, and branch on `code`/`category`, not message text ([`10`](10-host-providers.md)) |
| Email send fails with `provider_not_configured` | Site has no active sending provider — email has no local fallback | Detect the stable code; queue or skip optional email work |
| `emit-record` denied | Missing `site-brain-record:<category>` write scope in root `capabilities[]` | Declare the scope for each category you write ([`16`](16-analytics-and-site-brain.md)) |
| Analytics events "succeed" but never appear | Site analytics settings disable extension events; emission silently no-ops | Treat emission as best-effort; verify in staging with events enabled |
| Guest state vanished between requests | Per-request instantiation — no globals survive | Persist caches in settings or the database |
| Webhook signature verification impossible | Route bodies are re-serialized JSON, never raw bytes; form-encoded/binary bodies 400 before the guest | Use token-in-URL or header verification; raw-body passthrough is host-coordinated |

## FAQ

**Can my extension serve files or images?** Store bytes through the storage
seam and stream them from your own authenticated route. There are no public
storage URLs and no presigned URLs ([`07`](07-wasm-server-backends.md)).

**Can I read another extension's data?** No. The database seam reaches only
your declared content models. Consume another extension's data through its
published extension-service contract over `extension-services.invoke`, which
requires a declared dependency and capability grant
([`19`](19-composability-and-relying-party-contracts.md)); `http.fetch` is
for operator-allowlisted external hosts, not other extensions.

**How do I know who's calling my route?** The context envelope carries the
cedros-data principal (`actorId`, `principalId`, `authenticated`,
`authScheme` of admin-session, bearer-token, or extension-service,
`permissionClaims`, `capabilityClaims`, `csrfVerified`, `siteId`, and any
Assistant run identifiers). Site visitors use the separate `context.visitor`
object on opted-in `routePolicies` routes. Declare
`cedros-data:extension-visitor-v1`; the host verifies Login and supplies an
extension-scoped `userId`, without a cookie or token. See
[the visitor contract](contracts/extension-visitor-v1.md). Other identity
providers require their own published integration.

**Can I register a redirect?** No — redirects are site-owner-managed only
([`13`](13-public-pages-and-seo.md)).

**Can I emit my own `<head>` tags / JSON-LD / sitemap entries?** No. Declare
SEO intent (`seo`, `seoRoutes[]`, the `seo` wasm export) and Core emits
everything ([`13`](13-public-pages-and-seo.md)).

**Is there a per-tenant install model?** No. Cedros is per-site
single-tenant; model multi-business rows inside your own content models
([`01`](01-extension-system-overview.md)).

**How big can the archive and component be?** 64 MB request body on both
intake endpoints; the wasm component up to 64 MB; every other entry ≤2 MB
UTF-8 text, ≤8 MB total, ≤4096 entries ([`22`](22-packaging-and-upload.md)).

**Do job retries happen automatically?** No. `retryable` is recorded as a
failed run; design jobs idempotent and self-recovering on the next scheduled
run ([`11`](11-jobs-and-scheduling.md)).

**Same-version reinstall shows the full permission review again?** Yes — by
design (security fail-safe). Bump the patch version for a one-click
unchanged-scope update.

**Do existing extensions need to be rebuilt for progressive loading?** No.
Existing packages and legacy persisted archives remain compatible. New intake
automatically derives admin/web entry and file graphs from the package exports.
Re-upload or reinstall the existing built ZIP only when you want an older
installation to gain full surface payload projection; prefer a patch version
for normal distribution.

**Where do I check what a host actually supports?**
`GET /admin/runtime/wasm-extensions/capabilities` (admin auth) reports the WIT
version/checksum, granted seam set, providers, and runtime limits
([`07-wasm-server-backends.md`](07-wasm-server-backends.md)). Design for the
oldest host you target; host version strings do not prove loader behaviors.

**Something in these docs disagrees with the host I'm running?** The
authoritative order is: host behavior → [`07`](07-wasm-server-backends.md) /
[`04`](04-manifest-reference.md) → surface docs →
[`reference/host-wire-contracts.md`](reference/host-wire-contracts.md)
(digest). Report the discrepancy to Cedros with the capability endpoint
output.

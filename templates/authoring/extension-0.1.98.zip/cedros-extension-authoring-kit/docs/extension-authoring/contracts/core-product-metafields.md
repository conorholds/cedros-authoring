# Core Product Metafields Contract

> Status: coordination-only proposal. Cedros Data does not publish this
> contract id, capability, mutation API, validator, or storefront projection.
> Consumers must treat the seam as unavailable and must not describe it as a
> shipped Cedros Data capability.

Use this with
[`../18-official-extension-integrations.md`](../18-official-extension-integrations.md)
when Cedros Shop, Cedros Pay, or another commerce surface needs typed product
metafields.

This is a Core-owned commerce contract. Shop renders the admin UX from this
contract. Pay stores bounded product metadata values only. Neither Shop nor Pay
owns a parallel schema registry, storefront exposure policy, or typed validation
system.

## Contract Registry

| Contract id | Type | Status | Owner | Consumers | Purpose |
|---|---|---|---|---|---|
| `cedros-data:product-metafields` | proposed typed integration contract | not published | Unassigned cross-product coordination | Cedros Shop admin, Cedros Pay catalog, storefront projection | Proposed product metafield definitions, validation behavior, and storefront exposure policy. |

The contract is versioned by `schemaVersion`. The current schema version is `1`.
Transport is host-owned: Core may expose the same shapes through admin host
context, a Core route, or another Core-owned service. Consumers must key off the
contract id and `schemaVersion`, not a storage key or private module.

`cedros-data:product-metafields-manage` is reserved documentation text, not an
assigned capability. Hosts and extensions must reject it until a future
version publishes an executable contract and conformance tests.

## Proposal Completion Requirements

Cedros Data currently implements none of the operations below. External
consumer behavior is not release evidence for this repository. Every row needs
an executable host binding, authorization enforcement, and cross-repository
conformance tests before this document may move from coordination-only to
published.

| Item | Core binding required | Capability | Blocking? |
|---|---|---|---:|
| `upsertDefinition` | Create/update one typed definition and storefront policy, returning field-level validation errors. | `cedros-data:product-metafields-manage` | yes |
| `retireDefinition` | Mark one definition `retired` without deleting Pay product values. | `cedros-data:product-metafields-manage` | yes |
| `validateProductMetadata` | Validate Pay-bound product metadata before Shop or Pay publishes values as typed metadata. | admin caller uses `cedros-data:product-metafields-manage`; Pay catalog writes use their Pay catalog permission plus this Core validator | yes |
| `readStorefrontProjection` | Return only validated, storefront-exposed fields for product public rendering. | no admin write capability; public/read transport must still fail closed on malformed input | yes |
| Product metafield management capability | Add and enforce `cedros-data:product-metafields-manage` for authenticated admin writes. | `cedros-data:product-metafields-manage` | yes |

Until all rows are bound in staging, Shop must keep definition mutation controls
disabled. Until `readStorefrontProjection` is bound, Shop and storefront code
must not expose raw Pay metadata.

## Ownership

Core owns:

- the metafield definition registry
- validation rules for typed product metadata values
- storefront exposure policy and projection
- lifecycle rules for deprecating or retiring definitions

Pay owns:

- product identity, title, slug, price, checkout URL, status, and Pay catalog
  values
- bounded product metadata values keyed by Core metafield definition keys
- rejection of oversized or malformed catalog payloads before mutation

Shop owns:

- admin controls that render from the Core definitions
- operator workflows for editing definitions and product values
- fail-closed UI when the Core contract is unavailable

Shop must not persist metafield definitions under `cedros-shop:*` settings.
Pay must not persist metafield definitions inside product records. Unknown Pay
metadata keys remain opaque values until Core publishes matching definitions.

## Definition Registry Shape

Core returns a registry object:

```json
{
  "contractId": "cedros-data:product-metafields",
  "schemaVersion": 1,
  "updatedAt": "2026-06-19T00:00:00Z",
  "definitions": [
    {
      "id": "commerce.product.material",
      "namespace": "commerce.product",
      "key": "material",
      "label": "Material",
      "description": "Primary product material shown in product details.",
      "type": "string",
      "required": false,
      "list": false,
      "validation": {
        "minLength": 1,
        "maxLength": 80
      },
      "storefront": {
        "exposed": true,
        "label": "Material",
        "placement": "details",
        "filterable": false,
        "searchable": true,
        "sortOrder": 20
      },
      "admin": {
        "group": "Details",
        "order": 20,
        "helpText": "Use a customer-readable material name."
      },
      "lifecycle": "active"
    }
  ]
}
```

Definition fields:

| Field | Required | Rules |
|---|---:|---|
| `id` | yes | Stable id, unique per site, formatted as `<namespace>.<key>`. Never reuse for a different meaning. |
| `namespace` | yes | Lowercase dot-delimited domain such as `commerce.product`; no whitespace, slash, or tenant/user data. |
| `key` | yes | Lowercase kebab-case field key, unique inside `namespace`. |
| `label` | yes | Operator-facing label, safe for storefront if reused. |
| `description` | no | Admin help copy only unless storefront policy provides a public label. |
| `type` | yes | One of `string`, `number`, `integer`, `boolean`, `enum`, `date`, `dateTime`, `url`, `mediaRef`, or `json`. |
| `required` | no | Defaults to `false`; applies when saving product metadata values. |
| `list` | no | Defaults to `false`; when `true`, the value is an array of the same type. |
| `validation` | no | Type-specific validation object; absent means the type validator only. |
| `storefront` | yes | Storefront exposure policy. Missing or malformed policy fails closed as not exposed. |
| `admin` | no | Shop admin grouping and order hints. |
| `lifecycle` | yes | `active`, `deprecated`, or `retired`. |

## Validation Rules

Core validates definitions before saving them:

- `namespace` and `key` are immutable after first publish.
- `id`, `namespace`, and `key` cannot contain secrets, user identifiers, buyer
  identifiers, provider identifiers, or path-like values.
- `label`, `description`, and admin help text must be plain text; HTML is not
  accepted.
- string `pattern` validation must be host-approved and bounded; consumers must
  not submit arbitrary regular expressions from untrusted input.
- `type` changes are breaking unless Core can prove every existing Pay metadata
  value still validates under the new type.
- `required: true` cannot be enabled for a definition while published products
  are missing valid values, unless the change is staged as admin-only and not
  storefront-exposed.
- `deprecated` definitions remain readable and editable on existing products but
  should be hidden from new-field pickers.
- `retired` definitions are hidden from new admin entry and never storefront
  exposed; stored Pay values remain preserved until an explicit migration or
  cleanup removes them.

Core validates product metadata values against the active definition registry:

| Type | Accepted value | Validation fields |
|---|---|---|
| `string` | JSON string | `minLength`, `maxLength`, `pattern` |
| `number` | JSON number | `minimum`, `maximum` |
| `integer` | JSON integer | `minimum`, `maximum` |
| `boolean` | JSON boolean | none |
| `enum` | JSON string | `options[]` with stable `value` and public `label` |
| `date` | `YYYY-MM-DD` string | `minimum`, `maximum` as dates |
| `dateTime` | RFC 3339 UTC string | `minimum`, `maximum` as datetimes |
| `url` | HTTPS URL string | `allowedHosts[]` when the field is public |
| `mediaRef` | host media reference id string | `allowedKinds[]` |
| `json` | safe JSON object | Core-approved schema reference only; not storefront-exposed by default |

Validation failure is explicit. The caller receives the definition id, product
id when applicable, field path, stable error code, and non-secret message. Core
must not silently drop invalid values during writes.

## Storefront Exposure Policy

Storefront exposure is opt-in. A field is public only when all of these are true:

- the definition exists and `lifecycle` is `active`
- `storefront.exposed` is `true`
- the value validates against the current definition
- the type is storefront-safe (`json` is not storefront-safe unless Core binds a
  public projection for that definition)
- the value contains no secret, buyer, provider, wallet, token, or private admin
  data

`storefront.filterable` and `storefront.searchable` imply `exposed: true`.
Consumers must treat malformed storefront policy as not exposed.

Storefront placements:

- `summary`: compact product summary
- `details`: product details/specifications
- `badge`: short highlighted value
- `search`: searchable-only projection

Public projections return display-safe fields only:

```json
{
  "schemaVersion": 1,
  "productId": "prod_123",
  "fields": [
    {
      "definitionId": "commerce.product.material",
      "namespace": "commerce.product",
      "key": "material",
      "label": "Material",
      "type": "string",
      "value": "Organic cotton",
      "displayValue": "Organic cotton",
      "placement": "details",
      "filterable": false,
      "searchable": true,
      "sortOrder": 20
    }
  ]
}
```

The public projection must not include validation internals, admin help text,
lifecycle history, private metadata keys, or raw Pay catalog records.

## Logical Operations

Any Core transport that implements this contract must preserve these logical
operations and shapes.

| Operation | Caller | Behavior |
|---|---|---|
| `readDefinitions` | Shop admin, Pay catalog admin | Returns the registry shape above. Missing, malformed, or wrong-version data fails closed. |
| `upsertDefinition` | Shop admin through Core | Creates or updates one definition after Core validation. Immutable-field conflicts return validation errors. |
| `retireDefinition` | Shop admin through Core | Marks a definition `retired`; does not delete Pay product values. |
| `validateProductMetadata` | Shop admin, Pay catalog writes | Validates a product metadata object against Core definitions before Pay stores or publishes values. |
| `readStorefrontProjection` | storefront, Shop public UI, Pay public catalog | Returns only storefront-exposed, validated fields for one product or a bounded product page. |

Write operations require an authenticated admin actor with the host capability
`cedros-data:product-metafields-manage`. System-admin sessions may pass in local
development, but production callers must be explicitly authorized.

Minimum operation envelopes:

```json
{
  "operation": "upsertDefinition",
  "schemaVersion": 1,
  "definition": {},
  "expectedRegistryVersion": "2026-06-19T00:00:00Z"
}
```

```json
{
  "operation": "retireDefinition",
  "schemaVersion": 1,
  "definitionId": "commerce.product.material",
  "expectedRegistryVersion": "2026-06-19T00:00:00Z"
}
```

```json
{
  "operation": "validateProductMetadata",
  "schemaVersion": 1,
  "productId": "prod_123",
  "mode": "draft",
  "metadata": {}
}
```

```json
{
  "operation": "readStorefrontProjection",
  "schemaVersion": 1,
  "productId": "prod_123",
  "metadata": {}
}
```

Successful definition mutations return the updated registry. Validation and
projection calls return either a valid result or explicit field errors; they do
not silently drop invalid values.

## Consumer Rules

Shop:

- renders metafield definition and product-value controls from
  `cedros-data:product-metafields`
- hides the typed metafield admin UX when the Core contract is missing,
  unreadable, malformed, or wrong-version
- may render the registry read-only before write operations are bound
- sends definition and storefront policy writes to Core, not to Shop settings
- sends product metadata value writes to Pay only after Core validation passes
- does not expose raw Pay metadata as storefront fields

Pay:

- continues storing bounded product metadata values in Pay-owned product records
- rejects unknown top-level catalog fields as before
- does not define storefront exposure or typed schema locally
- calls Core validation, or accepts only admin-private opaque metadata until Core
  validation is available

Storefront/public consumers:

- read Core storefront projections or a Pay/Shop payload already projected by
  Core policy
- never expose raw Pay metadata values directly
- fail closed when projection data is missing, malformed, or stale for the
  current product version

## Failure Behavior

- Missing Core contract: Shop hides metafield-definition controls and leaves
  product metadata editing disabled.
- Unknown metadata key: preserve Pay value as opaque/admin-private; do not expose
  publicly.
- Invalid existing value: show an admin repair state; omit from storefront.
- Definition conflict: reject the definition write and report field-level errors.
- Storefront policy conflict: reject filter/search flags unless `exposed` is
  true and the field type is public-safe.

This keeps the catalog source of truth split cleanly: Core owns typed schema and
public policy, Pay owns catalog values and checkout, and Shop owns the admin UX
that lets operators work with both.

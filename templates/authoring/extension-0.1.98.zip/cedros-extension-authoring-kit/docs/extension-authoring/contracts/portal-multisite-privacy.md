# Portal multi-site privacy

`POST /portal/v1/sites/{siteId}/multisite` accepts only the boolean
`multiSiteEnabled`, the dedicated owner-facade credential, trusted actor/org/site
headers, and one existing bounded `Idempotency-Key`. Current owner/admin authority
is required on mutations and replays. Cookie authentication, `manage-site`, route
ID `cedros-portal:site-multisite-update`, and exact same-origin protection belong
to the Portal gateway. Core does not authenticate this endpoint with cookies.

The effective default is true. Preferences live on the existing Deploy/Fleet
registry; reconciliation retains them. The newest registry revision wins when a
runtime is linked to a deployment. Every new mutation has a distinct revision,
including repeated values, so off/on cannot revive a cursor or an older receipt.
Completed retry identities are retained indefinitely, without dashboard content.

Core commits the choice, retry receipt, and deletion of the organization's Core
multisite snapshots in one transaction. It filters disabled sites before source
reads, checks revisions before each source call and response, and fences snapshot
writes with the same database lock as mutations. Direct transcript/conversation
cursors also bind the policy revision. Site management remains available.

## Source-site Controls acknowledgment

Deploy the source-site Core/Controls adapters and migration before the owner
facade. Core sends `POST /managed-services/controls/v1/multisite-policy` over the
existing site-scoped signed Controls transport. Its signed JSON body is:

```json
{"contractVersion":2,"siteId":"runtime-id","orgId":"organization-id","multiSiteEnabled":false,"revision":1}
```

The source-site Core adapter verifies the existing site credential/signature and
exact site/org scope. It durably applies only monotonic revisions, rejects older or conflicting
revisions, and atomically removes local multisite snapshots. Snapshot writers
check this replica under the same lock, preventing late repopulation. HTTP 200
must echo the exact body after commit. Identical retries are safe. Core returns
success only after all current runtimes acknowledge and the choice is still
current. A disable remains durable in Core if a runtime is unavailable or older,
but the endpoint returns an error; retry with the same key. Enabled source reads
propagate the current revision first, including newly reconciled runtimes.

Source policy version 2 is required for the expanded Controls cleanup. The old
version 1 source adapter is insufficient and must fail confirmation during
rollout. This does not change Portal's response version or other source APIs.

Only dashboard snapshots/projections are deleted, conservatively across the
organization. Original mail, form submissions, orders, support messages and
assistant conversations remain at their sources. Pending Portal assistant turns
are marked failed under the source policy lock; late replies cannot publish or
restart after re-enable. Previously completed replies are retained. Already
delivered responses cannot be recalled. Delayed Portal assistant turns consult the existing signed
live authorization callback, which now includes the preference.

## Central Controls Bridge: required participant

`multiSiteEnabled` covers both Portal's direct source reads and central Controls.
Core's central sender uses the existing encrypted `cedros-controls:bridge-token`
and invokes `POST /extensions/cedros-controls/bridge/v1/multisite-policy` with:

```json
{"contractVersion":1,"siteId":"runtime-id","orgId":"organization-id","multiSiteEnabled":false,"revision":1}
```

HTTP 200 must echo exactly this object. Core requires both the central and source
acknowledgments before confirming the owner mutation. A central failure still
allows source disable delivery to be attempted; the preference remains durable.
Retry the original choice/key/revision after any unconfirmed response. This Core
change does not implement the extension receiver: an absent, old, or malformed
receiver fails closed, including before central publication.

Central revisions are non-negative JSON-safe integers (maximum 9007199254740991).
**Revision zero explicitly initializes an untouched default-on site.** This
corrects the earlier proposal's positive-only central revision rule. Subsequent
owner mutations use the shared positive sequence. Source signed POST mutations
remain positive-only; the source publisher can initialize zero from the trusted
central policy read. Missing policy is not implicit central initialization.

Identity comes from the existing registry. The Bridge `siteId` is authenticated
`fleet_sites.site_id`; `orgId` is its Fleet organization. Portal's route ID may be
a linked Deploy ID, resolved through `fleet_sites.deploy_extension_site_id` within
the same organization. Core enumerates each matching runtime and never substitutes
a Portal alias for a Bridge ID. Existing Bridge organization bindings must agree.

### Producer and command envelopes

Core's managed snapshot/event endpoints now require `orgId` and
`privacyPolicyRevision` alongside the existing fields and forward them unchanged
to the Bridge. Old envelopes are rejected. A source reads
`GET /managed-services/controls/v1/multisite-policy` using its existing managed
bearer and `x-cedros-site-id`; Core resolves its identity and returns the exact
policy object only after central acknowledgment. Collection starts afterward.
Fleet registration, heartbeat, billing and original site services remain separate.

The central receiver must stamp `orgId` and `privacyPolicyRevision` at command
creation and preserve them in command list/claim objects. Core returns both fields
at the top level of the managed command list as well. Managed claim requests add
both fields to `workerId`/`leaseSeconds`; the central claim request also includes
Core's authenticated `siteId`. Results add `orgId`/`privacyPolicyRevision` to the
existing result object. Core checks results against its persisted claim epoch,
including completed-result retries; it never accepts the caller's epoch as proof
of command identity. Existing command IDs, source versions, leases, and result
fingerprints retain their independent roles.

Core holds its organization policy lock through central ingestion/claim/result
publication and local snapshot/claim persistence. Mutations clear its stored
Bridge snapshots and claims. Revocation replay retains the snapshot's original
privacy epoch. Controls email/workspace facades reject disabled sites before IO;
email pagination and mutation retry identities also bind the policy epoch.

Source publishers hold the corresponding local fence through collection and
submission. Core bounds concurrent connection-holding fences below the configured
pool capacity, reserving connections for nested work (minimum pool size two). Email outbox entries record their creation epoch using a database
trigger; unknown/disabled policy suppresses only this dashboard outbox, not email
operation. Policy application deletes old outbox/delivery rows and Controls-only
site-agent projections/receipts. Disable and epoch changes reuse durable assistant cancellation for
Controls-originated runs, including lease revocation and visible settlement.
This also covers a source that misses Off and next receives a newer On policy.
Source policy, cleanup readiness, deletion, and cancellation commit together; a
failed transaction cannot mark cleanup complete.
Original conversations and completed source replies remain. Analytics cache
entries are keyed by epoch, so old results cannot be reused after Off → On.

### Controls receiver obligations and rollout

The central extension owns durable policy, all actors' mirror cleanup, command
terminalization, provider/intelligence boundaries, and notification publication.
Its acknowledgment must follow completed cleanup; partial batches must retain
progress and return failure. Same revision/value retries resume cleanup; older
or conflicting revisions fail. Ingestion, command execution, lease requeue,
result projection repair, direct data surfaces, and emitted events must all check
initialized, enabled, matching policy at their persistence/publication boundary.
Do not relabel old work with a new epoch after re-enable, or retroactively stamp
legacy unversioned commands with revision zero. Clear or deny access to
content-bearing checkpoints, caches, and command results; retain only necessary
content-free fencing/replay metadata. Already delivered data cannot be recalled.

Deploy compatible receivers and Core/source migrations with central ingestion
held closed; initialize every mirrored site's explicit current policy before
serving existing mirrors or enabling producers. The GET bootstrap initializes
active producers; offline or legacy mirrored sites also require initialization
through the trusted registry. Keep unknown-policy mirrors denied. Do not enable
old unversioned producers as a fallback. Joint acceptance with the real Controls
extension is required before treating the feature as complete in deployment.

### Host publication contract

The Controls receiver requires `cedros-data:controls-publication-v1` and imports
`cedros:extension/controls-privacy` (`bind` and `drain`). `bind` verifies an exact
`siteId`, `orgId`, and `privacyPolicyRevision` against the durable initialized
central policy, acquires a PostgreSQL shared transaction lock, and persists a
durable publication record with a host-generated invocation ID before dispatch.
The host owns that record through provider/telemetry calls and the complete HTTP body
lifetime, including disconnects. It rechecks before provider dispatch, provider
completion, and the first response frame. Bytes already handed to a transport
cannot be recalled.

After persisting denial, the receiver calls `drain` with the exact policy object.
The host obtains the exclusive site lock or returns a retryable failure. It
cancels and redacts the existing Controls notification queue in bounded batches
and retains content-free replay identities. It refuses acknowledgment while any
durable publication record remains, even if the original database lock vanished.
Only completion of the actual host invocation and response lifetime authorizes
removing its records, matched by the host-generated `hostInvocationId`; the host
also stamps this identity onto guest publication permits. Completion cleanup
retries storage failures, leaving disable unconfirmed until persistence succeeds.
Pending completion retains its admission slot, bounding retry tasks during an outage.
The exclusive lock spans the receiver's final ready CAS and response. A whole-host
crash before completion is persisted, or a legacy ownerless permit, requires explicit
reconciliation with the retired host; neither elapsed time nor absence of a
database lock authorizes deletion.

Notification dispatch uses host-validated scope metadata. Workers reacquire the
same shared locks using the creation epoch through delivery and settlement;
unknown/obsolete epochs are terminalized, while transient capacity/storage
failures stay retryable. Personal routes preserve their existing in-app behavior;
team routes resume through the existing configured channels. Guest metadata
cannot replace the host's scopes. Other extensions and original source services
retain their behavior.

Deploy host and worker support (including the concurrent notification cleanup
index) before enabling the rebuilt Controls component. Retire/drain older host
instances and their queues before claiming the new publication guarantee; the
required capability and WIT import reject incompatible hosts. Nested Core-to-Controls
publication requires at least four database pool connections under the existing
privacy admission budget; this change does not increase configured pool or
concurrency limits. Exhausted admission returns a retryable failure rather than
waiting while holding a caller's fence. Existing ownerless
permits require explicit reconciliation against those retired instances, never
wall-clock expiry. The existing Controls reconciliation worker now visits the
trusted Fleet registry in bounded batches, including offline sites without
Bridge state. Failed policies retry on subsequent passes and remain denied.

## Local acceptance

Run `multisite_`, `central_privacy`, and `controls_portal` Rust tests with
`CEDROS_DATA_TEST_POSTGRES_URI` pointing at disposable PostgreSQL with the pinned
pgvector extension. Set a disposable `CEDROS_EXTENSION_SECRETS_PASSPHRASE` for
the central host-binding fixture. Compile/test with `--features wasm-extensions`
to include the central managed router and source command worker. The privacy test
mounts separate Core/source databases and
real signed TLS acknowledgments, checks all seventeen operations, stale cursors,
concurrent/revoked retries, slow reads, source failures, and pending turns.

To include the matching Portal production-script fixture, link that checkout at
`.context/portal-privacy-workspace` before running `multisite_`. The test invokes
`server/tests/fixtures/portal-multisite/privacy-boundary.mjs` against its mounted
Core HTTP server. Portal's normal site toggle and refresh execute real preference
writes; account scaffolding remains the Portal fixture's test data. This does not
replace the installed-Wasm gateway or deployed rollout acceptance.
The central test receiver is a host-bound contract double using real encrypted
secret storage. It does not prove the Controls extension's mirror deletion,
provider cancellation, notification fencing, or installed-Wasm behavior.

The actual Controls component acceptance is
`controls_publication::tests::installed_controls_publication_barriers_cleanup_and_recovery`.
It is opt-in: supply `CEDROS_CONTROLS_COMPONENT_PATH`,
`CEDROS_CONTROLS_MANIFEST_PATH`, the disposable PostgreSQL URI and secret
passphrase above, and run the `controls_publication` test filter with
`--include-ignored --test-threads=1`. It uses real host seams, encrypted token
storage, registered collections, CAS grants and PostgreSQL locks. The same filter
includes the offline registry bootstrap regression. This local evidence does not
substitute for the target deployment's migration and cutover checks.

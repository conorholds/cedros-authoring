# Shop Customer Account CRM Contract

> Status: coordination-only proposal. Cedros Data exposes neither this contract
> id nor the route/adapter operations below. The Shop implementation is an
> external prerequisite and no integrated launch claim is valid.

Use this with
[`../18-official-extension-integrations.md`](../18-official-extension-integrations.md)
when Cedros Shop renders customer account UX backed by Host/CRM-owned customer
data.

This is a Host/CRM-owned adapter contract for Shop account pages. Shop owns the
customer-facing page, forms, and platform-specific templates only. Host/CRM
remains the source of truth for route mounting, address book data, CRM-owned
account fields, support links, and any saved checkout defaults CRM owns.

## Contract Registry

| Contract id | Type | Status | Owner | Consumer | Purpose |
|---|---|---|---|---|---|
| `cedros-data:shop-customer-account-crm` | proposed host adapter contract | not published | Unassigned cross-product coordination | Cedros Shop `CommerceAdapter` | Proposed account, address, support-link, and saved-checkout data seam. |

Cedros Data carries no executable conformance evidence for an external Shop
consumer. Integrated launch is unsupported until Host/CRM mounts the
account route/page, binds the adapter methods below, and both repositories run
the same versioned contract fixtures.

## Route And Page Mount

Host must mount the Shop account page from these Shop-published metadata ids:

| Item | Value |
|---|---|
| Page seed | `cedros-shop:account-page` |
| Default route | `/account` |
| Template | `cedros-shop:account-page-template` |
| Block | `cedros-shop:account-surface` |
| React runtime component | `AccountTemplate` |
| React Native runtime component | `AccountTemplate` |
| Route override key | `cedros-shop:account-page` |
| i18n route key | `account` |

The page seed must remain the stable route ownership key. Operator route
overrides attach to `cedros-shop:account-page`; localized route labels resolve
through i18n key `account`. Host route mounting must fail closed if the Shop
extension is not installed, the page seed is missing, or the runtime component
cannot be resolved.

## Required Adapter Methods

| Method | Required when | Owner | Behavior |
|---|---|---|---|
| `getCustomerAccount()` | always | Host/CRM | Returns the current authenticated customer's CRM-owned account projection, including `addresses[]`, `supportLinks[]`, and saved checkout data when CRM owns it. |
| `updateCustomerProfile(payload)` | CRM owns editable profile fields | Host/CRM | Updates only fields explicitly owned by CRM for the authenticated customer. Omit the method when no CRM-owned profile fields are editable through Shop. |
| `upsertCustomerAddress(payload)` | address book is in scope | Host/CRM | Creates or updates one address for the authenticated customer's CRM profile. |
| `deleteCustomerAddress({ addressId })` | address book is in scope | Host/CRM | Deletes or disables one address owned by the authenticated customer's CRM profile. |
| `getSavedCheckoutData()` | CRM owns saved checkout defaults | Host/CRM | Returns saved checkout defaults. Omit the method when CRM does not own saved checkout defaults. |
| `updateSavedCheckoutData(payload)` | CRM owns saved checkout defaults | Host/CRM | Updates saved checkout defaults for the authenticated customer. Omit the method when CRM does not own saved checkout defaults. |

Every mutation is scoped to the authenticated customer's own CRM profile. Public
customer account calls do not grant admin CRM read/write permissions and must
not accept arbitrary CRM profile ids.

## Data Shape

`getCustomerAccount()` returns this projection. Optional sections are omitted
only when the owning host service is not bound.

```json
{
  "profile": {
    "id": "crm_profile_123",
    "email": "customer@example.com",
    "name": "Customer Name",
    "phone": "+14155550100",
    "avatarUrl": "https://example.com/avatar.png",
    "marketingOptIn": true
  },
  "addresses": [
    {
      "id": "addr_123",
      "label": "Home",
      "line1": "123 Market St",
      "line2": "Apt 4",
      "city": "San Francisco",
      "state": "CA",
      "postalCode": "94105",
      "country": "US",
      "defaultShipping": true,
      "defaultBilling": true
    }
  ],
  "savedCheckout": {
    "email": "customer@example.com",
    "name": "Customer Name",
    "phone": "+14155550100",
    "shippingAddress": "addr_123",
    "billingAddress": "addr_123",
    "billingSameAsShipping": true,
    "preferredPaymentMethodId": "pm_default",
    "preferredShippingMethodId": "ship_standard"
  },
  "supportLinks": [
    {
      "id": "returns",
      "label": "Returns",
      "href": "/support/returns",
      "description": "Start a return or review the return policy."
    }
  ]
}
```

Profile fields:

| Field | Required | Rules |
|---|---:|---|
| `id` | yes | CRM-owned customer/profile id scoped to the authenticated user. |
| `email` | no | Customer-visible email. Cedros Login remains identity source if it owns email. |
| `name` | no | Customer-visible display name. |
| `phone` | no | Customer-visible phone number. |
| `avatarUrl` | no | Host-approved HTTPS URL or omitted. |
| `marketingOptIn` | no | Boolean preference only when CRM owns this field. |

Address fields:

| Field | Required | Rules |
|---|---:|---|
| `id` | yes | Stable CRM-owned address id. Required for updates/deletes. |
| `label` | no | Plain text display label. |
| `line1` | yes | Plain text street line. |
| `line2` | no | Plain text secondary street line. |
| `city` | yes | Plain text locality. |
| `state` | no | Plain text region/state/province. |
| `postalCode` | no | Plain text postal code. |
| `country` | yes | ISO 3166-1 alpha-2 country code. |
| `defaultShipping` | yes | Boolean; Host ensures only one default shipping address. |
| `defaultBilling` | yes | Boolean; Host ensures only one default billing address. |

Saved checkout fields:

| Field | Required | Rules |
|---|---:|---|
| `email` | no | Customer-visible checkout email. Login remains identity source if it owns email. |
| `name` | no | Customer-visible checkout name. |
| `phone` | no | Customer-visible checkout phone. |
| `shippingAddress` | no | Address id from `addresses[]`. |
| `billingAddress` | no | Address id from `addresses[]`. |
| `billingSameAsShipping` | yes | Boolean default; when true, billing uses `shippingAddress`. |
| `preferredPaymentMethodId` | no | Public-safe payment method preference id, not provider secret material. |
| `preferredShippingMethodId` | no | Public-safe shipping method preference id. |

Support links are read-only. `href` must be an internal path or a host-approved
HTTPS URL. Links must not contain access tokens, private ticket ids, or raw
customer identifiers.

## Ownership Boundary

Shop:

- renders the customer-facing account page, forms, and native/web templates
- calls adapter methods when present
- disables each mutation button unless the matching adapter method exists
- stores no durable CRM data

Host/CRM:

- owns route mounting for `cedros-shop:account-page`
- owns address book persistence and lifecycle
- owns CRM support-link projection
- owns any CRM-editable account fields
- owns saved checkout defaults when those defaults are CRM fields
- validates customer ownership for every read and mutation
- records audit/source metadata without exposing internal CRM records to Shop

Cedros Login:

- remains the source of truth for authenticated identity
- owns saved checkout defaults only if the host explicitly places them in Login;
  in that case CRM omits the saved-checkout adapter methods and Shop must consume
  a separate Login-owned contract

## Failure Behavior

- Missing `getCustomerAccount`: Shop renders account shell without CRM-backed
  data and disables CRM-backed account sections.
- Missing mutation method: Shop disables the matching mutation button.
- Missing saved-checkout methods: Shop hides or disables saved-checkout defaults
  unless Login supplies them through a separate published contract.
- Missing page seed/runtime component: Host does not mount `/account`.
- Unauthorized or unlinked customer: Host fails closed and returns no CRM data.
- Address id not owned by the authenticated customer: Host rejects the mutation.
- Malformed support link: Host omits the link from the projection.

This keeps the account UX split cleanly: Shop owns presentation and interaction,
Host CRM owns customer data, and Login owns authentication.

# Cedros Controls Email Router Contract

> Status: published by Cedros Data/Core. Runtime activation remains fail-closed
> behind Controls' default-off `emailInboxEnabled` gate until the staging
> evidence in this document has been retained.

This contract preserves site-owned email storage. Cedros Data's control plane
authenticates one current Cedros Login actor, resolves that actor's current
customer organization and sites, calls each site's canonical inbox services,
and merges only the response in memory. Email bodies and attachment bytes are
not stored by the control plane.

## Capabilities and binding

The published host capability ids are:

| Capability | Purpose |
|---|---|
| `cedros-data:controls-email-read-v1` | Mailboxes, messages, conversations, folder counts, scheduled sends, and bounded attachment reads. |
| `cedros-data:controls-email-write-v1` | Source-confirmed sends and message/scheduled-send mutations. |
| `cedros-data:controls-email-events-v1` | Versioned, normalized email event intake. |
| `cedros-data:controls-email-summaries-v1` | Actor-specific privacy-safe site summaries. |

Controls receives its control-plane credential through the encrypted extension
secret binding `cedros-controls:email-router.bearer-token`. The host derives this
purpose-scoped credential from its Portal-owner key; Controls never receives the
unrestricted Portal credential. It authenticates only `/portal/v1/controls/*`
bindings, which still enforce current membership and resource ownership. It is
never a client-visible setting. It remains a trusted first-party identity
delegate within those bindings: Controls must authenticate its browser caller
with Login before asserting a subject. A service credential alone proves no
customer identity. After upgrading hosts that previously seeded the unrestricted
key, rotate the Portal-owner key to revoke retained copies; require compatible
hosts during the rollout.
Every request to the host binding uses:

- `Authorization: Bearer <bound secret>`
- `x-cedros-user-id: <verified Cedros Login subject>`
- `x-cedros-org-id: <currently selected organization>`
- `Idempotency-Key: <stable key>` on every mutation

The host re-reads the Login membership for every request. It does not accept a
control-plane organization as a customer scope. Revocation therefore denies
the next request and removes the actor's Controls projection through the
existing Controls revocation reconciler.

Controls declares the following guest routes and binds them one-for-one to the
host paths below. These are route names, not operation names that consumers may
rename or infer.

| Controls route | Cedros Data host binding |
|---|---|
| `GET /v1/email/mailboxes` | `GET /portal/v1/controls/email/mailboxes` |
| `GET /v1/email/messages` | `GET /portal/v1/controls/email/messages` |
| `GET /v1/email/messages/{siteId}/{messageId}` | same suffix under `/portal/v1/controls/email` |
| `GET /v1/email/messages/{siteId}/{messageId}/conversation` | same suffix under `/portal/v1/controls/email` |
| `GET /v1/email/folder-counts` | `GET /portal/v1/controls/email/folder-counts` |
| `GET /v1/email/scheduled-sends` | `GET /portal/v1/controls/email/scheduled-sends` |
| `GET /v1/email/messages/{siteId}/{messageId}/attachments/{attachmentId}` | same suffix under `/portal/v1/controls/email` |

## Read schemas

All identifiers are opaque strings. Every mailbox, message, conversation
message, scheduled send, and attachment descriptor includes `siteId`.
Provider metadata, raw headers, provider payloads, and attachment bytes are
removed at the site boundary. Message and attachment identifiers exposed by
the contract remain opaque to Controls and must never be interpreted as
provider credentials.

Collection responses use this common partial-failure envelope:

```json
{
  "messages": [],
  "partial": true,
  "siteFailures": [{"siteId": "site-a", "code": "timeout"}],
  "nextCursor": "opaque-when-present"
}
```

The collection member is respectively `mailboxes`, `messages`, or
`scheduledSends`. Failure codes are `timeout`, `unavailable`,
`invalid_response`, `source_unauthorized`, `source_forbidden`, `not_found`, or
`source_error`. Healthy sites remain in the response when another site fails.

The v1 member schemas are fixed as follows. Nullable fields remain present as
JSON `null` unless stated otherwise:

- A mailbox contains `siteId`, `id`, `kind`, `address`, `displayName`, `source`,
  `status`, `canRead`, `canSend`, and `isDefault`.
- A message contains `siteId`, `id`, `conversationKey`, `messageIdHeader`,
  `threadId`, `inReplyTo`, `referencesHeader`, `fromName`, `fromEmail`,
  `toEmail`, `ccEmails`, `bccEmails`, `subject`, `preview`, `bodyText`,
  `bodyHtml`, `attachments`, `labels`, `starred`, `unread`, `viewerHasRead`,
  `readBy`, `claimedByUserId`, `claimedByUserLabel`, `claimedAt`, `receivedAt`,
  `repliedAt`, `forwardedAt`, `sourceMessageId`, `sourceAction`, `crmProfileId`,
  `mailboxId`, `mailboxAddress`, `mailboxKind`, and `mailboxDisplayName`.
- Every attachment descriptor is reconstructed at the source and contains
  exactly `siteId`, a derived opaque `id`, sanitized `name`, safe
  `contentType`, and non-negative JSON-safe `size`. Stored attachment URLs,
  provider ids, unknown metadata, and bytes are discarded.
- A scheduled send contains `siteId`, `id`, `sendAt`, `requestPayload`,
  `status`, `attemptCount`, `claimedAt`, `heartbeatAt`, `sentAt`,
  `cancelledAt`, `finishedAt`, and `createdAt`.
  `requestPayload` contains only `toEmails`, `ccEmails`, `bccEmails`,
  `subject`, `body`, `mailboxId`, and projected `attachments`.

An exact message read returns `{ "message": <message> }`; a conversation
returns `{ "messages": [<message>] }`. Successful send/reply/forward results
contain only `siteId`, `status`, `sentAt`, `inboxMessageId`, `mailboxId`,
`mailboxAddress`, `mailboxDisplayName`, and `mailboxKind`. Message mutations
return the projected message directly; deletes return `siteId`, `messageId`,
and `status`.

`GET /messages` accepts `folder`, `query`, `mailboxId`, `siteId`, `limit`
(`1..200`), and `cursor`. Messages sort by `receivedAt` descending, then
`siteId` and `id`. `nextCursor` is opaque to Controls. Its v1 payload is
base64url-without-padding JSON containing the actor id and a map of per-site
`beforeReceivedAt`/`beforeId` positions. Cedros Data rejects a cursor copied to
another actor, a different version, an invalid UUID/timestamp, or more than 200
sites.

`GET /folder-counts` accepts `mailboxId` and `siteId` and returns:

```json
{
  "counts": {"inbox": 3, "sent": 2, "archive": 0, "junk": 0, "trash": 0, "all": 5},
  "sites": [{"siteId": "site-a", "inbox": 3, "sent": 2, "archive": 0, "junk": 0, "trash": 0, "all": 5}],
  "partial": false,
  "siteFailures": []
}
```

Counts are clamped to non-negative JSON-safe integers. An attachment read
returns binary bytes with a source-confirmed content type, a sanitized download
filename, and `Cache-Control: private, no-store`. The source re-reads the exact
message with the exact actor before locating the attachment. A decoded
attachment may not exceed 25 MiB; the source and router response caps are 32
MiB and 64 MiB respectively.

## Mutations

These additional host bindings are published:

| Method and host path | Operation |
|---|---|
| `POST /portal/v1/controls/email/messages/send` | Send one new message. |
| `POST /portal/v1/controls/email/scheduled-sends` | Create one scheduled send. |
| `DELETE /portal/v1/controls/email/scheduled-sends/{siteId}/{scheduledId}` | Cancel the actor's scheduled send. |
| `POST /portal/v1/controls/email/messages/{siteId}/{messageId}/reply` | Reply. |
| `POST /portal/v1/controls/email/messages/{siteId}/{messageId}/reply-all` | Reply all, excluding the actor's visible mailboxes. |
| `POST /portal/v1/controls/email/messages/{siteId}/{messageId}/forward` | Forward. |
| `POST` / `DELETE .../{messageId}/read` | Read / unread. |
| `POST` / `DELETE .../{messageId}/claim` | Claim / release. |
| `PATCH .../{messageId}` | Star/unstar and archive/trash/label state using the canonical inbox patch. |
| `DELETE .../{messageId}` | Permanently delete an authorized source message. |

New-send input is:

```json
{
  "siteId": "site-a",
  "mailboxId": "8f47f53a-faf9-4de1-9c68-807aab77e058",
  "toEmails": ["recipient@example.test"],
  "ccEmails": [],
  "bccEmails": [],
  "subject": "Subject",
  "body": "Plain-text body",
  "attachments": [{"name": "brief.pdf", "contentType": "application/pdf", "base64Content": "..."}]
}
```

A scheduled send adds `sendAt` and nests that compose object under `request`.
Reply/reply-all/forward accept `body`, optional `subject`, optional forwarding
recipient arrays, and attachments. Controls cannot supply sender identity,
provider, region, transport configuration, threading headers, compliance
profile, or provider ids. The source derives and reauthorizes those values.

The host copies the required `Idempotency-Key` header into the signed source
body. Before the first canonical send or provider call, the source claims a
durable row keyed by `(siteId, actorId, idempotencyKey)` and binds it to the
operation, target, and request fingerprint. An identical completed retry
replays the stored response; a changed request conflicts. The canonical
outbound ledger provides the second provider-submission guard. A successful
send status means a sent/outbox record is durable and the provider accepted or
queued the request. It never means delivered.

## Service assertion

Control-plane-to-site calls use a 90-second v1 HMAC-SHA256 assertion keyed by
the site's derived Managed API registration token. Required headers are:

```text
x-cedros-email-actor-id
x-cedros-email-site-id
x-cedros-email-issued-at
x-cedros-email-request-id
x-cedros-email-service-assertion: v1.<lowercase hex HMAC>
```

The request id is a UUID. Duplicate assertion headers are rejected. The HMAC
input is the UTF-8 byte sequence:

```text
cedros-controls-email-v1
UPPERCASE_METHOD
PATH_AND_QUERY
SITE_ID
ACTOR_ID
UNIX_SECONDS
REQUEST_UUID
LOWERCASE_HEX_SHA256_OF_EXACT_BODY
```

The site id must equal the id embedded in the site's Managed API credential.
The source constructs a non-admin mailbox actor from the asserted Login actor;
it never grants the site-admin mailbox bypass.

## Site summary

Each `emailSummary` in `GET /portal/v1/controls/sites` is computed live for the
one authenticated actor and contains exactly:

```json
{
  "emailStatus": "active",
  "emailUnreadCount": 3,
  "emailMailboxCount": 1,
  "emailSummaryUpdatedAt": "2026-08-13T12:34:56Z",
  "emailInboxDeepLink": "https://site.example/admin/email/inbox"
}
```

The link is credential-free HTTPS with no query or fragment (or `null` when a
safe link cannot be derived). Summary failures return `unavailable` and zero
counts. No summary is persisted or reused for another actor.

## Events

Sites submit authenticated events through the existing site-scoped
`POST /managed-services/controls/v1/events` bridge. Email events must target
exactly one currently authorized actor. Published event ids are:

- `email.mailbox.provisioned.v1`, `email.mailbox.updated.v1`, `email.mailbox.revoked.v1`
- `email.message.received.v1`, `email.message.queued.v1`, `email.message.sent.v1`, `email.message.updated.v1`
- `email.message.delivered.v1`, `email.message.bounced.v1`, `email.message.complained.v1`, `email.message.rejected.v1`, `email.message.failed.v1`
- `email.scheduled_send.created.v1`, `email.scheduled_send.updated.v1`, `email.scheduled_send.cancelled.v1`

The event object has exactly six fields:

```json
{
  "schemaVersion": 1,
  "sourceEventId": "stable-source-event-id",
  "resourceId": "opaque-source-resource-id",
  "occurredAt": "2026-08-13T12:34:56Z",
  "revision": 7,
  "state": "delivered"
}
```

`sourceEventId` is the retry identity. `revision` is a non-negative JSON-safe
integer used to ignore reordered older state. Except for the two `updated`
events, `state` must match the terminal event-id component. Unknown fields are
rejected, which prevents addresses, subject/body content, attachment data,
provider ids, credentials, and raw provider payloads from crossing this event
boundary. Queued, sent, delivered, bounced, complained, rejected, and failed
remain distinct states.

## Activation evidence

`emailInboxEnabled` remains off until staging retains evidence for the two-actor
isolation and immediate-revocation cases; one-time inbound and exactly-once send
retry cases; distinct delivery outcomes; partial site outages; and inspection
of Controls snapshots, logs, analytics, audits, and lock-screen notifications
for absence of content and provider secrets. A contract unit test or a local
mock is not a substitute for this retained staging evidence.

The deterministic cross-repository fixture is
[`controls-email-router-v1.json`](controls-email-router-v1.json).
It fixes the two-actor mailbox/message isolation, partial-site response,
privacy-summary key set, retry cardinality, revocation, and distinct outcome
states that a staging evidence run must realize. It contains no email body,
provider payload, credential, or attachment bytes.

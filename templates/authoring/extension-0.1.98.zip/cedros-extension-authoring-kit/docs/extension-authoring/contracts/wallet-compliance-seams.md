# Cedros Wallet And Compliance Official Seams

Use this with
[`../18-official-extension-integrations.md`](../18-official-extension-integrations.md)
and
[`wallet-compliance-artifacts.md`](wallet-compliance-artifacts.md)
when an extension or theme consumes Cedros Wallet or Cedros Compliance. These
contracts are official extension seams, not private host internals. Consumers
must depend on published contract ids, route contracts, documented host helpers, or
explicit host handoff rows.

## Cedros Wallet

Cedros Wallet owns wallet enrollment, wallet material status, authenticated
unlock/signing flows, managed wallet tags, recovery lifecycle, and Wallet-owned
chain submission.

Current family:

| Field | Value |
|---|---|
| Extension id | `cedros-wallet` |
| Version | `1.0.0` |
| Min Cedros Data | `0.1.9` |
| Server package | `cedros-wallet-server@1.0.0` |
| React package | `@cedros/wallet-react@1.0.0` |
| Native package | `@cedros/wallet-react-native@1.0.0` |
| Server entrypoint | `cedros_wallet_server::register_extension_family` |
| Admin entrypoint | `@cedros/wallet-react/admin/register` |
| Web entrypoint | `@cedros/wallet-react/web/register` |
| Native entrypoint | `@cedros/wallet-react-native/register` |

### Wallet Contract Registry

| Contract id | Type | Status | Min version | Purpose |
|---|---|---|---|---|
| `cedros-wallet:account-read-transaction-sign` | typed integration contract | published | `0.0.2` | Account lookup, explicit approval, signing, and Wallet-owned transaction submission. Its `transfer` approval action is the player-signed deposit contract when the destination comes from Cedros Data's published operational-wallet read seam. |
| `cedros-wallet:wallet-lock` | AI action capability | published | `0.0.2` | Invalidates the current authenticated wallet unlock session. |
| `cedros-wallet:browser-signer-v1` | admin host service | host-coordinated | next | Connects an independent Solana browser wallet and signs a proof message for optional treasury hardening. |

Other Wallet HTTP route ids are route contracts, not cross-extension typed
contracts.

### Site treasury browser-signer handoff

Cedros Data consumes host service id `cedros-wallet-browser-signer`, version
`1`. It owns injected-provider access; Cedros Data must never read
`window.solana` or provider-specific globals. Cedros Data uses `connect`,
`signMessage`, and `replaceSquadsV4Member`, binding
cluster, address, purpose, threshold, members, vault index, durable operation,
and idempotency key. Member replacement receives a narrow callback that asks
Cedros Data/Vault to policy-sign only the bound Squads transaction; it never
receives a key. Every connection, signature, vote, and transaction requires
explicit wallet approval. Only public addresses and confirmed transaction
signatures are returned. `createSquadsV4Treasury` remains in version 1 only for
backward compatibility with older hosts; the core bootstrap flow does not call
it.

Cedros Data bootstraps the initial treasury as 1-of-1 with the Vault-managed
operational public key after the operator funds that address. The browser
signer service is optional until hardening: Phantom, Solflare, or another
host-approved wallet proves a distinct independent member, and Data atomically
adds it while changing the threshold to 2-of-2. Operational-key rotation is
blocked while the treasury remains 1-of-1.

The typed Tokenization contract is version `1.0.0`:

| Field | Value |
|---|---|
| Request type | `CedrosWalletAccountReadTransactionSignRequest` |
| Response type | `CedrosWalletAccountReadTransactionSignResponse` |
| Provider modes | `cedros-embedded-wallet`, `solana-browser-wallet` |
| Browser provider names | `Phantom`, `Solflare`, `Host-approved Solana wallet` |
| Approval-required actions | `mint`, `burn`, `transfer`, `redemption-settlement` |
| Submission owner | `cedros-wallet` |
| Pay fulfillment submission | `false` |

Failure codes:

- `wallet_unavailable`
- `browser_wallet_disconnected`
- `user_rejected_connection`
- `user_rejected_signature`
- `unsupported_cluster`
- `expired_intent`
- `provider_submission_failure`

### Wallet Dependencies And Grants

Required official dependency:

- Cedros Login `>=0.0.55`
- `cedros-login:user-context`
- `cedros-login:session-manage`
- `cedros-login:admin-auth`

Wallet declares no Cedros Pay dependency or `providerAccess[]` grant in version
`1.0.0`. Its records use `cedros-wallet:wallet-db` plus the host-mediated
`cedros-data:extension-storage-cas-v1` capability; neither is a public storage
provider credential.

Wallet-owned access:

| Access | Purpose |
|---|---|
| `cedros-wallet:wallet-db` | Read/count/write/delete Wallet-owned records. |
| `cedros-wallet:customer-tags` | Read, assign, and unassign managed wallet tags. |
| `cedros-wallet:site-brain-records` | Write redacted `site-brain-record:wallet`, `site-brain-record:recovery`, and `site-brain-record:security`. |

Tokenization requires these host capabilities:

- `cedros-login:user-context`
- `cedros-login:session-manage`
- `cedros-wallet:wallet-status`
- `cedros-wallet:wallet-material`
- `cedros-wallet:wallet-sign`
- `cedros-wallet:user-visible-transaction-approval`
- `cedros-wallet:wallet-owned-chain-submission`

### Wallet Routes

Routes are mounted under `/extensions/cedros-wallet` and return redacted JSON
errors as `{ code, message, details? }`. Common codes are
`INVALID_CREDENTIALS`, `VALIDATION_ERROR`, `NOT_FOUND`, `FORBIDDEN`,
`UNAUTHORIZED`, `STEP_UP_REQUIRED`, and `SERVER_ERROR`. `STEP_UP_REQUIRED`
includes `details.maxAgeSeconds`. Internal and downstream causes are masked to
clients as `SERVER_ERROR`.

| Method/path | Auth | Contract |
|---|---|---|
| `POST /wallet/enroll` | authenticated | `WalletEnrollRequest -> MessageResponse` |
| `GET /wallet/material` | authenticated | `WalletMaterialResponse | null` |
| `GET /wallet/status` | authenticated | `WalletStatusApiResponse` |
| `POST /wallet/lock` | authenticated | `MessageResponse` |
| `POST /wallet/recover` | authenticated | `MessageResponse` |
| `GET /wallet/list` | authenticated | `WalletListResponse` |
| `GET /wallet/derived` | authenticated | `AllWalletsListResponse` |
| `POST /wallet/derived` | authenticated plus unlocked session | `CreateDerivedWalletRequest -> DerivedWalletResponse` |
| `DELETE /wallet/derived/{id}` | authenticated | `MessageResponse` |
| `POST /wallet/share-b` | authenticated | `ShareCRecoveryRequest -> ShareCRecoveryResponse` |
| `GET /wallet/pending-recovery` | authenticated | `PendingWalletRecoveryResponse` |
| `POST /wallet/acknowledge-recovery` | authenticated | `AcknowledgeRecoveryRequest -> MessageResponse` |
| `POST /wallet/rotate-user-secret` | authenticated plus credential | `RotateUserSecretRequest -> MessageResponse` |
| `POST /wallet/sign` | authenticated plus unlock session or credential | `SignTransactionRequest -> SignTransactionResponse` |
| `POST /wallet/unlock` | authenticated plus session | `WalletUnlockRequest -> WalletUnlockResponse` |
| `POST /wallet/rotate` | authenticated plus step-up | `WalletRotateRequest -> MessageResponse` |
| `GET /wallet/admin/settings` | owner/admin | Wallet admin settings response |
| `PUT /wallet/admin/settings` | owner/admin | Settings update request -> wallet admin settings response |

GET routes are safe to retry. Signing, recovery, enrollment, rotation, and
derived-wallet creation should not be replayed automatically. The typed
Tokenization sign-submit contract includes `idempotencyKey`; expired
transaction intents must be refreshed instead of replayed. No route-specific
timeout is declared; host/runtime defaults apply. Wallet unlock TTL defaults
to 900 seconds. Pending recovery cleanup runs every 15 minutes UTC.

### Wallet Events

Wallet emits:

- `cedros-wallet:wallet-enrolled`
- `cedros-wallet:wallet-unlocked`
- `cedros-wallet:wallet-locked`
- `cedros-wallet:wallet-recovered`
- `cedros-wallet:wallet-rotated`
- `cedros-wallet:recovery-acknowledged`
- `cedros-wallet:transaction-signed`
- `cedros-wallet:user-secret-rotated`
- `cedros-wallet:derived-wallet-created`
- `cedros-wallet:derived-wallet-deleted`
- `cedros-wallet:recovery-share-issued`
- `cedros-wallet:recovery-material-viewed`
- `cedros-wallet:wallet-settings-updated`
- `cedros-wallet:pending-recovery-cleaned-up`

Payloads are redacted metadata only. They must not include wallet material,
recovery phrases, transaction payloads, signatures, tokens, private keys, seed
phrases, auth headers, raw provider payloads, raw user identifiers, or unsigned
transaction bytes. Site Brain records use subject = event id, wallet/recovery/
security tags, and `{ eventId, metadata }` details.

Route responses and fresh state reads are canonical. Events may trigger
idempotent cache refresh or analytics only.

### Wallet Theme And Public UI Rules

Version `1.0.0` declares no public page seeds, Visual Builder blocks/templates,
Forms templates, PWA shortcuts, or public wallet blocks. Public/theme code
must not call Wallet routes directly.

Authenticated Wallet UI is exposed through `@cedros/wallet-react` components
and hooks only when mounted inside a Cedros Login-authenticated runtime. Render
Wallet unavailable, no wallet, wrong chain, rejected signature, and provider
error states as fail-closed UI: disable signing/action buttons, show a
non-secret reason, and link admins to `cedros-wallet:settings-wallet` inside
module `cedros-wallet:admin` when operator setup is required.

Never store or log private keys, seed phrases, recovery phrases, wallet shares,
passwords, passkeys/PRF outputs, auth headers, tokens, raw provider payloads,
raw transaction payloads, unsigned transaction bytes, or production PII.

### Wallet Host Handoff And Rollback

Host-coordinated items:

- Wasm route/job runtime
- database seam for wallet content models
- settings seam for wallet settings
- secrets seam for recovery/KMS material and unlock/session secret handling
- telemetry seam for analytics and Site Brain
- customer-tags seam for managed tags
- host-supplied Cedros Login user/session context; Wallet does not configure a
  Login service credential
- optional sanctions allowlist binding
- native app placement
- Wallet-owned chain submission before staging sign-submit

Wallet intentionally does not import providers, `providerAccess[]`, or
`crmSourceAccess` in this release.

Rollback is disable-first: disable Cedros Wallet before unbinding host runtime.
Preserve wallet records, settings, docs, tags, analytics, and Site Brain
records unless an explicit remove-data action is approved. Do not drop tables
automatically. Contract consumers must version-check contract id, contract
version, and min Wallet version, then fail closed when unavailable.

## Cedros Compliance

Cedros Compliance owns KYC, accreditation, sanctions, jurisdiction policy,
tokenization policy, evidence references, and redacted audit records.

Current family:

| Field | Value |
|---|---|
| Extension id | `cedros-compliance` |
| Version | `2.4.0` |
| Platform API | `1` |
| Min Cedros Data | `0.1.11` |
| Server package | `cedros-compliance@2.4.0` |
| React package | `@cedros/compliance-react@2.4.0` |
| Native package | `@cedros/compliance-react-native@2.4.0` |
| Server entrypoint | `cedros_compliance::register_extension_family` |
| Admin entrypoint | `@cedros/compliance-react/admin/register` |
| Web entrypoint | `@cedros/compliance-react/web/register` |
| Native entrypoint | `@cedros/compliance-react-native/register` |

### Compliance Contract Registry

| Contract id | Type | Status | Min version | Purpose |
|---|---|---|---|---|
| `cedros-compliance:policy-read-check-run-audit-record` | typed contract | published | `0.0.1` | Active tokenization policy lookup, fail-closed check execution, and redacted durable audit record. |
| `cedros-compliance:site-brain-records` | capability/trust scope | published | `0.0.1` | Writes redacted `site-brain-record:compliance` operational records. |
| `cedros-compliance:kyc-self-service` | typed relying-party contract | published | `2.4.0` | Contract `1.0.0`: the current authenticated Login subject reads effective KYC status and starts/restarts verification. |
| `cedros-compliance:kyc-start` | AI action | host-coordinated execution | `0.0.1` | AI-gateway execution of `/kyc/start`; distinct from the published current-user self-service route. |
| `cedros-compliance:sanctions-refresh` | AI/admin action | host-coordinated execution | `0.0.1` | Refreshes sanctions cache through `/admin/sanctions/refresh`. |

No arbitrary-user KYC lookup, KYB, consent-check, audit-read, general
eligibility-read, attestation, or raw evidence-read public contract is exposed.
Use the Tokenization contract for policy/check/audit decisions; do not infer
gating from KYC status, private records, events, or tags.

### Compliance Tokenization Contract

Spec: `contracts/policy-read-check-run-audit-record.contract.json`.
Fixtures: `contracts/fixtures/policy-read-check-run-audit-record.staging.json`.
Operations: `policy-read`, `check-run`, and `audit-record`.

Decision values:

- `allow`
- `deny`
- `manual-review`
- `freeze`
- `thaw`
- `blocked-mint`
- `blocked-burn`
- `provider-unavailable`

Reason codes include `CHECK_PASSED`, `SANCTIONS_MATCH`, `KYC_REQUIRED`,
`KYC_EXPIRED`, `ACCREDITATION_REQUIRED`, `RESIDENCY_RESTRICTED`,
`JURISDICTION_UNSUPPORTED`, `TRANSFER_RESTRICTED`, `FREEZE_NOT_ELIGIBLE`,
`THAW_NOT_ELIGIBLE`, `REDEMPTION_INCOMPLETE`,
`REQUIRED_EVIDENCE_MISSING`, `PROVIDER_UNAVAILABLE`, `AUDIT_WRITE_FAILED`,
and `DECISION_EXPIRED`.

Evidence refs use
`cedros-compliance:evidence-ref:v1:{kind}:sha256:{digest12}`. Unavailable
policy, provider state, required evidence, or audit persistence returns `deny`
or `manual-review`; never authorize fulfillment.

### Compliance KYC Self-Service Contract

Contract `cedros-compliance:kyc-self-service` version `1.0.0` is published by
Cedros Compliance `2.4.0+`. The machine contract is
`contracts/kyc-self-service.contract.json`, staging fixtures are
`contracts/fixtures/kyc-self-service.staging.json`, the consumer SDK is
`@cedros/compliance-react/contracts`, and the package guide is
`CEDROS_KYC_INTEGRATION_GUIDE.md`.

The contract is identity-bound: the current Cedros Login subject is always the
KYC subject. Authentication is the subject's bearer token or same-origin
`cedros_access` cookie. There is no user-id input, arbitrary-user lookup,
service credential, or supported proxy from Compliance's admin routes.

| Operation | Route id | Method/path | Result |
|---|---|---|---|
| `status-read` | `cedros-compliance:kyc-status` | `GET /kyc/status` | `{ status, verifiedAt, expiresAt, enforcementMode }` for the current subject. |
| `verification-start` | `cedros-compliance:kyc-start` | `POST /kyc/start` | Ephemeral `{ sessionId, redirectUrl }`; requires `Idempotency-Key`. |

Both routes are mounted beneath the host-provided Compliance API base,
canonically `/extensions/cedros-compliance`. Consumers obtain that base from
the host and never derive it from a private service URL. Feature detection
accepts either a published contract descriptor or an enabled
`cedros-compliance` manifest at `2.4.0+` containing both route ids. Missing,
old, disabled, or route-incomplete discovery fails closed.

Declare the relying-party dependencies explicitly and keep the flattened
install-gating capabilities aligned:

```json
{
  "dependencies": {
    "extensions": [
      {
        "extensionId": "cedros-compliance",
        "minVersion": "2.4.0",
        "required": true
      },
      {
        "extensionId": "cedros-login",
        "minVersion": "0.0.60",
        "required": true
      }
    ],
    "capabilities": [
      {
        "capabilityId": "cedros-login:auth-response",
        "required": true
      },
      {
        "capabilityId": "cedros-login:user-context",
        "required": true
      }
    ]
  },
  "requiredCapabilities": [
    "cedros-login:auth-response",
    "cedros-login:user-context"
  ]
}
```

Before rendering or calling KYC, pass the discovered Compliance manifest or
contract registry entry to
`assertCedrosComplianceKycSelfServiceAvailable`. Do not infer availability
from the dependency declaration alone.

All responses declare:

- `Cache-Control: no-store`
- `X-Cedros-Contract-Id: cedros-compliance:kyc-self-service`
- `X-Cedros-Contract-Version: 1.0.0`

The host proxy preserves those headers and CORS-exposes both contract headers
to allowed browser origins. The SDK rejects a contract mismatch, malformed
body, unknown enum, invalid timestamp, or non-HTTPS redirect as
`INVALID_RESPONSE`.

Status values are:

- `none`
- `pending`
- `action_required`
- `verified`
- `canceled`
- `failed`
- `expired`

Enforcement modes are `none`, `optional`, `withdrawals`, `deposits`, and
`all`. `verifiedAt` and `expiresAt` are ISO 8601 timestamps or `null`. A
`verified` result with an elapsed `expiresAt` is effectively `expired` and must
not be cached as verified.

`verification-start` sends no body and requires an `Idempotency-Key` of 8–128
safe ASCII characters. Reuse a key only for transport retries of the same
logical start. A completed response, including conflict, is replayed for that
key. After reading current status, a deliberate new attempt uses a new key.
`sessionId` and `redirectUrl` are ephemeral; never log, analyze, or persist the
session id, and navigate only to a validated HTTPS redirect.

Stable SDK error codes are `CONTRACT_UNAVAILABLE`,
`AUTHENTICATION_REQUIRED`, `KYC_DISABLED`, `INVALID_CONFIGURATION`,
`REQUEST_CONFLICT`, `RATE_LIMITED`, `PROVIDER_UNAVAILABLE`,
`SERVICE_UNAVAILABLE`, `NETWORK_UNAVAILABLE`, `INVALID_RESPONSE`, and
`REQUEST_FAILED`.

| HTTP or failure | SDK code | Retry |
|---|---|---|
| `400`, `422` | `INVALID_CONFIGURATION` | No; repair the request or owner configuration. |
| `401` | `AUTHENTICATION_REQUIRED` | No anonymous retry; obtain a current Login session. |
| `403` | `KYC_DISABLED` | No loop; direct the owner to configuration. |
| `409` | `REQUEST_CONFLICT` | Read status, then replay the same logical start with the same key or deliberately begin a new attempt with a new key. |
| `429` | `RATE_LIMITED` | Bounded backoff when the SDK marks it retryable. |
| `500` | `SERVICE_UNAVAILABLE` | Fail closed; bounded retry when marked retryable. |
| `502`, `503` | `PROVIDER_UNAVAILABLE` | Fail closed; bounded retry when marked retryable. |
| Network failure | `NETWORK_UNAVAILABLE` | Bounded backoff; preserve the logical attempt key. |
| Malformed payload/header/timestamp/enum/redirect | `INVALID_RESPONSE` | Fail closed and report an integration fault. |

Never translate unavailable or malformed state into `none` or `verified`.

Consumers may use only effective status, `verifiedAt`, `expiresAt`,
`enforcementMode`, and the ephemeral HTTPS redirect. They must not receive or
store identity documents, provider payloads or session records, provider or
webhook secrets, raw database rows, authentication tokens, presigned URLs, or
PII. Do not place the session id or those prohibited values in logs, analytics,
events, Site Brain, theme props, support forms, or error messages.

KYC status answers only whether identity verification is current. It does not
authorize access, payment, tokenization, transfer, purchase, deposit,
withdrawal, mint, burn, freeze, thaw, or investment eligibility. Those
decisions use `cedros-compliance:policy-read-check-run-audit-record`. Events
and CRM tags may trigger a fresh read but are never authorization state.

Consumers require contract `1.x` and Compliance `2.4.0+`. Breaking identity
binding, required-field, enum, path, or fail-closed changes require a new major
contract. Additive optional fields require a minor contract release. Keep the
previous major discoverable for at least one production release train after a
replacement unless emergency security disablement is required. On rollback,
missing discovery or routes immediately becomes unavailable/non-verified; a
cached verified result never survives its `expiresAt` and never substitutes
for a current policy decision.

### Compliance Dependencies And Grants

Required consumed capabilities:

- `cedros-data:extension-storage-cas-v1`
- `cedros-login:auth-response`
- `cedros-login:user-context`
- `cedros-login:admin-auth`

Optional consumed Pay capabilities:

- `cedros-pay:checkout`
- `cedros-pay:entitlement-read`
- `cedros-pay:subscription-read`

Unavailable, stale, denied, refunded, disputed, chargeback, past-due, or
unreconciled Pay state denies dependent gates.

Compliance-owned grants:

- `cedros-compliance:compliance-db`
- `cedros-compliance:accreditation-document-storage`
- `cedros-compliance:customer-tags`
- `cedros-compliance:site-brain-records`

Missing required Login, database, settings, secrets, route ingress/auth,
telemetry, storage, or evidence dependencies blocks activation or fails closed.
Wallet and Contracts are not consumed directly. Notifications are setup seeds
only. The intelligence provider is not used.

### Compliance Routes

Routes are mounted under `/extensions/cedros-compliance`.

Public routes use Cedros Login relying-party auth. KYC self-service accepts the
current subject's bearer token or same-origin access cookie, returns
`Cache-Control: no-store`, and preserves its contract id/version headers:

- `POST /access-codes/generate`
- `GET /access-codes/mine`
- `POST /kyc/start`
- `GET /kyc/status`
- `GET /accreditation/status`
- `GET /accreditation/submissions`
- `POST /accreditation/submit`
- `POST /accreditation/upload`

Webhook route:

- `POST /webhook/kyc`: self-verifies Stripe signature and has no user/admin
  session.

Admin routes use host admin auth plus write CSRF for mutations:

- `GET/POST /admin/access-codes`
- `DELETE /admin/access-codes/{id}`
- `GET /admin/dashboard-stats`
- `GET /admin/signup-stats`
- `GET /admin/users/{user_id}/kyc`
- `POST /admin/users/{user_id}/kyc/override`
- `GET /admin/sanctions/stats`
- `POST /admin/sanctions/refresh`
- `GET/PUT /admin/settings`
- `GET /admin/accreditation/pending`
- `GET /admin/accreditation/submissions`
- `GET /admin/users/{user_id}/accreditation`
- `GET /admin/accreditation/{submission_id}`
- `POST /admin/accreditation/{submission_id}/review`
- `POST /admin/users/{user_id}/accreditation/override`
- `GET /admin/accreditation/documents/{doc_id}/url`

Route errors are redacted JSON, typically `400`, `401`, `403`, `404`, `409`,
`500`, or `502`. Missing auth, permissions, provider, database, settings,
secrets, route binding, or required evidence fails closed. Idempotency is
required for contract check-run and audit-record. KYC `POST /kyc/start`
publishes exact `Idempotency-Key` and replay behavior in the self-service
contract; other route-level idempotency is host-coordinated except existing
idempotent delete, sweep, or upsert behavior.

### Compliance Events

Compliance emits these event ids, all prefixed `cedros-compliance:`:

- `invite-code-generated`
- `access-code-created`
- `access-code-deleted`
- `kyc-started`
- `kyc-status-updated`
- `kyc-status-overridden`
- `accreditation-submitted`
- `accreditation-document-uploaded`
- `accreditation-reviewed`
- `accreditation-status-overridden`
- `sanctions-refreshed`
- `settings-updated`
- `onboarding-step-completed`

Payloads are redacted aggregate/status metadata only: result, status/decision,
counts, provider family, configured flags, and request id. Consumers may use
events for analytics, notifications, or low-risk cache refresh. Events are not
legal or gating source of truth.

### Compliance Theme And Public UI Rules

Public blocks:

- `cedros-compliance:compliance-copy`
- `cedros-compliance:compliance-action`

Page seeds cover invite codes, KYC status/verification/callback, and
accreditation status/verification.

Theme authors should render neutral states only: ready/allowed, gated, pending
review, rejected/action required, expired, jurisdiction unavailable, setup
missing, and provider unavailable/error. Use copy such as "verification
required", "review pending", "not available in this jurisdiction", "provider
unavailable", or "contact support". Do not claim "guaranteed compliant",
"legally approved", "available in all jurisdictions", "sanctions cleared
forever", "KYC guarantees eligibility", or legal/investment/tax advice.

Never log, store in manifests/settings, analytics, props, Site Brain, or theme
state: identity documents, sanctions payloads, provider secrets, PII, auth
headers, presigned URLs, private document keys, raw database rows, wallet
secrets, payment details, or unredacted evidence. PII and evidence remain
Compliance/provider-owned. Durable audit records are redacted and use evidence
refs. Extension disable should preserve historical audit records unless host
retention policy deletes them.

### Compliance Host Handoff And Rollback

Self-serve package artifacts cover manifest, React admin/web/native bootstrap,
Wasm routes/jobs, schemas, fixtures, pages, blocks, docs, policies, and
metadata.

Host-coordinated launch items:

- route ingress/auth
- Cedros Login `auth-response`/`user-context` binding and public JWKS
  verification; the consumer does not store a Login service credential
- optional Pay discovery
- storage provider
- database migration dry run
- settings and secrets storage
- scheduler
- notifications
- AI gateway
- Tokenization contract executor
- production smoke

Disable should preserve Compliance-owned historical records unless explicit
retention policy deletes them. Roll back consumers by failing closed for
Compliance-dependent gates and avoiding stale policy decisions from older
contract versions.

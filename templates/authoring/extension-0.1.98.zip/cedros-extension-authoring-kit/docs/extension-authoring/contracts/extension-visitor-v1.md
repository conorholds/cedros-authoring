# Extension visitors v1

Core contract: `cedros-data:extension-visitor-v1`. Require this capability to
prevent an older host from activating a package while ignoring its access gate.
The contract uses the existing JSON route context; the platform API and WIT
checksum do not change. Admission to the first-party namespace is unnecessary.

```json
{
  "requiredCapabilities": ["cedros-data:extension-visitor-v1"],
  "routePolicies": [
    { "routeId": "example:account-render", "endUserAuth": "required" },
    {
      "routeId": "example:requests",
      "endUserAuth": "required",
      "emailPurpose": "Send updates about your sourcing requests"
    }
  ],
  "pageSeeds": [
    {
      "id": "example:account-page",
      "displayName": "Account",
      "title": "Your account",
      "routePath": "/my-account",
      "access": "signed-in"
    }
  ],
  "interactiveBlocks": [
    {
      "blockType": "example:account",
      "renderRouteId": "example:account-render",
      "routeIds": ["example:requests"]
    }
  ]
}
```

Declare the referenced server routes and web block types in `surfaces`, and
declare their block metadata in `contentBlocks` as usual. This is a partial
manifest, not a complete installable package.

## Verified identity

On an opted-in HTTP route, Core asks the active, trusted Login current-user
handler to verify the presented bearer or unambiguous `cedros_access` cookie.
The extension receives:

```json
{ "visitor": { "userId": "visitor:opaque-uuid" } }
```

This ID is stable for one Login account within one site and extension. Another
extension gets a different ID. It is a reference, not a credential. A guest
cannot copy JSON or identity headers to authenticate a later request. Core
retains the native Login subject and credential privately for the lifetime of
the invocation, without storing a token in the mapping table.

`required` rejects anonymous or invalid sessions with 401 before the guest runs.
`optional` omits `visitor` for anonymous or expired sessions. Authentication
provider failures remain errors. Duplicate credentials are rejected. Cookie
authentication on a mutating route requires an allowed site Origin before guest
execution. `authenticated`, `actorId`, `permissionClaims`, and the top-level
`csrfVerified` retain their operator/service meanings; visitor identity does
not confer those permissions. Requests without an opted-in policy get no visitor.
Internal calls cannot manufacture a visitor either; a required visitor route
rejects an invocation without its private host authority.

Core sets opted-in HTTP responses to `private, no-store` and noindex. Extensions
must still bind account records to `context.visitor.userId` and compare that
ownership on every read and write.

## Email consent

Email is omitted by default. A route may declare a nonempty `emailPurpose`
(maximum 512 bytes). Direct the visitor to the host-owned page:

`/extensions/cedros-data/visitor-consent/{extensionId}`

Append a URL-encoded `returnTo` with a local site path to offer a Continue link
back to the account page. The host preserves that path through sign-in, shows
the current sharing choice, and redirects after saving so refreshing cannot
resubmit a consent change. External return URLs are rejected.

It verifies the visitor, displays the extension name and declared purpose,
and offers explicit share/revoke buttons. Consent writes require an allowed
Origin. Consent is bound to the exact purpose; changing the purpose does not
carry consent forward. The current consent choice stores one purpose per
extension/account. Sharing for another purpose replaces that choice. Revoking
removes email from subsequent route contexts for that purpose. A stale revoke
form cannot revoke a newer choice for a different purpose. Revocation prevents
future disclosure; it does not erase information an extension already received.
Neither email nor session tokens are stored in the visitor-reference mapping.

When consent matches, `visitor.email` comes from Login's current-user response.
The host does not depend on undocumented JWT email claims. This contract is not
a claim that an email address is verified; workflows needing verified email
must use Login's published email-verification contract.

## Personal notification preferences

The same host-owned visitor-consent page also offers notification preferences
for personal events declared in the extension's `setupSeeds.notifications[]`
and `surfaces.server.events[]`. Notification-only extensions need no
`emailPurpose`. Email sharing and notification subscriptions are separate choices.
The visitor can enable an event, choose an existing personal destination or add
an email destination, and stop alerts. Adding an email does not disclose that
address to the extension or establish a verified Login identity.

The host verifies the Login account and updates only that account's personal
settings through the existing notification-settings path. Saves require an
allowed site Origin and the page's settings revision; stale saves return 409
with a reload link. Other users, events, destinations and secrets are preserved.
The extension cannot subscribe a visitor or write preferences through a service
grant. Provisioning and provider readiness still govern actual event delivery.

Interactive blocks with email-sharing purposes or personal events receive a
host-rendered **Privacy and notification preferences** link outside the frame.
The link preserves the current local page through sign-in and offers Continue
after saving. Extensions can also link to the visitor-consent page from other
host-rendered account surfaces.

## Page gating and redirects

`pageSeeds[].access: "signed-in"` protects the seeded page. Content APIs return
401 with `code: "cedros.visitor.sign_in_required"` and a host-computed `loginUrl`.
The generated public host checks access before serving a cached document and
returns a 302 to Login, preserving the original route in `returnTo`. The shared
`PageRouteTemplate` uses `handleRedirect` when supplied, with a browser redirect
fallback otherwise. Custom hosts calling lower-level content APIs must handle
`VisitorSignInRequiredError` and issue their own redirect.
The same gate applies to a signed-in route's SEO description and the generated
host's SEO fallback. Disabled extensions retain their stored page and route
privacy declarations so older public HTML cannot bypass the gate.

Protected content stays noindex and is excluded from public content lists and
discovery. Page access checks precede body and document expansion; authenticated
documents are never shared through the public cache. An API route may also use
`access: "signed-in"` together with required auth to redirect GET/HEAD callers;
other anonymous methods receive 401. `seo.noindex` alone never gates access.

## Interactive blocks

Core renders each opted-in block in `sandbox="allow-scripts"`, without
`allow-same-origin`, forms, popups or top navigation. It installs a restrictive
CSP with no direct network, frame or worker access. The extension's web archive
is not imported into the host document in this mode. Serve inline browser code
and styles in the server render response instead.
Declare every web block type in `interactiveBlocks`; this mode cannot mix with
archive-backed web routes, templates, authored surfaces or template utilities.
Use host templates for these pages. Intake rejects mixed declarations, and
runtime binding validation rejects unsupported methods or paths before enablement.

The render route must be a concrete POST route under the extension's own
`/extensions/{extensionId}/` prefix. It receives `{ "props": { ... } }` and
returns JSON `{ "html": "..." }`. Its HTML runs only inside the isolated frame.
Use `window.cedros.request(routeId, body)` for JSON requests. Core resolves the
method and path from a declared registry binding, accepts only this block's
declared route IDs, and attaches browser credentials through same-origin fetch.
GET routes take no body; other methods receive the supplied JSON. Guests cannot
select a URL, add headers, call host consent routes, or redirect the bridge.
Each referenced route must opt into visitor auth. Parameterized paths are not
supported by this runtime. Render and callable route IDs must be unique within
each block. Host requests time out and cancel after 30 seconds, including response
reads; failed initial rendering offers a retry. Each block has at most 32 callable
routes, eight pending browser requests, a 64 KiB request limit and a 1 MiB response
limit.

The message bridge checks the source window, opaque origin and invocation nonce;
teardown aborts outstanding requests. It transfers only data/error results, not
cookies, bearer tokens, operator SDKs or a raw native Login subject.

The host bootstrap automatically measures content height on initial rendering,
content changes and resizing, and sends bounded height reports over that same
checked bridge. The frame grows and shrinks between 320 and 16,384 CSS pixels;
larger content scrolls inside the frame. Guests can call
`window.cedros.reportHeight()` to request a fresh measurement. Measurement is
coalesced per animation frame and grants no parent DOM or network access.

## Forms

Declare `cedros-data:extension-form-submissions-read-v1` as a capability dependency
and grant, then invoke the Core service with:

```json
{
  "targetExtensionId": "cedros-data",
  "routeId": "cedros-data:extension-form-submissions-read-v1",
  "capabilityId": "cedros-data:extension-form-submissions-read-v1",
  "method": "POST",
  "path": "/forms/v1/submissions",
  "body": { "templateId": "example:sourcing-form", "limit": 50, "offset": 0 }
}
```

The template must appear in the caller's `formTemplates`. Results contain only
new submissions whose host-recorded `extensionSource` matches that extension
and template. Owner editing preserves the existing form record. Unattributed
legacy submissions and unrelated forms are not granted. A signed-in submitter
adds `{ visitor: { userId } }`, using the same extension scope as account routes.
The submission's idempotency fingerprint also binds that verified visitor.
Pagination accepts 1–100 records and offsets up to 100,000. A guest exposing
these records to visitors must filter by the current visitor ID; the read grant
is for the declaring extension, not automatic access for every account.

The response is `{ "submissions": [...] }`. Each item is the stored submission
payload with `submissionId` (UUID string), `submittedAt` (RFC 3339 string),
`scope` (`contact` or `other`), `formKey`, `formTitle`, `formDefinitionVersion`,
`definitionSnapshot`, `sourcePath`, `readStatus`, `workflowStatus`,
`submitterName`, `submitterEmail`, `searchText`, `values`, and `fieldValues`.
Attributed records include `extensionSource: { extensionId, templateId }`;
signed-in submissions additionally include `visitor: { userId }`.

`values` maps field keys to normalized strings or checkbox booleans.
`fieldValues` is an array of `{ key, label, type, valueText?, valueBool?,
optionValue? }`: selects store their display label in `valueText` and raw choice
in `optionValue`; checkboxes include `valueBool`. Anonymous submissions have no
verified visitor identity and must not be matched to an account by entered email.

The current read implementation orders by stored entry `updated_at DESC`, then
`entry_key ASC`, rather than by `submittedAt`. Updating a submission can move it
in this order. Limit/offset paging has no snapshot or cursor: inserts and edits
between requests may repeat or omit records. Deduplicating by `submissionId`
does not guarantee a complete scan during concurrent writes.

Moving a template to another extension does not transfer historical submission
attribution or visitor references. The new extension's read grant cannot read
the old owner's records; no reattribution operation is provided. Existing form
keys owned by another extension are not silently adopted. Provision a form
owned by the new extension and update its page binding before expecting new
submissions to appear in the new extension's accounts.

## CRM and notifications

Invoke `cedros-data:visitor-reference-read-v1` through Core at
`POST /visitor/v1/reference`, with the route ID matching the capability ID.
The body is `{ "userId": "visitor:..." }`, or `{}` for the current invocation.
It returns `{ userId, profileId, recipientRef }`. `profileId` is null until the
existing Login-to-CRM ingestion bridge has resolved the profile. No CRM profile
is created by this read. The reference must belong to the calling extension.
Existing customer-tag declaration and scope checks still apply.

`recipientRef` is the opaque visitor reference. Pass it as the personal audience
reference in `cedros-data:notification-event-publish-v1`. Core resolves it only
within that extension and applies existing event destination consent and
ownership checks. A mapping does not subscribe the visitor or bypass opt-in.
Third-party extensions opting into this visitor contract cannot substitute a raw
Login user ID. Legacy notification contracts keep their existing recipient rules. References may
be saved for background work; they do not authenticate a background invocation.

## Purchases

A route with a verified current visitor may invoke `cedros-pay:purchases` using
the existing declared Pay dependency and capability grant: target `cedros-pay`,
route/capability `cedros-pay:purchases`, `GET /paywall/v1/purchases`. Existing
`limit` and `offset` query pairs remain supported. Core privately supplies the
live Login credential **only to that exact trusted Pay operation**. Pay retains
its own buyer verification and redacted, buyer-scoped ledger projection. The
calling guest receives no cookie or token. An anonymous or background invocation
has no such authority and cannot replay a saved visitor reference to read
purchases. Other provider services receive no visitor credential.

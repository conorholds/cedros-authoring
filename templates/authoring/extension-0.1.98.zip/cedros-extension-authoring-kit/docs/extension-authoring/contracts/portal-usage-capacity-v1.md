# Portal Usage and purchased capacity — financial protocol 1.0.0, accounting revision 2

**Final protocol decision by Cedros Data, under the user's delegated authority.**
Portal, Pay, Providers Manager, Providers and Data must implement accounting revision 2.
The product-owner correction supersedes earlier category and charging definitions.
Financial protocol envelopes remain 1.0.0 so accepted quotes retain their original digest;
`accountingVersion: 2` identifies the new usage/binding semantics. The contract
agreement gate is closed: teams do not need another acceptance round before
implementation. Data owns this standard and resolves concrete implementation
conflicts through versioned changes; a requested amendment does not suspend
unaffected work. Previous drafts 0.1.0–0.3.0 are superseded.

**Protocol publication is separate from runtime availability.** The expanded
service projection, delegated purchase authority and grant reconciler have native
implementations. Native managed-provider credit admission and settlement are implemented in
`portal_capacity/accounting.rs`. Native site reservation import and admission now use
the established owner HTTP facade and the existing capacity authority. Signed local
quota read/apply/ack and retained-object publication are implemented. Their
readiness depends on verified inventory, registered enforcing owners and current
allocation evidence. `callable: false` records unverified production activation;
it does not mean the standard is provisional. Native and installed joint tests
pass locally. Keep production sales disabled until commercial configuration and
the deployed installation are verified.
Unknown prices or quantities do not block implementing the published interfaces.
Native Manager guard review and approval are now implemented, as identified by
their operation flags. The overall `callable: false` is not a substitute for
per-organization commercial approval or current runtime evidence.
Native site-migration bootstrap reads the existing Portal CAS model. Trusted
financial reconciliation can start the fence; a complete, source-verified import
activates native admission. Missing source or financial state fails closed.

The normative schemas and operation bindings are in
[portal-usage-capacity-v1.contract.json](portal-usage-capacity-v1.contract.json).
[Fixtures](fixtures/portal-usage-capacity-v1.fixtures.json) are synthetic protocol
examples, not configured offers. Operation metadata now uses `path`, `routeId`
and `capabilityId` rather than the drafts' `proposed*` names. Internal service
bindings retain their distinct IDs. Financial wire envelopes remain pinned to
`contractVersion: 1.0.0`; recompute quote digests using that version and never
reinterpret an older quote. Usage alone uses `contractVersion: 1.2.0`; its 1.0 and 1.1 responses remain
valid. Version 1.0 cannot contain operational Email breakdowns; versions 1.0
and 1.1 cannot contain the Storage occupancy projection.

Run `python3 docs/extension-authoring/contracts/fixtures/check_portal_usage_capacity_v1.py`
(requires the review environment's `jsonschema`; installs nothing). The
[reference checker](fixtures/check_portal_usage_capacity_v1.py) verifies shapes
and reference transitions, not native enforcement or installed runtime readiness.

## Implemented boundary and compatibility

The native owner `GET /portal/v1/usage` preserves `windowDays` and the complete,
customer-safe hosting `sites` projection. It now includes schema/version, complete
canonical site count, organization and site meter identities, source availability,
and a Data publication revision. Uninstrumented service usage and reservations
remain null/unavailable. Pending grants never appear as applied purchased capacity.
The chart series retain their 500-point and 20-recommendation bounds; they are not
commercial balances. Responses that cannot fit the facade limit fail explicitly.

Native owner routes implement delegation creation, immutable authorization,
organization-scoped purchase status/recovery listing and target discovery. Four
Pay-only core service capabilities check delegations and scope, redeem acceptance,
and durably queue grant-change hints. The worker obtains owner bindings and full
pinned snapshots using native reads. Complete snapshots publish transactionally;
partial pages never change the live grant set. Durable hints retain the highest
announced source revision; an older unseen snapshot cannot restore freshness.
Exact replay of a published snapshot remains a non-mutating acknowledgement.
Payment observations use a separate invalidation generation under the same
organization lock; a delayed Pay read cannot overwrite a newer change hint.
Discovery pins target identities while refreshing eligibility on each page;
removed targets expire the cursor instead of returning stale authorization.
No public grant-application route
exists. `portal_capacity_applications` can only hold enforcing-owner evidence;
financial publication cannot write it. The native provider ledger applies accounting-v2 credit/recipient budgets only from
fresh owner bindings. It reserves organization capacity and configured site limits
under the same organization lock, snapshots pricing, retains uncertain reservations,
and settles actual observations idempotently. Other service owners cannot borrow
this acknowledgement. Sales and full activation remain blocked by incomplete
coverage and joint verification; this is not a completed launch.

### Native implementation and remaining activation gates

Before accounting revision 2, provider request/spend guards checked historical
rows before execution and wrote attempts afterward. They were operational limits,
not atomic purchased service allowances. No end-to-end service budget was enforced.

The native revision-2 ledger reserves customer credits and supplier micro-USD under
the existing organization capacity lock. Actual settlement uses the immutable
pricing snapshot; retries cannot dispatch an existing operation a second time.
Uncertain outcomes retain their full reservation. Failed work preserves supplier
cost, and partial Email acceptance charges only accepted recipients. The ledger
uses canonical Portal site IDs for commercial ceilings and retains runtime site
IDs for operational guards. Reviewed guards remain required. Managed extension AI
overwrites guest attribution with the host-verified organization, site, extension,
access and operation scope, and verifies that scope against the configured managed
transport. A supplied correlation key is validated and namespaced to that scope;
an absent key remains absent for customer-funded and local execution. Cedros-funded
admission requires a durable operation key, and trace request IDs do not substitute
for it. Cedros-funded xAI `grok-imagine-image-2.0` generation and edits are the narrow
non-text exception: the native path fixes one output and at most three source images,
enforces the published supplier-cost floors, reserves and settles Intelligence from
the provider's exact `supplier_cost_ticks` in `usd_1e-10`, and requires durable
media publication before returning success. New Cedros-funded image work requires
verified customer-owned media storage. Cedros-owned destinations are launch-gated:
their current retained-publication protocol requires final sizes/checksums and
cannot reserve a bounded image output before generation. Readiness preflight is
not capacity admission; it cannot account for concurrent in-flight generation.
Data owns this missing handoff. Already-dispatched image recovery still uses the
existing measured-byte publication admission, preserving its supplier evidence and
customer hold until durable delivery. Other Cedros-funded non-text AI
operations remain rejected before pricing, reservation or dispatch. The gate uses
the parsed payload operation kind, so unsupported image payloads cannot bypass it
through the Intelligence family. Customer-funded and local image behavior is
unchanged. AI usage preserves native
prompt totals and separately exposes observed uncached prompt tokens, so approved
rules need not charge cached tokens at the full uncached rate. Missing or
inconsistent cached counters do not produce a fabricated zero. Output bounds must
fit reserved completion-token quantities. Buffered provider JSON, binary and
ChatGPT/Codex SSE bodies have a separate 64 MiB transport ceiling enforced against
both Content-Length and accumulated chunks; overflow is a permanent invalid response
and does not fabricate settlement or authorize redispatch. Provider-specific
input/media bounds and full model billing-dimension coverage still gate activation.

The native accounting owner publishes `coverage=complete` only for the exact
Cedros-funded managed-credit and accepted-recipient meters it enforces. Every
Cedros-funded provider dispatch is admitted through the native ledger before
upstream access; the managed email route disables local provider fallback, and
the treasury Solana route does not bypass a failed managed provider. Customer and
local credentials return before native reservation and remain outside these
applications. Coverage remains code-owned: financial configuration cannot set it,
and Sites and Storage require their separate enforcing-owner evidence.
`accountingCutoverAt` records the first native application. Pre-cutover activity
is not converted into customer charges. Rollups group units/funding and publish
atomically; absent supplier observations stay null. Native financial rollups read
reservations directly, so missing or retained-away response logs cannot erase
recorded supplier cost. Matching logs are supplementary evidence and deduplicate
by reservation with organization/site/route/operation validation. Unmatched
operational logs keep their independent activity and unknown-cost state. Pending
reservations without a dispatch observation do not fabricate completed requests.
A supervised native worker now drains a durable queue of changed UTC months,
including older settlements and cross-month response associations. It processes
bounded tenant/month batches independently of installed extension jobs and Pay
refresh. Generation-aware publication preserves concurrent changes without locking
live producers during aggregation. Minimal accounting facts survive operational
log retention; request payloads and response/error bodies are not copied. Pre-cutover
aggregate snapshots remain separate audit evidence, not reconstructed events or
customer charges. Evidence deleted before this migration cannot be recovered from
those facts. Exact supplier invoice lines can now be reconciled through the
platform-operator endpoint described below; historical evidence still has to be
supplied by an authorized operator.
Daily request guards retain rolling 24 hours; monthly guards and included credits
use UTC calendar months.

`POST /admin/runtime/cedros-providers-manager/organizations/{org_id}/capacity-reservations/{reservation_id}/supplier-reconciliation`
accepts one complete invoice line for one existing reservation. It requires a fresh,
identified platform operator; tenant OpsWrite is insufficient. The immutable
attestation binds the reservation's organization/site, operation, route, original
profile revision, pricing snapshot, period, and explicit metric/unit quantities.
Provider account/environment, invoice/line identity, source digest and actual
micro-USD amount are operator-attested facts, not automatically fetched supplier
records. A global provider/account/environment/invoice/line identity prevents
reuse across organizations and profile aliases. Exact retries return the stored
receipt; changed evidence conflicts. Evidence, accounting changes and the mandatory
audit event commit together and mark the affected UTC month for recomputation.
Live `reserved` executions return `operation_pending` without storing a receipt or
changing their hold. Retry the same invoice after the runtime records its outcome
or recovery classifies it as uncertain; supplier evidence cannot interrupt execution.
Existing customer charges are never repriced. Customer quantities come only from
the original bounded native usage, never invoice quantities; a success boolean alone
does not prove measured usage. Missing native outcomes, pre-cutover
activity and over-bound quantities retain unresolved customer holds while recording
known supplier cost. Aggregate invoices cannot be guessed into individual charges.
An unresolved image publication is not a terminal failed customer operation:
supplier invoice reconciliation retains its customer hold until the owning media
service proves delivery. The invoice's verified supplier amount takes precedence
over earlier native cost estimates; it does not reprice customer units or authorize
another provider dispatch. Reconciliation receipts must describe the committed
reservation state, not merely the transition that was attempted.

Native metric dimensions require the expected unit. Repeated dimensions or aliases
are not summed as distinct supplier work; conflicting or incomplete evidence
remains unknown. A top-level usage envelope owns the observation rather than
borrowing omitted counters from a nested envelope. Raw dimensions remain available
for diagnosis. When actual dimensions exceed the reserved maximum, the customer
reservation remains unresolved and further paid work fails closed. Computable
actual supplier cost and its observation remain recorded; a later incomplete
observation cannot erase them. This recovery state is not a customer overage charge
or evidence that the adapter successfully enforced its pre-dispatch bound.

| Category | Working native boundary | Required before complete activation |
|---|---|---|
| Sites / Hosting | Frozen-source hold import, atomic reservations, transactional Deploy commit, safe release and complete-count SQL guards across Deploy/Fleet writes, revival and deletion. Usage and admission share the effective-cap resolver. Existing hosting observations are retained. Native reservation operations use the owner HTTP facade; the obsolete alternative service bindings have been removed. | Deploy matching Portal/Pay artifacts, run source-verified legacy-hold import and reconciliation against actual organization state, configure commercial plans and verify production cutover. Missing legacy evidence remains fenced and unavailable. |
| Intelligence | Configured rational credits, shared pools, model/settings snapshots, generation bounds, native reservations and settlement. Native HTTP actions, assistant tools and persisted jobs carry explicit phase-scoped operation identities. Browser retries retain their action identity; Council member receipts and learning-log snapshots survive worker recovery. Managed extension calls carry host-verified scope and scoped correlation identity. Native text adapters apply configured output-token maxima; bounded completed text responses and continuations replay from the original reservation before new admission. The narrowly bounded xAI image path described above additionally requires tenant-owned media publication; other unsupported non-text requests fail closed. | Configure actual model rates and verify provider-native input, cached-input, media and output billing dimensions. Responses lost before capture remain unresolved until authoritative reconciliation; they never authorize an automatic redispatch. Paid-image activation requires verified Storage ownership, exact supported model/rates and joint image/publication recovery qualification. |
| Email | Credential-aware SES, SMTP and supported HTTP adapters return confirmed envelope-recipient acceptance. Exact tenant-owned SES credentials remain customer-funded and cannot fall back to the platform account; native caller and isolation regressions cover the local boundary. Managed native inbox uses the root gateway; campaigns, confirmation queues and extension outboxes preserve durable scoped IDs. Data atomically issues immutable, purpose-bound Login token-email evidence behind `cedros-data:token-email-evidence-v1`; signed Controls receipt lookup and root admission against a separately configured bounded internal allowance have local native/TLS and installed-candidate coverage without charging customer applications. Proven preacceptance failures report zero while ambiguous outcomes remain held. | Deploy the supporting Data build before a compatible Login artifact, configure the approved central allowance, pricing and purpose set, and verify production source identity, installed outbox flow and cutover. Verify live credential ownership, sender authorization and attributable supplier acceptance/cost reconciliation in the production environment. |
| Search | Native extractor remains local-funded; paid Exa extraction enters the shared ledger. Durable fanout identity, native estimate/receipt preservation and bounded completed-response recovery use the original reservation and pricing. Retention preserves replay tombstones and unsettled supplier evidence. | Supply attributable invoice-line facts through the operator reconciliation boundary; estimated Exa response costs do not substitute for final supplier charges or prove an invoice. |
| Blockchain / Solana RPC | Validated, bounded RPC responses retain method activity. Hidden transport retries and redirects are disabled. Fabricated universal compute weights are removed; priced reservations require explicit native dimensions. | Authoritative provider-native chargeable units and method/resource observations; configured bounded pricing. Missing observations hold reservations. |
| X API | Catalog and historical observations remain, but Providers Manager Social/X routes and profiles are retired; there is no current managed funded X dispatch. Native Social runs outside Providers Manager. | A new funded offer needs an executable owner, authoritative native units, exact pricing, attribution and approved commercial configuration. Catalog membership does not authorize dispatch. |
| Storage | Captured destination identities, immutable grouped publication, atomic growth admission, retained-generation cleanup and restore fencing. Root-only fencing/adoption verifies listed historical objects and records immutable per-object liabilities while keeping completeness and old-writer cutover as separate operator attestations; exact captured-location deletion releases each liability once after confirmed absence. Independently registered mail, media and retained-object owners accept signed schedules, with complete local owner-coverage and physical-overlap checks. Conserved allocations preserve old-owner liabilities and require exact organization-revision acknowledgements. Deployment-owned mail proof binds live writers to one PostgreSQL authority. | Execute adoption against the actual historical root inventory and writer cutover for every production organization/location, deploy current owner registrations and signed schedules, and verify commercial configuration plus installed Portal/Pay activation. Missing history, inventory or current writer evidence remains unavailable. |

Site-local quota transport must reuse `controls_source_transport.rs` and signed
controls assertions. Native mail/Dovecot and local media remain the enforcing
owners. Mail and media register independent persistent installation bindings through
Fleet and accept only signed capacity-reconciler commands. Fleet advertises
`runtime.localQuotaRegistrations`; `runtime.localQuotaRegistration` remains the
legacy media entry. The root prefers the plural array, rejects malformed or
ambiguous owner bindings without falling back, and polls bounded batches fairly
across runtime/meter pairs. Publication rechecks the complete registration array,
hostname and organization revision. Registration and collected observations alone never allocate the pooled budget
or activate a purchase. The native allocation authority conserves outstanding
liabilities, maps signed owner schedules to an exact organization revision, and
publishes applied capacity only after complete, fresh enforcing acknowledgements.
Native mail proof inventories live writers, validates their executable and Dovecot
plugin identities, and pins the shared mail volume to its persistent PostgreSQL
authority. A copied database cannot establish a second independent allowance for
the same volume. Missing proof, changed configuration or writer death removes
readiness. Docker-local PostgreSQL is the supported proof topology; unprovable
external database configurations fail closed. Aggregate readiness still requires
authoritative root history and complete native owner coverage. Unknown storage supplier-cost history blocks new gateway writes and public
handoffs. Existing object reads, metadata checks and deletion remain available
under the existing request/rate and known-spend guards so recovery and reducing
occupancy remain possible. Their unknown supplier costs remain visible; this
recovery policy is not a complete financial cost ceiling. No storage upgrade is
active and no customer data is automatically deleted on downgrade.
Native X consumes a canonical organization-owned credential when selected and
otherwise uses its explicitly configured native platform account. The customer
path shares the existing X feature switches, fixed API origin, response bounds and
no-retry publishing transport. Missing/invalid customer tokens never trigger
platform-token fallback, and foreign-organization references are rejected before
admission. A captured native X response, including the confirmed post ID, replays
from the existing scoped reservation before another dispatch. Missing authoritative
supplier units keep that reservation unknown and held; a response lost before
capture cannot authorize a retry. Native SES selects either the root native
account or the exact tenant-owned `providers-manager/{org}/email-ses` credential.
Tenant credentials use the existing
credential PUT envelope with a JSON value containing `version: 1`, `accessKey`,
`secretKey`, `region`, and `configurationSet`. The tenant profile is bound before
the credential is stored; deleting it preserves that binding. Missing, malformed,
foreign, or profile-mismatched credentials fail closed without using the root
account. Tenant execution remains customer-funded and uses the existing exact
organization/site sender-domain authorization.

No change in this branch is deployed to production. Local live-Dovecot and signed
backend smoke tests verify enforcement, copied-database rejection and loss of
readiness after the mail master exits; they do not establish production rollout. Approved plan quantities,
customer conversion rates, supplier billing configuration, installed extension
versions and signed runtime/Stripe environments must be verified before launch.
The protocol is authoritative; its unfinished paths are explicitly unavailable.

### Native Pay base-binding read

Pay must export the additive `capacity.binding.read` operation. It has **only**
the internal extension-service route `cedros-pay:capacity-binding-read-v1` at
`POST /extensions/cedros-pay/capacity/v1/binding/read`; there is no public HTTP
buyer endpoint. The `Invocation` has null delegation and request key and command
`{organizationId}`. Native Data supplies authenticated extension-service context,
principal/actor `cedros-data`, the exact capability claim and the same organization.
Pay verifies installation/environment from its installed settings and confines the
organization to its trusted customer/base-subscription bindings. This read must
never call back into Data. Public/internal IDs for the existing Pay buyer operations
remain distinct and unchanged. The four Data core operations likewise declare
`transport: extension-service-only`; their operation paths now match their existing
service bindings instead of suggesting unimplemented HTTP aliases.

`BillingBindingResponse` supplies installation, environment, organization,
`bindingRevision`, freshness and the complete base-subscription list. Each subscription
has a stable ID, customer-facing display name, recovery/eligibility state, offer IDs
and included allowance contributions in approved service-owner units. `BaseAllowance`
includes meter, unit, canonical nullable site ID, explicit limit state, included
quantity and meter-specific `offerIds` (a subset of the base subscription's offers). Pay must exclude add-ons from base selection, verify organization/customer
ownership, and use the approved plan-to-meter mappings. Do not infer allowances from
price, Stripe quantity alone, a paginated site list, or wholesale provider guards.
A missing mapping is unconfigured, never zero. Do not include Stripe customer IDs,
prices, credentials, provider records or arbitrary metadata. A genuinely unsubscribed
organization has an authoritative empty list; an unavailable source returns 503.

Finite applicable contributions add; duplicate subscription IDs or scope/meter rows
are rejected. Conflicting limit states are unavailable until the owner mapping is
corrected. Revision-2 contributions use canonical site IDs for explicit site ceilings and
null scope for organization pools. The legacy site-local meters retain their old scope. A binding revision is opaque and immutable for its contents;
Data orders observations by their timestamp and rejects revision-content conflicts.
Freshness is at most 60 seconds. Oversized/incomplete projections fail rather than
truncate. This read is required for Data discovery, delegation and reconciliation;
its absence keeps those operations unavailable without manufacturing subscription
ownership from Deploy records. Pay's financial quote, purchase and grant wire shapes
are unchanged.

Reviewed prerequisites: Portal `1e095d6`, Providers Manager `8d86f69`
(`HOST_HANDOFF.md`, managed usage policy), Pay `a823f02b` (base-plan isolation).
Data adopts the service identities, units, precision and lifecycle rules below
as the final integration standard, incorporating the teams' concrete amendments.

## Usage read

Add fields inside `usage`, preserving `windowDays` and `sites`. Portal detects
`schemaVersion`; absence means the legacy hosting-only response, never zero
service usage. Version 1 includes complete `siteCount`, `meters`, `generatedAt`,
and `organizationId`. The initial response includes all applicable meter scopes;
there is no implicit pagination or truncation. If response limits prevent a
complete answer, fail explicitly. A future paginated detail API is a separate
versioned change. Organization totals cannot be calculated from a UI page.

Usage 1.1 adds `operationalBreakdowns` beside the purchased-capacity
`breakdowns`. Its Email rows report provider-confirmed accepted recipients for
customer-funded, local or unknown funding without a budget meter, reservation or
customer charge. Root-managed dispatches use provider receipt identities to
deduplicate repeated persistence; direct site sends use the durable physical
attempt identity, so a retry that contacts the provider again remains a distinct
dispatch. A request is staged before provider dispatch, so a lost completion
remains an unresolved observation. Root reads direct aggregates through the
same signed, deployment-bound Controls transport used by native capacity
evidence and reports an unavailable site source as `partial`. Missing
pre-cutover history, missing receipts, conflicting receipt facts and unknown
credential ownership remain `partial`; they are never converted to zero. Usage
1.0 stays strict and does not accept this field.

Usage 1.2 may add the optional `providerActivity` projection for customer-funded
BYOK provider activity. It is operational evidence, separate from purchased
capacity `breakdowns`, reservations, credits, tokens, supplier cost, and customer
charges. Each row records operation counts only: observed, succeeded, failed,
pending, and unknown operations for a provider family and operation. `categoryId`
and `providerId` may be null. In particular, unclassified SEO or Voice activity
remains visible with a null category rather than being assigned an invented
customer category. `coverage` stays `partial` until the month has a qualified
provider-activity baseline; omitted rows, missing provider identity, or pending
or unknown outcomes also keep the projection partial. A complete projection
describes the evidence in this read only; it does not qualify a live provider.

`siteCount` comes from `portal_site_eligibility`, including its existing Deploy /
Fleet deduplication and failed/deleted status semantics. It is not `sites.length`.
Site meter scope uses the canonical Portal site ID (Deploy ID when linked to an
actual Deploy row, otherwise Fleet ID); the host resolves runtime IDs internally.
An organization meter appears once, with site attribution in the ledger. Site
ceilings constrain this pool; they do not multiply it.

Every amount is an integer in [0, 9007199254740991] in the declared unit, or null
where the schema permits unknown/not applicable. Use checked integer arithmetic.
Never coerce overflow, source failure, an empty result, or missing configuration
into zero. `limited` with `effectiveCap: 0` is an explicit zero allowance;
`unlimited` requires an affirmative entitlement; `unconfigured` has no approved
allowance; `externally_managed` represents BYO/external enforcement. The last three
states have null cap and remaining. `unavailable` is a source state independent
of entitlement configuration. Measured zero is allowed only with an available
source. Partial/stale values remain labelled with their actual observation time.

`freshness` separately describes usage, allowance and reservation sources, with
`observedAt` and `validUntil`. Null timestamps mean unknown. An available source
requires both timestamps and `observedAt <= generatedAt < validUntil`. Overall
availability is the worst applicable state: unavailable, stale, partial, available.
Known fields may remain visible during another source's failure; `remaining`
must be null unless all three sources and the applied revision are current.
Do not stamp the response time onto old rollups. Missing services still get a
row with unavailable sources and null amounts, rather than disappearing.

`included + purchased = effectiveCap` for a known finite allowance. `purchased`
counts only effective, verified grants applied by the enforcing owner; pending
paid grants are shown in purchase status. `remaining = max(0, cap-used-reserved)`
only within one scope, unit, period and applied revision. Consumed usage can
exceed a reduced cap and is never erased. Operational restrictions are separate;
the displayed cap must not promise admission through a throttle or suspension.

`period` explicitly distinguishes UTC calendar month, rolling 24 hours, rolling
minute, subscription interval, and occupancy. Rolling windows have no discrete
reset (`resetsAt: null`); occupancy has no boundaries or reset. Existing daily
request counts are rolling 24 hours and monthly counts use a calendar month;
neither is a subscription-period allowance. New calendar-month meters require
UTC boundaries and no rollover. Grant expiry and financial renewal dates do not
change the meter's reset date.

All authenticated organization members may read Usage under existing
`PortalAuthority::Read`. Offers/status may be read with that authority after
scope verification; omit payment secrets and payment-method details. Preview,
authorization, checkout, and financial mutations require existing
`BillingManage`: owner, admin, billing-admin, billing_admin. Cache public meter
data separately from actor-specific eligibility, or key by actor and authority
as well as organization and site. Recheck membership on every operation.

## Catalog and commercial meaning — accounting revision 2

| Customer category | Customer quantity | Budget and retained breakdowns |
|---|---|---|
| Sites / Hosting | current allocated sites | `sites.count`, no reset. CPU, memory, physical disk, traffic and requests remain operational. Developer adds sites; it does not multiply Individual service budgets. |
| Intelligence | configured customer credits | AI execution, continuations, generation/editing images share one allocation. Retain provider/model/modality/tokens/image settings and activity separately. |
| Email | provider-accepted outbound recipients | `email.recipient-acceptances`, UTC calendar month. All tenant-attributable workflows, including transactional, notifications, replies, recovery and security. |
| Search | configured customer credits | Native extraction, Exa searches and Exa contents retain provider/operation and native cost dimensions. Cache activity cannot invent supplier usage. |
| Blockchain / Solana RPC | configured customer credits | Retain RPC method, provider-native billable units and call activity; no built-in universal method-price table. |
| X API | configured customer credits | Retain endpoints, read/write subtype and returned/billed resource counts; no equal-cost action allowance. |
| Storage | logical retained bytes | `storage.occupied-bytes`, no reset. Files/documents, mail, attachments and media; local and provider-specific breakdowns belong to this category. |

`managed.credits` can fund Intelligence, Search, Blockchain and X API together.
An explicitly configured category-specific credit meter is also supported. A
`BaseAllowance.categories` array maps categories to **one** organization budget;
the cap is published once in `meters`. `Usage.categories[].budgetMeterIds` supplies
references rather than duplicating a shared cap into every category. Site limits
are additional restrictions. Their quantities are not added to the organization
pool. `credit` is an integer customer unit; supplier cost is tracked separately in
micro-USD. Operator-approved rational conversion rates govern both quantities;
a customer credit is never implicitly one supplier dollar. Supplier micro-USD
is calculated from observed units and the snapshotted configured rate; it is not
proof of the provider's final invoice. Provider invoice reconciliation and rate
verification are separate activation requirements.

Platform-owned provider profile `accountingV2` holds immutable-at-admission pricing
rules. Customer-owned profile metadata cannot price Cedros-funded operations;
native synchronized SES/X tenant profiles resolve pricing from the matching
platform-owned profile through the existing profile store. Admission snapshots
the pricing profile ID, revision and configured version in the pricing version
identity. Missing or disabled platform pricing is unavailable for funded admission.
BYOK execution does not load Cedros pricing. The existing revision-fenced
`PATCH /admin/runtime/cedros-providers-manager/provider-profiles` permits the
platform operator with `OpsWrite` to change only `metadata.accountingV2` on
system-managed SES/X profiles, preserving all native connection settings and
other metadata. An empty rule array disables funded execution. Bootstrap
preserves these rules; full profile replacement and native credential mutation
remain disallowed through that profile endpoint.

Cedros-funded xAI text is unavailable until its separately billed reasoning tokens
have a verified execution ceiling and a complete approved native pricing mapping.
The current Chat Completions adapter preserves that metric but its visible output
limit is insufficient funding authority. Customer-owned xAI text and the separately
bounded delivered-image adapter retain their existing paths. Dedicated RPC and X API
credit meters remain historical/catalog vocabulary but cannot authorize a new sale:
RPC has no native accounting dimensions and X API has no current managed executor.

Organization-owned X tokens use the existing authenticated
`PUT /admin/runtime/cedros-providers-manager/provider-profiles/x/credential`.
Data binds `providers-manager/{organizationId}/x` before storing the secret.
Deletion retains the customer account binding: an absent or invalid token fails
without platform fallback, including after bootstrap or a feature-switch change.
The native client retains the fixed X origin, response/request limits, no automatic
publish retries and separate publishing switch. SES still consumes its native
platform account; unsupported credential references fail before reservation.

Existing notification/channel identities, calendar effect IDs and extension
email outbox idempotency keys now feed hashed email operation identities into
the same admission ledger. They do not create a second delivery ledger or infer
acceptance. Correlation-only local provider chains retain their existing delivery
semantics; unknown managed outcomes remain held for reconciliation.
Managed extension AI follows the same trust rule: the host replaces every
`cedrosExtension` attribution field, checks the resolved organization/site against
the configured managed transport, and binds any supplied idempotency correlation
to organization, site, extension, access, provider and operation. Missing
correlation is preserved until the root accounting boundary knows the funding;
only Cedros-funded work requires it. This correlation is retry identity, not
authorization, and direct customer-key/local execution retains its existing path.
The configured rules contain:
`version`, exact `operation` and `model`, `category`, `meterId`,
`maxRequestBytes`, nullable `maxOutputTokens`, `requestSchema`, and `rates`.
Each rate binds `metric`, `unit`, `maximum`, `supplierMicroUsd`,
`customerCredits`, and positive `divisor`. Rates and quantities are nonnegative
integers; accumulate rational prices before rounding up once. Exactly one rule must match the request schema; ambiguous or unmatched settings
are unavailable. The request schema must constrain the approved model, modality, settings, fanout and resource bounds.
Missing, ambiguous, unsupported or stale configuration rejects paid execution.
Native generation adapters apply the server output bound. An actual observation
outside configured bounds remains unresolved, never becomes a fabricated zero.
No supplier or customer rates are supplied by this standard.

Pay's existing native binding read adds `accountingVersion: 2` only at the
approved cutover. `includedAllowances` remains the owner API; no second plan or
entitlement source is introduced. Approved plan configuration must supply actual
values. Workbook scenarios and Developer plan names do not create allowances.
`purchasedCreditPolicy` explicitly describes purchased allowance behavior. The
currently implemented policy is `calendar_month_recurring_no_rollover`: recurring
capacity supplies each UTC month, within independently verified grant effective
and expiry times. Unsupported or unconfigured rollover/one-time credit policies
remain unavailable; do not silently give them monthly expiry. Sites/storage
remain occupancy entitlements and are unaffected by monthly boundaries.

SEO/Ahrefs and Voice/ElevenLabs are always customer-funded integrations, outside
Cedros included/top-up products. The credential installed by native Manager's
organization credential API determines funding. An organization profile referring
to a Cedros key is not BYOK. Invalid/missing customer keys fail; no Cedros fallback.
Adapters that resolve native global accounts (currently SES and X) must never be
labeled customer-funded from a profile metadata flag. Local infrastructure costs
remain Cedros costs even when a customer's external API key funds an operation.

Email acceptance is distinct from delivery: a later bounce does not refund an
accepted recipient. Unknown outcomes retain their reservations; retries at the instrumented native
gateway cannot send again merely because a worker timed out. Partial acceptance settles the
provider's accepted subset. Platform-owned correspondence carries its own internal
allocation. Data now implements `identity.outbox.enqueue-token-email`, which
atomically persists the Login verification, initial outbox item and immutable,
PII-free purpose/message receipt. The additive
`cedros-data:token-email-evidence-v1` capability makes rollout Data-before-Login:
a Login version that requires the operation fails installation on an older host.
The extension email adapter accepts the opaque claim only for the fixed Login
extension/access identity and exact recipient, content and durable delivery key.
The root gateway then reads that receipt over the signed financial Controls source
for the exact native Deploy/Fleet identity described below, rechecks purpose,
message digest, scope and operation identity, and admits it only against an
explicitly configured nonzero central monthly cap and allowed-purpose set. It
records accepted recipient units and supplier cost under
`internal.email.essential-recipient-acceptances` without consuming or updating a
customer purchased-capacity application. Caller-supplied purpose flags and subjects
still cannot authorize the allowance. No default cap, price or live policy is
introduced. Local native/TLS and installed-candidate tests exercise receipt
issuance and lookup plus the Login forgot-password outbox path. Deployment must
preserve Data-before-Login ordering; production source identities, installed
versions and policy configuration remain activation evidence.

Historical request/image/URL/voice/SEO and campaign-only meters remain immutable
history. They cannot authorize new purchases, and their unreliable logs are not
converted into credits or retroactively billed. Existing financial acceptance and
snapshot reconciliation remain idempotent. New offer versions must bind the new
meter/unit and approved conversion policy. Base-plan isolation is unchanged.
The old `cedros-addon-managed-capacity` request mapping and campaign-only mapping
must not be reused without a new immutable offer/version. Voice/SEO/image-only
Cedros-funded offers are prohibited.

Storage routing remains R2 for site/public media and DigitalOcean for private
files, backups and existing non-media workloads. Immutable object locations
preserve old DigitalOcean media reads after the new-write route switches to R2.
Inventory must follow actual residence. Migration copies, platform backups,
replicas, temporary staging and internal indexes add physical costs but do not
multiply logical customer assets. Retained generated files use Storage, without
adding a second Intelligence charge. Over-cap downgrades block growth, not delete
customer data.

## Decision record and incorporated amendments

The standard incorporates Pay's patch against `a12fa68c67`, Providers Manager's
catalog/lifecycle and R1/R2 requests recorded at `7326d1f`, and Portal's discovery,
permissions, recovery, freshness and reservation requirements. Data's final
decision supersedes the former unanimous-review workflow. The record below
explains what was incorporated; it does not solicit another sign-off round.

| Review requests | Amended normative sections / artifacts |
|---|---|
| Pay 1 | Invocation, delegation and exact `serviceBindings` / core registrations |
| Pay 2; Portal 2 | Immutable quote, capacity increase, interval count and currency |
| Pay 3; Manager M1; Portal lifecycle | Recurring service / payment attempts / grants |
| Pay 4; Portal 5 | Uniqueness, acceptance, recovery and actions |
| Pay 5; Portal 3 | Member-safe status and role mapping |
| Pay 6; Portal 4, 6 | Atomic snapshot publication, freshness and Usage receipt |
| Pay 7 | HTTP mappings and executable fixture checks |
| Portal 1 | Target discovery and recovery destinations |
| Portal 7 | Fenced site reservation migration and operation bindings |
| Manager M2, M3 | Local accounting / read-apply-ack; versioned guard migration |
| Pay 0.2.0 request 1 | Distinct public/service route IDs in operations and serviceBindings; union registration check |
| Pay 0.2.0 request 2 | Immutable grant bindings; confined snapshots; duplicate-page/completion replay and revision-zero bootstrap |
| Pay 0.2.0 request 3 | Durable idempotency receipts for all mutations, independent of response-cache retention |
| Manager 0.2.0 R1 | Separate schedule/enforcement identities, strict writer acknowledgement and organization revision mappings |
| Manager 0.2.0 R2 | Complete per-operation guard decisions, immutable values, server approval and atomic migration |

## Invocation, delegation and exact registrations

The existing WIT `server/wit/cedros-extension.wit:314` carries target extension,
route ID, capability ID, method, path, query and body JSON. It carries no original
buyer or request header. `extension_service_routes.rs` constructs a context whose
actor is the **calling extension**, not a customer. Do not reinterpret it as a
buyer. `staging_sync_service.rs` already uses an opaque server-issued authorization
and a request key inside JSON; use that pattern without reusing its unrelated
staging permission or token namespace.

Every internal invocation uses the exact `serviceBindings` JSON table:
`target-extension-id`, `route-id`, `capability-id`, POST, exact concrete `path`,
empty query, and `body-json` serialized from `Invocation`:
`{contractVersion, operationId, delegationId, requestKey, command}`. Command is
validated against that operation's request schema, with no extra fields. Public
HTTP operations retain the six original Pay paths; their HTTP adapters translate
to the same domain command. Internal POST paths differ from public GET paths so
there is no GET-body ambiguity. No caller-supplied headers are forwarded. The required public Pay HTTP adapter
accepts `X-Cedros-Capacity-Delegation` and `Idempotency-Key` alongside existing
Login authentication, and moves those values into the Invocation body. The
operation requestSchema remains the JSON command. These are required header
bindings that Pay must implement. Native Data owner HTTP routes
continue using their established verified owner authentication.

Pay public HTTP route IDs end in `-http-v1`; internal service route IDs keep
their `-v1` IDs. The capability ID names the authorized operation and remains the
internal service ID. Public and internal paths share a domain command, not a
route registration. Register both IDs from the exact tables; the Data registry
permits one method/path per extension/route ID. The checker validates the union
of public Pay and internal service registrations, not each table in isolation.

`requestKey` is the public Idempotency-Key transported as JSON. It is required
for mutations and null for reads. Missing keys and inconsistent header/body keys
are 422. Keep the exact key on retries. Service handlers reject an operation ID,
method, path or exact capability mismatch. Data registrations are enumerated in
`coreCapabilityRegistrations`, all **required-not-registered**. Implementation must
update the published-core allowlist in `extension_service_routes.rs`, Core
capability declarations in `extension_platform.rs`, and compose dispatch into
`staging_sync_service.rs::CoreServices` / `extension_runtime_host.rs`; do not
replace the existing wallet/staging handlers. Pay must register every listed
service route and implement its guest-to-domain invocation adapter. Capability
publication remains withheld until those handlers and authorization tests pass.

For financial and delegated capacity mutations, scope a durable idempotency receipt by operation ID, Pay
installation, payment environment, organization, authenticated acting user, and
request key. Compare the entire canonical command (including target, action,
quantity and referenced quote digest); changed input under the same scoped key
returns 409 idempotency_conflict before side effects. Public and internal adapters
share the same operation identity. Distinct operations or actors have distinct
receipts, but never bypass quote/purchase/authorization financial uniqueness.
Keep canonical request digests and durable outcomes for the financial audit
lifetime, including billing actions, cancellation and authorization redemption.
Expiry of a delegation or removal of a response cache cannot remove these records
or financial uniqueness indexes. Replay always rechecks current authorization,
except the explicitly confined trusted recovery of an already accepted purchase.
An expired action URL stays expired: replay returns the same action/outcome;
a newly authorized action needs a new key and creates no duplicate charge.
Concurrent receipt claim, outcome publication and financial state changes require
atomic native persistence; the in-memory reference is not that implementation.
The new native guard-approval and Portal migration-import operations have no Pay
installation or buyer delegation. Their explicit `idempotencyScope` metadata
and operation-specific rules below apply instead; current operator/host authority
is still required on every replay.

Portal first obtains a delegation through the owner route specified here
`POST /portal/v1/billing/capacity/delegations` using the existing verified owner
facade identity. Data verifies current Login membership and the authority needed
for the requested operation. It stores a hash of a cryptographically random
opaque token, exact operation/command/request key, acting user, organization,
canonical site, target Pay installation and environment, allowed calling
extension and expiry (at most five minutes). The returned delegation ID is a
secret bearer reference restricted to that binding, not a free-form identity.
Do not put it in URLs, logs or durable customer projections. Store tokens using
the existing secret handling pattern; no new shared browser or provider secret.

A Pay HTTP request must still authenticate its Login buyer. Its domain adapter
presents the delegation to Data `capacity.delegation.check` via the host service
route and requires that the returned acting user matches that Login buyer.
A host invocation from Portal has no second buyer header: Pay uses Data's checked
delegation as the original buyer evidence. Data verifies the host-fixed caller,
token hash, command, operation and key, then current membership and expiry.
For scope-check/redemption, the adapter supplies the original delegated operation
and command to delegation-check, then compares the extracted target or accepted
quote to the leaf command. A token for an unrelated read cannot authorize a
purchase. Neither guest-supplied actor fields nor `auth_scheme=extension-service` alone
constitute buyer authority. Delegations cannot be minted by an extension merely
asserting a buyer ID. Browser cookie routes retain CSRF protections.

Installation identity comes from the host's installed Pay record and server-side
billing-account binding; `test/live` comes from that installation's verified Pay
configuration. The generic route-context environment label (managed/self-hosted)
is not a payment environment. Missing or inconsistent mapping returns 503 and
withholds offers. Data scope-check/delegation-check/redemption are **leaf local
operations**, using verified persisted organization/subscription bindings, and
never call Pay. Binding synchronization/discovery is a separate native job. No
Data scope check may infer account ownership just from a Deploy subscription ID.

Trusted Data reads of Pay quote/purchase/grant records use a new **native Data
adapter** into the installed Pay service routes, with host-fixed core principal,
exact capability, installation/environment/org confinement and null delegation.
The current `client("cedros-data")` is not this adapter: normal clients require
an installed calling manifest. Implement this explicit core dispatch path before
publishing it. Pay's trusted-read branch validates the native host identity and
returns persisted records without calling Data. Thus Data authorization → Pay
quote read ends at Pay; Portal → Pay → Data delegation check ends at Data. Grant
hints only durably enqueue work; reconciliation runs after the hint call returns.
No nested Pay → Data → Pay callback or invented Data guest manifest is allowed.
The exact native context fields are in `invocationMechanism.nativeDataContext`;
only the native dispatcher may construct that principal. A guest body claiming
those fields is rejected. Internal trusted replay is restricted to an existing
purchase/quote/digest under the verified Pay installation; absence of a live
delegation can never create a new acceptance.

## Target discovery, permissions and safe actions

Data `capacity.targets` returns canonical organization/site names and eligible
base-subscription targets from verified billing ownership and the complete site
eligibility projection. It returns every supported target through explicit opaque
cursors pinned to one discovery snapshot, never a paginated UI-site inference.
Unknown sources produce `destination: unavailable`, not an empty subscribed
account. No active base plan produces `base_plan_selection`; past due produces
`billing_recovery`. These destination tokens select Portal's existing base-plan
chooser or billing recovery flow; they are not arbitrary URLs. Add-ons cannot
be base selections. Each target carries offer IDs; offer lookup uses its exact
`Target`, and every subsequent operation revalidates ownership.

Read authority permits Usage, discovery, offers and sanitized purchase/status
listing. BillingManage is required for preview, delegation of billing mutations,
authorization, purchase, cancellation and payment actions. Portal must extend its
Login role parser to map `billing-admin` and `billing_admin` to **billing-only**
authority; it must not map them to owner/admin or grant site/team/security rights.
Unknown roles fail closed. Site reservation operations retain SiteManage.

`PayPurchaseResponse` and `StatusResponse` contain no checkout/action URL. The
separate `capacity.billing.action` operation authenticates a current BillingManage
actor, records `actingUserId`, and returns a short-lived action URL. Another
billing administrator may manage the organization's purchase; immutable
`originalPurchaserId` remains unchanged and each action is separately audited.
This requires an organization-owned Pay financial customer. If provider action
semantics require the original payer, fail closed with 403 rather than share that
payer's link. Member reads do not contain delegation, payment method or financial
provider secrets. URLs are returned only by this action response.

Pay constructs checkout success/cancel URLs from the installed Portal's approved
origin and fixed recovery route, with an opaque expiring return reference bound
to purchase/installation/environment. The customer cannot choose an arbitrary
return URL. Return parameters never prove payment. Data's organization-scoped
`capacity.purchases.list` supports a `quoteId` filter and snapshot-pinned cursors,
so lost responses/session storage do not strand purchases. After Login recovery,
authorized users can recover accepted purchases by organization without the
original request key. No session is required for trusted financial reconciliation.
Activation retries are automatic durable jobs; the browser refreshes status and
must not create another purchase to retry application.

## Complete quote, additional items and financial acceptance

`quantity` means **additional purchased items**, not a new total subscription
quantity. Enforce offer minimum/maximum/step on the server. `Terms` only accepts
billing interval count 1 in this release; catalog offers with count >1 are
ineligible and preview returns 422 `unsupported_interval`. The amount per item
is allowance per UTC calendar month, including annual-billed offers; occupancy
items are a simultaneous site/byte ceiling. No unit proration or rollover.

`Quote` includes the entire Binding, tax, subtotal, total due, renewal total and
renewal tax, currency minor-unit digits, effective and paid-through times,
server-computed `capacityIncrease` (scope/meter/unit/period/amount), and acceptance
policy. Increase is checked `quantity * allowancePerItem`, not arithmetic trusted
from Portal. All money is an integer in that currency's minor unit: display
amount / 10^currencyMinorUnitDigits using localized formatting, never hard-coded
cents. Total due includes tax. Renewal total also includes the quoted renewal tax
and is an estimate for the next billing period; tax changes require a new
Pay-authenticated billing-period record under accepted terms, never editing the
initial accepted quote. Unknown tax/amount prevents preview acceptance.

`PreviewResponse = {quote, quoteDigest}`; digest scheme is
`capacity-json-v1`: SHA-256 of UTF-8 compact JSON with recursively lexicographically
sorted object keys, array order unchanged, unescaped Unicode and standard JSON
escapes, no whitespace, no floats/NaN, safe-range integers only. Field names are
ASCII and the digest covers the **entire Quote including contractVersion**.
No Unicode normalization is applied. Prefix the lowercase hex digest `sha256:`.
Duplicate JSON keys must be rejected before parsing. The fixture runner includes
the canonicalizer; it is not claimed to be general RFC canonical JSON.

Data fetches the stored quote through the leaf trusted read, validates digest,
current membership, scope and runtime eligibility, and persists the full immutable
snapshot with authorization. Pay redemption sends quote ID and digest; Data
compares against the stored snapshot, never a subset Binding. Any changed tax,
amount, effective date or paid-through date invalidates authorization. Quote and
snapshot remain available through authorized purchase reads after quote expiry.

Pay durably claims a purchase ID **before** invoking Data redemption. Acceptance
is the atomic Data redemption at a server timestamp strictly before quote expiry,
recorded in Pay through retry/reconciliation. Data rechecks current mutation
authority on first redemption. Pay must not create a charge before confirmed
redemption. Lost redemption responses query/replay the durable result. Expiry
prevents first acceptance, not replay or completion of an accepted purchase.

There is one accepted purchase per `(installation, environment, quoteId)` and one
redemption target per authorization, independent of Idempotency-Key, buyer retry
key, or multiple authorizations. Data additionally binds the quote itself to the
purchase ID, so minting a second authorization cannot evade uniqueness. Pay
returns the existing purchase for compatible retries; conflicting bindings fail
409. Concurrent attempts under different keys cannot create a second charge.
Provider payment idempotency derives from stable purchase/billing-period/attempt
identity, not a fresh browser key. An ambiguous outcome stays pending and is
reconciled against that provider identity; do not start another charge until its
outcome is known. Trusted replay after expiry/session loss must match an already
accepted record; it cannot create fresh acceptance or change the acting buyer.

Delayed payment confirmation activates only the remaining portion of the quoted
[effectiveAt, paidThrough) interval; no silent repricing, shifted dates or reset.
After paidThrough, settlement may still be recorded as paid, but capacity is
expired; Pay must resolve the payment under accepted refund/credit terms. Such
terms must be configured before sales. Until confirmed financial eligibility,
no new grant exists. An accepted quote is never replaced by a newer catalog price.

## Recurring service, grants and payment attempts

`purchaseId` identifies one stable recurring add-on purchase across renewals;
independent purchases may add capacity. `initialAttempt` and `latestAttempt`
carry durable `attemptId`, `billingPeriodId`, initial/renewal kind, financial
interval, payment freshness, refund revision and dispute state. `initialAttempt`
is the latest attempt for the initial billing period, not permanently the first
failed attempt; older attempts remain in Pay audit history. New payment attempts
within a period require a definitively resolved prior failure; ambiguous outcomes
continue using the same attempt identity. The recurring
service has a separate cancellation/paid-through state. A failed or canceled
**initial** payment grants nothing; a failed/canceled/action-required **renewal**
does not revoke previous paid-through capacity. Cancellation stops renewal at the
paid-through boundary, not the current payment or grant. BillingManage may call
`capacity.cancel` with `at_paid_through`; immediate destructive cancellation is
not offered. Replays return the original effective cancellation and actor audit.

Partial refunds do not translate money into units. Pay publishes an explicit
approved revised allowance, possibly unchanged for a monetary-only refund.
Dispute opening may revoke at its explicit effective time; a won dispute may
restore via a higher active revision, while a lost dispute retains revocation.
Data does not infer reinstatement from a payment status string. Preserve consumed
units and all admitted reservations throughout refund/dispute changes. A failed
renewal with active paid capacity is expressly valid in `StatusResponse`.

Each grant binds the immutable initial quote snapshot plus billing-period/payment
attempt IDs, financial interval, allowance, and `revisionEffectiveAt`. Annual
billing permits the same contribution each calendar month during that year, not
12 times the monthly cap. Adjacent renewal intervals do not overlap. Reject
overlapping or duplicate interval grants for the same installation/environment/
purchase/scope/meter even with different IDs. Across revisions of one grant,
purchaseId, authorizationId, quoteId, the entire initial snapshot, billingPeriodId,
paymentAttemptId and [effectiveAt, expiresAt)
are immutable. Validate the embedded quote digest and matching quoteId; recomputing
a digest does not authorize rebinding a known grant. Renewal uses a new grant ID
and billing-period identity, retaining the original purchase/quote binding.
Initial revision effectivity equals
effectiveAt; revocation effectivity equals revocationEffectiveAt. Higher revisions
may arrive early; retain the prior effective revision until the transition.
Reject retrograde revision schedules. Corrections received after their effective
time apply immediately on publication while preserving historical settlements;
the new effective timestamp must not precede the prior revision effective time.

Reservations and settlement remain pinned to the **admission calendar period**,
even after midnight. Allocate included capacity first, then purchases by earliest
expiry and grant ID. Track recurring allocation by purchase and calendar period
so adjacent mid-month renewal replaces the item's contribution instead of
refilling consumed allowance. A reduction may leave used > cap; do not erase
usage, double-subtract consumption or reject settlement of admitted work.

## Atomic snapshots, enforcement revision and freshness

Stage every snapshot page under installation/environment/org/snapshot ID, page
index, high-water source revision and immutable snapshot digest. Cursors bind the
same snapshot; expiry restarts collection. The digest uses capacity-json-v1 over
`{payInstallationId, environment, organizationId, sourceRevision, grants}` with
grants sorted by grant ID then numeric revision. Keep historical and scheduled
revisions needed for transitions. Verify all pages and explicit tombstones,
overlap and revision rules before **one transaction** publishes the new ledger
view and advances the source checkpoint. Every page and every embedded grant
must match the trusted requested Pay installation, environment and organization. Reject a mismatched page or grant
before staging. Exact page retries return their stored outcome without appending
again; completed-snapshot retries never republish or move the checkpoint.
A changed payload at the same snapshot ID/page index conflicts. A fresh snapshot
at the current source revision is permitted only with the same source digest;
older unknown snapshots fail closed, while recorded exact replays are no-ops.
No checkpoint is distinct from source revision zero: an initial empty complete
revision-zero snapshot must publish successfully. Preserve replay receipts across
restarts. A rejected final page must leave its staging position retryable; an
expired cursor restarts collection under a new snapshot without changing live data.
No page changes live allowances. This
prevents replacement grants split across pages being counted together. Absence
is not revocation; Pay must retain explicit tombstones until all consumers have
reconciled. Older/conflicting snapshots cannot replace newer published state.

Data maps a published source revision to a desired organization revision
`{epoch, sequence}`; sequence increases within a persistent epoch. The mapping is
stored, never inferred by Portal from Pay revision numbers. Scheduled changes
create a new desired revision when effective. Applied revision advances only
when the central resolver and every affected enforcing runtime acknowledge the
same desired state. Mixed application remains applying; reads use each owner's
actual applied state with unavailable/partial status and no invented remaining.
Unknown epochs cannot be compared; restore/migration requires explicit fencing.

Active status includes affected MeterRefs and an opaque Data-issued `usageReceipt`
bound to organization, purchase and applied revision. Portal sends it as
`minimumReceipt` on the existing Usage GET. Data returns Usage at that revision
or a newer same-epoch revision, otherwise 409 `revision_not_applied` or 503 if
unavailable. Portal discards earlier in-flight responses after observing active;
it never compares opaque strings or mixes pre-receipt balances into that view.
Data invalidates caches on publication and application, rejects late cache fills
from an old revision, and also aligns `cedros.portal.siteQuantity` with this
resolver before sales. A current lower cap after revocation is valid newer data.

Payment, recurring service, capacity, offers and discovery have separate Source
freshness. Available means observedAt <= now < validUntil. A missing observation
uses unknown and null timestamps; it cannot assert paid, failed, zero or active.
Upon expiry, retain a prior active observation as `last_confirmed_active`, not
active. Other prior states remain explicitly stale; no action eligibility can be
inferred from them. Capacity unknown has null revisions and no Usage receipt.
Status may return null purchase when its source is unavailable after local scope
authorization; nonexistent or other-org IDs remain 404. Browser clocks may render
age but server freshness is authoritative. Expiry never extends itself on a
cached read. Paid + pending/applying/application_failed remains distinct from
active and supports recovery without repurchasing.

## Local quota accounting and signed read/apply/ack

Data owns transport, reconciliation and both ends of runtime application. Native
mail plus Dovecot own mail enforcement; local-media storage owns media enforcement.
Manager owns policy review. Exact required POST paths are the three
`capacity.local.*` operation bindings below `/managed-services/controls/v1/capacity/`.
Reuse `controls_source_transport.rs` signed method/path/body/site/actor assertions,
nonce/time validation and no redirects. Financial essential-email receipt reads,
quota observations and Storage commands use its stricter financial transport.
That transport accepts only an active Fleet runtime backed by the exact root-owned
native Deploy row: Fleet runtime ID, Fleet Deploy ID and Deploy ID are equal;
organization/account and customer/owner match; the Deploy row is the root control
site in a ready status with a provisioned target. It resolves HTTPS only from the
canonical `deploy_sites.subdomain_fqdn`, never a Fleet-reported `publicHostname`.
Managed registration derives and persists that canonical hostname in the same
site write transaction. A missing or mismatched trusted Deploy row makes financial
readiness unavailable. The generic legacy/nonfinancial Controls request retains
its existing transport behavior. These are new source handlers, not existing admin
routes. Assert the control-plane service actor
`cedros-data:capacity-reconciler-v1`; the runtime verifies that reserved
actor and an explicit quota-control registration on this exact route. The current
assertion has no capability claim field: do not pretend it does. Ordinary
email-read actors/assertions do not authorize quota mutation. Bind organization, canonical site, runtime site and runtime
installation independently against runtime registration. No customer/admin
credential is forwarded to Portal or exposed in these bodies.

Local mail and media are Storage breakdowns. The existing mail site-quota view
also includes internal index/history bytes, and the local-media guard includes
staging. Those are physical safety measurements, not the revised customer logical
storage quantity. Logical accounting must exclude those copies while preserving
physical infrastructure guards. Count mailbox message/attachment content once per
retained logical asset; do not sum mailbox caps or repeated site totals per user.
Storage bytes follow the asset's recorded destination, not current provider choice.
Native local-media read/apply/ack now uses the existing Controls signature and
exact reserved actor. Fleet presence advertises its locally persisted organization,
canonical site, runtime site and installation binding; incoming commands cannot
create or replace that binding. Rebinding and schedule epoch changes fail closed
until an explicit ownership fence is implemented. The media owner persists exact signed schedule JSON with file/directory
synchronization under its existing OS writer lock. A durable opt-in marker prevents
a missing schedule file from restoring the legacy cap. Request-key digests are
claimed immutably in the existing runtime PostgreSQL store before adoption, so
renewals do not accumulate receipts in the bounded writer policy file. A command
receipt alone never proves application. Every native local-media byte/stream writer evaluates the selected
schedule and checks positive logical growth again before publication. Restart reads
the persisted schedule; expiry requires no running reconciler. Non-growing
replacements and deletions remain available. Inventory follows private-shadow read
precedence and excludes staging and backups; the separate physical guard still
counts media copies and staging. Control-state paths cannot be accessed as objects.

The native mail owner stores its exact received/previous schedules in runtime
PostgreSQL, with a volume binding and durable opt-in marker. Native writers and
the Dovecot capacity plugin share the volume lock and reserve logical growth
before publication. They recheck the selected schedule at commit; expiry and
explicit zero fence positive growth without a running reconciler. Interrupted
publication retains its hold until locked inventory reconciliation accounts for
the actual retained files; a missing completion receipt cannot release potentially
consumed capacity. Mail inventory counts retained
message content independently of physical indexes/history and reconciles archive
copies against their logical identity.

The native control plane now allocates the shared organization Storage budget,
persists exact organization-revision mappings and requires three distinct owner
registrations per active runtime: mail, local media and retained objects. Coverage
sums each owner's signed acknowledgement once. It does not add the retained-object
inventory again through a media `storage/read` call, which would double-count the
same logical liability. Publication preserves prior-owner liabilities and requires
the adopted root baseline, resolved registration history, current Fleet identity,
fresh exact acknowledgements and the required writer-readiness evidence. These are
implemented gates, not evidence that any deployment has satisfied them. No local
storage upgrade may be reported active until the actual root inventory has been
adopted and all three owners and their organization mapping pass those checks.

`LocalQuotaCommand.scheduleRevision` orders **stored replacement schedules**,
not organization allowance revisions. It binds validFrom, validUntil, base cap,
and chronologically ordered non-overlapping intervals with unique interval IDs.
Intervals must fit inside the authority lease; all intervals are half-open.
The full command is immutable under capacity-json-v1 digest. Persist a received
schedule immediately, while retaining the prior enforcing schedule until every
writer is ready to switch. Identical revision/digest replays; lower revisions or
a different digest for the same revision conflict. Epoch changes require an
explicit runtime-registration fence. An ordinary replay cannot reset an epoch.

A replacement carrying a future reduction includes the interval covering now
with the unchanged current cap. Merely receiving its future interval does not
change that cap. Once writers adopt the replacement, its current interval can
be acknowledged, while its future interval remains unapplied until its exact
boundary. Runtime adoption switches the full schedule atomically under the
existing writer locks; it must not publish a mixture of two schedules. Future
intervals and fallback must be restored before any growth is allowed on restart.

If a pending replacement's lower-cap transition arrives before every writer can
apply it, fence positive growth until all writers enforce the reduction; do not
extend the old higher cap merely because application is pending. The source then
reports unavailable/pending application rather than successful enforcement.

`LocalQuotaAck.storedSchedule` identifies the latest durably received schedule
revision/digest. `enforcing` separately identifies the schedule actually used by
writers and its current selection: kind, nullable intervalId, and effectiveAt.
These identities are distinct when a newly stored schedule is pending while an
older schedule still enforces. `state: applied` requires them to match; `pending`
can report the older enforcing schedule and cap without granting activation.
The identities of each selection are:

- `interval`: the command's exact interval ID and effectiveAt.
- `base`: null interval ID; effectiveAt is validFrom before the first interval,
  or the immediately preceding interval's expiresAt in a gap or after the last.
  Including this timestamp distinguishes separate base fallback segments.
- `lease_expired`: null interval ID and effectiveAt equal to validUntil; this is
  an expired authority state, never active capacity or permission to grow.

Before validFrom, the command cannot enforce: retain the prior valid schedule or
report unavailable and block growth. At an interval expiry during outage, runtime
selects the next interval or verified base fallback locally. At authority expiry,
it blocks positive growth and reports expired with null enforcingLimitBytes;
this does not report zero usage. Reads, deletion, non-growing replacement and
existing data remain available. Never retain an expired purchased increase.

For an applied acknowledgement, enforcingLimitBytes must be numeric, including
zero; `supportedLimitBytes` must contain the signed maximum schedule value
accepted by that writer. Missing or null values leave allocation unavailable.
This value describes command support, not available physical disk capacity;
media reports its native media limit and mail reports its supported integer range.
`nativeWriterReady` must be true; mail additionally requires dovecotReady=true
and allMediaWritersReady=null; media requires allMediaWritersReady=true and
dovecotReady=null. Queued provisioning is pending. Cross-field validation verifies
both identities against persisted commands, site/installation/meter bindings,
digests, chronological selection, cap and lease at observation time and again at
read time. A response crossing a transition boundary cannot prove the new state.
Acknowledgement freshness must expire no later than the next interval/fallback/
lease transition; used/reserved remain null if their source cannot be verified.
No timestamp refresh can manufacture readiness or a measurement.

`LocalOrganizationRevisionMapping` is a **Data-internal persisted mapping**, not
an instruction from Pay or the runtime. It binds runtime/site/meter, the exact
enforcing schedule/selection, numeric cap, and organization allowance revision.
Data precomputes mappings for every interval and base-fallback transition and
persists a new desired organization revision when each becomes effective. A
stored schedule acknowledgement alone cannot satisfy that mapping. Publishing
active or issuing a Usage receipt requires current writer readiness and exact
identity/cap correspondence for every affected owner. A prior interval, an older
schedule with equal bytes, or a lease-expired acknowledgement cannot satisfy a
new mapping. A cap-preserving schedule adoption may receive its own organization
revision, but its future transitions remain distinct mappings. The sequence in a
schedule revision is never compared to an organization revision's sequence.

Retrieve acknowledgement with the signed ack operation; lost replies are polled,
not reinterpreted as failure to apply. Restart reports a new boot ID and rechecks
all native/Dovecot/media writers before acknowledgement. Native mail and its
Dovecot capacity plugin accept explicit zero for the logical growth schedule;
the older physical quota settings remain a separate safety guard. Native media
accepts explicit zero and scheduled logical
limits up to its independent 2 GiB physical safety ceiling; larger schedules are
rejected rather than clamped or acknowledged. Increasing that physical ceiling
requires its own reviewed infrastructure change. Do not enable sales from a local
owner acknowledgement alone.

## Fenced site reservations and guard-policy migration

### Native Manager review binding (2026-09-09 integration correction)

Use the existing authenticated Manager admin transport:

* `GET /admin/runtime/cedros-providers-manager/organizations/{organizationId}/sites/{siteId}/guard-review`
  requires `OpsRead` and returns `GuardReviewResponse`.
* `POST` to that path plus `/approve` requires `OpsWrite`, one
  `Idempotency-Key` (8–180 bytes), and `GuardApproveRequest` containing only
  `migrationEpoch` and `guardSetDigest`. It returns `GuardReviewResponse`.

These are native HTTP routes, not extension-service capabilities. Organization
and approving actor derive from the authenticated identity. An operator in the
configured control-plane organization may manage registered Fleet tenants;
other operators are restricted to their own organization. BillingManage alone
does not authorize either action. Site IDs here are Fleet runtime IDs, as in the
existing Manager tenant/guard editor, not arbitrary customer-supplied aliases.
Responses use `Cache-Control: no-store` and the shared `Error` envelope.

`policy` is the immutable approved policy, or a complete legacy policy when no
approval exists. `currentReview` and `currentGuardSetDigest` describe all current
rows and the complete route catalog; `approvalCurrent` says whether they still
match the durable approval. Manager must display both when drift occurs and
submit the **current** digest for another review. Never relabel old approval
evidence as the current rows. This response's `salesEligible` remains false:
guard cutover does not prove commercial admission or payment/runtime readiness.

Approval locks the limit table against all existing writers, including tenant
sync, recomputes the review, and atomically records both the policy and mandatory
audit receipt. Same scope/key/body replays the original receipt without changing
the approving actor; a different body or stale digest returns 409. Retry keys
are scoped to organization/site, so another currently authorized operator can
recover a lost response. A replay is historical evidence: reload GET to learn
whether it remains current. Receipt retention is durable, independent of caches.
Fleet removal deletes the active policy and retains its historical audit receipt.
The approved enforcement mode evaluates every applicable operational row using
that row's own scope; unrelated and unmigrated sites keep legacy selection.
Existing attempt, spend, rolling-day and calendar-month accounting is retained;
this change does not turn attempt counts into purchased logical-work units or
make count-before-dispatch admission atomic.

The separate browser read binding is
`GET /admin/runtime/cedros-providers-manager/organizations/{organizationId}/sites/{siteId}/local-quotas`,
with the same authenticated OpsRead/scope checks. `LocalQuotaAdminResponse`
contains exactly one row for each mail, media and retained-object meter. Each row has a nullable
`observation` (the last Data-validated `LocalQuotaAck`) and independent freshness.
No observation means null, never a fabricated runtime installation/boot identity
or zero usage. An old acknowledgement remains visible as stale evidence;
`state=applied` inside that historical observation does not override its expired
freshness. Data validates runtime ownership, signature, schedule identity and
acknowledgement before storing or projecting it. This browser read is implemented
with current Fleet organization/site authorization and a consistent database
snapshot. A polling failure preserves the last verified acknowledgement only for
the same registration and marks its source unavailable; a replaced registration
clears that observation. Future, overlong or mismatched timestamps cannot restore
freshness. Manager handles 503 explicitly and must never call the signed
`capacity.local.*` routes or receive the reconciler's credentials.

### Portal bootstrap and import binding

The bootstrap read is implemented for compatibility with existing organizations.
Data reads the JSONB `cedros-portal:site-quota-reservations` collection at the
lowercase SHA-256 organization key. A verified absent entry or a valid legacy
reservation array with no migration markers yields `state=legacy` and 15-second
freshness, starting before the database read. Portal can continue its existing
base-plan creation flow in that state. An absent/typed model, malformed record,
duplicate hold identities, or any migration marker yields `state=unavailable`,
null observation times, no epoch/receipt and `canUseDataReservations=false`.
Source errors and timeouts use the shared 503 envelope; neither becomes legacy.
The read requires current SiteManage authority and is never cached.

This compatibility read never issues an epoch, starts import, removes a hold,
or treats a Portal-supplied activation marker as Data evidence. Native Deploy
creation checks the same source inside the site/job transaction under the same
entry lock used by Portal CAS, including absent entries. A committed freeze
blocks new creation; an earlier accepted transaction completes before the freeze
and remains an identity to reconcile. Existing durable creates can replay.
The shared allocation guard also holds the same source lock in Fleet registration
and handoff transactions, including organizations without an accounting-v2 binding.
A frozen source rejects positive allocation growth while permitting metadata
updates and registration of an already-counted deployment. Native Deploy retains
its earlier pre-dispatch fence. This closes the alternative creation-path bypass;
native import now verifies the frozen source revision and the complete snapshot
before publishing holds, its receipt and the applied site allowance atomically.

`GET /portal/v1/sites/reservations/migration` requires the existing Portal owner
facade and SiteManage. `SiteMigrationStatus` is the authoritative bootstrap:
Portal may reserve only when `state=active`, `canUseDataReservations=true`, and
the current migration epoch and durable import receipt are present. Missing,
unavailable or aging bootstrap is not permission to fall back to legacy holds.
Discovery accepts optional `includeSiteAdmission=true` and then includes
`siteAdmission` plus `migrationEpoch`; its top-level epoch is non-null only for
active admission. Omitting the option preserves the existing discovery shape.
Members can view Discovery's sanitized status, but cannot perform migration.

`POST /portal/v1/sites/reservations/migration/import` accepts `SiteImportRequest`
through the trusted Portal host/owner transport, with SiteManage and
Idempotency-Key. Import retry identity is operation, verified Portal installation,
organization, migration epoch and key. The full canonical page command is bound;
changed input returns 409, and a new key cannot import the same snapshot twice.
This is **not** a browser upload of purported holds: Data must
verify the frozen source CAS version and server-side organization against the
registered Portal installation's `cedros-portal:site-quota-reservations` model.
The entry key is the existing lowercase SHA-256 of organizationId. Portal freezes
that entry with the Data-issued epoch using CAS before reading its full contents;
Data must also fence every creation path and reconcile previously dispatched jobs.
No epoch or source version supplied by a buyer is authority for this transition.

The snapshot digest covers `{organizationId,migrationEpoch,snapshotId,sourceVersion,holds}`
under capacity-json-v1. Holds are sorted by `requestHash` and preserve the exact
stored payload, fallback payload, expiry and request identities. Missing legacy
fields become null; never invent a request ID, digest or base subscription.
`sourceVersion=null` means a verified absent entry, never an unavailable read.
Each page carries identical snapshot identity/digest/counts, zero-based pageIndex,
and at most 100 holds. Stage all pages durably; exact repeated pages are no-ops,
conflicting pages/identity/digests fail 409, and incomplete staging produces no
import receipt. Only a complete, source-verified snapshot can atomically publish
all holds and an immutable `SiteImportReceipt`. Snapshot replacement requires a
new snapshotId and a verified newer frozen CAS version; old receipts remain
recoverable. The response distinguishes staged pages from the completed import.

Expiry alone never releases an imported hold. Verify `requestHash` against any
known creationRequestId, requestDigest against the original payload, and both
original/fallback identities against durable Data creation records. Deduplicate
only with verified matching organization and creation identity. Unknown records
remain uncertain and counted. `cleanupAllowed` is false until every imported
identity is reconciled and all old writers are fenced/drained; Portal must retain
legacy records until a matching receipt explicitly permits cleanup. Receipt
reads never expose the imported creation payloads to customer members.

Import, reserve, reconcile and release are implemented on the authenticated owner
HTTP facade already used by Portal. The alternate extension-service registrations
and standalone commit HTTP route remain unavailable. Commit occurs inside the
Data transaction that creates the deployment and job, verified by a transaction-local
admission marker; Portal only reads the persisted result. Source drift fences new
growth. An expired financial snapshot does not prevent release of a proven unused
new hold, and does not become fresh when that hold is released.

Imported holds without authoritative creation evidence remain uncertain and counted.
Expiry never proves that old work was not dispatched. The import receipt keeps
`cleanupAllowed=false`; no customer data or legacy records are deleted.

Data is the single site-admission owner. The schemas specify reserve,
commit, reconcile and release. Reserve requires SiteManage and exact creation
request ID/digest/base subscription/migration epoch. The organization allowance,
complete eligibility count and live uncommitted holds are checked under one
transactional lock. For the existing `POST /portal/v1/sites`, the migrated handler resolves the hold
by the same organization and Idempotency-Key/creationRequestId and verifies the
request digest under the fence; no client-provided reservation proves admission.
Every customer-allocating creation entry point, including
direct/admin creation, must consume the same reservation or remain fenced.
Commit is trusted creation-worker-only and verifies durable site ownership and
creation request identity; customer-supplied site IDs are not proof. Reconcile
uses persisted creation/idempotency/job state. Release succeeds only with proof
that work was never dispatched or definitively failed without a site. Ambiguous
transport/timeouts remain uncertain and consume a hold; elapsed TTL alone is not
proof. `reconcileAfter` schedules investigation, not automatic release.

Migration phases: (1) persist a new organization migration epoch and fence both
legacy and new creation entry points; old workers check the fence before side
effects, and already-dispatched jobs are drained/reconciled; (2) import Portal's
CAS holds with their original request hashes and payload identity, including
uncertain entries, deduplicating against created Deploy/Fleet sites and Data's
idempotency records; (3) prove complete eligibility + holds and the effective
`cedros.portal.siteQuantity` agree, then atomically switch admission ownership;
(4) publish the epoch and unfreeze only updated clients/workers. Legacy clients
receive migration_fenced, never silently fall back. Crash recovery resumes the
same migration epoch. Do not delete legacy holds until a durable import receipt
and all in-flight identities are reconciled. Portal's current 30-minute expiry
and release-on-transport-error behavior is not sufficient for this transition.

`GuardPolicy.review` replaces the scalar site-wide winner with an immutable
`GuardReview`. It includes the entire organization/site scope, migration epoch,
versioned host route catalog, row snapshots, protection-policy revision and one
`LegacyGuardDecision` for each route/family/operation tuple. Include operations
with no legacy row (selectedRowId=null), not only currently metered routes. The
catalog is the actual host catalog including native adapter entry points; a
customer or UI cannot choose the subset. Reject missing/duplicate decisions,
duplicate rows/targets and catalog changes before cutover.

For every decision record the actual legacy selected row, all top-priority tied
candidate IDs (including the selected ID when tied), the complete enabled
applicable row IDs, and independent provider/safety protection IDs. No tie uses
an invented deterministic winner: record the observed legacy winner and tied set,
and bind all of them to review. Two operations at one site may have different
winners. Disabled rows remain in snapshots for change detection but cannot become
applicable guards. Operator request/rate/spend caps continue to count attempts;
commercial meters remain separate logical-work accounting.

Commercial admission requires trusted site attribution. The initial migration
therefore approves concrete site scopes only; a site-less legacy review may
document its existing selection behavior but cannot cut over or enable sales.
In particular, preserve the inspected SQL's site-less matching and lexical
NULLS LAST ordering when recording legacy evidence; do not silently replace it
with a new specificity rule. Site-less paths must be attributed or remain fenced
before the organization's commercial service can pass its creation/dispatch audit.

`GuardRowSnapshot` contains the existing limit row's scope, enabled state, four
numeric limit values and updatedAt, plus rowId and rowRevision. rowRevision is
the capacity-json-v1 digest of all the snapshot fields except rowRevision itself;
it is a new review fingerprint, not a claim that the old database has a revision
column. Do not include provider credentials or arbitrary operational metadata.
The complete row list comes from the authoritative relevant organization/site
policy inventory, including disabled entries, never a UI page. The existing
safety/protection resolver supplies the separately versioned per-operation
protection list; its digest is protectionPolicyRevision. The reference fixture
uses ordered `{target, guardIds}` records for that list. Omission of an independent
storage-abuse/provider restriction fails review even if all database rows match.

The guardSetDigest covers the **whole GuardReview** under capacity-json-v1,
including scope, epoch, route catalog/revision, complete row revisions/values,
protection revision and decisions. Catalog arrays, rows and decisions have a
persisted order; changing order also changes the digest, rather than silently
normalizing a reviewed document. routeCatalogRevision hashes that full ordered
catalog. Server validation recomputes row/candidate decisions and checks complete
coverage against the current host catalog and current policy rows.

`commercial-all-guards-v2` requires non-null approvedBy and approvedAt even when
salesEligible=false. Those fields are projections of a durable **server-owned**
operator approval receipt for that exact digest and migration epoch; a supplied
name/date is not authorization. Approval requires the established operator/admin
authority, not customer BillingManage. Under one transaction/fence, recheck
catalog, rows, protections, receipt, scope and epoch, then switch the whole scope
from `legacy-winner-v1` to `commercial-all-guards-v2`. A missing or changed guard,
new route, changed values/enabled state, stale epoch or partial review aborts the
cutover and requires a new complete review/approval.

Tenant resync cannot replace the approved policy version, migration epoch or
approval receipt, or turn operational rows into grants. Drift invalidates sales
eligibility and requires a new review while preserving the already-selected
migration model and safety enforcement; it must not silently revert to legacy
winner behavior. Unmigrated scopes remain sales-ineligible. Operator approval
alone never enables sales: enforcing runtime readiness, verified commercial
configuration and joint activation remain independent prerequisites.

## Errors, executable review and remaining activation work

The JSON `httpErrors` table and `Error.error.httpStatus` cover 401 missing buyer,
403 authority denial, 404 scope/resource privacy, 409 conflicts/expired quote or
cursor/revision fences, 422 malformed or unsupported inputs and 503 unavailable
sources. Safe messages never expose provider errors. Successful create acceptance
returns 201; exact replay/read returns 200; a durably queued hint/application
returns 202 with pending state. Never translate 202 to applied capacity.

Run the checked-in Python fixture runner alongside the schema examples. It tests
changed financial fields, independent-key uniqueness, expiry replay, delayed
payment, renewal failure, cancellation, partial refund/dispute revisions, URL
redaction, unknown/aging status, atomic split-page publication, scheduled grants,
annual/monthly allocation, admission-period settlement and revision-aware reads.
These are executable **contract reference checks**, not native enforcement tests.
They cannot establish concurrency, real payment, Dovecot readiness or host trust.

Implementation is authorized now. Data implements native persistence, trusted
adapters, the effective-cap resolver, atomic admission/settlement, reconciliation,
site/guard migrations, runtime quota application and customer-safe reads. Pay
implements the financial owner interfaces and durable lifecycle. Portal consumes
the standard and migrates site reservations. Providers Manager aligns catalog,
policy and migration UI; it does not create a competing enforcement service.

Commercial installation/environment/prices/quantities/terms are configured and
verified before sales. An opt-in native acceptance harness now installs pinned
Portal, Pay and Login archives through the production archive installer into a
disposable database, then exercises synthetic offers and a local TLS Stripe-shaped
fixture across purchase, grant, site-cap application and Usage. That fixture does
not retrieve a real Stripe record or verify commercial configuration. The affected
native suite passed 378 tests with no ignored tests under `cedroscloud-backend`.
The installed acceptance also passed with the pinned Portal 2.0.30, Pay 4.0.19
and Login 1.0.15 archives: durable Login evidence, owner/member permissions,
quote/authorization/purchase replay, paid grant application, Sites cap 1 → 3,
a fourth-reservation rejection and release back to three available slots. Its
existing base subscription is a valid synthetic x402 record; add-on reconciliation
uses the local Stripe fixture. It does not deploy infrastructure. The financial
Controls TLS fixtures passed with a valid root-authorized Deploy target plus a hostile Fleet hostname, resolving only the canonical Deploy
hostname and rejecting absent deployment authority. Actual
signed runtime evidence, configured rates and live commercial facts remain
independent launch requirements; missing evidence stays explicitly unavailable.

## Implementation directives for the teams

Data is the integration owner and final protocol decision-maker. Pin this standard
and its companion schemas/fixtures; report implementation defects with an exact
operation/field and a failing case. Continue unaffected implementation while Data
resolves the issue. Do not request blanket contract acceptance or define competing
route, scope, unit, grant, or lifecycle semantics.

**Portal:** the current candidate implements target discovery, Usage and Upgrade,
the quote/purchase flow, member-safe recovery/status, BillingManage role mapping
and revision-aware refresh, and uses Data's fenced site reservation boundary. Keep
capability detection and explicit unavailable states. The candidate passed the
installed Usage/Upgrade flow; preserve unsubscribed/past-due recovery.

**Pay:** the current artifact implements the published capacity HTTP and internal
service routes used by the assembled test, including delegated purchase, grant and
reconciliation paths. Preserve immutable quote/authorization redemption, scoped
durable idempotency, recurring payment identity, billing recovery and base-plan
isolation. Synthetic offers and the local Stripe-shaped fixture are integration
inputs only. The pinned installed artifact passed the assembled flow; verify real
commercial configuration before enabling live purchases.

**Providers Manager:** per-operation guard review/approval, local-quota projection
and supplier reconciliation routes are implemented. Keep wire units/catalog and
customer-safe recovery aligned with this standard, treat schedule storage and
enforcing interval acknowledgement separately, and preserve operator safety
accounting. Unmigrated or unready scopes remain sales-ineligible. Data owns
transport, persistence and native mail/media/provider enforcement.

**Data:** the trusted host/owner adapters, durable authority records, shared
grant/capacity ledger, supplier reconciliation, site migration, signed runtime
read/apply/ack and three-owner Storage allocation are implemented. Native Usage
also emits the optional customer-funded `providerActivity` projection with its
evidence coverage. Keep unavailable states fail closed. Native affected-scope verification and installed integration
passed using the exact standard fixtures and failure cases; production activation
still requires configured financial facts and current runtime evidence.

### Historical root Managed Storage adoption

The root-only `POST /managed-providers/storage/retained-inventory/fence` and
`POST /managed-providers/storage/retained-inventory/adopt` endpoints establish the
one-time historical baseline. Site-derived credentials cannot invoke them.
Operators supply the exact captured location set; current storage defaults cannot
stand in for historical custody. Fencing and root-owner registration commit
atomically. In-flight legacy mutations block fencing unless the root operator
supplies explicit writer-quiescence recovery evidence. Recovery preserves the
original attempts and an immutable receipt; late acknowledgements cannot erase
that evidence, and a failed fence leaves no newly registered owner behind.

Adoption verifies each listed captured object's size and SHA-256 by reading it,
then atomically records the legacy liability and evidence. Completeness and old
writer cutover remain explicit operator attestations, distinct from verified
bytes. Exact evidence retries are idempotent; changed evidence conflicts. The
request is bounded to 64 locations and 5,000 objects, with a five-minute byte
verification deadline. Unknown, oversized or incomplete inventories remain
unavailable. Legacy puts stay closed after enrollment. Deletion uses recorded
physical locations, holds bytes through uncertain IO, and releases the liability
once only after confirmed absence; it does not depend on today's destination.

### Signed registered-object inventory

`POST /managed-services/controls/v1/capacity/storage/read` reuses the registered
runtime binding and signed capacity-reconciler assertion. It reads retained native
asset, knowledge-file, document, retained feedback-attachment and recipient-export registries and verifies
object sizes through the existing destination routing. Feedback attachments are scoped
to the signed organization/runtime site; prepared and rejected uploads are excluded.
Recipient exports use their separate export-storage owner, including its local root or
object destination. Only completed, unexpired jobs with the matching active artifact
contribute; staged and obsolete generations do not. Unverified historical artifacts,
backend or destination mismatches, missing historic destination identities, and missing export objects leave the total unavailable. New artifacts capture a non-secret destination identity before publication (canonical local root or resolved object endpoint, region, bucket and prefix); downloads, continuation and cleanup require that same identity. Legacy artifacts are not inferred from current configuration. Its summary identifies its remote-registry scope,
registry revision, excluded local-media/mail owners and explicit incomplete reasons.
It does not expose object keys or document content. Registry changes during the
observation, missing objects, unknown metadata and bounded-scan exhaustion produce
null total usage; they never become zero usage or an enforcing acknowledgement.
`admissionReady` remains false: this observation does not reserve shared Storage
capacity or prove complete organization occupancy. Native Mail status separately
reports nullable logical retained-message occupancy, excluding physical indexes
and delivery overhead, with bounded scans and explicit unavailable reasons.

### Published Storage occupancy projection (Usage 1.2)

`storageBreakdowns` contains logical occupied and reserved bytes from the same
complete application publication as the account Storage meter. Native owner
rows carry the canonical `siteId` and `site_media`, `mail`, or `private_retained`
component. The root retained owner uses `siteId: null` and `managed_retained`:
its account-shared bytes are not attributed to an invented site. Rows are
aggregated by scope/component and their sums must equal the published meter.
They carry byte occupancy, not request counts, monthly consumption, supplier
cost, or physical backup/migration copies.

An absent legacy snapshot, stale publication, changed revision, or incomplete
coverage produces an empty projection and an explicit unavailable display. It
must never synthesize zero usage. Portal renders these rows with occupancy
provenance, separately from the monthly managed-gateway `breakdowns`. Financial
quote/grant envelopes remain 1.0.0; Usage clients explicitly accept 1.0, 1.1,
and 1.2 and reject unknown versions.

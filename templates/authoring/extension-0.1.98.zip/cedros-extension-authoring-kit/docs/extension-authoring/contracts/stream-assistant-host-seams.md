# Stream Assistant Host Seam Handoff Reference

> Status: coordination-only proposal. None of the requested seams below are
> Cedros Data capabilities. Extension-owned fallbacks are the only supported
> current implementation and must not be labelled as native host integration.

Use this when authoring or reviewing the Cedros Stream Assistant extension, or
any extension that needs native Cedros calendar/content planning, file/document
registration, media clipping, report export, or public runtime security
controls beyond the published extension runtime.

These seams are requested host product contracts. They are not currently
self-serve manifest fields, WIT imports, or generic provider operations. Until
Cedros publishes the host contracts, keep the extension-owned implementation
durable, audited, and easy to replace with native host calls.

## Current Status

- Extension-owned routes, content models, storage provider calls, telemetry, and
  integration-event handoff records are acceptable production fallbacks.
- Do not add manifest fields or SDK helpers for these seams without a published
  Cedros contract.
- Do not treat generic `storage` provider access as a Cedros Files/Documents
  registration seam. It can store private extension objects, but it does not
  mint durable host file ids or permission-aware public/private URLs.
- Do not claim media clipping is complete unless a host clipping contract or an
  approved sidecar actually cuts and stores the output asset.
- Keep all handoff records redacted: no raw tokens, signed URLs, asset contents,
  transcripts, personal data, or provider credentials.

## Requested Host Seams

| Seam | Needed for | Current extension fallback | Host contract needed |
|---|---|---|---|
| Calendar / Content Scheduling | Approved clip candidates | `stream-integration-events` with `kind: calendar-handoff` | Create/update Cedros calendar or content-plan items |
| Documents / Files / Asset | Recordings, screenshots, transcripts, reports, clip assets | Generic `storage` provider plus extension-owned asset records | Register assets as Cedros Files/Documents and return durable ids/URLs |
| Media Processing / Clipping | Actual clip generation from recordings/video | Clip candidates plus clip-asset/edit-instruction records | Submit trim/transcode/burn-in jobs and store outputs |
| Reports Export | Cedros-native report artifacts | Extension-owned report JSON/CSV records | Create/export Cedros Reports and optional scheduled delivery |
| Public Runtime Security | Public polls and display pages | Extension-owned request guards and server-rendered HTML | Host rate limits, optional CAPTCHA/Turnstile, CSP-compatible static assets/nonces |

## Calendar / Content Scheduling Handoff

Host contract should accept:

- `title`, `caption`, `platform` or `channel`, `scheduledAt`, and `status`.
- Source extension id and source resource id.
- Attached storage, file, document, or asset refs.
- Approval and audit metadata.
- Returned host calendar/content item id and status.

Extension fallback requirements:

- Store a durable `calendar-handoff` event with the source candidate id.
- Keep approval metadata and actor/audit context redacted but traceable.
- Show owner-visible pending or exported state instead of implying native
  calendar creation.

## Documents / Files / Asset Handoff

Host contract should support:

- Registering a stored asset as a Cedros File or Document.
- Requesting signed upload/download URLs where authorized.
- Attaching files to calendar, report, and content items.
- Returning durable file ids plus permission-aware public/private URLs.

Extension fallback requirements:

- Store assets through the published storage provider only within the extension
  namespace.
- Persist extension-owned asset records that can later be migrated to host file
  ids.
- Do not expose raw storage keys or long-lived signed URLs in UI, telemetry, or
  handoff records.

## Media Processing / Clipping Handoff

Host contract should accept:

- Source video/audio asset ref.
- Start and end timestamps.
- Target aspect ratio or platform preset.
- Caption and burn-in options.
- Output asset destination.

Extension fallback requirements:

- Produce clip candidates and edit instructions.
- Mark media output as pending host clipping until a real clip asset exists.
- Keep timestamps and output instructions deterministic so the host or sidecar
  can replay the cut.

## Reports Export Handoff

Host contract should support creating or exporting a Cedros Report with JSON and
CSV at minimum. XLSX, PDF, hosted report output, and scheduled report delivery
should be exposed as availability metadata if they are not universally
supported.

Extension fallback requirements:

- Store report JSON and CSV in extension-owned report records.
- Include schema/version metadata for future host import.
- Do not promise XLSX/PDF/scheduled delivery unless the host contract exists or
  an approved sidecar provides it.

## Public Runtime Security Handoff

Host contract should provide extension-friendly protections for public routes:

- Host-level per-token and per-IP rate limits.
- Optional CAPTCHA or Turnstile verification for public POSTs.
- CSP-compatible extension static asset serving or script nonce support.

Extension fallback requirements:

- Keep public request guards fail-closed.
- Validate tokens and input before writes.
- Avoid inline scripts unless a nonce-compatible host path is available.
- Return generic errors for security failures and log only redacted context.

## Authoring Checklist

- Every requested seam appears as a host-coordinated item in the release
  handoff, not as an invented manifest or SDK field.
- Fallback records include source extension/resource ids, status, safe audit
  metadata, and migration-ready refs.
- UI copy distinguishes pending handoff, exported fallback, and native host item
  states.
- Tests or smoke evidence cover one successful fallback write and one
  fail-closed/error path for each in-scope seam.
- Release notes state which host seams remain requested and which fallbacks are
  active.

## Source Artifact

Captured from the Stream Assistant host seam request draft at
`.scratch/issues/stream-assistant-host-seams.md`.

# Required Subscription Selection Gate

> Status: coordination-only proposal. This Cedros Data release does not host a
> `/subscribe` chooser or expose Pay selection operations. Consumers must not
> enable the gate unless Login and Pay provide their external routes and the
> deploying host supplies and tests the chooser.

Cedros Login can require an explicit subscription-plan choice after registration
and on later logins. This handoff records the minimum cross-product contract
between Cedros Login, Cedros Pay, and Cedros Data.

## Ownership

- Cedros Login owns registration, invite-code completion,
  `subscription_selection_required`, `subscription_selection_route`,
  `subscription_selection_pay_base_url`, and the post-login decision.
- Cedros Pay owns public plan definitions, checkout, free-plan selection,
  subscription state, webhook reconciliation, and the durable record that a
  Login user selected a plan.
- A deploying host would own the public chooser route. Cedros Data does not
  currently provide it and must not create a shadow user or subscription store.

## Flow

1. A user registers through Cedros Login.
2. If invite codes are enabled, Login requires a valid invite first.
3. If subscription selection is not required, Login continues normally.
4. If selection is required, Login asks Pay whether the current user has
   completed subscription selection.
5. If Pay does not return `complete === true`, Login returns:

```json
{
  "postLogin": {
    "action": "choose_subscription",
    "redirectUrl": "/subscribe"
  }
}
```

6. The Data-hosted `/subscribe` page renders Pay-owned plans and actions.
7. A free-plan action records selection in Pay. A paid-plan action starts
   checkout through Pay.
8. Pay marks selection complete only after a durable selection or subscription
   state exists.
9. On every later login, Login repeats the Pay status check and redirects back
   to the chooser while selection remains incomplete.

## External Login Prerequisites

Cedros Data does not verify or ship the Login implementation. A compatible
Login release would need these admin settings:

- `subscription_selection_required`
- `subscription_selection_route`, default `/subscribe`
- `subscription_selection_pay_base_url`

When the gate is required and the user has a real Cedros Login access token,
Login calls Pay:

```http
GET {subscription_selection_pay_base_url}/paywall/v1/subscription/selection-status?userId={login_user_id}
Authorization: Bearer <cedros-login-jwt>
```

Data/Core accepts this as the current integration path. Long term,
`subscription_selection_pay_base_url` remains the manual override until
Core/Data provides tenant-scoped runtime extension dependency wiring or service
discovery, so Login does not carry a manually configured Pay URL long term.

## Pay API Cedros Login Needs

Cedros Login should call Pay server-to-server during login and registration.
Do not infer completion from shared database rows, webhooks, or CRM events.

Current route:

```http
GET /paywall/v1/subscription/selection-status?userId={login_user_id}
```

Inputs:

| Field | Source | Required | Notes |
|---|---|---:|---|
| `userId` | Login query parameter | yes | Must be the durable Cedros Login user id, not email. |
| `Authorization` | Cedros Login bearer token | yes | Pay validates the caller and derives trusted user/site/account context from the JWT or its configured Login integration. |
| site/account scope | Pay/Login integration config | yes | The status response must be scoped to the site whose subscription gate is being evaluated. |

Do not add unsigned `siteId` or `accountId` query parameters to this Login ->
Pay status check. Tenant/account scope must come from the signed Login token,
Pay's Login integration, or future Core service discovery.

Current Pay 3.x response shape:

```json
{
  "complete": true,
  "selection": "complete",
  "status": "free_selected",
  "planId": "free",
  "resource": "free",
  "subscriptionId": "free_opaque_id",
  "paymentMethod": "free",
  "currentPeriodEnd": "2126-06-16T18:00:00Z",
  "cancelAtPeriodEnd": false
}
```

`complete === true` is the canonical Login gate input. `status` is a
billing/access projection and must not be the only source of truth.

## Completion Semantics

Pay persists a durable buyer-bound subscription projection for every completed
choice. Free selections use a stable Pay-owned subscription id and a long-lived
active period; paid selections become complete only after Stripe/webhook state
produces an active or trialing subscription. A checkout redirect by itself is
never completion.

Recommended gate mapping:

| Pay projection status | `complete` | Reason |
|---|---:|---|
| `free_selected` | yes | Explicit zero-cost choice exists. |
| `trialing` | yes | Paid plan choice created a provider subscription in trial. |
| `active` | yes | Paid plan choice created an active provider subscription. |
| `past_due` | no | Current Pay 3.x completion requires active/trialing state and a future period end. |
| `canceled` | no | A canceled/expired selection returns to plan choice under the current contract. |
| `checkout_pending` | no by default | Starting checkout is not durable enough to satisfy the gate until Pay commits a selection. |
| `incomplete` | no | Provider subscription is not usable and should return to the chooser. |
| `no_selection` | no | No explicit choice exists. |

If Product wants checkout-session creation to count as selection, Pay must make
that an explicit durable status such as `checkout_selected`, with expiry and
resume semantics. The safer default is to keep `checkout_pending` incomplete.

## Free Plan Selection

Current Pay 3.x publishes a dedicated endpoint for selecting a free public plan:

```http
POST /extensions/cedros-pay/paywall/v1/subscription/free-selection
```

Request:

```json
{
  "planId": "free",
  "interval": "month"
}
```

Behavior:

- Validate that the plan is active, public, free, and available for the site.
- Derive the user from the verified Login bearer; an optional `userId`, when
  supplied, must match that verified buyer.
- Persist a stable Pay-owned free-subscription projection idempotently.
- Return `complete: true` and `status: free_selected`.
- Do not create a Stripe subscription just to represent a free account unless
  Pay explicitly needs provider-side lifecycle hooks.
- Derive site/account scope from authenticated context, not unsigned request
  parameters.

## Public Selectable Plans

Current Pay 3.x publishes the Pay-owned public plans endpoint:

```http
GET /extensions/cedros-pay/paywall/v1/subscription/plans?interval=month
```

Required fields:

| Field | Notes |
|---|---|
| `planId` | Stable Pay plan id used by free selection and checkout. |
| `displayName` | Display name. |
| `description` | Short public copy. |
| `priceCents` | Minor units, `0` for free. |
| `currency` | ISO currency for paid plans. |
| `interval` | `month`, `year`, `one_time`, or `none` for free. |
| `sortOrder` | Numeric display order. |
| `active` | Pay operational flag. |
| `public` | Whether the plan can be shown on the chooser. |
| `free` | Convenience boolean; must match price semantics. |
| `paymentMethods` | Customer-safe available rails for this plan. |

The endpoint must exclude draft/private plans and provider secrets.

## Paid Checkout

The chooser starts paid checkout through Pay, not through Data:

```http
POST /extensions/cedros-pay/paywall/v1/subscription/plan/stripe-session
```

Request:

```json
{
  "planId": "pro",
  "interval": "month",
  "successUrl": "https://example.com/subscribe?checkout=return",
  "cancelUrl": "https://example.com/subscribe?checkout=cancelled"
}
```

Response:

```json
{
  "flow": "redirect_checkout",
  "sessionId": "cs_123",
  "url": "https://checkout.stripe.com/c/session"
}
```

After checkout returns, the `/subscribe` page should ask Pay for current
selection status. Provider redirects alone do not prove completion.
As with free selection, buyer identity comes from the verified Login bearer.
Pay validates the configured return-origin allowlist and never accepts an
unsigned user id as authority.

## Cedros Data Route Decision

Confirmed default route: `/subscribe`.

Reasoning:

- It is short, public-facing, and product-neutral.
- It matches the existing Cedros page-seed model: a normal owner-editable page
  row can live at `/subscribe`.
- It avoids overloading `/account/subscription`, which sounds like a logged-in
  management page rather than an onboarding gate.

Alternative route names such as `/choose-plan` are acceptable only as owner
overrides. Login should consume the configured/effective route, not hard-code a
route that conflicts with an operator override.

## Who Creates The Page

Recommended split:

- Cedros Pay ships the plan-picker web block/template and a page seed for the
  chooser.
- Cedros Data provisions the page row, resolves route conflicts, renders the
  page shell, and keeps the route owner-editable.
- Cedros Login redirects to the effective Data route after invite completion
  or login when Pay reports incomplete selection.

Suggested Pay page seed:

```json
{
  "id": "cedros-pay:subscription-choice-page",
  "displayName": "Subscription choice",
  "title": "Choose a plan",
  "routePath": "/subscribe",
  "templateId": "cedros-pay:subscription-choice-template",
  "autoCreateOnEnable": true,
  "publishOnEnable": true
}
```

If Pay is not installed or its page seed cannot publish, Login must fail closed
for required-selection sites and surface setup diagnostics to the site admin.

Data's role is to provision and render the page row from the Pay page seed. Data
does not ship a core fallback `/subscribe` page by itself; therefore enabling
the Login gate before the Pay chooser page is provisioned is a setup error.

## Cedros Data Route Guard

Cedros Data should not be the first enforcement point. Login's post-login
redirect is the minimum required gate because Login owns registration/login
state and can call Pay before handing the user to the site.

Data can add a site-route guard later only when all of these are available:

- A reliable Login user principal on public site requests.
- The Pay selection-status API above.
- A route classification model that distinguishes protected routes from public
  routes.
- An exemption list for `/subscribe`, Login auth routes, checkout return/cancel
  routes, static assets, webhooks, and public previews.

Without those pieces, Data can render the chooser and optional upgrade entry
points, but it cannot safely enforce a global protected-route subscription gate.

## Optional Upgrade Path

When `subscription_selection_required` is disabled, Data may still expose an
upgrade path if Pay is active:

- Prefer a reusable Pay block such as `cedros-pay:manage-subscription` or
  `cedros-pay:plan-picker`.
- Host it on an owner-editable account/settings page when the site has one.
- Keep public marketing links separate from the required-selection gate.
- Use Pay status/checkout APIs for all mutations.

## Remaining Host Coordination

1. Core/Data should eventually replace Login's configurable Pay base URL with
   runtime extension dependency wiring or service discovery.
2. Data route-guard enforcement should remain out of scope until public Login
   principals and protected-route classification are available.

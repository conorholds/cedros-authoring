# Core staging sync v1

Implementation: `server/src/staging_sync*.rs`, `server/src/http_staging_sync.rs`,
and `server/src/store/runtime/staging_sync*.rs`. Available with Core's `storage`
feature.

## Coverage

Core promotes a reviewed, manually initiated, one-way release between separate
sites. It does not replicate the database or deploy code. The destination may
have one active source pairing. Nothing pairs or publishes automatically.

| Kind | Portable projection | Limits |
|---|---|---|
| `setting` | `site_title`, `site_description`, `default_description`, `default_og_image`, `locale`, `social_links`, independently selected | All other settings and metadata stay destination-owned. |
| `theme` | Active `site_settings/theme` entry | This is the active configuration, not the theme-manager package catalog. |
| `navigation` | Menu title, items and authored metadata | Item/parent IDs are namespaced for the destination; content links require valid targets. |
| `redirect` | Source/target paths, status, prefix/forward flags and note | Existing route-ownership validation applies. |
| `content` | Saved current revision and separate published revision, including authored body, SEO, taxonomy, media and attributes | Drafts remain drafts. Schedules and actor claims are not imported. Unknown/incompatible builder templates or blocks and unsupported owner dependencies block apply. |
| `media` | Ready, stored public assets, variants, alt text and caption | Bytes move into destination storage. Access-controlled and unfinished assets are excluded. Other destination metadata is preserved. |
| `form` (optional) | Authored contact/custom form fields, presentation, status and per-form SEO | IDs are `contact/<key>` or `other/<key>`. Scope/key mappings must be identical. Subscriptions, protection tokens, delivery metadata and submissions stay local. |
| `collection` | Unnamespaced JSONB collection definitions and contracts | New collections and optional field additions only; existing field contracts and storage modes cannot change. No rows, typed/custom SQL schema, or extension namespaces. |
| `emailTemplate`, `emailSnippet` | Authored definition fields and `metadata.visualBuilder` | Existing email validators run. Sender defaults, other metadata, campaigns, audiences and execution stay local. |

Users, authentication, credentials, domains, infrastructure, provider/storage
bindings, operational data and extension-owned data are excluded. An unknown
kind or a selected unsupported change fails preparation. Required supported
references are added to the selection; their conflicts remain explicit. Missing,
private, or unsupported dependencies block. Unrelated external URLs remain
external; known content/media references are rewritten. Remaining staging-origin
URLs require an authored edit instead of a global text replacement.

Links follow the reviewed destination resource: retaining a production page
retains its route, and retaining production media uses its existing storage URLs
rather than newly staged bytes. Media variants are matched by their declared role
instead of array position; missing or ambiguous retained counterparts and shared
source locators with conflicting retain/promote decisions block preparation.
Any intermediate media-review plan is cancelled before Core returns
the final plan, and intervening destination/baseline edits require a new pull.

The source artifact is a complete inventory of its declared categories. A missing
resource can become a deletion only when a managed baseline exists and that key
is selected. Core checks retained production references. Home-page and default-navigation-menu deletion, and
settings, media, forms, collection, and email-definition deletion are unsupported; use
explicit email archival or form draft status where appropriate. Reversal retains newly created forms, as it does newly created media/email definitions. Existing form edits are reversible with the normal drift checks.

### Settings and services that stay local

The `setting` adapter exports only the six fields above and updates only selected
columns. It never exports or replaces `site_runtime_settings.metadata`.
Consequently, the following are protected by Core's resource boundary, not merely
unchecked UI options:

- Site-wide indexing: `metadata.searchIndexing.noindex`.
- Public site mode: `metadata.internalMode`, `maintenanceMode`, `presaleMode`
  and `waitlistMode`. “Live” is the resolved mode, not a portable `siteMode` field.
- Assistant configuration and operational state, including conversations,
  memories, tasks, provider credentials and tool permissions.
- Mail configuration, accounts, messages, audiences and sending activity.
- Backup configuration, schedules, credentials, archives and restore history.

Promotion and reversal preserve each site's existing values. They do not force
production to become live/indexable or configure staging as internal/noindex;
configure those separately in each site's settings. Per-content authored SEO,
including a page's own `noindex`, is part of the content projection and **does**
travel with that content. Assistant-authored page edits also travel when selected;
the assistant itself and its state do not.

Authored email templates/snippets are the explicit mail-related exception in the
coverage table. They can be included by pairing scope and release selection;
their promotion does not transfer mail operations or initiate a send.

Each portable setting can be omitted from `pull.selections` to retain its local
value for that release. `keepProduction` is a baseline-acceptance decision, not a
persistent exclusion policy. V1 has no per-pair setting-exclusion API or automatic
environment-value overrides. An extension may remember non-secret selection
preferences, but must apply them on every new review and check the complete
returned plan, including mappings and dependencies. These UI preferences do not
restrict another authorized client. See the extension plan's section 7 for the
required presentation and selection behavior.

## Host HTTP boundary

All administrative calls require a **bearer-authenticated `data:admin` operator**
with a resolved actor identity. Cookie-only and open-setup access do not authorize
promotion. Responses are `private, no-store`. Actor identity is derived by Core.

- `POST /admin/runtime/staging-sync/requests`: `{ "requestKey": "...", "command": {...} }`.
  Returns `{ "requestId": "uuid" }`; work executes in Core.
- `GET /admin/runtime/staging-sync/requests/{id}`: owning operator's request
  status, result or error code. A current permission check is required.
- `POST /admin/runtime/staging-sync/authorize`:
  `{ "extensionId": "installed-extension-id", "command": {...} }`.
  Returns `{ "authorization": "opaque-token", "expiresInSeconds": 300 }`.

Core issues approvals valid for five minutes and retains their authentication
material in its existing secret store so the worker can recheck operator permission;
the cleanup worker removes expired approval records and credentials.
It is never supplied to an extension or included in an artifact. Expiration,
permission revocation and extension disablement deny pending extension work.
Apply checks authority again directly before the local transaction, and checks
plan and approval expiry against the wall clock after owner writes, before
committing the receipt; expiry rolls back writes, baselines and effects.
Authorization to an upstream identity provider or
remote site cannot be atomically locked with PostgreSQL; remote checks establish
fresh authority immediately before the local commit boundary.

Request diagnostics distinguish unavailable dependencies, unsupported owner capabilities,
route conflicts, transfer limits, and media integrity failures. Raw provider/domain
error text is not stored in request diagnostics.

Commands use camelCase and reject unknown fields:

| `action` | Additional fields | Result |
|---|---|---|
| `identity` | None | Deployment UUID, protocol, coverage and limits |
| `pairings` | None | Latest 100 pairings, excluding credentials |
| `grant` | `remoteId`, `remoteOrigin`, `scope` | Source pairing and a new scoped token |
| `connect` | `remoteId`, `remoteOrigin`, `grantId`, `token`, `scope` | Destination pairing after authenticated source handshake |
| `revoke` | `pairingId` | Revokes local pairing and removes its credential |
| `export` | `pairingId` | Source artifact ID/digest and resource keys |
| `artifacts` | `pairingId` | Latest 20 artifact summaries |
| `pull` | `pairingId`, `artifactId`, `selections` | Destination `{ digest, plan }` |
| `plan` | `planId` | Previously prepared `{ digest, plan }` |
| `apply` | `planId`, `planDigest`, `requestKey` | Durable release operation |
| `operation` | `operationId` | State, required effects and receipt |
| `operations` | `pairingId` | Latest 100 operation summaries for recovery |
| `cancel` | `planId` | Cancels before commit |
| `reverse` | `operationId` | New guarded reversal `{ digest, plan }`; does not apply it |
| `request` | `requestId` | Owning operator's request status |

A selection is:

```json
{
  "source": { "kind": "setting", "id": "site_title" },
  "destination": { "kind": "setting", "id": "site_title" },
  "resolution": null
}
```

An explicit `destination` establishes an initial counterpart. UUID resources
otherwise receive deterministic destination IDs; matching slugs do not imply
identity. Existing same-key ambiguity conflicts unless explicitly mapped or
resolved. `resolution` may be `keepProduction` or `acceptStaging`. An explicit
keep accepts both projections without writing production; ordinary production
only drift does not advance the baseline. Omitted resources stay unmanaged.

Review the whole returned plan, including automatically included dependencies,
normalized values and deletion intent. Any changed decision requires another
`pull` and approval of its new digest. Both current and published revisions are
shown; do not equate saving a draft with publishing it.

The outer request key deduplicates command submission. The `apply` command's
inner key deduplicates the release operation. Reuse each key with identical input
to recover a lost response; changed input is rejected. Applying a plan twice
returns the existing operation even with a new inner key.

## Local extension service

Use the existing `extension-services.invoke` host import with:

- Target: `cedros-data`.
- Capability and route ID: `cedros-data:staging-sync-read-v1` for discovery/status,
  or `cedros-data:staging-sync-write-v1` for mutations.
- Method/path: `POST /runtime/staging-sync/v1`; no query parameters.
- Body: `{ "authorization": "host-issued-token", "requestKey": "...", "command": {...} }`.

The manifest must request the relevant published capability through the existing
Core service dependency mechanism. The host fixes caller identity. An approval
is bound to that exact extension, real operator and command digest; guest actor
IDs or confirmation booleans grant no authority. `request` returns a status
response directly; other commands return HTTP 202 with a request ID. Large plans
and receipts can be retrieved through the host HTTP boundary rather than the
existing 4 MiB Wasm service envelope. Extensions must not keep the execution
ledger or receive stored pairing credentials.

## Pairing and source transport

First discover both deployment IDs. On staging, grant production's ID/origin and
chosen categories. Supply that grant ID and token to production's `connect`.
Production stores the scoped source token in Core's secret store; staging stores
its hash. Staging receives no production administrator token. Grants remain
valid until revoked; rotate by revoking and establishing a new pairing.

Production initiates authenticated GET requests to:

- `/staging-sync/v1/source/{grantId}`
- `/staging-sync/v1/source/{grantId}/artifacts/{artifactId}`
- `/staging-sync/v1/source/{grantId}/artifacts/{artifactId}/blobs/{sha256}`

These require `Authorization: Bearer <pairing-token>` and
`x-cedros-staging-destination: <deployment-uuid>`. Artifact IDs and hashes are not
credentials. Identity, direction and scope are checked independently of hostnames.
The source transfer API exposes immutable artifacts, never arbitrary SQL or
production mutations.

Only public HTTPS origins are supported. Credentials in URLs, paths/queries on
an origin, private/reserved DNS destinations, proxies and redirects are rejected.
DNS results are checked and pinned per request. Fetching is bounded to 5 seconds
for DNS, 5 seconds to connect and 20 seconds overall per response.

Supported Core backup restoration rotates the deployment ID and revokes copied
pairings and approvals. Copied committed operations retain their commit and
receipt, with `deployment_restored` as their diagnostic; they neither block new
deployment releases nor continue verification against the restored site.
In-flight verification results are fenced against identity rotation.
Raw PostgreSQL/file copying is not a supported cloning
workflow and does not supply an independent deployment identity; use Core's
restore path before establishing new trust.

## Commit, verification and recovery

Requests move `queued -> running -> succeeded|failed`. A request has a 120-second
claim and a 90-second execution bound. An expired running request becomes
`failed` with `interrupted_review_state`, rather than replaying a possibly
completed grant or preparation. Inspect `pairings`, `artifacts` and `operations`,
then submit a fresh preparation if needed. A lost apply response is recovered
through its idempotency key or operation listing.

Expired request results are returned as `null` even if cleanup has not run; status
and operator ownership checks remain intact. Source artifact reads and listings
enforce the 30-day lifetime independently of physical cleanup, including the
artifact check performed before serving its blobs.

Release operations move `queued -> committed -> succeeded`, or fail/cancel before
commit. Core serializes apply/cancel/revoke and locks the supported authored
tables against ordinary editors. Preparation validates with real owning-domain
writes in a savepoint, then rolls those writes back. Apply rechecks the reviewed
resource versions, baseline and reference predicates; writes, baseline changes,
before-images, commit receipt and required effects commit together. A stale plan
or validation failure commits none of the authored changes.

Success requires both durable content and redirect cache effects, verified staged
media hashes, and successful nonempty public responses for up to three routes,
including `/`. Public-response checks establish reachability, not visual browser
QA. Failed post-commit checks remain `committed` with
`committed_verification_pending` and retry every 30 seconds. Required effect IDs
and statuses are available on the operation; use existing Core outbox recovery
for a failed effect. A new release is blocked while another release is queued or
awaiting committed verification.

Reversal produces another reviewed plan using retained before-images. It conflicts
when affected resources changed afterward and needs a new apply authorization.
It works without the source grant and can recover after source revocation.
Additive collection definitions and newly created media/email definitions remain
in place; their retention protects consumers outside the promoted content. Other
supported created content/redirect/navigation resources can be removed only when
unreferenced. A reversal itself is not reversible: prepare a new source release.
Reversal cannot undo external observation of published content.

## Bounds and retention

- 500 resources per artifact and destination inventory; dependency expansion is bounded by the same limit.
- 64 MiB serialized artifact; 32 MiB per blob and 128 MiB total, additionally subject to destination local-storage limits.
- Eight queued/running commands; one pending release per destination.
- Plans expire after 30 minutes. Request results, including one-time grant token results, expire after 10 minutes.
- Source artifacts and captured bytes expire after 30 days.
- Unpromoted staged objects expire after one day when no active plan uses them;
  cleanup only uses the matching storage configuration. A changed storage binding
  requires cleanup with the original provider configuration.
- Promoted media, plans, receipts and baselines are retained for guarded recovery.
  Recovery evidence does not contain pairing or operator credentials.

Network transfer and a real deployment's public rendering need a disposable
HTTPS pair/pilot before release rollout. No extension UI or production rollout is
part of the Core implementation.


## Optional form capability

The original nine `identity.supportedKinds` remain unchanged for older v1 clients.
New hosts additionally advertise `identity.optionalKinds: ["form"]`. A client may
include `form` in scope only after recognizing this advertisement; a destination
must support every category in a source handoff. Baseline v1 clients can keep using
their existing scopes. No WIT change is required. The extension's 1.1.0 client
understands both baseline v1 hosts and optional Forms; it rejects unknown categories.

The form adapter reads only `contact_forms` and `other_forms`. It canonicalizes
`PublicSiteFormDefinition`, removes `emailSubscription` and `protectionToken`, and
rejects incoming fields outside that authored projection. Writes use the existing
entry owner service and form validators in the release transaction. They merge
authored fields while preserving destination execution fields; a retained
subscription that becomes invalid under new fields blocks the transaction.

Embedded `formKey`/`formScope` references participate in dependency closure (an
omitted scope means `contact`, matching the public renderer). Missing definitions
block preparation. Published pages must reference active forms; making a form
inactive also checks retained published pages and navigation links before commit. Known standalone `/forms/<scope>/<key>` links participate in
closure and source-origin rewriting. A legacy `formId` remains an unsupported
owner reference; it is not an alias for these scoped form keys. Form deletion and
scope/key renaming are unsupported; explicitly draft an obsolete form. Submissions
are never included, deleted, or reassigned by a release or reversal.

## Admin presentation host contract

Core exposes the optional `admin-presentation-v1` host service. This is presentation
only: it neither authorizes access nor selects resources, changes environment
settings, starts services, or sends/releases anything. The extension must forward
`hostContext.services` into its `PluginContext.services` to consume it.

```ts
interface PresentationService {
  getSnapshot(): Snapshot | null;
  subscribe(listener: () => void): () => void;
  refresh(): Promise<Snapshot>;
  configure(configuration: Configuration): Promise<void>;
  setPreferences(preferences: Preferences): Promise<void>;
}
interface Snapshot {
  deploymentId: string;
  revision: number;
  active: boolean;
  configuration: Configuration | null;
  preferences: Preferences;
}
interface Configuration {
  extensionId: string;
  mode: string;
  profile: null | {
    label: string;
    description: string;
    controlSectionId: string;
    sections: Record<string, { group: string | null; routes: string[] | null }>;
  };
}
interface Preferences { fullAdmin: boolean; revealedSections: string[] }
```

Section keys are **qualified module/section IDs**, not friendly URLs. A null routes
list includes all section subroutes. An explicit list permits exact routes and
slash-delimited descendants; `""` permits only the root. The Staging control ID is
`cedros-staging-sync:admin:cedros-staging-sync:releases`. Core always preserves
permission-authorized Extensions, Account, Help and the owner control section.
Group changes are display-only and do not alter registered routes.

Backing endpoints (bearer auth and deployment org header required with Cedros Login):

- `GET /admin/runtime/presentation` returns the snapshot to an authenticated user.
- `PUT /admin/runtime/presentation` takes `{ deploymentId, revision, configuration }`;
  requires DataAdmin and an enabled owner extension.
- `PUT /admin/runtime/presentation/preferences` takes
  `{ deploymentId, revision, preferences }`; writes only the authenticated actor's
  preference row. Actor identity comes from Core, never a supplied user header.

Both writes require the current deployment and configuration revision. A stale
write fails without changing data; reload and reconcile before retrying. Updating
the site default resets personal overrides. Writes serialize with restore identity
rotation; restored deployments read no copied profile or preference authority.
The configuration and per-actor preferences live in dedicated Core tables and are
outside promotion scope. A disabled/uninstalled owner immediately removes the
profile from the current shell; reload also checks server lifecycle state.

The host service serializes reads/writes and publishes only confirmed snapshots.
A bearer change invalidates loaded state and rejects queued writes or old read
results; a new session must reload before changing preferences.
The shell refreshes on focus, becoming visible, and every visible minute. While
loading it withholds navigation and the assistant launcher. A refresh failure
retains the last loaded view and reports the error; the first failed read falls
back to ordinary permission-filtered admin with an explicit error. Views are not
an authorization boundary.

The profile covers the sidebar, dashboard, command palette and entity/Help search,
profile shortcuts, assistant launcher, direct routes, and nested Site/Appearance
settings. Hidden direct links show an explanation and a personal full-admin action.
The focused dashboard contains site-authoring shortcuts instead of operations data.
The normal site-wide sidebar layout is preserved; its editor is available in full
admin. Personal area reveals live in the extension's advanced settings and never
change release exclusions or authored-email opt-ins.

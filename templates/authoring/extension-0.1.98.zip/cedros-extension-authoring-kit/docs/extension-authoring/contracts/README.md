# Product Integration Contracts

The documents in this folder are product-specific integration contracts and
launch-handoff references for Cedros products and host integrations: Pay-adjacent
commerce surfaces, Wallet/Compliance, Shop/Core commerce, affiliates, and
Stream Assistant. They are not part of the generic extension-authoring
walkthrough in [../README.md](../README.md). Read one only when the named
product or surface is actually in scope for the extension you are building or
reviewing. The [visitor contract](extension-visitor-v1.md) also applies to generic
third-party extensions building signed-in account areas.

Only rows marked **shipped** are Cedros Data release capabilities. Rows marked
**coordination-only** are non-executable cross-repository proposals retained to
prevent teams from inventing incompatible seams. They are not exposed by the
Cedros Data host, are excluded from release-readiness claims, and must fail
closed in consumers until every owning repository publishes and tests the
contract.

Rows marked **published implementation standard** fix the protocol for teams to
implement; they do not claim deployed handlers. Runtime readiness and launch
checks remain separate from protocol approval.

| Doc | Product / surface | What it covers | Status |
|---|---|---|---|
| [extension-visitor-v1.md](extension-visitor-v1.md) | Third-party visitor accounts | Host-verified identity, purpose-bound email consent, private pages, isolated blocks, submissions, CRM/notifications and Pay buyer history. | **Implemented; build, DB and deployed acceptance verification pending.** |
| [portal-usage-capacity-v1.md](portal-usage-capacity-v1.md) | Portal Usage + Pay capacity upgrades | Authoritative v1.0 service meters, offers, scoped purchase authorization, activation and grant reconciliation; schemas and fixtures. | **Published implementation standard; expanded runtime capabilities remain unimplemented. No further protocol sign-off required.** |
| [balance-rail.md](balance-rail.md) | Cedros Balance consumers | Capability-gated balance read, credit, debit, hold, capture, release, and atomic account-to-account transfer. | Provider contract published at Balance `0.5.0`; Cedros Data publishes host-derived caller identity and exact-claim invocation through `extension-services.invoke`. Financial production use requires installed-host acceptance. |
| [pay-checkout-consumers.md](pay-checkout-consumers.md) | Third-party one-time Pay checkout | Exact Pay `4.0.47` checkout schemas/auth, catalog handoff, buyer purchase/resource association, refund reads, and activation prerequisites. | Checkout implemented but **host-coordinated**; product/history/payment-status reads remain separate published contracts. |
| [gated-media-content.md](gated-media-content.md) | Cedros Data media + Cedros Pay entitlements | Data-owned access rules, redacted public delivery, and Pay entitlement checks for mixed free/preview/locked media. | Shipped host surface; Pay entitlement contracts published at Pay `2.0.0`. |
| [required-subscription-gate.md](required-subscription-gate.md) | Cedros Login + Pay onboarding proposal | Proposed required subscription-plan choice after registration. | **Coordination-only; not a Cedros Data capability.** No Data-hosted chooser is shipped and Pay routes remain external prerequisites. |
| [wallet-compliance-seams.md](wallet-compliance-seams.md) | Cedros Wallet + Cedros Compliance | Official contract ids, route contracts, dependencies, and failure codes for consuming Wallet or Compliance seams, including KYC self-service. | Published official seams introduced at Wallet `0.0.2` / Compliance `0.0.1`; KYC self-service is published by Compliance `2.4.0`. Current family versions are recorded in the seams doc. |
| [wallet-compliance-artifacts.md](wallet-compliance-artifacts.md) | Cedros Wallet + Cedros Compliance | Implementation-depth package artifacts: schemas, fixtures, SDK exports, route/event docs, validation gates, and staging smoke checklists. | Companion to the seams doc; consumers fail closed unless the listed artifacts ship in the installed package. |
| [operational-wallet-notification-seams.md](operational-wallet-notification-seams.md) | Cedros Casino + Data/Core + Notifications | Site operational-wallet address discovery, finalized inbound activity, reserved outbound transfer/status, and [durable notification publication](notification-event-publication-v1.md). | **Wallet read/activity shipped in Cedros Data `0.1.62`; notification publication ships in `0.1.75`; outbound transfer remains unavailable.** |
| [core-product-metafields.md](core-product-metafields.md) | Shop + Pay commerce proposal | Proposed typed product metafield registry and validation seam. | **Coordination-only; not published by Cedros Data.** No write, validation, or storefront projection operation is exposed. |
| [shop-customer-account-crm.md](shop-customer-account-crm.md) | Cedros Shop + CRM proposal | Proposed account adapter. | **Coordination-only; not a Cedros Data capability.** No route mount or adapter binding is exposed. |
| [affiliate-resources-payouts.md](affiliate-resources-payouts.md) | Affiliates + Pay proposal | Proposed authenticated resources and payouts workflow. | **Coordination-only; not a Cedros Data capability.** |
| [stream-assistant-host-seams.md](stream-assistant-host-seams.md) | Stream Assistant proposals | Requested host seams. | **Coordination-only; not published.** Extension-owned fallbacks are the only supported current path. |
| [controls-email-router.md](controls-email-router.md) | Cedros Controls Email | Actor-scoped multisite reads, source-confirmed mutations, bounded attachment delivery, summaries, assertions, cursors, and normalized events. | Published by Cedros Data/Core; activation remains default-off pending retained staging evidence. |

Historical, superseded Cedros Pay launch artifacts remain under `archive/` in
the Cedros source repository and are intentionally excluded from authoring
kits.

- [Personal notification destinations](personal-notification-destinations-v1.md): Data 0.1.76 authenticated additional emails and per-event channel selection.

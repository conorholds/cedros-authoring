# Operational Wallet And Notification Publication Handoff

> Status: operational-wallet deposits published; durable notification publication
> published in Data `0.1.75`. Generic outbound wallet transfers remain unavailable;
> the Pay-only x402 refund operation is a separate host-coordinated boundary.
> Both published seams use `extension-services.invoke`.

Use this handoff when an extension needs the current site's operational wallet
or durable publication into Cedros Notifications. It records the requested
generic boundary without assigning NFT custody, staking, collection rules,
withdrawal workflows, or other extension-domain behavior to Core.

## Availability Decision

| Requested seam | Published contract | Minimum Data version | Capability IDs | Invocation |
|---|---|---|---|---|
| Site operational-wallet read + finalized inbound activity | `cedros-data:site-operational-wallet-v1` `1.0.0` | `0.1.62` | `cedros-data:site-operational-wallet-read-v1`, `cedros-data:site-operational-wallet-activity-read-v1` | `extension-services.invoke` with target `cedros-data` |
| Site operational-wallet outbound transfer/status | none | none | none published | none |
| Durable runtime notification-event publication | `cedros-data:notification-event-publication-v1` `1.0.0` | `0.1.75` | `cedros-data:notification-event-publish-v1`, `cedros-data:notification-event-status-read-v1` | `extension-services.invoke` with target `cedros-data` |

Wallet read/activity and notification publish/status are published. Outbound
`cedros-data:site-operational-wallet-transfer-v1` remains unavailable; do not
infer signing authority from a read-only contract.

## Why Existing Surfaces Do Not Satisfy The Request

### Operational wallet

The Wasm blockchain provider currently exposes:

- `blockchain.config.read`, a configuration/readiness projection that is not
  the narrow versioned wallet-info response requested here;
- `blockchain.solana.sign.x402`, restricted to the exact
  `cedros-pay:blockchain-x402-sign` grant and Pay x402 intent;
- `blockchain.solana.sign.assistant-x402`, restricted to the isolated Site
  Assistant wallet and its exact Pay grant; and
- `blockchain.solana.refund.x402`, restricted to the exact
  `cedros-pay:blockchain-x402-refund` grant and durable Pay refund contract.

Those signing/refund operations are not generic operational-wallet transfers.
The published Data contract exposes the active public wallet projection and
pages finalized inbound native/SPL activity; it does not expose outbound
submission or status. Consumers must not repurpose the Pay x402 operation,
submit arbitrary serialized transactions, or infer a transfer capability from
wallet setup/control-plane code.

Player-signed deposits use the published
`cedros-wallet:account-read-transaction-sign` contract's explicit `transfer`
approval action and Wallet-owned chain submission. The destination must be the
current address returned by `operationalWallet.read`, the network must match,
and the resulting signature is only deposit evidence after it appears in
`operationalWallet.activity.list` as `finalized` and `valid`.

### Notification publication

`telemetry.emit-event` is analytics telemetry, not a durable notification
acceptance contract. It can silently no-op when extension analytics are
disabled. The current host may make a best-effort attempt to route the event
through an enabled extension notification seed, but routing errors are logged
and are not returned to the caller. A successful telemetry call therefore does
not prove notification intent persistence or delivery.

`cedros-notifications:route-write` remains published for provisioning
`setupSeeds.notifications[]`. It creates route/template settings; it does not
publish a runtime event. The [notification publication contract](notification-event-publication-v1.md)
now provides a separate, capability-checked API over that durable queue.

## Machine Artifacts

| Seam | Contract/schema | Fixtures |
|---|---|---|
| Operational wallet | [`site-operational-wallet-v1.contract.json`](site-operational-wallet-v1.contract.json) | [`fixtures/site-operational-wallet-v1.fixtures.json`](fixtures/site-operational-wallet-v1.fixtures.json) |
| Notification events | [`notification-event-publication-v1.contract.json`](notification-event-publication-v1.contract.json) | [`fixtures/notification-event-publication-v1.fixtures.json`](fixtures/notification-event-publication-v1.fixtures.json) |

The operational-wallet artifact sets `publicationStatus: "published"`,
`callable: true`, minimum Cedros Data `0.1.62`, and exact
`extension-services.invoke` bindings for read/activity. Its transfer operations
remain individually unavailable. The notification artifact publishes version `1.0.0` on Data `0.1.75`. These files and their fixtures are bundled into the official
authoring kit.

## Operational-Wallet Contract

The family keeps three independently reviewable capabilities:

| Capability | Operation | Status |
|---|---|---|
| `cedros-data:site-operational-wallet-read-v1` | Read the redacted active wallet projection. | Published |
| `cedros-data:site-operational-wallet-activity-read-v1` | Page finalized inbound wallet activity. | Published |
| `cedros-data:site-operational-wallet-transfer-v1` | Submit a typed allowlisted transfer and read its status. | Unavailable |

The following read and activity behavior is the published contract. The typed
transfer section remains its publication gate.

### Read contract

The response contains only the public address, network/cluster, readiness,
maintenance and policy-lock flags, stable wallet/configuration version,
supported native/SPL deposit types, stable failure codes, and observation time.
It must not expose a Vault wallet id, private key, seed, signature material,
signer internals, RPC credentials, treasury membership, unrelated treasury
data, or provider payloads.

Site and caller identity are host-derived. A caller-provided site id, header,
cookie, bearer token, or request property cannot select another tenant.

### Typed transfer contract — unavailable

The transfer input contains generic chain facts only: typed asset/mint,
supported token standard and transfer type, amount when applicable,
destination address, network, wallet version, idempotency key, caller
correlation reference, expiry, and bounded allowlisted policy metadata.

Core must build or validate the transaction against explicit program and
instruction allowlists before signing. The contract never accepts unrestricted
signing authority or an arbitrary serialized transaction from the extension.
Core owns signer isolation, fee policy, rate/value limits, operation audit, and
chain submission mechanics. The extension owns its reservation and business
decision before calling Core.

The durable operation state is:

`accepted -> signing -> submitted -> confirmed`

with terminal or recovery states `rejected`, `failed`, `expired`, and
`indeterminate`. `indeterminate` means reconciliation is required; it is not a
definitive failure. A response-loss or timeout recovery reads by Core operation
id and/or the original idempotency key.

The response includes Core operation id, status, source, destination, asset,
amount, transaction signature only after submission, confirmation/finality
state, timestamps, stable error, retryability, and contract version.

### Activity contract

The v1 shape uses transaction-signature cursor pagination rather than claiming
a subscription transport. It returns only finalized inbound native/SPL
transfers, with activity id, wallet version, asset/mint, amount,
source/destination, signature, slot/block reference, confirmation state,
schema version, observation and confirmation times, and invalidation state.
`confirmationState` is `finalized` and `invalidationState` is `valid`; earlier
reorg-prone observations are never published. Core publishes chain facts only;
the consumer assigns deposit meaning and credits Balance idempotently by
transaction signature plus activity id.

### Published read/activity guarantees

- Exact capability authorization and host-derived site isolation are checked
  on every call.
- Read is limited to 60 calls/minute and activity to 6 calls/minute per
  host-derived calling extension per Cedros Data process; activity pages
  contain at most 25 signatures.
- The activity cursor is the last finalized transaction signature and remains
  usable across process restarts.
- Activity for current or retired wallet versions is resolved from Vault's
  validated public version history, so rotation does not make prior deposits
  undiscoverable.
- Raw RPC envelopes, Vault ids, credentials, signer internals, and serialized
  transactions never cross the service boundary.

### Unpublished transfer guarantees

- The idempotency scope is site + authenticated extension + operation.
- Same key and same canonical input returns the original operation without a
  second transfer.
- Same key with changed input returns `idempotency_conflict` and changes
  nothing.
- The operation and canonical fingerprint commit before signing begins and
  survive restart.
- A timeout after acceptance remains unknown until status or chain
  reconciliation proves the outcome.
- New requests must use the active wallet version; rotation does not erase
  status or activity for an older version.
- Expired, submitted, and indeterminate requests are never blindly
  resubmitted with a new key.
- Policy rate/value limits and durable transfer audit retention must be
  published before the transfer capability becomes available.

## Notification publication

See [Notification event publication v1](notification-event-publication-v1.md)
for the published operations, exact manifest grants, recipient configuration,
Rockpile Wasm example, state model, retry limits, and retention guarantees.
Keep `surfaces.server.events[]` and `setupSeeds.notifications[]` aligned.
`telemetry.emit-event` remains analytics and cannot acknowledge delivery.
Older hosts reject the required publication capabilities during installation.

## Casino Ownership Boundary

Cedros Casino remains responsible for accepted collections, deposit intents,
player-wallet association, mint/collection validation, beneficial ownership,
inventory, staking/unstaking/claims, Balance rewards, withdrawal eligibility
and reservation, verified destination selection, chain-event interpretation,
business idempotency/reconciliation, Casino audit records, and all Casino UI.

For deposits, the player signs through
`cedros-wallet:account-read-transaction-sign` using its explicit `transfer`
approval action and Wallet-owned submission to the current Core-provided public
address. Casino matches the resulting finalized activity to its deposit intent,
player wallet, and accepted asset before one idempotent Balance credit. Outbound
withdrawals remain disabled because the typed Core transfer/status capability
is not published. No Casino behavior moves into Core as part of this contract.

# Personal notification destinations v1

Available in Cedros Data **0.1.76**, with the bundled Notifications runtime.
This extends existing personal notification settings; no additional Wasm import,
publish capability, or publish audience is required. Addresses may be the user's
backup inboxes or designated third-party contacts. They are notification
endpoints, not additional sign-in or recovery identities.

## Authentication and configuration

Use `GET` and `PUT /admin/runtime/notifications/personal` with
`Authorization: Bearer <Cedros Login access token>` against the customer's Data
host. With the installed Cedros Login extension, Data forwards only the bearer
to Login's `cedros-login:public-auth-current-user` route (or the older
`cedros-login:get-current-user` binding), and derives the owner from the verified
`user.id` response. Login **0.0.74** publishes the supported native binding;
no admin role, organization membership, or relying-party secret is required.
The configured Login authentication profile and local-admin sessions remain
supported for their own identities. No administrator permission is required
for ordinary personal events.

The installed Login extension's `cedros_access` cookie is also supported for
same-site browser sessions: use `credentials: "include"`. Login-cookie-authenticated
writes require an `Origin` permitted by the site's runtime origin policy;
missing/untrusted origins receive HTTP 403. Explicit bearer requests do not
require a cookie or Origin. Caller-supplied identity headers never establish
ownership.

GET returns `destinationRoutingVersion: "1.0.0"`, `notifications`, `secrets`, and
`updatedAt`. **Check this feature marker before saving destination selections**;
older hosts do not enforce them. The response includes only the authenticated
user's channels, policy, and referenced secret inventory, never secret values.

PUT replaces that user's personal settings. Read first, preserve the returned
channels, policies and secret inventory, and submit `expectedUpdatedAt` equal to
GET's `updatedAt`. A concurrent settings edit produces HTTP 409; reload and
reapply the edit. The server checks the loaded revision even if the client
omits it. Other users' settings and site/team settings are preserved.

Example PUT body for a user with ID `customer-1` and no credential-backed channels
(replace the timestamp with the actual GET result):

```json
{
  "expectedUpdatedAt": "2026-09-10T12:00:00Z",
  "notifications": {
    "channels": [
      {
        "channelId": "notifications-email-primary-customer-1",
        "kind": "email", "label": "My email", "target": "me@example.com",
        "enabled": true, "metadata": {"ownerUserId": "customer-1"}
      },
      {
        "channelId": "notifications-email-contact-customer-1",
        "kind": "email", "label": "Trusted contact", "target": "contact@example.com",
        "enabled": true,
        "metadata": {"ownerUserId": "customer-1", "additionalEmail": true}
      }
    ],
    "metadata": {
      "userDeliveryPolicies": {
        "customer-1": {
          "personalNotificationTypes": {
            "rockpile-pro:activity": true,
            "rockpile-pro:duress": true
          },
          "personalNotificationChannelIds": {
            "rockpile-pro:activity": ["notifications-email-primary-customer-1"],
            "rockpile-pro:duress": ["notifications-email-contact-customer-1"]
          }
        }
      }
    }
  },
  "secrets": {"entries": [], "metadata": {}},
  "secretValues": []
}
```

Channel IDs must be unique within the site; use generated UUID-based IDs.
Ownership must match the verified principal. Every selected ID must reference a
channel owned by that user, never a team channel or another user's channel.
Invalid or duplicate selections are rejected. A destination list supports at
most 32 unique channel IDs; each user policy supports at most 256 event lists.
Email syntax is validated using the existing email provider rules. Saving an
address does not verify ownership of that mailbox or make it a Login identity;
this feature uses the existing notification-address permission model.

## Routing rules

- `personalNotificationTypes[eventId]` remains the user's event opt-in.
- When `personalNotificationChannelIds[eventId]` exists, it is the **complete**
  allowed destination list. `[]` means deliver nowhere, without fallback.
- When that event key is absent, legacy routing applies to ordinary personal
  channels. Channels marked `additionalEmail: true` are excluded from this
  default; they receive nothing until explicitly selected for an event.
- Explicit lists can include email, Discord, Telegram, and Slack channels.
  `additionalEmail: true` is only valid on personal email channels.
- Disabled/incomplete channels, quiet hours and severity policies remain in
  effect. No eligible destination rejects extension publication with
  `audience_not_authorized`.
- To delete an address, remove its channel and its IDs from all destination
  lists in the same PUT. Preserve empty lists rather than removing event keys
  when the intent is to stop delivery.
- Preferences are site- and user-scoped. Already accepted publications retain
  their durable routing snapshots; edits affect subsequent publications.

The built-in **Settings → Notifications → My alerts** UI supports adding/removing
additional emails and choosing destinations separately for each event. Editing
the primary email does not replace additional addresses.

## Extension publication

Declare both Rockpile events with `audience: "personal"` in notification setup
seeds and set `compatibility.minCedrosDataVersion: "0.1.76"`. Keep the existing
publish/status declarations from [notification-event-publication-v1.md](notification-event-publication-v1.md).
If the older team-audience example was already provisioned, use a new personal
seed ID (for example `rockpile-pro:duress-personal-route`): provisioning preserves
existing routes and does not rewrite their audience. Stop publishing this
subscriber event with the team audience.

Publish the existing body with the event's template variables and:

```json
{
  "eventId": "rockpile-pro:duress",
  "audience": {"kind": "personal", "recipientRef": "customer-1"}
}
```

This is a fragment of the full publish body, not an additional endpoint. The
extension supplies no addresses or channel IDs. It must derive `recipientRef`
from a verified user context or an authorized server-side job. Data authenticates
the calling extension and resolves only that user's opted-in destinations for
that event. The publish contract does not itself authenticate a browser user.

In the example, activity goes only to `me@example.com`; duress goes only to
`contact@example.com`. No site-wide team route or duress-specific storage exists.
Durable acceptance, idempotency, delivery status and provider retries are unchanged.

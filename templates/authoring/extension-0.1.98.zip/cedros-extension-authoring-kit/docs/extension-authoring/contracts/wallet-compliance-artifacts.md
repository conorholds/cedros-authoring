# Wallet And Compliance Implementation Artifacts

Use this with
[`wallet-compliance-seams.md`](wallet-compliance-seams.md)
when an extension needs to consume Cedros Wallet or Cedros Compliance at
implementation depth. The seams doc names the official contracts; this file
names the package artifacts, SDK helpers, fixtures, validation gates, and
professional-grade authoring checks that make those contracts usable without
private source spelunking.

## Authoring Rule

An extension author may treat Wallet or Compliance as implementation-ready only
when the target package archive includes the relevant schema, fixtures, public
authoring guide, SDK exports, route/event docs, staging smoke checklist, and
validation evidence listed below. If an artifact is missing from the installed
package or the package version does not match the required minimum, fail closed
and add a host handoff row.

## Cedros Wallet

Published contract:

| Field | Value |
|---|---|
| Contract id | `cedros-wallet:account-read-transaction-sign` |
| Contract version | `1.0.0` |
| Current Wallet version | `1.0.0` |
| Minimum Wallet version | `0.0.2` |
| Current package archive | `dist/cedros-wallet-1.0.0.cedros-extension.zip` |
| Provider modes | `cedros-embedded-wallet`, `solana-browser-wallet` |
| Browser provider names | `Phantom`, `Solflare`, `Host-approved Solana wallet` |
| Submission owner | Cedros Wallet |
| Pay fulfillment submission | `false` |
| Operational-wallet deposits | The explicit `transfer` approval action is authorized when the destination/network come from `cedros-data:site-operational-wallet-read-v1`; credit only after matching finalized activity from `cedros-data:site-operational-wallet-activity-read-v1`. |

Package artifacts:

| Artifact | Path |
|---|---|
| Contract schema | `workspace/shared/wallet/account-read-transaction-sign.schema.json` |
| Authoring guide | `workspace/CEDROS_WALLET_AUTHORING.md` |
| Route contracts | `workspace/CEDROS_WALLET_ROUTE_CONTRACTS.md` |
| Event schemas | `workspace/CEDROS_WALLET_EVENT_PAYLOAD_SCHEMAS.md` |
| Staging smoke checklist | `workspace/CEDROS_WALLET_STAGING_SMOKE.md` |
| Alignment validator | `scripts/validate-cedros-wallet-authoring.mjs` |

The Wallet authoring artifacts must cover:

- request and response fields, required/optional fields, enums, validation
  failures, and redacted examples
- dependency declarations and fail-closed consumer behavior
- host runtime exports and feature-detection helpers documented by the Wallet
  package authoring guide
- route contracts and event payload schemas
- explicit approval UX requirements for `mint`, `burn`, `transfer`, and
  `redemption-settlement`
- host handoff readiness signals for Wallet-owned chain submission
- versioning and deprecation rules
- a "do not do this" section covering public/theme route calls, private module
  imports, unsafe retries, unsafe wallet identifier storage, and event-driven
  workflow progression

Validation expectations:

- `scripts/validate-cedros-wallet-authoring.mjs` passes and verifies schema,
  docs, SDK exports, route/event docs, redaction rules, and package alignment
- web and native typecheck, tests, and builds pass
- Rust server tests pass
- Wasm artifact validation passes
- package generation and archive validation pass with the implementation
  artifacts included
- release readiness validation passes

Security expectation: Tokenization receives only redacted contract response
fields and a transaction signature only after explicit approval and
Wallet-owned submission. Private keys, seed/recovery phrases, auth headers, raw
provider payloads, unsigned transaction bytes, raw signed transaction bytes,
raw production PII, and provider private/session payloads must not appear in
Tokenization logs, analytics, props, database rows, route errors, fixtures, or
Site Brain records.

## Cedros Compliance

Published contract:

| Field | Value |
|---|---|
| Contract id | `cedros-compliance:policy-read-check-run-audit-record` |
| Contract version | `1.0.0` |
| Current Compliance version | `2.4.0` |
| Minimum Compliance version | `0.0.1` |
| Operations | `policy-read`, `check-run`, `audit-record` |
| Current package archive | `dist/cedros-compliance-2.4.0.cedros-extension.zip` |
| Archive SHA-256 | `fe4b2e24c7e70a9ecb400a6386bedcfced3ba54b4d7be172af75e0a55fe2f09c` |

Package artifacts:

| Artifact | Path |
|---|---|
| Contract/schema | `contracts/policy-read-check-run-audit-record.contract.json` |
| Event payload schema | `contracts/compliance-event-payloads.schema.json` |
| Staging fixtures | `contracts/fixtures/policy-read-check-run-audit-record.staging.json` |
| Authoring guide | `CEDROS_COMPLIANCE_CONTRACT_AUTHORING_GUIDE.md` |
| SDK exports | `@cedros/compliance-react/contracts` |

SDK helpers:

- `getCedrosComplianceTokenizationContract`
- `assertCedrosComplianceTokenizationContractAvailable`
- `createCedrosComplianceContractClient`
- `isCedrosComplianceFulfillmentAllowed`
- `isCedrosComplianceFailClosedDecision`
- `isCedrosComplianceEvidenceRef`

Fixture coverage:

- `allow`
- `deny`
- `manual-review`
- `freeze`
- `thaw`
- `blocked-mint`
- `blocked-burn`
- provider unavailable
- expired decision
- expired KYC
- unaccredited investor
- sanctions match
- unsupported jurisdiction
- missing evidence
- audit-write failure

The Compliance authoring artifacts must cover:

- exact request/response shapes for all operations
- complete event payload schemas marked analytics/cache/notification-only
- fail-closed consumer examples
- legal/product copy guidance
- evidence-ref format and handling
- host handoff acceptance criteria
- redaction/privacy expectations
- versioning and rollback rules
- staging smoke checks

Validation expectations:

- contract validators pass
- package/archive checks pass
- web and mobile typecheck/tests pass
- server tests pass
- formatting, whitespace, line-budget, and secret-shaped token scans pass

Security expectation: raw identity documents, sanctions payloads, provider
secrets, PII, auth headers, presigned URLs, raw provider rows, wallet secrets,
payment details, and unredacted evidence must not be returned to Tokenization
logs, analytics, props, database rows, Site Brain records, events, route
errors, or fixtures.

### KYC Self-Service Artifacts

Published contract:

| Field | Value |
|---|---|
| Contract id | `cedros-compliance:kyc-self-service` |
| Contract version | `1.0.0` |
| Minimum Compliance version | `2.4.0` |
| Operations | `status-read`, `verification-start` |
| Route ids | `cedros-compliance:kyc-status`, `cedros-compliance:kyc-start` |
| SDK export | `@cedros/compliance-react/contracts` |

Package artifacts:

| Artifact | Path |
|---|---|
| Contract/schema | `contracts/kyc-self-service.contract.json` |
| Staging fixtures | `contracts/fixtures/kyc-self-service.staging.json` |
| Authoring guide | `CEDROS_KYC_INTEGRATION_GUIDE.md` |
| Contract validator | `scripts/validate-kyc-contract.mjs` |

SDK helpers and exports:

- `getCedrosComplianceKycSelfServiceContract`
- `assertCedrosComplianceKycSelfServiceAvailable`
- `createCedrosComplianceKycClient`
- `isCedrosComplianceKycVerified`
- `isCedrosComplianceKycEnforced`
- `isCedrosComplianceKycRequiredFor`
- `canStartCedrosComplianceKycVerification`
- `CedrosComplianceKycError`

The fixture suite covers every KYC status, nullable timestamps, each
enforcement mode, a successful idempotent verification start, authentication
required, KYC disabled, provider unavailable, and concurrent-start conflict.
Consumers must run the fixtures against the installed host and also verify:

- contract discovery for present, missing, old, disabled, and route-incomplete
  Compliance installations;
- bearer and same-origin cookie authentication plus logout/session expiry;
- preservation of `Cache-Control`, contract id, and contract version headers;
- exact idempotent replay without a second provider session;
- bounded callback polling across pending, completion, timeout, cancellation,
  retry, and unmount;
- elapsed verification resolves as `expired` and every malformed/unavailable
  response is non-verified;
- no session id, token, PII, provider payload, document, secret, or raw record
  reaches logs, analytics, errors, Site Brain, or durable consumer storage;
- the separate policy/check/audit fixture suite gates every protected business
  action, because KYC status alone is not authorization.

## Consumer Checklist

- Pin the minimum official extension version and contract version.
- Feature-detect the contract using the package-provided SDK helper or schema
  registry before enabling dependent UI or jobs.
- Use staging fixtures and smoke checks before marking a dependency published
  in release readiness.
- Treat events as analytics/cache/notification signals only.
- Route every missing contract, missing host seam, stale dependency, invalid
  fixture, unavailable provider, failed audit write, rejected wallet action, or
  unsupported jurisdiction to fail-closed behavior.

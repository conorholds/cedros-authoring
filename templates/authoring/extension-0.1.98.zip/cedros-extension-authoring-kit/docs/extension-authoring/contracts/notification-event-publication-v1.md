# Durable notification events v1

Available in Cedros Data **0.1.75+**, with the exact capabilities below. This
uses the Notifications runtime bundled with Data; no separate Notifications
extension version is required. Hosts must run the existing automation worker
and have the relevant delivery providers configured. Source availability is not
proof that a particular hosted installation has been upgraded. The per-subscriber
destination example below requires **0.1.76+**.

Previously the documentation was correct: route provisioning and a best-effort
telemetry side effect existed, but durable extension publish/status did not.
`telemetry.emit-event` still provides no acceptance or delivery guarantee. Do not
also emit the same alert through telemetry: its legacy best-effort routing can
create a separate notification outside this idempotency scope.

## Manifest and Wasm authentication

Merge these fields into Rockpile's existing manifest (retain its packages,
registration, routes, and compatibility/WIT checksum declarations):

```json
{
  "extensionId": "rockpile-pro",
  "compatibility": {"minCedrosDataVersion": "0.1.76"},
  "requiredCapabilities": [
    "cedros-notifications:route-write",
    "cedros-data:notification-event-publish-v1",
    "cedros-data:notification-event-status-read-v1"
  ],
  "dependencies": {
    "capabilities": [
      {"capabilityId": "cedros-notifications:route-write", "required": true},
      {"capabilityId": "cedros-data:notification-event-publish-v1", "required": true},
      {"capabilityId": "cedros-data:notification-event-status-read-v1", "required": true}
    ]
  },
  "surfaces": {"server": {"events": ["rockpile-pro:activity", "rockpile-pro:duress"]}},
  "setupSeeds": {"notifications": [
    {
      "id": "rockpile-pro:activity-route",
      "displayName": "Rockpile activity", "title": "Rockpile activity",
      "eventId": "rockpile-pro:activity", "audience": "personal", "severity": "info",
      "defaultChannels": ["email", "discord", "telegram"],
      "bodyTemplate": "{{message}}"
    },
    {
      "id": "rockpile-pro:duress-personal-route",
      "displayName": "Rockpile duress", "title": "Rockpile duress alert",
      "eventId": "rockpile-pro:duress", "audience": "personal", "severity": "error",
      "defaultChannels": ["email"],
      "subjectTemplate": "Rockpile duress alert", "bodyTemplate": "{{message}}"
    }
  ]}
}
```

Import `cedros:extension/extension-services@0.1.0` in the component's WIT world.
No new WIT ABI is required. The host binds the installed extension identity and
active site's store; callers cannot supply another site, bearer token, user
cookie, or destination. The host checks the exact capability dependency on
every invocation, plus the namespaced event and matching manifest seed on
publish. A browser must call an authenticated Rockpile route whose own
permissions authorize the business action; never expose an unrestricted
public endpoint that forwards arbitrary publication requests.

The following Rust function uses the standard `wit-bindgen` generated imports
(`crate::cedros::extension::extension_services`) from the authoring kit:

```rust
use crate::cedros::extension::extension_services::{self, ServiceRequest};

fn publish_activity(body_json: String) -> Result<String, String> {
    let response = extension_services::invoke(&ServiceRequest {
        target_extension_id: "cedros-data".into(),
        route_id: "cedros-data:notification-event-publish-v1".into(),
        capability_id: "cedros-data:notification-event-publish-v1".into(),
        method: "POST".into(),
        path: "/runtime/notification-events/publish-v1".into(),
        query: vec![],
        body_json,
    }).map_err(|error| error.message)?;
    if response.status != 200 {
        return Err(response.body);
    }
    Ok(response.body) // Parse the contract state; 200 does not mean delivered.
}
```

Activity `body_json`:

```json
{
  "contractId": "cedros-data:notification-event-publication-v1",
  "contractVersion": "1.0.0",
  "eventId": "rockpile-pro:activity",
  "eventSchemaVersion": 1,
  "occurrenceId": "activity-000001",
  "occurredAt": "2026-09-10T12:00:00Z",
  "audience": {"kind": "personal", "recipientRef": "host-user-id"},
  "severity": "info",
  "templateVariables": {"message": "Your Rockpile activity has completed."},
  "correlationRef": "rockpile-job-000001"
}
```

For per-subscriber duress use `eventId: "rockpile-pro:duress"`, a stable occurrence
ID, `audience: {"kind": "personal", "recipientRef": "host-user-id"}`, and
`severity: "error"`. Configure the subscriber's additional email destinations
and an explicit event destination list using the authenticated
[personal notification destinations API](personal-notification-destinations-v1.md)
(**Data 0.1.76+**). This keeps contacts separate from activity destinations.

## Customer and recipient configuration

Use existing **Settings > Notifications** controls. Active extension seeds
appear in the event catalog. For activity, each user connects email, Discord,
or Telegram endpoints in their personal settings and opts into Rockpile activity.
The stored channel's `metadata.ownerUserId` must equal `recipientRef` and
`metadata.userDeliveryPolicies[recipientRef].personalNotificationTypes[eventId]`
must be true. These are host-owned settings. The personal settings API
`GET/PUT /admin/runtime/notifications/personal` authenticates the actor and only
allows that actor's endpoints and preferences. Keep its existing optimistic
concurrency and secret handling; never write directly to host tables.

Additional email addresses and per-event selections are configured by each user,
not by a site-wide team route. Email uses the site's configured email provider.
Discord/Slack webhooks and Telegram bots use existing secret references; secrets
are not returned to the extension. Site-wide alerts can still use team routes.

All settings, publications, channel snapshots, and status queries are scoped to
the active site's database. An extension can publish only its own events and
read only its own publication IDs. `recipientRef` is a saved host user reference,
not an email address. A missing opt-in or no eligible channel rejects with
`audience_not_authorized`. Missing/disabled seeds reject with `route_missing` /
`route_disabled`. Multiple matching routes reject with `route_ambiguous`.

`defaultChannels` provides setup hints; actual delivery follows the saved
channel configuration. Select only the subscriber's designated email channels for the duress event
to keep it email-only. Disabled channels, owner boundaries, personal opt-ins,
severity thresholds and quiet hours remain effective. Duress is not
an emergency-delivery bypass: customers must configure the appropriate policy.

## Acceptance, status and retries

Publication success returns `durablyAccepted: true`, a UUID `publicationId`,
the occurrence ID, timestamps, and usually `status: "delivery_pending"` with
`deliveryState: "pending"`. It means intent, input fingerprint, delivery entries,
and routing snapshot committed before provider I/O.

Use the same Wasm import for status with both route/capability set to
`cedros-data:notification-event-status-read-v1`, path
`/runtime/notification-events/status-v1`, method `POST`, and either:

```json
{
  "contractId": "cedros-data:notification-event-publication-v1",
  "contractVersion": "1.0.0",
  "eventId": "rockpile-pro:activity",
  "occurrenceId": "activity-000001",
  "correlationRef": "rockpile-status-000001"
}
```

Or replace `eventId` and `occurrenceId` with `publicationId`. When supplying
both forms they must identify the same row. Unknown or foreign IDs return 404
`publication_not_found`; destinations, rendered messages and provider errors
are not exposed.

| Status | Meaning |
|---|---|
| `rejected` | This attempt was not accepted; see stable error code. A conflicting attempt does not alter the original publication. |
| `delivery_pending` | Accepted; queued, sending, or awaiting an automatic retry. |
| `delivered` | All selected providers accepted delivery. This is not proof of inbox arrival or recipient reading. |
| `terminally_failed` | Permanent/exhausted failure, partial delivery, or policy-skipped delivery. Some channels may already have succeeded. |
| `indeterminate` | Provider outcome is ambiguous, including expired sending leases. Reconcile; do not create a fresh occurrence. |

The idempotency scope is site + authenticated extension + event ID + occurrence
ID. Exact input replay returns the original publication without another send,
including after settings change or restart. Changed input returns
`idempotency_conflict`. A timeout/503 has an unknown commit outcome; look up the
original event/occurrence, then replay only the identical payload if needed.
Do not change timestamps, variables or correlation reference during replay.

Cedros automatically retries explicitly retryable failures, with **5 total
attempts**. Backoff uses full jitter from zero to `min(900, 5*2^(attempt-1))`
seconds; provider Retry-After can extend this to 3600 seconds. Ambiguous sends
are not blindly retried. Transport cannot guarantee exactly-once provider
receipt. Existing administrative retry controls remain subject to fencing and
partial-success restrictions; this API has no force-retry operation.

## Limits and storage

- 16 KiB serialized request; 32 template variables, scalar or arrays of at most
  20 scalars. Keys are 1–64 ASCII letters, digits, `_` or `-`.
- Event schema version 1 only. Occurrence IDs are 8–128 ASCII letters, digits,
  `.`, `_`, `~`, or `-`. At most 32 selected channels.
- 60 new accepted publications per rolling minute per site/extension,
  enforced across Data processes; exact replays are free. Rate rejection is 429.
- `{{variable}}` substitution is single-pass; missing variables reject. Rendered
  title, subject and body are each limited to 16 KiB.
- Idempotency keys and status have no automatic expiry and survive restarts;
  retention lasts for the site database's lifetime unless administratively
  removed. Existing notification outbox and Site Brain records store rendered
  content. Supply redacted messages, not credentials or sensitive duress details.

The [machine contract](notification-event-publication-v1.contract.json) and
[fixtures](fixtures/notification-event-publication-v1.fixtures.json) ship in the
current authoring kit. Pre-dispatch manifest/grant failures use the existing
Wasm host-error result; contract validation failures use a non-200 response.

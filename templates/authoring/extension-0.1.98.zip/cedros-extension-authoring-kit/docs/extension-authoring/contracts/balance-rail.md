# Cedros Balance Rail Official Seam

Use this with
[`../18-official-extension-integrations.md`](../18-official-extension-integrations.md)
and
[`../19-composability-and-relying-party-contracts.md`](../19-composability-and-relying-party-contracts.md)
when an extension needs to read or move credits owned by Cedros Balance.

Cedros Balance `0.5.0` publishes the provider-side contract for balance read,
credit, debit, hold, capture, release, and atomic account-to-account transfer.
Its package artifacts are the normative sources:

- `CEDROS_BALANCE_RAIL_API.md`
- `cedros-balance-rail.openapi.json`
- Cedros Balance implementation commit `feaa353`

The provider and consumer seam are published. Cedros Data supplies authenticated
extension-to-extension invocation through the Wasm
`extension-services.invoke` import. Financial production use still requires the
target provider, consumer, grants, and installed host to pass the acceptance
matrix below. Consumers must not simulate the host binding with public routes,
`http.fetch`, headers, cookies, bearer tokens, or request JSON.

## Ownership Boundary

Cedros Balance owns its ledger, transactions, holds, account balances, and
rollups. Consumers call the published Balance routes and must never read or
write Balance-owned content models, settings, or private package modules.

Cedros Pay owns checkout, card and stablecoin rails, payment state, refunds,
disputes, and reconciliation. Pay may fund or spend Balance through this
contract, but Pay is not the ledger for Casino wagering or player-to-player
transfers. Casino and P2P consumers use Balance hold/capture/release and atomic
transfer; they do not model those movements as Pay checkouts.

## Provider Publication Contract

The provider publishes each operation in two aligned places:

- root `capabilities[]` contains the operator-reviewed
  `cedros-balance:balance-*` capability;
- `surfaces.server.routes[]` contains the corresponding Wasm route id.

| Capability | Route id | Method and mounted path |
|---|---|---|
| `cedros-balance:balance-read` | `cedros-balance:rail-balance-read` | `GET /extensions/cedros-balance/credits/rail/balance/{user_id}` |
| `cedros-balance:balance-credit` | `cedros-balance:rail-balance-credit` | `POST /extensions/cedros-balance/credits/rail/credit/{user_id}` |
| `cedros-balance:balance-debit` | `cedros-balance:rail-balance-debit` | `POST /extensions/cedros-balance/credits/rail/debit/{user_id}` |
| `cedros-balance:balance-hold` | `cedros-balance:rail-balance-hold` | `POST /extensions/cedros-balance/credits/rail/hold/{user_id}` |
| `cedros-balance:balance-capture` | `cedros-balance:rail-balance-capture` | `POST /extensions/cedros-balance/credits/rail/capture/{hold_id}` |
| `cedros-balance:balance-release` | `cedros-balance:rail-balance-release` | `POST /extensions/cedros-balance/credits/rail/release/{hold_id}` |
| `cedros-balance:balance-transfer` | `cedros-balance:rail-balance-transfer` | `POST /extensions/cedros-balance/credits/rail/transfer` |

Publishing metadata makes an operation discoverable; the active host still
checks the caller, dependency versions, capability declaration/grant, provider
publication, and bound route on every invocation.

Installed-host public contract discovery projects only these seven allowlisted
route and capability ids plus the installed Balance version. This supports
feature detection; it does not expose private Balance metadata and does not make
the service routes browser-callable.

## Consumer Manifest

Declare Cedros Balance `0.5.0+`, list each consumed operation in
`dependencies.capabilities[]`, and keep the flattened
`requiredCapabilities[]` install-gating view aligned:

```json
{
  "dependencies": {
    "extensions": [
      {
        "extensionId": "cedros-balance",
        "required": true,
        "minVersion": "0.5.0",
        "reason": "Atomic credit reservation and wager settlement."
      }
    ],
    "capabilities": [
      {
        "capabilityId": "cedros-balance:balance-hold",
        "required": true,
        "reason": "Reserve a player's available credits before a wager."
      },
      {
        "capabilityId": "cedros-balance:balance-capture",
        "required": true,
        "reason": "Settle a reserved debit."
      },
      {
        "capabilityId": "cedros-balance:balance-release",
        "required": true,
        "reason": "Return a reservation after cancellation or failure."
      },
      {
        "capabilityId": "cedros-balance:balance-transfer",
        "required": true,
        "reason": "Atomically settle credits between Balance accounts."
      }
    ]
  },
  "requiredCapabilities": [
    "cedros-balance:balance-hold",
    "cedros-balance:balance-capture",
    "cedros-balance:balance-release",
    "cedros-balance:balance-transfer"
  ]
}
```

Request only the operations the consumer actually uses. A required dependency
blocks install or enable when the provider or grant is unavailable. An optional
dependency must hide or disable every dependent action and must never fall back
to Pay or direct Balance storage access.

## Host-Authorized Invocation

Call `extension-services.invoke` from the consumer Wasm component with:

- `target-extension-id: "cedros-balance"`;
- the exact route and capability ids from the table above;
- the route's method and concrete mounted path;
- ordered query pairs and the JSON body string.

The request type deliberately has no headers field. The host:

1. authenticates the calling extension;
2. sets `authenticated: true` and `actorId` to that extension's stable id;
3. injects exactly one `permissionClaims[]` value matching the target operation;
4. rejects missing, wrong, duplicate, or multiple operation claims;
5. makes the service route unavailable to browsers and end-user sessions;
6. rejects self-calls, cycles, inactive providers, version mismatches,
   undeclared grants, unpublished capabilities, and unbound routes.

`actorId`, `authenticated`, and `permissionClaims` are host-owned context.
Inbound headers, cookies, bearer tokens, and request JSON cannot self-grant an
operation. Consumers compile against the target host's current WIT checksum;
components built before `extension-services` was published cannot call it and
must be rebuilt.

## Request And Replay Rules

Account ids are opaque, case-sensitive identifiers. The caller resolves a
current authorized source account before invoking a mutation and never accepts
an untrusted client-supplied source account. Currency ids are uppercase and
case-sensitive; `SOL` is the default. Amounts are positive signed 64-bit
integers in the currency's smallest unit.

Credit, debit, hold, and transfer require a stable `idempotencyKey` containing
8–128 URL-safe characters. A timeout has an unknown outcome: retry the exact
same semantic request with the same key. Exact replay returns the originally
committed result with `applied: false` or `isNew: false`; reuse with a different
actor, account, amount, currency, reason, or reference returns `409 CONFLICT`.

Capture derives its identity from `capture:{hold_id}`. Release is a guarded
terminal transition. Duplicate capture and release return success with
`applied: false`; a captured hold cannot be released.

## Concurrency And Atomic Transfer

Balance `0.5.0` requires `cedros-data:extension-storage-cas-v1`. Transfer uses
`database.compare-and-set` to commit the source debit, destination credit, both
account balances, and the currency rollup in one guarded database operation.
The paired ledger entries share a `transferId`, point to one another with
`counterpartTransactionId`, and record the authenticated service actor.

A guard conflict commits nothing and returns retryable `409 CONFLICT`.
Consumers retry the identical request with bounded exponential backoff and
jitter; they never change the idempotency key or compensate before an
idempotent retry or ledger read establishes the committed outcome.

## Errors

Errors use `application/problem+json` with stable `status`, `code`, `message`,
and optional `requestId` fields.

| Status/code | Meaning | Consumer action |
|---|---|---|
| `400 VALIDATION_ERROR` | Malformed input, invalid state, or insufficient spendable credit. | Correct the request or business state; do not retry unchanged. |
| `401 UNAUTHORIZED` | The host did not authenticate a service actor. | Fail closed and repair the host binding. |
| `403 FORBIDDEN` | The exact operation capability was not granted. | Fail closed and request operator approval. |
| `404 NOT_FOUND` | A requested capture hold does not exist. | Reconcile the originating workflow. |
| `409 CONFLICT` | Concurrent mutation or idempotency-key misuse. | Retry only the identical request with bounded backoff when the request is otherwise valid. |
| `500 SERVER_ERROR` | Internal or inconsistent stored state. | Fail closed, preserve the key, and escalate with the request id. |
| `503 SERVICE_UNAVAILABLE` | A dependency or safety bound is unavailable. | Retry the identical request with backoff; never fall back to Pay or direct storage. |

## Installed-Host Acceptance Matrix

Do not enable money movement until the installed provider, consumer, grants,
and host invocation binding pass every row.

| Area | Exercise | Required result |
|---|---|---|
| Operation grants | Invoke every granted capability independently. | Only the matching route succeeds; missing, wrong, duplicate, and multiple claims fail closed. |
| Browser isolation | Attempt each route from a browser session, cookie, bearer token, forged header, and forged JSON context. | No request gains service authorization. |
| Happy path and replay | Run credit, hold, capture, release, and transfer, then repeat the exact request. | One mutation commits; replay returns the original result and ids without another write. |
| Semantic mismatch | Reuse an idempotency key with changed input or actor. | `409 CONFLICT`; no state changes. |
| Spendable balance | Debit or transfer more than total minus active holds. | Validation failure; no ledger or balance mutation. |
| Account concurrency | Race hold against debit/transfer. | One guarded commit and one retryable conflict; no lost update. |
| Hold concurrency | Race capture against release or expiry. | Exactly one terminal hold state and at most one debit. |
| Transfer atomicity | Inspect the source debit, destination credit, both balances, and rollup. | All linked records commit together or none commit. |
| Dependency failure | Disable or make Balance unavailable during a consumer workflow. | Consumer fails closed without Pay fallback or direct storage access. |

Release evidence records the target host, provider and consumer versions,
archive checksums, granted capabilities, request ids, concurrency results, and
observed replay bodies. Local tests and static Forge scans are preliminary;
they do not replace this installed-host matrix.

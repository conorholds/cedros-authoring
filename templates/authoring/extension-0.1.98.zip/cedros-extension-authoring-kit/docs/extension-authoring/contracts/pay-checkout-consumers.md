# Pay checkout consumer reference

## Publication status and provenance

`cedros-pay:checkout` is **host-coordinated**: canonical one-time checkout is
implemented, but the owning contract still requires guarded-policy activation
and joint host/Shop conformance evidence before publication. It is not published
at Pay `2.0.0`. The legacy `cedros-pay:paywall` checkout route is **unavailable**.
Published catalog, buyer-history, entitlement, and service payment-status reads
do not publish checkout or waive its activation gate.

This reference pins Pay `4.0.47`, payload `schemaVersion: 1`, to source
[`ad84d59af5b1ef0591fb09b7024b510abb5b8b5e`](https://github.com/conorholds/cedros-pay-dev/tree/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e).
The versioned ZIP's `workspace/supply-chain/source.json` identifies that source.
The [owner's checkout contract](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/docs/cedros-pay-checkout-contract.md)
and [final release-readiness packet](https://github.com/conorholds/cedros-pay-dev/blob/c21963cb37760aca8fe8dcaf676301c9a7c4add9/cedros-extension.release-readiness.json)
retain the launch gate. The final packet marks the install gate ready and the
launch gate blocked; an installed extension is not evidence of launch completion.

On 2026-10-04, the read-only cedros.ai MCP registry reported Data `0.1.89`,
Pay `4.0.47`, and Shop `4.0.13` active. Pay's admin status route returned HTTP
403 to this operator session, so target-site marker readiness was not verified.
No payment, policy enrollment, or site configuration was changed. Source Pay
5.x is a separate coordinated release and must not be inferred from this
installed Pay 4 contract.

## Exact checkout contracts

The bundled [JSON schemas](pay-checkout-schemas.json) are a byte-for-byte copy
of the pinned owner's `docs/fixtures/cedros-pay-checkout-schemas.json`.
Use the named `$defs` below; each is the exact request or success response,
including nested fields, enums, required fields, and unknown-field rejection.
The [owner's request/quote fixtures](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/docs/fixtures/cedros-pay-checkout-contract.json),
[outcome fixtures](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/docs/fixtures/cedros-pay-checkout-outcomes.json),
and [error/no-effect matrix](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/docs/fixtures/cedros-pay-checkout-errors.json)
provide the corresponding examples. Fixture hash values are illustrative,
not production request material.

All paths below are relative to the host-supplied mounted Pay API base
(on cedros.ai, `/extensions/cedros-pay`). Do not invent a private sidecar URL.

| Route ID | Method/path | Request `$defs` | Response `$defs` |
|---|---|---|---|
| `cedros-pay:checkout-descriptor` | `GET /checkout/descriptor` | No body or query | `descriptor` |
| `cedros-pay:checkout-quote` | `POST /checkout/quote` | `quoteRequest` | `quoteResponse` |
| `cedros-pay:checkout-create` | `POST /checkout` | `checkoutRequest` | `paymentOutcome` |
| `cedros-pay:checkout-status` | `GET /checkout/{operationId}` | No body or query; `operationId` | `paymentOutcome` |
| `cedros-pay:checkout-resolve` | `POST /checkout/resolve` | `resolveRequest` | `resolveOutcome` |
| `cedros-pay:checkout-return-verify` | `POST /checkout/return/verify` | `verifyReturnRequest` | `verifyOutcome` |

### Authentication and transport

Canonical checkout routes require one `Authorization: Bearer <buyer Login
access token>` header. Pay verifies that credential through Login's public
current-user contract; no consumer-held Pay service secret or guest identity
is accepted. A cookie alone is insufficient for this route family: its
[transport preflight](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/server-wasm/domain/src/routes/canonical_checkout_transport.rs)
requires Authorization even though other buyer routes accept same-origin
Login cookies. Do not confuse operator MCP authority with a verified buyer.
Site, environment, buyer, and provider authority are host-derived.

The Cedros Data HTTP host can adapt its first-party `cedros_access` cookie to
that bearer header for these six canonical routes. This adapter requires one
`Sec-Fetch-Site: same-origin` header; writes also require one Origin accepted
by the site's runtime origin policy. It forwards only a single unambiguous
Login access cookie, never replaces explicit Authorization, and does not grant
Core authority. Pay still verifies the buyer through Login. Consumers must
verify this host behavior is deployed before relying on cookie-only browser
checkout; it does not change Pay's bearer transport contract.

POSTs require exactly `Content-Type: application/json`, no query parameters,
strict JSON bodies of at most 16 KiB, and `schemaVersion: 1`. Quote/create also
require `Idempotency-Key` byte-equal to body `idempotencyKey`: 1–67 visible
ASCII characters. Use separate stable keys for quote and checkout, preserve
the original opaque `attemptId`, and replay identical material after an
unknown outcome. Both require a 64-character lowercase `clientMaterialSha256`
binding the complete client material to the descriptor's fixed operation scope.
It is correlation material, never price authority. Changed material under
the same key conflicts; it must not trigger a second charge.

### One-time flow after publication and activation

1. Declare `cedros-pay` and `cedros-pay:checkout` dependencies and discover the
   installed contract/base. Read the descriptor under the buyer's session.
2. Quote explicit items, for example `source: { kind: "items", items:
   [{ resource: "directory-listing-fee", qty: 1 }] }`. `resource` is the Pay
   product ID, not a Directory listing ID. Supply `customerContext` with
   digital fulfillment and allowlisted HTTPS success/cancel URLs, plus the
   requested configured payment methods. Pay reloads catalog prices and
   determines the authoritative quote; callers do not supply a fee total.
3. Create checkout with the quote's `operationId` as `quoteOperationId`, the
   same attempt/context, and one quoted `paymentMethod`. Persist the opaque
   checkout operation and attempt association in the consuming extension.
4. For Stripe `action_required`, resolve the returned artifact with exact
   operation/attempt correlation. Only a `resolved` response supplies an
   ephemeral `checkoutUrl`; validate the contract's Stripe HTTPS origin.
   Status reads do not return a provider URL.
5. Recover through status; for Stripe returns call return verification with
   exactly `{ schemaVersion: 1, expectedAttemptId, returnArtifact }`. It does
   not accept a caller-supplied operation ID. Accept only `status: "verified"`
   with matching `checkoutAttemptId`, or the exact buyer-scoped operation's
   `paid` outcome. Pay requires durable paid proof and settles atomically
   before verification succeeds. Browser navigation to a success URL alone
   is not proof.
6. `processing` and `indeterminate` remain unpaid for fulfillment purposes;
   recover the existing operation without a new attempt. `mismatch`, malformed
   responses, authentication failure, and unavailable Pay fail closed.
   Apply Directory fulfillment once per owned fee obligation/payment binding.

The same canonical family supports configured x402 and credits rails through
the schema's `railProof`; their completion uses `paymentOutcome`, not Stripe
return verification. No legacy direct payment alias is a fallback.

## Catalog handoff

`cedros-pay:product-read` (`GET /products/v1/catalog`) is a published public
active-product read usable by Shop, Directory, or another extension.
`cedros-pay:product-create` (`POST` to that path) requires its host-verified
capability/admin context; it is not a buyer checkout endpoint.

Older catalog documentation described `checkoutUrl`. In Pay `4.0.47`, the
[catalog projection](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/server-wasm/domain/src/routes/products/catalog_projection.rs)
deliberately exposes this instead:

```json
{
  "purchaseAction": {
    "capabilityId": "cedros-pay:checkout",
    "routeId": "cedros-pay:checkout-create",
    "urlOwner": "host"
  }
}
```

The host/consumer composes navigation from published installed routes; Pay
does not supply a product-detail or durable provider checkout URL. A legacy
`checkoutUrl` is a navigation hint under its own versioned contract, not
payment proof, a refund API, or evidence that canonical checkout is published.
The ephemeral `resolveOutcome.checkoutUrl` above is a different field with
operation-specific meaning. Product availability does not override checkout's
host-coordinated status.

## Buyer purchase history and resource association

Published `cedros-pay:purchases` is `GET /paywall/v1/purchases`, with no body.
It requires a verified Login buyer: bearer access token, or `cedros_access`
with the route's same-origin checks. API consumers should forward the buyer
bearer, not assert a user ID. Query `limit` defaults to 50, clamps to 1–500;
`offset` defaults to 0 and clamps to nonnegative. Rows sort by creation time
descending. The exact [handler/projection](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/server-wasm/domain/src/routes/purchases.rs)
returns `{ purchases: [...] }`; each row contains:

| Field | Wire type / meaning |
|---|---|
| `signature` | String; ledger payment reference, not a general wallet proof. |
| `resourceId` | Optional string; ledger `productId`. |
| `amount` | String; gross minor units formatted as a two-decimal major amount. |
| `amountCents` | Integer; gross minor units. |
| `currency`, `provider` | Strings from the payment ledger. |
| `status` | String, `succeeded` for returned rows. |
| `paidAt` | String; ledger `processedAt`. |

The response includes only this buyer's succeeded `payment` rows; no arbitrary
buyer lookup, raw metadata, wallet, profile ID, or provider-internal fields.
Canonical settlement stores the complete purchased-product set internally,
but this projection exposes only the first product as `resourceId`, when
present. It is not a full multi-item receipt or a Directory listing/claim ID.

Directory should own a durable association between its fee obligation,
authenticated owner, fee product, quote, checkout operation, and attempt.
For a single fee product, `resourceId` supports a history display; repeated
payments for the same product cannot identify which listing was paid without
that Directory-owned association. Canonical requests reject unknown fields,
so do not inject listing IDs or custom attribution metadata into them. History
does not establish listing ownership or authorize fulfillment. Use the bound
canonical proof above; use entitlement checks for current product access.

## Payment and refund state

Buyer history has **no** `refundCents`, refund status, net amount, dispute
state, or full product set. A succeeded payment can remain in history after
a refund; `status: "succeeded"` is not a current unrefunded-access guarantee.
Likewise canonical `paid`/`verified` proves settlement, not perpetual access.
Entitlement consumers must recheck Pay and invalidate on the published
`cedros-pay:entitlement-changed` event.

Published `cedros-pay:payments` is a separate service-to-service contract:
`GET /payments/v1/status?ref=<ledger-entry-key>`, no body. Its
[exact handler](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/server-wasm/domain/src/routes/payments.rs)
requires `Authorization: Bearer <relying-party shared secret>` configured in
Pay as `relying_party.shared_secret`; absent configuration returns 403,
missing/wrong credentials 401, missing `ref` 400, unknown entry 404.
The parameter is `ref`, not `ledgerRef`, `paymentRef`, or `operationId`.
Its successful response has these fields:

```text
{ reference: string, status: string, kind: string,
  grossCents: integer, refundCents: integer, netCents: integer,
  currency: string, processedAt: string }
```

Refund amounts distinguish zero, partial, and full refunds against gross;
do not invent a buyer-history `refunded` enum. This response has no buyer or
product identity, so a trusted consumer must independently authorize its
owned payment/resource association before reading or using it. It is not
buyer-authenticated or a drop-in substitute for canonical verification.
Declare this exact service contract only if needed; keep its credential
server-side. It is not a general Pay setup requirement for every consumer.
Directory owns refund consequences for listings/claims; Pay owns financial
settlement and refund truth. No new Pay/Data functionality is implied.

## Activation prerequisites

Pay `4.0.47` requires Data `0.1.81+` with matching WIT/extension-services and
`cedros-data:extension-storage-cas-v1`. A sufficient host version alone does
not prove activation. The exact [compiled policy contract](https://github.com/conorholds/cedros-pay-dev/blob/ad84d59af5b1ef0591fb09b7024b510abb5b8b5e/server-wasm/domain/src/guarded_policy/contract.rs)
requires eighteen guarded-only models, model-set SHA-256
`eb25861790db9cb6da3145426b0afb4dce17b29a39b70651c523f1ed720972b2`,
and marker `cedros-pay:guarded-write-policy-state/active`. The marker includes
the exact model list, capability, minimum host version, request/schema version,
host provenance, `policy: "guarded-only"`, `active: true`, and host timestamp;
a boolean flag or the older fourteen/seventeen-model marker is insufficient.

The operator uses `cedros-pay:guarded-policy-enroll`,
`POST /admin/guarded-policy/enroll`, with authenticated admin write authority
and `{}` only. MCP discovery exposes its strict input schema and output
`{ newlyEnrolled: boolean, modelCount: integer, modelSetSha256: string }`.
Enrollment must use the installed artifact's compiled set; consumers neither
write the marker nor reopen guarded models themselves.

Before the owning teams mark checkout published and enable consuming traffic,
retain artifact-tied evidence for archive identity, Wasm route/job binding,
exact policy enforcement across workers/restart, configured rails and allowed
return origins, customer-context HMAC authority, relevant inventory/tax/shipping/
tipping configuration, and replay/recovery/return/settlement failures. Complete
the joint Pay/Shop hard-cutover matrix against exact host and extension digests.
The owner's packet still lacks the immutable joint-run URL and assertions;
that recorded prerequisite must be resolved, not inferred from installation.

Until publication and target-site readiness are established, keep Directory's
optional charged listing/claim flow disabled with an explicit handoff to Pay
and Data owners. Directory's free flow, fee policy, association records, and
fulfillment remain Directory-owned. This documentation correction neither
activates payments nor requests a new host or Pay feature.

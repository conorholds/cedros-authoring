# Affiliate Resources And Payouts Host Contract

> Status: coordination-only proposal. Cedros Data does not publish the route or
> payout operations in this document. Consumers must fail closed.

Use this with
[`../18-official-extension-integrations.md`](../18-official-extension-integrations.md)
when an affiliates extension exposes approved-affiliate resources and payout
queue workflows.

This is a Host/Web and Pay coordination contract. Affiliates owns affiliate
profiles, applications, resource records, and affiliate approval state. Host/Web
owns the friendly account route mount. Cedros Pay owns any future direct payout
settlement. CRM tags are visibility mirrors only.

## Contract Registry

| Contract id | Type | Status | Owner | Consumer | Purpose |
|---|---|---|---|---|---|
| `cedros-data:affiliate-resources-account-route` | host route mount | host-coordinated | Host/Web | `cedros-affiliates` | Mounts the affiliate resources panel at a friendly authenticated account route. |
| `cedros-pay:affiliate-payout-settlements` | route/capability | planned | Cedros Pay | `cedros-affiliates` | Settles reviewed affiliate payout batches once Pay publishes destination storage, validation, and failure semantics. |

## Approved Affiliate Resources Route

Host/Web should mount the Affiliates-published `AffiliateResourcesPanel` at:

```text
/account/affiliate/resources
```

The route is an authenticated account route, not a CRM-tag-gated route and not a
generic public `pageSeeds[]` page. The server boundary remains:

```http
GET /extensions/cedros-affiliates/affiliate/resources
```

That endpoint must validate the Cedros Login end-user session and grant resource
access only when the extension-owned `AffiliateProfile.status` is `approved`.

Host/Web responsibilities:

- mount `AffiliateResourcesPanel` only when `cedros-affiliates` is installed and
  its web runtime component is available;
- keep `/account/affiliate/resources` out of public nav and sitemap unless an
  operator intentionally links to it;
- show unauthenticated, pending, suspended, rejected, and error states returned
  by the extension API;
- do not use CRM tags, analytics events, or site-brain records as the route
  access check;
- optionally redirect `/affiliate/resources` to `/account/affiliate/resources`
  as a short link, without changing the server security boundary.

Failure behavior:

- missing Affiliates extension or missing `AffiliateResourcesPanel`: do not
  mount the route;
- unauthenticated Login user: show the extension's sign-in/denied state;
- non-approved affiliate profile: show the extension's pending/suspended/denied
  state;
- extension API unavailable: fail closed and show a recoverable account-route
  error.

## CRM Tag Mirrors

Affiliates may mirror approval state to CRM customer tags for admin visibility
and segmentation:

- `cedros-affiliates:affiliate-pending`
- `cedros-affiliates:affiliate-approved`
- `cedros-affiliates:affiliate-suspended`

These slugs are valid for the customer-tag bridge because they are namespaced
under `cedros-affiliates:`. The extension should declare them in
`customerTagAccess[].managedTagSlugs` and request the scopes needed to reconcile
state, normally `assign`, `unassign`, and `read`.

CRM tags are never the security boundary. The authoritative gate is the
extension-owned `AffiliateProfile` record.

## Direct Payout Settlement Gate

Direct affiliate payout settlement must remain disabled until Cedros Pay
publishes `cedros-pay:affiliate-payout-settlements`.

Minimum Pay requirements before Affiliates can enable direct settlement:

- destination storage for affiliate payout destinations;
- validation for each supported destination type;
- `POST /admin/affiliate-payouts/settlements`;
- idempotency key format `affiliate-payout-settlement:{batchId}`;
- multi-rail destination shape;
- documented item failure codes that Affiliates can store and display safely.

Until all requirements are published and verified, Affiliates may queue payouts,
let admins review/retry/cancel queued records, and grant credits through the
published Pay credits contract when configured. It must not move money through a
private or inferred Pay route.

## Verification

- Host/Web route smoke: open `/account/affiliate/resources` with no Login
  session, a pending affiliate, an approved affiliate, and a suspended affiliate.
- Extension API smoke: confirm every visible state comes from
  `GET /extensions/cedros-affiliates/affiliate/resources`.
- CRM smoke: confirm tag assignment mirrors profile state but removing or adding
  a CRM tag does not grant resource access.
- Pay smoke: confirm direct settlement controls stay disabled until
  `cedros-pay:affiliate-payout-settlements` is published and route tests cover
  idempotency and item failure codes.

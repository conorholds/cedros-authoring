# Gated Media Content Reference

Gated media is a shipped host surface. It extends the page/blog paywall model
so a public page can contain a mix of free, preview-only, and purchased media
items. Use this as the published-surface reference; the access model,
endpoints, admin UI, and Pay entitlement integration below are implemented.

## Ownership Summary

- Cedros Data owns media records, media authoring, access rules, preview
  metadata, private storage selection, public redaction, and protected media
  delivery.
- Cedros Login owns persistent viewer identity. Purchased media access requires
  an authenticated Login user.
- Cedros Pay owns checkout, purchases, subscriptions, refunds, disputes, and
  entitlement truth. Cedros Data may cache entitlement checks briefly, but
  fails closed when Pay cannot answer.
- CRM records Pay activity for profile history and segmentation. CRM tags are
  useful for operator workflows, but they are not an access-control source.

## Use Cases

| Use case | Required behavior |
|---|---|
| Course library | A lesson video can appear in a public course outline, show a poster/preview, and stream only after the viewer buys the course or lesson. |
| Private photography | A gallery can show watermarked or low-resolution previews while full-resolution assets remain unavailable until purchase. |
| Mixed gallery | One page can render free items next to locked items without gating the whole page. |
| Future access | A returning viewer can sign in later and regain access without purchasing again while the Pay entitlement remains active. |

## Access Model (Shipped)

Gated media is modeled as Data-owned access rules attached to media assets or
media collections:

| Field | Values / purpose |
|---|---|
| `scope` | `asset` or `collection`. |
| `scopeId` | The media asset id or collection id being protected. |
| `accessMode` | `public`, `preview`, or `locked`. |
| `previewPolicy` | Public preview kind: `thumbnail`, `watermarked`, `clip`, `poster`, `placeholder`, or `none`. |
| `payProductId` | Cedros Pay product that grants access. |
| `requiredEntitlementId` | Pay entitlement to check. |
| `requiresLogin` | Durable future access requires an authenticated Login user. |
| `status` | `draft`, `active`, `disabled`, or `archived`. |

Locked-media redaction is applied server-side: public responses for preview
and locked assets withhold original URLs, premium variant URLs, private
storage keys, and reusable signed URLs.

Fail-closed save constraint (host-enforced): an active `preview` or `locked`
rule must reference a Pay product (`payProductId`) or an entitlement
(`requiredEntitlementId`) AND set `requiresLogin: true`. Saves that do not
satisfy this are rejected.

Do not overload arbitrary media metadata as the source of truth. Metadata can
carry display hints, but access decisions come from the typed rule model.

## HTTP Surface (Shipped)

| Endpoint | Purpose |
|---|---|
| `GET /site/media/assets/{id}` | Public lock state for an asset: mode, preview, `requiresLogin`, and safe product/entitlement references. |
| `GET /site/media/assets/{id}/delivery/original` | Protected original delivery. Validates the Login session before streaming and supports HTTP range requests for video. |
| `/admin/media/assets/{id}/access-rule` | Admin access-rule CRUD. |

The admin UI ships a Media access rule editor; operators do not need raw API
calls to configure rules.

## Pay Entitlement Integration

The entitlement read/check/event contracts below were published at Cedros Pay
`2.0.0`. Checkout is a separate contract: canonical checkout is implemented but
remains **host-coordinated**, pending guarded-policy activation and recorded
joint staging conformance. The former Pay 2 checkout route is retired; it is
not a published fallback. See
[`../18-official-extension-integrations.md`](../18-official-extension-integrations.md).

| Contract ID | Type | Status | Role |
|---|---|---|---|
| `cedros-pay:checkout` | capability/route family | host-coordinated | Canonical product checkout; implementation exists, but consumption requires the [checkout publication and activation gates](pay-checkout-consumers.md). Not published at Pay `2.0.0`. |
| `cedros-pay:entitlement-read` | capability | published | Lets Data ask whether a Login user has active access to one or more products or entitlement ids. |
| `cedros-pay:entitlements` | route | published | Batch entitlement checks at `POST /extensions/cedros-pay/entitlements/v1/check` without N+1 Pay calls. |
| `cedros-pay:entitlement-changed` | event | published | Invalidates Data entitlement caches when purchases, refunds, disputes, subscription expiry, or cancellation changes access. |

Data calls `POST /extensions/cedros-pay/entitlements/v1/check` under
`cedros-pay:entitlement-read` and grants access only when
`results[0].granted === true`. A missing route, non-2xx response, invalid
JSON, empty results, or `granted: false` all fail closed.

Entitlement check request:

```json
{
  "userId": "login_user_id",
  "checks": [
    {
      "scope": "media_asset",
      "scopeId": "asset_123",
      "productId": "product_abc",
      "entitlementId": "entitlement_course_1"
    }
  ]
}
```

Entitlement check response:

```json
{
  "results": [
    {
      "scope": "media_asset",
      "scopeId": "asset_123",
      "granted": true,
      "reason": "purchase",
      "expiresAt": null
    }
  ]
}
```

The response does not include payment details, raw customer PII, wallet
addresses, or full order records.

Existing purchased access can be checked independently of starting a new
checkout. `checkoutAvailable` in the runtime example below is conditional on
published checkout and target-site activation; it is not evidence that either
gate has passed. Until then, omit the purchase action or show it unavailable,
while continuing entitlement checks for existing buyers. Catalog navigation,
buyer purchase history, and refund limitations are documented in the
[Pay consumer reference](pay-checkout-consumers.md).

## Media Delivery Model

Public media rendering splits preview delivery from premium delivery.

1. Public page/runtime requests resolve media references through the existing
   media reference path.
2. Data applies active media access rules before shaping the public response.
3. For locked or preview assets, Data returns only safe preview URLs and lock
   state. It withholds original URLs, premium variant URLs, private storage
   keys, and any reusable signed URL.
4. When a viewer requests the full asset, Data validates the Login session,
   performs a Pay entitlement check, and streams the protected object through
   the delivery endpoint.
5. Video delivery supports HTTP range requests.

The protected delivery path fails closed when Login is unavailable, Pay is
unavailable, entitlement status is unknown, or the media asset is not stored
in a protected form.

## Public Runtime Shape

Public consumers get enough data to render mixed locked/unlocked galleries
without leaking protected media:

```json
{
  "assetId": "asset_123",
  "access": {
    "mode": "locked",
    "state": "locked",
    "requiresLogin": true,
    "productId": "product_abc",
    "checkoutAvailable": true
  },
  "preview": {
    "url": "https://example.test/media/preview/asset_123",
    "kind": "watermarked"
  },
  "delivery": null
}
```

For entitled viewers, `state` becomes `unlocked` and `delivery` contains a
protected delivery endpoint controlled by Data. It does not contain a
long-lived raw storage URL.

## Admin Authoring Flow

Site owners configure gated media without building a custom page:

1. Upload or select media in the Media Library.
2. Choose access mode: Public, Preview, or Locked.
3. Pick the preview behavior for locked assets.
4. Link a Cedros Pay product or entitlement.
5. Publish the access rule. The fail-closed save constraint applies: active
   preview/locked rules without a Pay product/entitlement and
   `requiresLogin: true` are rejected; keep them draft until Pay is wired.
6. Use the existing page/gallery/media block surfaces to display the item.

## CRM And Analytics

CRM integration stays observational:

- Pay submits purchase/refund/source events through the existing CRM source
  event path.
- Pay or Data can assign customer tags for segments such as course purchaser or
  gallery buyer when a declared tag owner exists.
- Public media unlock events can be analytics events, but must use redacted
  identifiers and avoid filenames or buyer details when those could contain PII.

Access checks must not trust CRM tags, analytics events, or site-brain records.

## Security Requirements

- Locked media must be private at storage or delivery time.
- Public responses must redact originals, premium variants, private keys, and
  reusable signed URLs.
- Entitlement checks must be tied to a Login user id, not only an email address.
- Authorization failures return locked state or 403 without revealing whether a
  buyer exists.
- Logs include asset id, rule id, and error class; they must not include tokens,
  raw payment details, email addresses, or private media URLs.
- Download prevention is not DRM. Once a user can view an image or video, they
  can capture it through normal device capabilities.

## Verification Plan

- Unit test public response redaction for locked assets.
- Unit test entitlement check denial when Login or Pay context is missing.
- Integration test a mixed gallery with one public asset, one preview asset, and
  one locked asset.
- Integration test a purchase/refund cycle invalidating access.
- Manual smoke video playback with range requests against a locked video asset.

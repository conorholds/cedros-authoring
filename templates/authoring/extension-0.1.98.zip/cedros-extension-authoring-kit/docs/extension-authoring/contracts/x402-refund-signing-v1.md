# Cedros Pay x402 Refund Signing Contract v1

## Boundary

Cedros Pay calls the existing WIT
`cedros:extension/providers.execute` import with:

- access id `cedros-pay:blockchain-x402-refund`;
- provider `blockchain`;
- operation `blockchain.solana.refund.x402`.

Core accepts this combination only from the `cedros-pay` extension. The generic
provider WIT ABI does not change; the manifest grant and exact operation string
are the capability boundary. No wallet seed, private key, RPC credential, or
decrypted secret crosses into the guest.

Core also requires Vault to advertise `policyBoundX402Refunds`. An older Vault
fails with `refund_signer_unavailable`; Core does not optimistically send it a
new intent.

## Request

The JSON payload is closed to unknown fields:

```json
{
  "refundId": "refund_01J_STABLE_ID",
  "expectedWalletVersionId": "managed-wallet-version-id",
  "cluster": "mainnet-beta",
  "serializedTransactionBase64": "...",
  "transactionSha256": "lowercase sha256",
  "recentBlockhash": "solana-blockhash",
  "paymentMint": "allowlisted-spl-mint",
  "refundAmountMicrounits": 2500000,
  "tokenDecimals": 6,
  "originalPayer": "original-payer-wallet",
  "originalPaymentSignature": "original-payment-signature",
  "maxFeeLamports": 5000
}
```

`refundId` is the only caller-visible idempotency key. Core derives the Vault
key as `x402-refund:<refundId>` and scopes durable uniqueness to the current
site and authenticated Cedros Pay extension. Reusing the refund id with any
changed field is an idempotency conflict and performs no signing or broadcast.

The request has no wallet id, destination token account, recipient override,
memo, program list, priority fee, or arbitrary instruction field. Core resolves
the site operational wallet. The recipient policy is the `originalPayer`, and
Core derives the exact memo `cedros:x402:refund:<refundId>`.

## Policy

Before a new operation signs, Core requires an active managed operational
wallet, the expected active wallet version, its configured Solana cluster, and
`paymentMint` in the site's `blockchain.allowedTokenMints` policy. Vault's
`x402Refund` intent independently parses the transaction and must require:

- the resolved wallet/version as the only managed signer;
- `originalPaymentSignature` resolves on the configured cluster to a finalized
  x402 transfer for this Vault-bound site/merchant, with `originalPayer` as its
  transfer authority/source owner, the same mint, and an amount at least as
  large as the refund;
- one classic SPL `TransferChecked` from the wallet's canonical source token
  account to the original payer's canonical token account;
- the exact allowlisted mint, integer amount, and decimals;
- the exact Core-derived refund memo and supplied recent blockhash;
- a fee no greater than `maxFeeLamports`;
- no Compute Budget instructions, durable nonce, address lookup table,
  arbitrary program, CPI shape, account creation, unrelated transfer, or
  additional signer.

The host validates the transaction digest and the shape/size limits before
calling Vault. Vault remains the final instruction-level policy authority.

## Durability and concurrency

Core records one operation identity before external work. A database advisory
lock plus row lock serializes the same site/extension/refund id across workers.
Vault's idempotent signer returns the same signed bytes and signature for the
same request. Core persists that evidence and broadcasts only those bytes.

After response loss or an RPC timeout, status is `indeterminate`; retrying
rebroadcasts the persisted bytes. Solana therefore sees the same transaction
signature, never a second transfer. Core never refreshes the blockhash or
rebuilds an accepted operation. A retry after `submitted` returns the persisted
evidence without broadcasting again.

A crash rolls back an incomplete Core transaction. The retry uses the same
Vault idempotency key, so a signature created immediately before the crash is
recovered rather than replaced.

## Response

```json
{
  "contractVersion": "1.0.0",
  "operationId": "core-operation-uuid",
  "refundId": "refund_01J_STABLE_ID",
  "status": "submitted",
  "errorCode": null,
  "retryable": false,
  "signature": "solana-signature",
  "signedTransactionBase64": "...",
  "transactionSha256": "lowercase sha256",
  "recentBlockhash": "solana-blockhash",
  "network": "solana",
  "cluster": "mainnet-beta",
  "walletId": "managed-wallet-id",
  "walletVersionId": "managed-wallet-version-id",
  "policyDecisionId": "vault-policy-decision-id",
  "signedAt": "RFC3339 timestamp",
  "replayed": false
}
```

Stable statuses are `submitted`, `indeterminate`, and `failed`.

- Wallet rotation or an inactive signer rejects a new operation with
  `wallet_rotated_or_unavailable`. Persisted signed evidence remains replayable
  after rotation.
- `blockhash_expired` is final for that refund operation. Core never substitutes
  a fresh blockhash under the same id.
- `insufficient_balance` is retryable only with the same signed bytes while its
  blockhash remains valid.
- Transport timeouts and unreadable or mismatched RPC responses are
  `indeterminate` with `broadcast_ambiguous` or `rpc_response_ambiguous`.
- Missing Vault/HSM capacity returns `refund_signer_unavailable` and is
  retryable. Policy and instruction denials are final.

Cedros Pay persists the complete response before treating the refund as
submitted. It polls/rebroadcasts only the returned signed bytes and never asks
Core to rebuild an ambiguous operation.

## Telemetry

Core emits lifecycle state, stable error code, Core operation id, extension id,
cluster, and managed wallet/version identifiers. Logs and metrics exclude
transaction bytes, payer addresses, original payment signatures, RPC payloads,
credentials, wallet secrets, and customer data.

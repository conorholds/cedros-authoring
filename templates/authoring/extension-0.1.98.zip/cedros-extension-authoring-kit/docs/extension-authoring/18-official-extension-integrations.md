# 18 · Official Extension Integrations

Read this when an extension needs to integrate with official Cedros
extensions and first-party systems such as Cedros Login, Cedros Pay, Cedros
Balance, Cedros Scheduling, Cedros Shop, Cedros Notifications, Cedros
Contracts, Cedros Email, Cedros Wallet, or Cedros Compliance.

Official extensions and first-party systems are not private internals. Treat
them as contract publishers other extensions may depend on.

## Official Contract Status Registry

Every official contract must carry one of these statuses: `published`, `draft`,
`planned`, `host-coordinated`, or `unavailable`.

The owning official extension's published manifest, release notes, or Cedros
contract registry is the source of truth for status. Do not infer status from
examples in this document.

### Login and Pay authentication boundary

The standard customer-facing Login and Pay seams are credential-free for the
consuming extension:

- Login consumers use `cedros-login:auth-response` or local verification of
  the host-forwarded `cedros_access` cookie through Login's public JWKS. The
  host forwards that cookie only to first-party `cedros-*` consumers (and the
  reserved legacy first-party id `vinescribe`) that
  declare a **required** `cedros-login` dependency and a **required**
  `cedros-login:user-context` capability (see the Wasm guide's relying-party
  rules); third-party extensions never receive it, and the host never verifies
  the user for the guest. They do not store a Login service credential.
- Pay's public catalog/plan reads and buyer-authenticated `/paywall/v1/*` routes
  do not require a consumer-held Pay credential. The consumer passes the end
  user's Login session as the route contract requires; Pay owns buyer
  verification through its Login integration.
- Admin/operator calls use published host capability context, including
  `cedros-login:admin-auth` and the relevant Pay capability.

Login's restricted introspection/directory routes and Pay's specialized
`/subscription/v1/*`, `/credits/v1/*`, and `/payments/v1/status` routes are
separate service-to-service contracts. Their presence in a package must not be
interpreted as a general Login/Pay credential requirement or turned into a
Portal/customer integration setup screen. Use one only when the consumer
explicitly declares that exact contract and its authentication requirements.

| Official extension | Contract ID | Type | Status | Min version | Owner | Notes |
|---|---|---|---|---|---|---|
| Cedros Data | `cedros-data:extension-visitor-v1` | host route context | implemented; release verification pending | Capability-gated | Data + Login | [Extension-scoped visitors, signed-in pages and isolated blocks](contracts/extension-visitor-v1.md); no first-party admission required. |
| Cedros Data | `cedros-data:visitor-reference-read-v1` / `cedros-data:extension-form-submissions-read-v1` | core services | implemented; release verification pending | Capability-gated | Data | Scoped CRM/notification references and declaring-extension submission reads through `extension-services.invoke`. |
| Cedros Login | `cedros-login:user-context` | capability | published | 0.0.55 | Login team | Authenticated user/profile context and redacted permission claims. |
| Cedros Login | `cedros-login:session-manage` | capability | published | 0.0.55 | Login team | Session status and permission-gated account security actions. |
| Cedros Login | `cedros-login:admin-auth` | capability | published | 0.0.55 | Login team | Admin/operator authorization context for Settings, Team, and CRM handoff flows. |
| Cedros Login | `cedros-login:auth-response` | capability | published | 0.0.60 | Login team | Stable browser auth-response contract; session cookies are `cedros_access` and `cedros_refresh`. Standard consumers read the host-forwarded `cedros_access` (admitted first-party consumers only) and verify it through public JWKS; no consumer-held Login credential is required. |
| Cedros Login | `cedros-login:site-brain-records` | capability | published | 0.0.58 | Login team | Redacted site-brain writes for Login job, provider, security, and setup records. |
| Cedros Login | `cedros-login:admin` | admin module | published | 0.0.58 | Login team | Executable React admin runtime with section `cedros-login:login` and card `cedros-login:identity-health-card`. |
| Cedros Login | `cedros-login-team-directory` | host service | published | 0.0.58 | Login + Data | Org-scoped team roster, invite, login metadata, and password-reset delegation for Cedros Data Team/Vault controls. |
| Cedros Login | `cedros-login:members` | route family | published | 0.0.60 | Login team | End-user-authenticated organization member list, role update, and removal at `/orgs/{org}/members`; Login enforces admin/owner rules and last-owner safety. |
| Cedros Login | `cedros-login:invites` | route family | published | 0.0.60 | Login team | End-user-authenticated organization invite list/create/cancel/resend under `/orgs/{org}/invites`; raw create/resend tokens must not cross a composing extension's public response. |
| Cedros Login | `cedros-login:v1-jwks` | route | published | 0.0.58 | Login team | JWKS identity contract for relying parties under `/extensions/cedros-login/v1/.well-known/jwks.json`. |
| Cedros Login | `cedros-login:relying-party-session-introspect` | route | published | 0.0.58 | Login team | Restricted service-to-service opaque-session fallback; not the standard customer/Portal authentication seam. |
| Cedros Login | `cedros-login:relying-party-user-get` | route | published | 0.0.58 | Login team | Restricted minimal user lookup; not a general Login credential requirement. |
| Cedros Login | `cedros-login:invite-gate-handoff` | `crmSourceAccess` | host-coordinated | 0.0.60 | Login + Data | Synchronously creates an idempotent product-waitlist record for a pending invite-gated account; release requires the scoped email lookup policy and joint staging evidence. |
| Cedros Login | `cedros-login:relying-party-users-count` | route | published | 0.0.58 | Login team | Restricted aggregate user count for an explicitly authorized service consumer. |
| Cedros Login | `cedros-login:login-screen` | native screen | published for hosted App Builder | 0.0.14 | Login + mobile host | Native login screen is packaged; the hosted App Builder registry binds declared screens from the immutable archive. Other native hosts remain host-coordinated. |
| Cedros Login | `cedros-login:provider` | native provider | published for hosted App Builder | 0.0.14 | Login + mobile host | Native auth provider is packaged; hosted App Builder composes declared providers. Other native hosts must load and bind it. |
| Cedros Login | `cedros-data:identity-atomic-v1` | host data/storage capability | published | Data 0.1.10 | Cedros Data + Login | Published [`registration.account.complete`](reference/conditional-operations.json) operation with the exact capability/access/model grant. The immutable 0.1.9 `registration.account.create` row remains compatible without outbox. Also covers typed avatar replace/delete with durable object cleanup. |
| Cedros Login | `cedros-data:abuse-budget-consume-v1` | host service capability | published | Data 0.1.82 | Cedros Data + Login + Redis | Atomically checks and consumes all supplied rolling system/tenant/endpoint/IP/identity budgets; host-hashed expiring keys, retry-after, and fail-closed datastore errors. |
| Cedros Pay | `cedros-pay:admin` | capability/admin module/route | published | 2.0.0 | Pay team | Admin permission, React admin runtime, and `GET /admin/v1/status`. |
| Cedros Pay | `cedros-pay:checkout` | capability/route family/AI skill | host-coordinated | 4.0.47 | Pay + Data + Shop | Canonical authenticated quote, checkout, status, resolve, and verified-return contract. Implemented; publication still awaits guarded-policy and joint staging evidence. Exact Pay `4.0.47` schemas, auth, and gates: [consumer reference](contracts/pay-checkout-consumers.md). |
| Cedros Pay | `cedros-pay:versioned-cart-write-v1` | capability/route family | host-coordinated | 3.0.2 | Pay + Data + Shop | Pay-owned authoritative cart with generation fencing, CAS, stale-write rejection, permanent mutation replay, and buyer/environment isolation. |
| Cedros Pay | `cedros-pay:guarded-policy-enroll` | admin route | host-coordinated | 4.0.47 | Pay + Data | Atomically enrolls the installed release's compiled Pay model set and writes the fail-closed activation marker; Pay `4.0.47` requires eighteen models. See [activation prerequisites](contracts/pay-checkout-consumers.md#activation-prerequisites). |
| Cedros Pay | `cedros-pay:paywall` | retired route | unavailable | 3.0.2 | Pay team | The old packaged-Wasm product checkout route is not published by Pay 3.x. |
| Cedros Pay | `cedros-pay:balance-read` | capability | published | 2.0.0 | Pay team | Operator-aggregate revenue/refund/net via `cedros-pay:stats`. |
| Cedros Pay | `cedros-pay:subscription-read` | capability | published | 2.0.0 | Pay team | Operator-aggregate subscription stats via `cedros-pay:stats`. |
| Cedros Pay | `cedros-pay:stats` | route | published | 2.0.0 | Pay team | Read-only `RevenueSummary` at `GET /stats/v1/summary`; capability-scoped blocks. |
| Cedros Pay | `cedros-pay:product-rag-records` | capability/route/RAG source | published | 2.0.0 | Pay + Cedros Data | Support-safe live product records at `GET /products/v1/rag-records`; excludes private catalog, buyer, purchase, wallet, token, and secret data. |
| Cedros Pay | `cedros-pay:product-read` | route | published | 2.0.0 | Pay team | Live catalog read at `GET /products/v1/catalog`: public active products + derived categories; `slug`/`categoryId`/`featured` filters and pagination. The id is `product-read`, not the older `cedros-pay:products` example shape. |
| Cedros Pay | `cedros-pay:product-create` | capability/route | published | 2.0.0 | Pay team | `POST /products/v1/catalog`, gated by a host-supplied `cedros-pay:product-create` capability claim (system-admin sessions pass). `title` + `price.amountCents` required; bounded optional fields; unknown fields rejected. Idempotent on caller-supplied stable `id` (replays and duplicate slugs 409). Returns the storefront projection; Pay `4.0.47` exposes host-owned `purchaseAction`, not legacy `checkoutUrl`. See [catalog handoff](contracts/pay-checkout-consumers.md#catalog-handoff). |
| Cedros Pay | `cedros-pay:entitlement-read` | capability | published | 2.0.0 | Pay team | Required for Data-owned gated media to check durable Login-user access. |
| Cedros Pay | `cedros-pay:entitlements` | route | published | 2.0.0 | Pay team | Batch entitlement check at `POST /entitlements/v1/check`; Data fails closed unless `results[0].granted === true`. |
| Cedros Pay | `cedros-pay:site-brain-records` | capability | published | 2.0.0 | Pay team | Redacted setup, automation, compliance, maintenance, and messaging records. |
| Cedros Pay | `cedros-pay:payments` | route | published | 2.0.0 | Pay team | Specialized service-to-service status read at `GET /payments/v1/status`; not the customer/Portal payment seam and never returns buyer identifiers or raw provider ids. |
| Cedros Pay | `cedros-pay:webhooks` | route | published | 2.0.0 | Pay team | Stripe webhook intake at `POST /webhook/stripe`; verifies signature and fails closed. |
| Cedros Pay | `cedros-pay:subscriptions-status`, `cedros-pay:subscriptions-create`, `cedros-pay:subscriptions-cancel` | route family | published | 2.0.0 | Pay team | Specialized service-to-service subscription status, create, and cancel contracts under `/subscription/v1/*`; not the customer/Portal seam. |
| Cedros Pay | `cedros-pay:subscriptions-portal` | route | published | 3.0.2 | Pay team | Specialized service-to-service Stripe Billing Portal handoff at `POST /subscription/v1/portal`; not a general Pay credential requirement. |
| Cedros Pay | `cedros-pay:subscription-selection-status`, `cedros-pay:subscription-plans`, `cedros-pay:subscription-free-selection`, `cedros-pay:subscription-plan-stripe-session` | route family | published | 3.0.2 | Pay + Login + Data | Buyer-authenticated plan discovery, durable free selection, Stripe subscription checkout, and post-checkout status under `/paywall/v1/subscription/*`; plan projections include their supported `paymentMethods`. |
| Cedros Pay | `cedros-pay:buyer-subscription-cancel`, `cedros-pay:buyer-subscription-portal` | route family | published | 3.0.21 | Pay + Login | Buyer-authenticated cancellation and Stripe Billing Portal handoff under `/paywall/v1/subscription/*`. Consumers forward the end user's Login session without storing a Pay credential; Pay independently verifies the session and subscription ownership before Stripe access. |
| Cedros Pay | `cedros-pay:subscription-plan-solana-subscription`, `cedros-pay:subscription-solana-subscription-collect-initial`, `cedros-pay:subscription-solana-subscription-activate` | route family | host-coordinated | 3.0.2 | Pay team | Pay 3.0.7 packages authenticated preparation, merchant/approved-puller initial collection, and dual-signature activation. Consumers must keep Solana-only plans hidden until the encrypted collector secret is provisioned and joint staging passes. |
| Cedros Pay | `cedros-pay:purchases` | route | published | 3.0.2 | Pay team | Buyer-scoped redacted purchase history at `GET /paywall/v1/purchases`; excludes other buyers and private provider metadata. |
| Cedros Pay | `cedros-pay:credits-balance`, `cedros-pay:credits-grant`, `cedros-pay:credits-authorize`, `cedros-pay:credits-hold`, `cedros-pay:credits-release` | route family | published | 2.0.0 | Pay team | Specialized service-to-service credit contracts under `/credits/v1/*`; they do not create a general Pay credential requirement. |
| Cedros Pay | `cedros-pay:admin-config-*` | route family | published | 2.0.0 | Pay team | Admin config list/history/validate and Stripe, x402, Cedros Login, and native-store get/update routes. |
| Cedros Pay | `cedros-pay:admin-site-settings-*` | route family | published | 2.0.0 | Cedros Data + Pay | Pay validates and writes host-owned `site_settings/tipping` and `site_settings/monetization`; public rendering and install gating remain host-owned. |
| Cedros Pay | `cedros-pay:payment-succeeded` | event | published | 2.0.0 | Pay team | Unified with `flow=checkout\|subscription\|credit-purchase`; see notes below. |
| Cedros Pay | `cedros-pay:payment-failed` | event | published | 2.0.0 | Pay team | Redacted payment failure event. |
| Cedros Pay | `cedros-pay:refund-settled` | event | published | 2.0.0 | Pay team | Refund settled event. |
| Cedros Pay | `cedros-pay:entitlement-changed` | event | published | 2.0.0 | Pay team | Invalidates Data-side gated media entitlement caches after purchases, refunds, disputes, subscription expiry, or cancellation. |
| Cedros Pay | `cedros-pay:crm-source-events` | `crmSourceAccess` | published | 2.0.0 | Cedros Data + Pay | Pay submits deterministic purchase, subscription, refund, failure, dispute, chargeback, and credit events through Wasm `crm-source-events.submit`; Data owns CRM linking. |
| Cedros Pay | `cedros-pay:customer-tags` | customer tag access | published | 2.0.0 | Cedros Data + Pay | Applies CRM-visible lifecycle tags: first purchase, repeat customer, VIP, and at risk. |
| Cedros Pay | `cedros-pay:store-db` | database access | published | 2.0.0 | Cedros Data + Pay | Host database seam for Pay-owned ledger, catalog, subscriptions, credits, webhook, audit, support-AI, compliance, and rollup records. |
| Cedros Pay | `cedros-pay:storage`, `cedros-pay:email`, `cedros-pay:intelligence`, `cedros-pay:blockchain-config` | provider access | published | 2.0.0 | Cedros Data + Pay | Host-owned storage, email, optional intelligence, and blockchain config provider grants; raw secrets are never returned to Pay. |
| Cedros Pay | `cedros-pay:blockchain-x402-sign` | provider access | published | 3.0.29 | Cedros Data + Pay + Vault | Policy-bound operational-wallet signing for merchant x402 flows. |
| Cedros Pay | `cedros-pay:blockchain-assistant-x402-sign` | provider access | published | 3.0.29 | Cedros Data + Pay + Vault + Assistant | Policy-bound outbound x402 signing from the isolated Site Assistant wallet. |
| Cedros Pay | `cedros-pay:blockchain-x402-refund` | provider access | host-coordinated | coordinated release | Cedros Data + Pay + Vault | Durable policy-bound x402 refund signing and broadcast from the managed operational wallet. Publishes only after Vault advertises `policyBoundX402Refunds` and Pay declares the exact grant. |
| Cedros Pay | `cedros-pay:assistant-x402-purchase` | AI action/route | published | 3.0.29 | Cedros Data + Pay + Vault + Assistant | Confirmation-gated `cedros.monetization.x402.purchase` action with exact trusted context, durable replay reconciliation, and no operational-wallet fallback. |
| Cedros Pay | `cedros-data:durable-operations-v1` | host data capability | published | Data 0.1.10 | Cedros Data + Pay | Atomic affiliate payout acceptance, item ids, fenced retry leases/backoff, and failed-operation visibility. |
| Cedros Pay | `cedros-data:extension-config-cas-v1` | host data capability | published | Data 0.1.10 | Cedros Data + Pay | CAS across extension settings, encrypted secrets, audit, and committed revision receipt. |
| Cedros Pay | `cedros-data:extension-shared-cache-v1` | host data capability | published | Data 0.1.10 | Cedros Data + Pay | Site/identity-scoped cross-worker cache and fill single-flight. |
| Cedros Pay | `cedros-data:extension-invalidations-v1` | host SSE capability | published | Data 0.1.10 | Cedros Data + Pay | Authorized monotonic invalidation cursors with reconnect replay and reconciliation. |
| Cedros Pay | `cedros-pay:monetization-admin` | admin ownership | published | 2.0.0 | Cedros Data + Pay | Pay owns commerce admin surfaces and validates tipping/paywall settings through published admin routes; host public blog rendering remains install-gated on Pay. See the [Cedros Pay](#cedros-pay) section. |
| Cedros Balance | `cedros-balance:balance-read` | capability/route | published | 0.5.0 | Balance + Data | Reads total, held, and spendable credit through host-derived caller identity and one exact operation claim. |
| Cedros Balance | `cedros-balance:balance-credit` | capability/route | published | 0.5.0 | Balance + Data | Credits an account with exact semantic idempotency through `extension-services.invoke`. |
| Cedros Balance | `cedros-balance:balance-debit` | capability/route | published | 0.5.0 | Balance + Data | Debits spendable credit without bypassing active holds. |
| Cedros Balance | `cedros-balance:balance-hold` | capability/route | published | 0.5.0 | Balance + Data | Creates an idempotent expiring reservation. |
| Cedros Balance | `cedros-balance:balance-capture` | capability/route | published | 0.5.0 | Balance + Data | Atomically settles an active hold as a debit. |
| Cedros Balance | `cedros-balance:balance-release` | capability/route | published | 0.5.0 | Balance + Data | Releases a hold through an idempotent terminal transition. |
| Cedros Balance | `cedros-balance:balance-transfer` | capability/route | published | 0.5.0 | Balance + Data | Atomically commits two linked ledger entries, both balances, and the rollup through `cedros-data:extension-storage-cas-v1`; financial production use requires installed-host acceptance. |
| Cedros Scheduling | `cedros-scheduling:appointment-type-write` | capability | draft | TBD | Scheduling team | Required before `setupSeeds.scheduling[]` can auto-provision appointment types. |
| Cedros Scheduling | `cedros-scheduling:booking-payment-policy-manage` | capability | planned | TBD | Scheduling + Pay teams | Required before paid scheduling can enforce payment timing. |
| Cedros Shop | `cedros-shop:storefront` | web/admin/server family | host-coordinated | 3.0.1 | Shop + Pay + Data | Shop-owned storefront, cart, checkout, account, purchase-history, subscription, category, and product surfaces are packaged; Production checkout launch requires the artifact-tied [Pay/Data/Shop matrix](contracts/pay-checkout-consumers.md#activation-prerequisites). |
| Cedros Shop | `cedros-shop:product-read` | retired example capability | unavailable | 3.0.1 | Shop team | Shop consumes `cedros-pay:product-read`; it does not publish a duplicate product-read capability. |
| Cedros Shop | `cedros-shop:product-write` | capability | draft | TBD | Shop team | Required before `setupSeeds.products[]` can auto-provision products. |
| Cedros Shop | `cedros-shop:inventory-write` | capability | planned | TBD | Shop team | Required before event capacity can auto-provision inventory. |
| Cedros Notifications | `cedros-notifications:route-write` | capability | published | 0.1.9 | Notifications team | Provisions `setupSeeds.notifications[]` route/template starters for declared extension events. |
| Cedros Data/Core | `cedros-data:notification-event-publication-v1` | host contract family | published | `0.1.75` | Data + Notifications | Durable publish/status through `extension-services.invoke`. See the [contract and Rockpile example](contracts/notification-event-publication-v1.md). `telemetry.emit-event` remains analytics. Per-user additional emails and event destination selections require Data `0.1.76`; see [personal destinations](contracts/personal-notification-destinations-v1.md). |
| Cedros Data/Core | `cedros-data:notification-event-publish-v1` | host capability | published | `0.1.75` | Data + Notifications | Durably publish a declared event. |
| Cedros Data/Core | `cedros-data:notification-event-status-read-v1` | host capability | published | `0.1.75` | Data + Notifications | Read an extension-owned publication state. |
| Cedros Contracts | `cedros-contracts:template-write` | capability | unbound | — | Data (Contracts) | Reserved id for provisioning `setupSeeds.contractTemplates[]`. No host binding exists: Data validates the seed and creates nothing. Create templates in the Contracts admin, or from your extension at runtime, until a binding ships. |
| Cedros Contracts | `cedros-contracts:document-ingest` | capability | unbound | — | Data (Contracts) | Reserved id for ingesting package-relative PDF `documentRefs`; same unbound status as `template-write`. |
| Cedros Email | `cedros-email:template-write` | capability | unbound | — | Data (Email) | Reserved id for provisioning `setupSeeds.emailTemplates[]`; no host binding exists, so seeded email templates are never created. |
| Cedros Wallet | `cedros-wallet:account-read-transaction-sign` | typed integration contract | published | 0.0.2 | Cedros Wallet | Account lookup, explicit approval, signing, and Wallet-owned transaction submission; its `transfer` action authorizes player-signed deposits to the current Core-published operational-wallet address. |
| Cedros Wallet | `cedros-wallet:wallet-lock` | AI action capability | published | 0.0.2 | Cedros Wallet | Invalidates the current authenticated wallet unlock session. |
| Cedros Data/Core | `cedros-data:site-operational-wallet-read-v1` | host service capability | published | 0.1.62 | Data + Vault | Reads the active public address, `solana:mainnet-beta` network, readiness, policy state, and wallet version through `extension-services.invoke` with target `cedros-data`. |
| Cedros Data/Core | `cedros-data:site-operational-wallet-activity-read-v1` | host service capability | published | 0.1.62 | Data + Vault + Providers | Pages finalized inbound native/SPL activity for a validated current or retired wallet version with a transaction-signature cursor. |
| Cedros Data/Core | `cedros-data:site-operational-wallet-transfer-v1` | reserved host capability | unavailable | none | Data + Vault | Outbound transfer submission/status remains unavailable; read/activity publication grants no signing authority. |
| Cedros Compliance | `cedros-compliance:policy-read-check-run-audit-record` | typed contract | published | 0.0.1 | Compliance/Tokenization | Active tokenization policy lookup, fail-closed check execution, and redacted durable audit record. |
| Cedros Compliance | `cedros-compliance:site-brain-records` | capability/trust scope | published | 0.0.1 | Compliance/platform | Writes redacted `site-brain-record:compliance` operational records. |
| Cedros Compliance | `cedros-compliance:kyc-self-service` | typed relying-party contract | published | 2.4.0 | Compliance + Login | Contract `1.0.0`: the current Login subject can read effective KYC status and start verification through `cedros-compliance:kyc-status` and `cedros-compliance:kyc-start`. No arbitrary-user lookup or overall authorization decision. |
| Cedros Compliance | `cedros-compliance:kyc-start` | AI action | host-coordinated | 0.0.1 | Compliance/AI gateway | AI-gateway execution remains host-coordinated; this is distinct from the published current-user KYC self-service route in Compliance `2.4.0`. |
| Cedros Compliance | `cedros-compliance:sanctions-refresh` | AI/admin action | host-coordinated | 0.0.1 | Compliance/AI gateway | Refreshes sanctions cache through `/admin/sanctions/refresh`; execution remains AI-gateway coordinated. |

Min-version warning: `compatibility.minCedrosDataVersion` is enforced at
install time against the running host release. It is not a crates.io or npm
version. A manifest pinning a higher, not-yet-deployed host version (for
example copying `0.1.9` from the rows above, where it is the owning
*extension's* version) cannot install. Declare the lowest Cedros Data host
release that actually provides the seams the extension needs; a server
regression test prevents first-party extensions from pinning beyond the
current host release.

### Cedros Pay checkout publication and activation

`cedros-pay:checkout` remains **host-coordinated**, not published. The Pay
`4.0.47` source and package implement the canonical route family; its owning
checkout contract and launch packet still require exact guarded-policy and
joint staging conformance evidence. This is an activation/publication gate,
not a missing checkout implementation. The Gated Media reference's former
claim that checkout was published at Pay `2.0.0` was incorrect for this family.

See the [Pay checkout consumer reference](contracts/pay-checkout-consumers.md)
for exact authentication, request/response schemas, one-time checkout and
payment verification, catalog handoff, buyer purchase/resource association,
refund limitations, and activation prerequisites. Third-party consumers use
these same Pay seams; Directory owns its fee policy and fulfillment.

The old `cedros-pay:paywall` packaged-Wasm checkout route is unavailable.
`cedros-pay-checkout` is a protocol/internal permission namespace, not a
published capability alias. Scheduling checkout is a separate sidecar contract.
Do not route around the publication gate through an old checkout URL, sidecar,
or product/history read.

### Cedros Pay 2.0.0 legacy contract notes

The remaining published 2.0.0 routes below stay valid only where current Pay 3.x still
declares them. Do not use the retired Pay 2 checkout routes for Shop 3.

- **Unified `cedros-pay:payment-succeeded` event** replaces example `cedros-pay:checkout-completed` and `cedros-pay:invoice-settled`. A single ledger commit emits one event with `flow=checkout|subscription|credit-purchase`; two IDs for one ledger entry would create a reconciliation race.
- **No `cedros-pay:balance-updated` event.** Replaced with pull-via `cedros-pay:stats` plus `payment-succeeded` / `refund-settled` push triggers that consumers use to invalidate a cached summary. A future `cedros-pay:ledger-updated` push event can be minted if a low-frequency consumer needs it.
- **No published `cedros-pay:subscription-manage`, `cedros-pay:balance-debit`, `cedros-pay:balance-credit`, or `cedros-pay:products` contract.** The live catalog read shipped as `cedros-pay:product-read` (not the older `cedros-pay:products` example id), and product creation is `cedros-pay:product-create` — see the registry rows above. For the rest, use the published route/capability ids above and add a host handoff item if a consuming workflow still requires one of these older example shapes.

Do not consume a draft, planned, host-coordinated, or unavailable contract as
if it exists. Add it to the host handoff table instead. The examples below are
expected public contract shapes until the owning official extension marks them
`published`.

Event examples are not consumable until marked `published` by the owning
official extension.

Until a contract is marked `published`, treat every consuming route, job,
admin action, dashboard card, or AI capability that depends on it as
host-coordinated and add a host handoff row with owner, contract id, launch
gate, fallback behavior, and staging verification.

## Required Outputs

- official extension dependencies in `dependencies.extensions[]`
- capability or service contract each dependency must expose
- minimum supported version for each official extension
- feature-level fallback when an optional official extension is absent
- events, routes, data models, provider calls, or admin links consumed
- release handoff items for any contract not yet published by the owning team

## Standard Contract Shape

Every official extension should publish:

- stable `extensionId`
- semantic version
- `capabilities[]` for user-visible powers it exposes
- `dependencies.services[]` only for host services it needs
- `dependencies.extensions[]` for other extension families it requires
- `surfaces.server.events[]` for emitted domain events
- `surfaces.server.routes[]` for Wasm-backed endpoints or documented sidecar hooks
- `surfaces.server.contentModels[]` only for extension-owned site data
- `databaseAccess[]` for its own database operations
- docs articles for public integration guidance

Consuming extensions should not call private modules from official extension
packages. Depend on declared capability ids, documented host helpers and services,
Wasm route/capability endpoints, or host-coordinated hooks.

Dependency example:

```json
{
  "dependencies": {
    "extensions": [
      {
        "extensionId": "cedros-pay",
        "minVersion": "2.0.0",
        "required": true,
        "reason": "Checkout and balance operations are owned by Cedros Pay."
      }
    ],
    "capabilities": [
      {
        "capabilityId": "cedros-pay:checkout",
        "required": true,
        "reason": "Required to create checkout sessions."
      }
    ]
  }
}
```

Optional dependency example:

```json
{
  "dependencies": {
    "extensions": [
      {
        "extensionId": "cedros-shop",
        "minVersion": "1.0.0",
        "required": false,
        "reason": "Enables optional product lookup for richer recommendations."
      }
    ],
    "capabilities": [
      {
        "capabilityId": "cedros-shop:product-read",
        "required": false,
        "reason": "Used only when product enrichment is enabled."
      }
    ]
  }
}
```

When an optional dependency is unavailable, hide enrichment metrics, show a
connect state, and avoid broken links.

## Cedros Login

Use Cedros Login for identity, session, auth context, Login-owned admin/web
surfaces, and relying-party identity contracts.

Current published family:

- extension id `cedros-login`; manifest version `0.0.71`; min Cedros Data `0.1.9`
- package family: `cedros-login@0.0.71`, `@cedros/login-react@0.0.71`,
  `@cedros/login-react-native@0.0.71`
- fixed entrypoints: `cedros_login::register_extension_family`, `@cedros/login-react/admin/register`, `@cedros/login-react/web/register`, and `@cedros/login-react-native/register`
- root capabilities: `cedros-login:user-context`, `cedros-login:session-manage`, `cedros-login:admin-auth`, `cedros-login:site-brain-records`, and `cedros-login:auth-response`
- server runtime: 177 Wasm route ids covering auth/onboarding, OAuth/Solana,
  MFA/WebAuthn/SSO, verification/recovery, account/profile/session,
  org/member/invite/RBAC, setup, API key, admin settings/audit/user, feature,
  credential, and relying-party identity flows
- relying-party route ids: `cedros-login:v1-jwks`, `cedros-login:relying-party-session-introspect`, `cedros-login:relying-party-user-get`, and `cedros-login:relying-party-users-count`
- jobs/events: `cedros-login:outbox-dispatch`,
  `cedros-login:cleanup-expired-auth-data`, `cedros-login:authenticated`,
  `cedros-login:registered`, `cedros-login:logout`,
  `cedros-login:registration-created`, and `cedros-login:user-login`
- provider/database access: `cedros-login:email-provider`,
  `cedros-login:image-storage`, `cedros-login:identity-db`,
  `cedros-login:org-db`, and `cedros-login:settings-audit-db`
- web runtime: public page seeds for `/login`, `/register`,
  `/password-recovery`, `/reset-password`, `/verify-email`,
  `/instant-link/verify`, `/accept-invite`, and `/profile`, plus
  block types `cedros-login:auth-page-copy`, `cedros-login:auth-form`,
  `cedros-login:login-button`, and `cedros-login:account-workspace`. Re-verify
  this seed list against the shipped login web bootstrap before depending on a
  path.

Authoring and host requirements:

- declare `dependencies.extensions[]` when Login is required. A first-party
  `cedros-*` consumer (or the reserved legacy id `vinescribe`) that reads the
  signed-in user's `cedros_access` cookie
  must declare Login **and** `cedros-login:user-context` as **required**
  dependencies (third-party ids never receive the cookie) — with an optional
  dependency the host strips the cookie, so only the anonymous path can ever
  run
- standard customer-facing consumers use `cedros-login:auth-response` or public
  JWKS verification of the forwarded cookie; they do not provision or retain a
  Login service credential
- restricted introspection and directory routes are separate contracts, not an
  automatic prerequisite for consuming Login
- never store raw session tokens in extension settings or logs; fail closed when
  identity, session, or permission context is absent
- consumers must depend on published capability ids or relying-party HTTP
  contracts, not private package modules or Login database records
- Early Access automatic enrollment requires the dedicated
  `cedros-login:invite-gate-handoff` grant for `cedros_login` /
  `invite_gate.pending`. Data accepts only after its waitlist record commits and
  resolves the bounded email through the host-coordinated Login identity
  handoff; missing verified user context, scope, site context, or active
  Waitlist + Early Access mode fails closed without success copy
- the intake ZIP must include canonical manifest/bootstrap JSON,
  `cedros-extension.server.wasm`, React package metadata, the
  `exports["./admin/register"]` and `exports["./web/register"]` entries, and
  resolved browser ESM files with relative chunks; Cedros Data does not fetch
  npm tarballs, workspace vendor installs, or registries during intake
- the admin runtime must expose `registerCedrosAdminSurface()`, the default
  export, or `cedrosLoginAdminExtensionBootstrap`, and must include module id
  `cedros-login:admin`
- Cedros Data keeps core Team, Team Permissions, Team Invites, and Vault Team
  pages; Login owns team accounts and must expose
  `cedros-login-team-directory` for org-scoped roster, invite, login metadata,
  and password-reset delegation
- native `cedros-login:login-screen` and `cedros-login:provider` are packaged
  and bound by the hosted App Builder registry; other native hosts remain
  host-coordinated

## Cedros Pay

Use Cedros Pay for checkout, Stripe, Solana x402, credits, subscriptions,
billing state, Cedros Balance, product commerce grounding, payment support,
CRM purchase attribution, and gated-media entitlements.

Checkout reference family (launch remains host-coordinated; see the
[pinned consumer contract](contracts/pay-checkout-consumers.md)):

- extension id `cedros-pay`; manifest version `4.0.47`; min Cedros Data `0.1.81`
- package family: `cedros-pay@4.0.47`, `@cedros/pay-react@4.0.47`,
  `@cedros/pay-react-native@4.0.47`
- fixed entrypoints: `cedros_pay::register_extension_family`,
  `@cedros/pay-react/admin/register`, `@cedros/pay-react/web/register`, and
  `@cedros/pay-react-native/register`
- optional official dependency: Cedros Login `0.0.71`
  (`cedros-login:admin-auth`, `cedros-login:user-context`); protected admin and
  user-context routes fail closed without it
- optional official dependency: Cedros Notifications `0.1.9`
  (`cedros-notifications:route-write`)
- published package archive: Cedros Data intake expects canonical
  `cedros-extension.manifest.json`, `cedros-extension.bootstrap.json`,
  `cedros-extension.server.wasm`, package metadata for all three package-family
  members, and the React admin/web/native register entrypoints

Pay capabilities (checkout/cart are host-coordinated until staging passes):

| Capability | Category | Scope |
|---|---|---|
| `cedros-pay:checkout` | commerce | Authenticated authoritative quote, checkout creation, status recovery, provider resolution, and verified return for Shop 3. |
| `cedros-pay:versioned-cart-write-v1` | commerce | Authenticated Pay-owned cart open/read/rotate/apply with generations, CAS, stale rejection, and permanent replay. |
| `cedros-pay:admin` | admin | Read and write Pay configuration, catalog, orders, refunds, subscriptions, and operations. |
| `cedros-pay:balance-read` | commerce | Read Cedros Balance aggregate gross/net/refund/currency/time-series summaries through `cedros-pay:stats`; no buyer identifiers or ledger rows. |
| `cedros-pay:subscription-read` | commerce | Read aggregate subscription metrics through `cedros-pay:stats`; no subscriber identifiers or per-row state. |
| `cedros-pay:product-rag-records` | commerce | Read public/operator-approved product facts for Data's `products` RAG source. |
| `cedros-pay:entitlement-read` | commerce | Check Pay-owned purchase/subscription access for Data gated media without payment, provider, wallet, or buyer profile details. |
| `cedros-pay:site-brain-records` | runtime | Emit redacted setup, automation, compliance, maintenance, and messaging records. |

Authentication model:

- customer-facing consumers do not store a Pay credential
- public `/paywall/v1/*` reads are unauthenticated only where the route table
  says `public read`
- protected `/paywall/v1/*` routes accept the end user's Login session and Pay
  verifies the buyer through its own Login integration
- admin and capability-scoped routes use host-verified context
- specialized `/subscription/v1/*`, `/credits/v1/*`, and
  `/payments/v1/status` service contracts are not substitutes for the
  buyer-authenticated customer routes and must not drive general setup UI

Server routes:

| Route id | Method/path | Auth/permission | Contract notes |
|---|---|---|---|
| `cedros-pay:checkout-descriptor` | `GET /checkout/descriptor` | verified Login buyer bearer; guarded marker first | Returns opaque, buyer-independent provider scope and supported checkout contract metadata. |
| `cedros-pay:checkout-quote` | `POST /checkout/quote` | verified Login buyer bearer; idempotency key; guarded marker first | Creates or exactly replays an authoritative, scope-isolated quote. |
| `cedros-pay:checkout-create` | `POST /checkout` | verified Login buyer bearer; idempotency key; guarded marker first | Creates one durable checkout operation; mismatched reuse is `409`, concurrent duplicates converge, and response-loss recovery uses the operation contract. |
| `cedros-pay:checkout-status` | `GET /checkout/{operationId}` | verified Login buyer bearer and matching scope | Recovers durable checkout status without exposing raw provider or buyer identifiers. |
| `cedros-pay:checkout-resolve` | `POST /checkout/resolve` | verified Login buyer bearer and matching scope | Resolves one canonical checkout operation through Pay-owned provider authority. |
| `cedros-pay:checkout-return-verify` | `POST /checkout/return/verify` | verified Login buyer bearer; guarded marker first | Verifies operation-bound or operationless provider returns and fails closed on invalid scope or authority. |
| `cedros-pay:versioned-cart-open`, `cedros-pay:versioned-cart-read`, `cedros-pay:versioned-cart-rotate`, `cedros-pay:versioned-cart-apply` | `POST /cart/open`, `/cart/read`, `/cart/rotate`, `/cart/apply` | verified Pay buyer; guarded marker first | Pay-owned cart generation recovery, reads, rotation/fencing, and version/idempotency-guarded mutation. |
| `cedros-pay:guarded-policy-enroll` | `POST /admin/guarded-policy/enroll` | authenticated admin write; empty body only | Atomically enrolls the installed release's compiled model set (eighteen in Pay `4.0.47`) and writes `cedros-pay:guarded-write-policy-state/active`; mutation traffic remains unavailable until the exact marker validates. |
| `cedros-pay:admin` | `GET /admin/v1/status` | authenticated admin with `cedros-pay:admin` | Safe operator status for the Wasm backend, configured routes, jobs, and blockchain readiness. Fails closed on absent/unauthenticated actors or missing permission. |
| `cedros-pay:admin-config-list` | `GET /admin/config` | authenticated admin with `cedros-pay:admin` | Lists Pay-owned payment config categories and secret metadata; secrets are not logged. |
| `cedros-pay:admin-config-history` | `GET /admin/config/history` | authenticated admin with `cedros-pay:admin` | Returns config history shape; currently empty when the host settings seam has no audit-history read. |
| `cedros-pay:admin-config-validate` | `POST /admin/config/validate` | authenticated admin with `cedros-pay:admin` | Validates Pay-owned config payloads without saving. Rejects non-Pay categories and unknown config keys. |
| `cedros-pay:admin-config-stripe-get` | `GET /admin/config/stripe` | authenticated admin with `cedros-pay:admin` | Reads Stripe config; `secret_key` and `webhook_secret` are redacted unless explicitly requested by a trusted admin diagnostic read. |
| `cedros-pay:admin-config-stripe-update` | `PUT /admin/config/stripe` | authenticated admin with `cedros-pay:admin` | Updates Stripe settings and encrypted secrets. Full PUT is idempotent; `[REDACTED]` placeholders preserve existing secrets. |
| `cedros-pay:admin-config-x402-get` | `GET /admin/config/x402` | authenticated admin with `cedros-pay:admin` | Reads x402/crypto config; server wallets are redacted unless explicitly requested by a trusted admin diagnostic read. |
| `cedros-pay:admin-config-x402-update` | `PUT /admin/config/x402` | authenticated admin with `cedros-pay:admin` | Updates x402/crypto settings and encrypted server wallet references. Full PUT is idempotent; `[REDACTED]` placeholders preserve existing secrets. |
| `cedros-pay:admin-config-cedros-login-get` | `GET /admin/config/cedros_login` | authenticated admin with `cedros-pay:admin` | Reads Cedros Login credits payment settings; API key is redacted unless explicitly requested by a trusted admin diagnostic read. |
| `cedros-pay:admin-config-cedros-login-update` | `PUT /admin/config/cedros_login` | authenticated admin with `cedros-pay:admin` | Updates Cedros Login credits settings and encrypted API key. Full PUT is idempotent; `[REDACTED]` placeholders preserve existing secrets. |
| `cedros-pay:admin-config-native-store-get` | `GET /admin/config/native_store` | authenticated admin with `cedros-pay:admin` | Reads App Store and Google Play payment settings; private keys are redacted unless explicitly requested by a trusted admin diagnostic read. |
| `cedros-pay:admin-config-native-store-update` | `PUT /admin/config/native_store` | authenticated admin with `cedros-pay:admin` | Updates App Store and Google Play payment settings and encrypted private keys. Full PUT is idempotent; `[REDACTED]` placeholders preserve existing secrets. |
| `cedros-pay:webhooks` | `POST /webhook/stripe` | Stripe signature verification; no Cedros permission claim | Verifies `Stripe-Signature` with encrypted `stripe.webhook_secret`, timestamp tolerance, replay/idempotency key, event type, and required object fields before writes. Duplicate Stripe event ids are acknowledged without replaying side effects. |
| `cedros-pay:subscriptions-status` | `GET /subscription/v1/status` | specialized service bearer/provider validation; `cedros-pay:subscription-read` for reads | Reads redacted subscription status by subscription id. Rejects missing bearer, unknown subscription, cross-site lookup, or provider mismatch. Not the customer/Portal seam. |
| `cedros-pay:subscriptions-create` | `POST /subscription/v1/create` | specialized service bearer/provider validation | Creates a subscription from customer ref, price id, and optional idempotency key. Provider idempotency prevents duplicate creation. |
| `cedros-pay:subscriptions-cancel` | `POST /subscription/v1/cancel` | specialized service bearer/provider validation | Cancels a subscription by subscription id. Provider subscription id and request idempotency prevent duplicate cancellation. |
| `cedros-pay:subscriptions-portal` | `POST /subscription/v1/portal` | specialized relying-party bearer secret; idempotency key | Opens a Stripe Billing Portal session for an existing subscription customer. Body: `subscriptionId`, HTTPS `returnUrl`. Returns `{ url }`; customer identity and provider references remain Pay-owned. This route does not establish a general Pay credential requirement. |
| `cedros-pay:buyer-subscription-cancel` | `POST /paywall/v1/subscription/cancel` | verified Login buyer; Pay-side ownership check | Cancels the exact buyer-owned subscription. Pay verifies every present Login-user identity field, falls back to `customerRef` only for legacy records without a user identity, and rejects missing or conflicting ownership before Stripe access. Consumers hold no Pay credential. |
| `cedros-pay:buyer-subscription-portal` | `POST /paywall/v1/subscription/portal` | verified Login buyer; Pay-side ownership check; idempotency key | Opens a Stripe Billing Portal session only for the exact buyer-owned subscription and an HTTPS `returnUrl`. Pay rejects missing or conflicting ownership before Stripe access; consumers hold no Pay credential. Returns `{ url }`. |
| `cedros-pay:subscription-selection-status` | `GET /paywall/v1/subscription/selection-status` | verified Login buyer | Requires `userId` to match the verified buyer. Returns `complete`, status, plan/subscription ids, payment method, period end, and cancellation projection. |
| `cedros-pay:subscription-plans` | `GET /paywall/v1/subscription/plans` | public read | Returns active public selectable plans for optional `interval=month\|year`; excludes Stripe price ids and private catalog metadata. |
| `cedros-pay:subscription-free-selection` | `POST /paywall/v1/subscription/free-selection` | verified Login buyer | Validates an active public zero-cost plan and idempotently persists a Pay-owned free selection for the verified buyer. |
| `cedros-pay:subscription-plan-stripe-session` | `POST /paywall/v1/subscription/plan/stripe-session` | verified Login buyer; idempotency key | Creates or replays a Stripe subscription checkout for an active public paid plan. Validates HTTPS return origins and returns `{ flow, sessionId, url }`. |
| `cedros-pay:subscription-solana-subscription-collect-initial` | `POST /paywall/v1/subscription/solana-subscription/collect-initial` | verified Login buyer; Pay-owned idempotency | Verifies the finalized Subscribe authorization, derives and signs the exact official initial collection with the configured encrypted merchant/approved-puller key, and returns a stable `paymentSignature` with `status=finalized` (200) or `status=submitted` (202). Exact retries poll or rebroadcast the persisted transaction; uncertainty never activates access. |
| `cedros-pay:purchases` | `GET /paywall/v1/purchases` | verified Login buyer | Returns only the buyer's succeeded payment ledger rows as redacted purchase projections with optional resource, amount, currency, provider, status, and paid time; no refund fields or full product set. |
| `cedros-pay:stats` | `GET /stats/v1/summary` | admin plus `cedros-pay:balance-read` or `cedros-pay:subscription-read` | Returns `RevenueSummary` aggregates. Query: `window=P7D|P30D|P90D|PYTD|PALL`, optional `include=revenue,subscriptions,timeseries,topRoutes,topProducts`, optional `minAttributionTxnCount`. Capability claims trim blocks. Never returns buyer ids, provider ids, emails, wallets, or raw ledger rows. |
| `cedros-pay:credits-balance` | `GET /credits/v1/balance` | relying-party bearer secret; dormant until `relying_party.shared_secret` is configured | Reads credit balance by subject id. Rejects missing secret, unknown account, or cross-site reference. |
| `cedros-pay:credits-grant` | `POST /credits/v1/grant` | relying-party bearer secret; dormant until configured | Grants credits by subject id, amount, currency, and `sourceRef`. `sourceRef` makes grants safe to retry. |
| `cedros-pay:credits-authorize` | `POST /credits/v1/authorize` | relying-party bearer secret; dormant until configured | Authorizes a credits spend by subject id, amount, currency, and `sourceRef`. Rejects insufficient balance or duplicate conflicting source refs. |
| `cedros-pay:credits-hold` | `POST /credits/v1/hold` | relying-party bearer secret; dormant until configured | Places a credits hold by subject id, amount, currency, `holdId`, and optional expiry. `holdId` makes holds safe to retry. |
| `cedros-pay:credits-release` | `POST /credits/v1/release` | relying-party bearer secret; dormant until configured | Releases a credits hold by `holdId`; hold status makes releases safe to retry. |
| `cedros-pay:product-rag-records` | `GET /products/v1/rag-records` | context claim `cedros-pay:product-rag-records` | Bounded pagination with `limit` 0..100 and non-negative `offset`. Reads active catalog records only and returns `{ source: "products", records }` with public/operator-approved product facts. Excludes draft/private products, metadata, buyer/purchase data, provider secrets, and ledger details. |
| `cedros-pay:entitlements` | `POST /entitlements/v1/check` | host-supplied `cedros-pay:entitlement-read` | Data gated-media check body: `{ userId, checks: [{ scope: "media_asset", scopeId, productId?, entitlementId? }] }`, 1..50 checks. Returns booleans only. Data grants access only when `results[0].granted === true`; missing route, non-2xx, invalid JSON, empty results, or `granted: false` all fail closed. |
| `cedros-pay:payments` | `GET /payments/v1/status` | relying-party bearer secret | Reads redacted ledger state by required query `ref` (ledger entry key), including `refundCents` and `netCents`; see [schemas and auth](contracts/pay-checkout-consumers.md#payment-and-refund-state). Never returns buyer identifiers, credentials, or raw ledger rows. |
| `cedros-pay:admin-site-settings-tipping-get` | `GET /admin/site-settings/tipping` | authenticated admin with `cedros-pay:admin` | Reads host-owned `site_settings/tipping` through Pay admin route. Response settings include `enabled`, `recipient`, `currencies`, `presets`, `label`, `description`, and `allowPerPostRecipient`. |
| `cedros-pay:admin-site-settings-tipping-update` | `PUT /admin/site-settings/tipping` | authenticated admin with `cedros-pay:admin` | Writes allowed tipping keys only, rejects unknown keys, malformed primitives, `cedrosPayInstalled`, and secret-looking nested fields. PUT is idempotent for the same settings body. |
| `cedros-pay:admin-site-settings-monetization-get` | `GET /admin/site-settings/monetization` | authenticated admin with `cedros-pay:admin` | Reads host-owned `site_settings/monetization` through Pay admin route. Response settings include `enabled`, `defaultAccessMode`, `defaultPreviewParagraphs`, `defaultPrice`, `acceptedPaymentMethods`, `subscriptionProductId`, `creditsPerArticle`, `freeReadsPerMonth`, and `lockedMessage`. |
| `cedros-pay:admin-site-settings-monetization-update` | `PUT /admin/site-settings/monetization` | authenticated admin with `cedros-pay:admin` | Writes allowed monetization keys only, preserves omitted fields, rejects `cedrosPayInstalled` and secret-looking nested fields. PUT is idempotent for the same settings body. |

Server jobs and schedules:

| Job id | Schedule id | Default cron | Purpose |
|---|---|---|---|
| `cedros-pay:webhook-delivery` | `cedros-pay:schedule-webhook-delivery` | `* * * * *` | Deliver queued webhook outbox items, single-flight per site, 60s timeout, no automatic executor retry, default batch size 10. |
| `cedros-pay:subscription-sync` | `cedros-pay:schedule-subscription-sync` | `30 3 * * *` | Reconcile subscription state, single-flight per site, 300s timeout, no automatic executor retry. |
| `cedros-pay:sanctions-refresh` | `cedros-pay:schedule-sanctions-refresh` | `15 2 * * *` | Refresh sanctions/compliance assets, single-flight per site, 300s timeout, no automatic executor retry. |
| `cedros-pay:sanctions-sweep` | `cedros-pay:schedule-sanctions-sweep` | `45 2 * * *` | Run sanctions/compliance sweep, single-flight per site, 600s timeout, no automatic executor retry. |
| `cedros-pay:balance-alert` | `cedros-pay:schedule-balance-alert` | `0 * * * *` | Balance alert job, single-flight per site, 120s timeout, no automatic executor retry. |
| `cedros-pay:health-check` | `cedros-pay:schedule-health-check` | `*/5 * * * *` | Health check with optional provider checks, single-flight per site, 60s timeout, no automatic executor retry. |
| `cedros-pay:cleanup` | `cedros-pay:schedule-cleanup` | `0 4 * * *` | Retention cleanup, single-flight per site, 600s timeout, no automatic executor retry. |
| `cedros-pay:email` | `cedros-pay:schedule-email` | `* * * * *` | Email queue job, single-flight per site, 120s timeout, no automatic executor retry, default batch size 25. |
| `cedros-pay:stats-rollup` | `cedros-pay:schedule-stats-rollup` | `30 0 * * *` | Daily stats rollup, single-flight per site, 120s timeout, no automatic executor retry. |

Events, analytics, and notification setup:

- server events: `cedros-pay:payment-succeeded`, `cedros-pay:payment-failed`,
  `cedros-pay:refund-settled`, and `cedros-pay:entitlement-changed`
- analytics metadata also declares `cedros-pay:payment-started` and
  `cedros-pay:wallet-connected`
- `cedros-pay:payment-succeeded` is the unified success event for checkout,
  subscription, and credit purchase flows; do not depend on
  `cedros-pay:checkout-completed` or `cedros-pay:invoice-settled`
- there is no `cedros-pay:balance-updated` event; consumers invalidate cached
  balance summaries from `payment-succeeded` / `refund-settled` and pull
  `cedros-pay:stats`
- notification setup seeds:
  `cedros-pay:purchase-completed-team-notification` for
  `cedros-pay:payment-succeeded`, and
  `cedros-pay:refund-settled-team-notification` for
  `cedros-pay:refund-settled`
- Cedros Notifications provisioning is optional and uses
  `cedros-notifications:route-write`; destination addresses, webhook URLs, bot
  tokens, and provider secrets must not live in the Pay manifest

Data, migrations, settings, and storage:

- database access id: `cedros-pay:store-db`
- database verbs: `read`, `count`, `write`, `delete`, and `migrate` through the
  validated host site-database seam; calls are scope-checked per operation
- content models: `cedros-pay:commerce-ledger`, `cedros-pay:catalog`,
  `cedros-pay:subscriptions`, `cedros-pay:webhook-outbox`,
  `cedros-pay:settings-audit`, `cedros-pay:support-ai`,
  `cedros-pay:compliance-assets`, `cedros-pay:credits`, and
  `cedros-pay:stats-rollup`
- migrations: `cedros-pay:core-schema-v1`, `cedros-pay:catalog-v1`,
  `cedros-pay:orders-fulfillment-v1`, `cedros-pay:subscription-billing-v1`,
  `cedros-pay:webhook-outbox-v1`, `cedros-pay:settings-audit-v1`,
  `cedros-pay:support-ai-v1`, `cedros-pay:compliance-assets-v1`,
  `cedros-pay:performance-indexes-v1`, `cedros-pay:credits-v1`, and
  `cedros-pay:stats-rollup-v1`
- settings schemas: `cedros-pay:payment-settings`,
  `cedros-pay:store-settings`, `cedros-pay:automation-settings`,
  `cedros-pay:site_settings/tipping`, and
  `cedros-pay:site_settings/monetization`
- Pay-owned data must go through `cedros-pay:store-db` and the declared content
  models/migrations; consuming extensions must not read private Pay ledger rows
  or provider ids directly
- generated/build outputs are not authored integration contracts; Cedros Data
  should consume manifest/bootstrap/package metadata and runtime exports, not
  source-tree internals

Provider access:

| Access id | Provider | Scopes | Contract |
|---|---|---|---|
| `cedros-pay:storage` | `storage` | `storage.read`, `storage.write` | Store and retrieve product or payment-related media through host-owned storage. |
| `cedros-pay:email` | `email` | `email.send` | Send redacted payment, order, subscription, and webhook notification emails through host email. |
| `cedros-pay:intelligence` | `intelligence` | `chat.generate` | Generate payment/catalog assistance only through host-owned intelligence providers when AI endpoints are bound. |
| `cedros-pay:blockchain-config` | `blockchain` | `blockchain.config.read` | Read site-owned wallet and Solana readiness. Pay may read `mainWalletAddress`, redacted `managedWallet`, `assistantWallet`, and `treasury` references/status, `assistantWalletAvailable`, `solana.rpcUrl`, network/commitment metadata, and `solana.rpcSecretConfigured`; Data never returns wallet material or the raw RPC secret. An active Squads vault becomes `mainWalletAddress`. |
| `cedros-pay:blockchain-x402-sign` | `blockchain` | `blockchain.solana.sign.x402` | Requests a policy-bound x402 fee-payer signature and fails unless every reference, cluster, version, and `payTo` matches the active projection. The response is a signed transaction plus redacted policy metadata, never key material. |
| `cedros-pay:blockchain-assistant-x402-sign` | `blockchain` | `blockchain.solana.sign.assistant-x402` | Maps Pay's exact SPL mint, amount, decimals, merchant owner/ATA, memo, and separate fee ceiling into the `assistantX402Payment` Vault intent. Uses only the active `site-assistant` wallet, binds the canonical assistant and run, and cannot sign treasury administration or expose key material. |
| `cedros-pay:blockchain-x402-refund` | `blockchain` | `blockchain.solana.refund.x402` | Accepts a stable Pay refund id and an unsigned transaction, resolves the managed operational wallet in Core, maps the exact mint, amount, original payer, memo, blockhash, and fee ceiling into Vault's `x402Refund` intent, then broadcasts only the returned signed bytes. Exact retries return the persisted operation evidence. |

CRM source events and tags:

- CRM source access id: `cedros-pay:crm-source-events`
- source kind: `cedros_pay`
- scope: `write`
- supported event types: `purchase.completed`, `subscription.created`,
  `subscription.renewed`, `subscription.canceled`, `credit.purchase`,
  `refund.settled`, `payment.failed`, `chargeback.opened`,
  `dispute.opened`, `dispute.updated`, and `dispute.closed`
- runtime code submits through
  `crm-source-events.submit(accessId, "cedros_pay", eventType, payloadJson)`
- permitted payload classes include deterministic identity references
  (`customerId`, `cedrosLoginUserId`, `email`, `phone`, or privacy-reviewed
  wallet hash), amount/currency, public product fields, route/page attribution,
  payment rail and flow, order/ledger/checkout/subscription/invoice references,
  receipt URL, refund cents, redacted failure code, provider customer reference,
  dispute status/reason/amount/currency/deadlines, and `occurredAt`
- raw wallet addresses, card details, bank details, raw provider dispute
  evidence, provider secrets, and tokens are not accepted for CRM attribution
- customer tag access id: `cedros-pay:customer-tags`
- tag scopes: `assign`, `unassign`, `read`
- managed tag slugs: `cedros-pay:first-purchase`,
  `cedros-pay:repeat-customer`, `cedros-pay:vip-customer`, and
  `cedros-pay:at-risk`

Admin, web, native, and AI surfaces:

- admin module id: `cedros-pay:admin`
- admin package: `@cedros/pay-react`, package subpath `./admin`
- admin sections: `cedros-pay:catalog`, `cedros-pay:transactions`, and
  `cedros-pay:settings-hub`
- admin dashboard card: `cedros-pay:status-card`
- public page seed: `cedros-pay:payment-page`, route path `/pay`,
  template `cedros-pay:payment-page-template`, `autoCreateOnEnable: false`,
  `publishOnEnable: false`
- web block: `cedros-pay:checkout-cta`
- authored web surface: `cedros-pay:payment-pages`
- form template: `cedros-pay:payment-support-request` with fields `name`,
  `email`, optional `order_reference`, required `issue_type`, required
  `message`, and required `support_consent`
- policy starter: `cedros-pay:refund-returns` at `/refund-returns`; owner
  review is required before publishing because it is not legal advice
- AI discovery skills: `cedros-pay:checkout` (public),
  `cedros-pay:subscriptions` (authenticated), and `cedros-pay:admin` (admin)
- native package entrypoint `@cedros/pay-react-native/register` is published;
  this release declares no native screen, stack, or provider ids

Setup seeds:

- product seed `cedros-pay:ebook-1`: demo ebook, slug `ebook-1`, standard
  product, variant `digital-download`, SKU `CEDROS-EBOOK-1`, price 100 cents
  USD, `installMode: referenceOnly`, `updatePolicy: preserveOperatorEdits`,
  `disablePolicy: leaveCreated`
- product seed `cedros-pay:tip-1`: demo support tip, slug `tip-1`, addon
  product, variant `one-time-tip`, SKU `CEDROS-TIP-1`, price 69 cents USD,
  `installMode: referenceOnly`, `updatePolicy: preserveOperatorEdits`,
  `disablePolicy: leaveCreated`
- setup products are starter metadata only. Operators must replace demo catalog
  data with public/operator-approved product facts before publishing.
- Data product grounding should prefer live
  `cedros-pay:product-rag-records`; use `setupSeeds.products[]` only as a
  fallback when the route/capability is unavailable.

Authoring and host requirements:

- declare the exact Pay capability, route, provider access, database access, CRM
  source access, customer tag access, or setup seed consumed; use an optional
  extension dependency only when the feature has a safe degraded state
- state whether each operation is read-only or money-moving; checkout, credits,
  refunds, subscriptions, config writes, CRM writes, and tag writes must use
  idempotency keys, stable provider ids, `sourceRef`, `holdId`, or equivalent
  retry-safe identifiers
- never implement a parallel balance ledger, subscription ledger, product RAG
  source, CRM purchase source, customer tag namespace, credit balance, or
  entitlement store inside a consuming extension
- dashboard, assistant, and MCP revenue summaries execute `cedros-pay:stats`
  and expect the published `RevenueSummary` shape; balance blocks require
  `cedros-pay:balance-read`, and subscription blocks require
  `cedros-pay:subscription-read`
- public support grounding must stay limited to public/operator-approved
  product records; do not place private product, buyer, purchase, wallet,
  provider, or ledger facts in public support RAG
- Data-owned gated media must call `cedros-pay:entitlements` with
  `cedros-pay:entitlement-read`; every missing/invalid/ungranted outcome denies
  access
- Pay validates and writes tipping/paywall defaults through
  `cedros-pay:admin-site-settings-*` routes for host-owned
  `site_settings/tipping` and `site_settings/monetization`. The host public blog
  still owns rendering, install-state gating, and `GET /site/config/*`
  behavior.
- the host derives Pay install state from the installed-extension registry;
  extensions must not write `cedrosPayInstalled`
- all admin config and site-setting writes must reject secret-looking nested
  fields unless the field is an explicitly managed encrypted secret handled by
  the host secrets seam
- production launch remains host-coordinated until the target host passes Wasm
  runtime, Pay-owned encrypted provider-secret storage, HTTPS egress allowlist,
  provider grants, and Login contract preflight checks
- required launch checks: load `cedros-extension.server.wasm` with the
  `cedros:extension` WIT world, call list-routes/list-jobs, configure Pay-owned
  encrypted provider-secret storage, allowlist `https://api.stripe.com` and any
  configured webhook/sanctions egress, grant storage/email/blockchain-config
  and optional intelligence providers, and bind Login admin/user-context
  capabilities
- only a consumer that explicitly adopts the specialized `/credits/v1/*`
  service contract configures `relying_party.shared_secret`; customer-facing
  buyer flows do not
- rollback/disable behavior: unbind routes and jobs, pause schedules, preserve
  owner-created pages/forms/docs and Pay data unless explicit data deletion is
  approved, keep host-owned site settings as host data, and fail closed for
  provider/database/CRM/tag calls when the extension is disabled
- Shop 3 staging and release evidence is host-coordinated and follows the
  current operator-owned staging runbook; that runbook is not a self-serve
  extension contract

## Cedros Balance

Use Cedros Balance for owned credit-ledger state: balance availability, credit,
debit, reservation, settlement, release, and atomic account-to-account
transfer. The complete consumer contract and installed-host acceptance matrix
are in
[`contracts/balance-rail.md`](contracts/balance-rail.md).

Current provider family: `cedros-balance` version `0.5.0`, min Cedros Data
`0.1.11`. The normative provider artifacts are `CEDROS_BALANCE_RAIL_API.md`,
`cedros-balance-rail.openapi.json`, and Balance implementation commit
`feaa353`.

Provider publication requirements:

- publish every `cedros-balance:balance-*` operation in root
  `capabilities[]` and its executable route id in
  `surfaces.server.routes[]`;
- keep the capability, route, method/path, schema, errors, idempotency, and
  replay behavior aligned with the shipped OpenAPI contract;
- own and authorize every Balance record; never grant consumers raw access to
  Balance content models or private modules;
- use `cedros-data:extension-storage-cas-v1` for guarded mutations; atomic
  transfer commits both ledger entries, both balances, and the rollup or
  commits nothing.

Consumer declaration requirements:

- require `cedros-balance` `0.5.0+` in `dependencies.extensions[]`;
- list only the consumed operations in `dependencies.capabilities[]` and keep
  `requiredCapabilities[]` aligned;
- use stable idempotency keys for financial writes and replay an unknown
  outcome with the same key and exact semantics;
- fail closed on missing provider, grant, host binding, conflict, malformed
  response, or unavailable state; never fall back to Pay or direct Balance
  storage access.

Cedros Data publishes authenticated extension-to-extension invocation through
the Wasm `extension-services.invoke` import. It derives the calling extension,
sets its id as `actorId`/`principalId`, injects exactly one authorized operation
claim, and rejects browser/end-user authorization, invalid dependency versions,
undeclared grants, unbound routes, self-calls, and cycles. Headers, cookies,
bearer tokens, and request JSON cannot self-grant a Balance operation. Financial
production use still requires the installed-host matrix.

Cedros Pay remains the payment rail for checkout, payment state, refunds,
disputes, and reconciliation. It is not the Casino wagering or P2P ledger.

## Cedros Scheduling

Use Cedros Scheduling for appointment profiles, appointment types,
availability, bookings, private links, and booking lifecycle notifications.

Expected public contracts:

- extension id: `cedros-scheduling`
- capability examples:
  - `cedros-scheduling:appointment-type-read`
  - `cedros-scheduling:appointment-type-write`
  - `cedros-scheduling:availability-manage`
  - `cedros-scheduling:booking-read`
  - `cedros-scheduling:booking-payment-policy-manage`
- event examples:
  - `cedros-scheduling:booking-created`
  - `cedros-scheduling:booking-rescheduled`
  - `cedros-scheduling:booking-cancelled`

Authoring requirements:

- declare Scheduling dependencies when using `setupSeeds.scheduling[]`
- keep appointment setup stable by seed id, not title or slug
- paid scheduling must bind to Cedros Pay through a declared checkout
  capability and preferably a `setupSeeds.products[]` product seed
- appointment availability owns service capacity; do not mirror appointment
  slot capacity into Shop inventory unless Shop only references the scheduled
  service product
- cancellation, refund, and reschedule behavior must state whether Scheduling,
  Pay, or manual operator review owns each step

## Cedros Shop

Use Cedros Shop for products, variants, inventory, carts, and ecommerce catalog
behavior.

Expected public contracts:

- extension id: `cedros-shop`
- capability examples:
  - `cedros-shop:product-read`
  - `cedros-shop:product-write`
  - `cedros-shop:inventory-read`
  - `cedros-shop:cart-manage`
- data model examples:
  - `cedros-shop:products`
  - `cedros-shop:variants`
  - `cedros-shop:inventory`

Authoring requirements:

- consume product/catalog APIs instead of duplicating product tables
- keep product references stable by id, not title or slug
- document sync ownership if the extension imports external catalog data
- use Cedros Pay for checkout/payment settlement unless Cedros Shop explicitly
  publishes a bundled checkout contract
- event products should use `setupSeeds.products[]` and
  `setupSeeds.productCollections[]` for turnkey setup metadata
- purchasable event capacity belongs to Cedros Shop inventory; Scheduling owns
  only appointment availability or scheduled-service slots

## Cedros Notifications

Use Cedros Notifications for owner/team notification routing and reusable
notification copy. Extensions may declare `setupSeeds.notifications[]` only for
events they publish in `surfaces.server.events[]`.

Authoring requirements:

- keep notification route/template setup stable by seed id
- do not place destination addresses, webhook URLs, bot tokens, or secret refs
  in the manifest
- default channels are channel-kind suggestions; operators configure actual
  delivery targets
- live route creation uses the published `cedros-notifications:route-write`
  host binding; it provisions routes/templates only, not destination secrets

## Cedros Contracts

Use Cedros Contracts for reusable signing templates, signer roles, field
schemas, request email preferences, and package-referenced starter documents.

Authoring requirements:

- declare contract starters through `setupSeeds.contractTemplates[]`
- package document references must be relative paths with immutable digests
  when automatic ingestion is expected
- signer fields must reference declared roles; legal signer profiles,
  submitters, and live sends are not manifest data
- `setupSeeds.contractTemplates[]` (including `documentRefs`) is validated
  metadata only: no host binding provisions templates or ingests package PDFs,
  so installing or enabling the extension creates no contract template. The
  `cedros-contracts:template-write` and `cedros-contracts:document-ingest` ids
  are reserved for that binding; create templates in the Contracts admin until
  it ships

## Cedros Email

Use Cedros Email for campaign templates, snippets, sender defaults, supported
tokens, and delivery compliance.

Authoring requirements:

- declare reusable campaign templates through `setupSeeds.emailTemplates[]`
- ship subject, HTML body, and plain-text fallback copy together
- sender defaults are suggestions, not provider credentials
- campaign creation/scheduling/sending remains owned by Email Campaigns
  contracts, not template setup
- `setupSeeds.emailTemplates[]` is validated metadata only: no host binding
  creates the templates (the `cedros-email:template-write` id is reserved for
  it), so create them in the Email admin until it ships; categories must
  match published Email template categories

## Cedros Wallet

Use Cedros Wallet for wallet enrollment/material status, authenticated signing,
unlock/session lifecycle, managed wallet tags, and Wallet-owned chain
submission. See
[`contracts/wallet-compliance-seams.md`](contracts/wallet-compliance-seams.md)
and
[`contracts/wallet-compliance-artifacts.md`](contracts/wallet-compliance-artifacts.md).

Current family: `cedros-wallet` version `1.0.0`, min Cedros Data `0.1.9`.
Published contracts are `cedros-wallet:account-read-transaction-sign` version
`1.0.0` and `cedros-wallet:wallet-lock`. Wallet requires Cedros Login
`>=0.0.55` and declares no Cedros Pay dependency or `providerAccess[]` grant in
this release.

Authoring requirements:

- consume the typed contract or `@cedros/wallet-react` public helpers; do not
  call private Wallet modules or read Wallet records directly
- public/theme code must not call Wallet routes directly; authenticated Wallet
  UI requires a Cedros Login-authenticated runtime
- fail closed for unavailable context, settings, wallet state, signing,
  cluster, intent, host seams, or provider submission
- never store or log Wallet secrets, raw provider payloads, raw transaction
  payloads, unsigned transaction bytes, or production PII

## Cedros Compliance

Use Cedros Compliance for policy checks, eligibility checks, sanctions checks,
audit gates, KYC/accreditation workflows, and regulated-workflow approvals. See
[`contracts/wallet-compliance-seams.md`](contracts/wallet-compliance-seams.md)
and
[`contracts/wallet-compliance-artifacts.md`](contracts/wallet-compliance-artifacts.md).

Current family: `cedros-compliance` version `2.4.0`, min Cedros Data `0.1.11`.
Published contracts are
`cedros-compliance:policy-read-check-run-audit-record` version `1.0.0`,
`cedros-compliance:kyc-self-service` version `1.0.0`, and
`cedros-compliance:site-brain-records`. AI-gateway execution of
`cedros-compliance:kyc-start` and
`cedros-compliance:sanctions-refresh` remains host-coordinated; that does not
make the current-user KYC self-service route host-coordinated.

Authoring requirements:

- use the published Tokenization contract for policy/check/audit decisions; do
  not infer gating from private Compliance records or customer tags
- use `cedros-compliance:kyc-self-service` only for the current Cedros Login
  subject's status and verification-start workflow; there is no caller-supplied
  user id or arbitrary-user lookup
- discover KYC self-service from a published contract descriptor or from an
  enabled `cedros-compliance` `2.4.0+` manifest containing both
  `cedros-compliance:kyc-status` and `cedros-compliance:kyc-start`; obtain the
  mounted API base from the host rather than constructing a private service URL
- preserve `Cache-Control: no-store`, `X-Cedros-Contract-Id`, and
  `X-Cedros-Contract-Version` through the host proxy, and CORS-expose both
  contract headers to allowed browser origins; reject mismatched headers,
  unknown enums, malformed timestamps, or insecure redirects
- reuse `Idempotency-Key` only for the same logical verification start; read
  status before deliberately starting a new attempt after a conflict
- treat KYC status as identity-verification state only; protected business
  actions still require the policy/check/audit contract
- fail closed when required Compliance, Login, Pay, evidence, provider,
  settings, storage, database, or audit persistence state is unavailable
- do not duplicate Compliance-owned policy, evidence, provider parsing, audit,
  identity document, access-code, or customer-tag decisions locally
- record redacted Compliance references and evidence refs only; never place PII,
  evidence, provider secrets, raw rows, wallet/payment details, or legal
  guarantees in extension manifests, settings, logs, analytics, or theme state

## Acceptance Checklist

- Required official extensions appear in `dependencies.extensions[]`.
- Optional official extensions have a documented degraded mode.
- Consumed capabilities are stable ids, not private imports.
- Money movement, auth, signing, and compliance paths fail closed.
- `setupSeeds` provisioning for Scheduling and Shop appears in the handoff
  table until those contracts are published.
- Notification setup seeds provision through the published `route-write`
  binding. Contracts and Email setup seeds (`template-write`,
  `document-ingest`) are host-coordinated: their request builders exist but
  no lifecycle step submits them, so they belong in the handoff table until
  the bindings are wired.
- All required unpublished official contracts appear in the host handoff table.

Next: [`19-composability-and-relying-party-contracts.md`](19-composability-and-relying-party-contracts.md).

# Admin Notifications and Toasts

Use this contract for feedback inside extension-owned admin pages and dashboard
cards. It covers short-lived UI feedback in the current AdminShell session. It
does **not** replace durable Cedros Notifications events, routes, email, or team
delivery declared through `setupSeeds.notifications[]`.

The host owns the toast viewport, queue, motion, stacking, timing, sound, theme,
and accessibility behavior. Extensions publish outcomes through the
`cedros:admin` virtual module and never render their own toaster.

## Public API

```tsx
import { toast } from "cedros:admin";

toast.success("Settings saved.");

toast.error("Page wasn't published.", {
  description: "Your draft is safe. Try again."
});
```

The published API is:

```ts
interface ToastAction {
  label: string;
  onClick: () => void;
}

interface ToastOptions {
  action?: ToastAction;
  description?: string;
  duration?: number;
  id?: string;
}

interface ToastApi {
  (message: string, options?: ToastOptions): string;
  success(message: string, options?: ToastOptions): string;
  error(message: string, options?: ToastOptions): string;
  info(message: string, options?: ToastOptions): string;
  warning(message: string, options?: ToastOptions): string;
  message(message: string, options?: ToastOptions): string;
  dismiss(id?: string): void;
}
```

`toast(...)` and `toast.message(...)` are equivalent neutral messages. The
other methods select the semantic tone. The returned string is the toast id.

The host defaults every toast without an action to 4 seconds. A toast with one
action defaults to 8 seconds. Hover and keyboard focus pause the remaining
time. Use the defaults unless the lifecycle genuinely requires persistence;
`duration: 0` persists until replacement or explicit dismissal.

## Choose the right feedback surface

| Situation | Surface | Example |
| --- | --- | --- |
| A user action completed and no continuing context is required | Toast | “Settings saved.” |
| A user action failed and the failure cannot stay beside its trigger | Error toast with a redacted next step | “Export failed.” / “Try again in a moment.” |
| A reversible action completed | Toast with one `Undo` action | “Page deleted.” |
| A batch completed | One summary toast | “236 products imported; 4 skipped.” |
| A field is invalid | Inline field error with `aria-describedby` | “Enter a valid URL.” |
| A form submission failed and the user must correct or retry it there | Inline status notice beside the form | “Connection failed.” + Retry |
| Data for the current view failed to load | Inline status notice in that view | “Orders couldn't load.” + Retry |
| Work is actively running | Inline progress, working button, or step list | “Importing 148 of 240…” |
| Autosave is saving, offline, conflicted, or failed | Autosave indicator and inline recovery UI | “Offline — changes will sync.” |
| A permission, capability, dependency, setup, or read-only condition persists | Inline status/setup notice | “Connect Stripe to enable checkout.” |
| A durable status or empty state describes the page | Badge, chip, status notice, or empty state | “No campaigns yet.” |
| A terminal result requires acknowledgement or contains copy-now material | Modal or inline workflow result | Backup phrase, generated API key |

The governing rule is simple: **transient completed event = toast; persistent
condition = status notice; field issue = inline error**. A single event gets one
announcement. Do not show an inline success banner and a toast for the same
save.

Do not toast initial-load success, every autosave, field validation, empty
states, permissions, setup requirements, or information already visible in the
updated UI. Successful autosave is normally silent apart from the shared
autosave indicator.

## Stable ids and long-running work

Use a stable, extension-prefixed id when retries or phases describe one logical
operation. A new call with the same id replaces the existing toast and restarts
its timer instead of creating another card.

```tsx
const SYNC_TOAST_ID = "acme-catalog:sync";

async function syncCatalog() {
  toast.info("Syncing catalog…", {
    id: SYNC_TOAST_ID,
    duration: 0
  });

  try {
    const result = await runCatalogSync();
    toast.success("Catalog synced.", {
      id: SYNC_TOAST_ID,
      description: `${result.updated} products updated.`
    });
  } catch {
    toast.error("Catalog sync failed.", {
      id: SYNC_TOAST_ID,
      description: "Review the connection and try again."
    });
  }
}
```

A persistent progress toast is appropriate only when work continues outside a
useful inline origin, such as a cross-page background action. It must be
replaced by success, warning, or error on every terminal path. It is not a
substitute for progress UI on the page that owns the work.

Use `toast.dismiss(id)` only when an operation is cancelled or becomes
irrelevant without another outcome. Calling `toast.dismiss()` without an id
clears the entire host queue and is reserved for host lifecycle and tests; an
extension must not dismiss notifications it does not own.

## Actions

A toast may have one short verb action. The host runs it before beginning the
dismissal transition and keeps action toasts available for 8 seconds by
default.

```tsx
toast.success("Page published.", {
  action: {
    label: "View page",
    onClick: () => {
      window.open(publicUrl, "_blank", "noopener,noreferrer");
    }
  }
});
```

Use `Undo`, `Retry`, `View page`, or `View log`—not “Click here.” Keep critical
or multi-step recovery at the origin instead of compressing it into a toast.
Validate action URLs and never put secrets, tokens, unnecessary PII, stack
traces, or raw provider errors in toast copy.

## Copy and tone

- Lead with the outcome: “Settings saved.”, not “Success!”
- Keep the title concise; use the optional description only for consequence or
  the next useful step.
- Use `success` for completed user actions, `error` for failed actions,
  `warning` for completed outcomes needing review, `info` for neutral system
  state, and `message` for tone-neutral acknowledgement.
- Summarize batch work once. Never emit one toast per item or file.
- Translate user-visible copy through the extension's i18n catalog.
- Redact server and provider errors into safe, actionable language.

## Host behavior authors must not recreate

The host renders a bottom-right, theme-tokenized card stack with no liquid-glass
surface. It retains at most six entries, shows the newest three in the collapsed
stack, and expands the full queue on hover, keyboard focus, or touch intent.
Stable ids replace in place. Entries rise and settle over 400ms; exit takes
200ms; reduced-motion users get no transition. Ordinary entries use polite live
announcements, while each error is announced assertively once. Focus never
moves into a toast automatically.

Do not:

- mount `Toaster`, Sonner, or another notification library;
- create a portal, fixed toast container, queue, timer, stacking CSS, or custom
  enter/exit animation;
- copy `.cedros-toaster` or `.cedros-toast` markup or styles;
- import `ui/src/admin/primitives/*` or any other private host file;
- override host toast positioning, z-index, colors, motion, sound, or timing;
- combine a toast with an inline success message for the same event.

## Tests and release checks

- Assert the exact `toast.success`, `toast.error`, `toast.warning`, or
  `toast.info` call instead of searching the page for transient toast text.
- Cover the happy path and a meaningful failure path.
- Verify stable operation ids replace progress/retry state on every terminal
  path.
- Exercise the single action and validate any URL or navigation target.
- Confirm persistent conditions and field errors remain inline and accessible.
- Run the packaged extension through the host loader; the
  `cedros:admin` import is a host-provided bare-import shim and must
  remain external to the ZIP bundle.
- Check light/dark themes, narrow widths, keyboard interaction, and reduced
  motion in the host AdminShell.

## Copy/paste prompt for an extension coding agent

```text
Audit and implement admin feedback for this Cedros extension using the host-owned
notification system.

Read these sources before editing:
- docs/extension-authoring/reference/admin-notifications.md
- docs/extension-authoring/reference/admin-ui-patterns.md
- docs/extension-authoring/12-admin-pages-and-dashboard-cards.md
- design-admin.md §7 (Toasts and Inline alerts) and §11 (extension contract)

Use only the host-provided virtual module:
  import { toast } from "cedros:admin";

Apply this decision rule everywhere:
- transient completed event or non-contextual action failure -> host toast
- persistent condition, load/setup/permission state, progress, or recovery that
  belongs beside the work -> inline status notice
- field validation -> inline field error linked with aria-describedby
- durable state -> badge, chip, empty state, or contextual status UI

Requirements:
1. Inventory every existing toast, banner, status message, inline notice,
   auto-dismiss timer, notification library, and hand-built fixed notification.
2. Remove local Toaster/Sonner instances, portals, queues, toast CSS, timers,
   animations, and duplicated inline-success-plus-toast announcements. Never
   import private Cedros files or copy host toast markup.
3. Route transient outcomes through toast.success/error/warning/info/message.
   Keep titles concise and outcome-led. Put only consequence or next step in
   description. Redact secrets, PII, stack traces, and raw provider errors.
4. Use one summary toast for batches. Use one short verb action at most. Prefix
   stable ids with the extension id so retries and phases replace in place.
5. Use default timing (4 seconds; 8 seconds with an action). Use duration: 0
   only for cross-page/background work with no useful inline origin, and replace
   it on every success, warning, error, and cancellation path.
6. Do not toast initial-load success, field validation, autosave on every edit,
   in-page progress, empty state, permission/capability/setup state, or anything
   already evident in the updated UI.
7. Preserve inline errors when the user must correct or retry at that location.
   Preserve terminal workflow results that require acknowledgement.
8. Add or update tests for the exact toast API call, failure path, stable-id
   replacement, action behavior, and the absence of duplicate inline success.
9. Verify the packaged admin runtime leaves cedros:admin external and
   loads through the Cedros host shim. Run the extension's typecheck, lint,
   targeted tests, packaged-runtime smoke test, and keyboard/narrow-width checks.

Before implementing, report the inventory and classification. Then complete the
migration, remove replaced code, run the checks, inspect the final diff, and
report any intentional inline exceptions. Do not leave TODOs or parallel
notification paths.
```

# Admin UI Patterns — Classes and Accessibility Contract

Use this with
[`../12-admin-pages-and-dashboard-cards.md`](../12-admin-pages-and-dashboard-cards.md)
when an extension ships admin pages or dashboard cards and needs to look
cohesive inside Cedros AdminShell.

> **Visual source of truth.** Every visual, motion, and voice decision behind
> these classes — control metrics, casing, focus behavior, durations, state
> anatomy, copy formulas — is owned by the admin design standard,
> [`/design-admin.md`](../../../design-admin.md) ("Workbench"); its §11 is the
> extension author contract and its Appendix C is copy-paste CSS. This file is
> the class and accessibility catalog. Where the two disagree, Workbench wins.

Extension authors do not have access to Cedros' internal React components, and
must not import private files such as `ui/src/admin/components.tsx` or
`ui/src/admin/primitives/*`. When building equivalent admin UI, mirror the
stable class and accessibility shape below inside an extension-scoped root
class. Use exported SDK primitives when Cedros publishes them; otherwise use
the class contract here and write only the small amount of component code you
need.

## Base Rules

- Wrap admin section content in `.cedros-data` so the full `--cd-*` token set is
  available.
- Namespace custom selectors under your extension root. Do not redefine
  `.cedros-data-btn`, `.cedros-data-table`, or other host classes globally.
- Use `--cd-*` tokens with fallbacks for custom colors. Do not use
  `--cedros-runtime-*` tokens on admin pages; those are for public/builder
  runtime blocks.
- Keep host-owned layout intact. Add extension classes for domain-specific
  grids, not for one-off replacements of shared controls.
- Match the ARIA shape, not only the visual class names. A styled tab, menu, or
  icon action is incomplete without keyboard and screen-reader behavior.
- Follow Workbench for the values: 32px buttons and 36px single-line fields,
  sentence-case labels and button text, mono only for identifiers,
  motion through the host `--motion-*` tokens (never hardcoded durations), and
  focus rings on `:focus-visible` only.

## Shared Patterns

- Page title rows: use `.cedros-data__header` with title copy in
  `.cedros-data__header-text` and right-side controls in `.cedros-data-actions`.
  Use `.cedros-data__header-title`, `h2.cedros-data__title`, and
  `p.cedros-data__subtitle`. Keep actions outside the text block so they wrap
  to the right on desktop and below on narrow screens.
- Back/detail headers: for inner detail, add/edit, or cancel flows, put a
  `button` or link with `.cedros-back-breadcrumb` above the title. Keep it
  text-sized and muted; do not make it a primary action.
- Cards and card headers: use `.cedros-data-card` for framed panels, with
  `.cedros-data-card__header`, `.cedros-data-card__title`,
  `.cedros-data-card__subtitle`, `.cedros-data-actions`, and
  `.cedros-data-card__body`. Do not nest cards inside cards; place repeated
  cards in `.cedros-data-grid` or `.cedros-data-stack`.
- Setup notices: for one primary setup callout, use a card-shaped section with
  `.cedros-data-setup-notice` and `.cedros-data-setup-notice__body`; keep the
  CTA in `.cedros-data-actions`.
- Buttons and small actions: use `button.cedros-data-btn` plus the intent
  modifier: `--primary`, `--secondary`, `--ghost`, `--danger`, and `--sm`.
  Icon-only buttons need a stable `aria-label` and tooltip/title text.
- Form fields: use `label.cedros-data-field`, `.cedros-data-label`,
  `.cedros-data-input`, `.cedros-data-select`, `.cedros-data-textarea`, and
  `.cedros-data-field__description`. Use native text inputs for simple values;
  for selects, use the host pattern (`.cedros-data-select` today — Workbench's
  target is the custom trigger + menu, so don't build new native popups). Use
  `.cedros-data-checkbox-row` for inline checkboxes. Pair invalid
  fields with explicit inline copy and `aria-describedby`; do not rely on color
  alone.
- Toolbars, search, and filters: use `.cedros-data-toolbar` with
  `.cedros-data-toolbar__left` for search/filter controls and
  `.cedros-data-toolbar__right` for commands. Let fields flex; avoid fixed
  pixel widths that clip localized labels.
- Tabs: use `.cedros-data-tabs`, a `role="tablist"` element with
  `.cedros-data-tabs__list`, real button tabs with `.cedros-data-tabs__tab`,
  `role="tab"`, `aria-selected`, `aria-controls`, roving `tabIndex`, and
  panels with `role="tabpanel"` plus `.cedros-data-tabs__panel`. Badges use
  `.cedros-data-tabs__tab-badge`. Arrow, Home, and End keyboard navigation are
  required. If you add the moving indicator, make it decorative and honor
  reduced motion.
- Dropdown command menus: prefer `select.cedros-data-select` for simple value
  selection. For command menus, use a real button trigger with
  `aria-haspopup="menu"`, `aria-expanded`, and `aria-controls`; wrap it in
  `.cedros-dropdown-menu`; render `.cedros-dropdown-menu__content` with
  `role="menu"`; render command buttons with `.cedros-dropdown-menu__item` and
  `role="menuitem"` or `role="menuitemradio`; separate groups with
  `.cedros-dropdown-menu__separator`; apply
  `.cedros-dropdown-menu__item--danger` only to destructive commands. Menus
  inside scrollable tables should portal or use fixed positioning so they are
  not clipped by `.cedros-data-table-wrap`.
- Tables: use `.cedros-data-table-wrap` around `table.cedros-data-table`.
  Headers stay compact and uppercase. Sortable headers use `aria-sort` on `th`
  and a button `.cedros-data-table__sort` with a clear sort label. Empty tables
  use `.cedros-data-empty`. On the first resolved load only, the rows may use
  the Workbench initial-row recipe: 220ms fade + 8px rise with the tokenized
  45ms stagger. Stagger every row — skipping the tail paints those rows ahead of
  the rows above them still waiting their turn. Budget the turns across the rows
  on screen (`ceil(visibleHeightBelowTableTop / rowHeight)`, clamped to the row
  count), give each row `min(rowIndex, turns - 1)`, and scale the step by
  `min(1, 500 / (45 * (turns - 1)))`. Budgeting across the full row count instead
  squeezes a long table's visible cascade into a few milliseconds. Record a
  stable page/table key in a module-level Set
  so the reveal runs once per browser document; returning from detail, sorting,
  filtering, and refetching must render instantly. Reduced motion skips it.
- Clickable table rows: add `.cedros-data-table__row--clickable` to the row,
  but keyboard activation still needs a real first-cell button with
  `.cedros-data-table__row-activate`. Do not make `tr` the only activation
  target.
- Table row actions: group right-aligned actions in `.cedros-data-row-actions`.
  For multiple row commands, use an overflow trigger styled like
  `.cedros-row-actions__trigger` with an accessible label such as "Order
  actions", then reuse the dropdown menu pattern. For one or two direct icon
  actions, use `.cedros-data-row-actions__icon`; add
  `.cedros-data-row-actions__icon--danger` for destructive actions and always
  provide `aria-label`.
- Table summary cells: for primary text plus secondary context, use a small
  extension-owned wrapper with `.cedros-data-table-summary` and
  `.cedros-data-table-summary__preview` so titles, ids, and descriptions stack
  consistently.
- Status notices: use `.cedros-data-status` with tone modifiers `--neutral`,
  `--info`, `--success`, `--warning`, or `--error`; put inline actions in
  `.cedros-data-status__actions`. Use `role="alert"` for errors and
  `role="status"` for non-error updates. Status notices represent persistent
  or contextual conditions, not ordinary completed-action confirmation. Route
  transient outcomes through the host SDK using the decision contract in
  [`admin-notifications.md`](admin-notifications.md).
- Chips and filter pills: use `.cedros-data-chip-row` with `.cedros-data-chip`
  for filter chips, tags, and compact labels. Add `--active` for selected
  filters and `--static` for non-interactive labels. Use `--readonly`,
  `--success`, and `--danger` for semantic chips.
- Status pills: use `.cedros-data-pill` for status/category badges in table
  cells and card metadata. Supported tones include `--success`, `--warning`,
  `--error`, `--info`, `--scheduled`, and `--archived`. Use
  `.cedros-data-pill--toggle` only for clickable pill filters.
- Metrics and summaries: use `.cedros-data-summary-grid` and
  `.cedros-data-metric` with `.cedros-data-metric__label`,
  `.cedros-data-metric__value`, and `.cedros-data-metric__hint`. Use tabular
  numerals for counts, money, percentages, and latency-like values. Eligible
  non-negative counts animate 0 → final once in 500ms; hide the changing text
  from assistive technology and expose only the final formatted value. Money,
  negative values, exact compliance counts, and reduced motion stay instant.
- Dashboard cards and charts: use one `.cedros-data-card` root and follow
  [`design-admin.md` §6.1](../../../design-admin.md#61-dashboard-contribution-cards)
  for the fixed header → summary → evidence → freshness/action hierarchy.
  Extension chart selectors remain namespaced because the host does not
  currently export a public chart primitive. Wrap a chart in `figure`, give it
  a visible `figcaption` with the measure and window, keep the current value
  and comparison visible outside the plot, and supply a concise accessible
  trend summary plus a screen-reader data table or equivalent structured data.
  Mark a non-interactive sparkline `aria-hidden="true"`; its metric value and
  delta are the accessible twin. When tooltips expose exact points, make the
  plot focusable and support Left/Right/Home/End plus Escape, with the same
  behavior available to touch. Use `--cd-chart-1..6` in order, status tokens
  only for semantic outcomes, and never encode a series by color alone.
- Empty states: use `.cedros-data-empty` for compact table/list empties. For a
  larger panel empty state, use `.cedros-data-empty-state` with
  `.cedros-data-empty-state__copy` and optional
  `.cedros-data-empty-state__action`. Keep illustrations decorative with
  `aria-hidden="true"`.
- Pagination: host UI uses the shared `Pagination` primitive for known-total tables
  and `CursorPagination` when a cursor API cannot provide a total. Both render
  `.cedros-data-pagination` with compact range/page metadata and icon navigation.
  Omit the row only when neither direction is available; otherwise disable unavailable
  boundary controls instead of hiding them. Extensions should mirror this anatomy when
  host primitives are not directly importable.
- Dialogs: use `.cedros-data-dialog__overlay` around a `role="dialog"` element
  with `.cedros-data-dialog`, `aria-modal="true"`, and
  `aria-labelledby`/`aria-describedby`. Use `.cedros-data-dialog__heading`,
  `.cedros-data-dialog__title`, `.cedros-data-dialog__description`,
  `.cedros-data-dialog__body`, and `.cedros-data-dialog__close`. Trap focus,
  restore focus to the opener, close on Escape when safe, and keep destructive
  confirmation actions explicit.

## Review Checklist

- The page works in light and dark admin themes through `--cd-*` tokens.
- Every custom tab, dropdown, dialog, and icon action is keyboard reachable and
  has a useful accessible name.
- Shared surfaces use host classes before adding extension-specific CSS.
- No global CSS rule from the extension targets a host class without an
  extension root ancestor.
- Mobile widths do not clip toolbar controls, table actions, tabs, or button
  labels.
- All copy is sentence case (buttons included) and follows the Workbench §8
  formulas; exactly one primary action per view.
- No hardcoded colors, durations, easings, or z-indexes — tokens only; focus
  styling on `:focus-visible` only.
- Loading, empty, error, and capability-locked states exist for every surface,
  including dashboard cards.
- Dashboard cards pass Workbench's five-second gate, use one–three headline
  metrics and at most one evidence region/action, state window and source
  freshness, and distinguish measured zero from unknown/stale data.
- Dashboard comparisons declare stock/flow/rate/duration semantics; charts
  use the prescribed visual for the question and expose pointer, keyboard,
  touch, reduced-motion, and screen-reader equivalents.
- Transient outcomes use the public host `toast` API exactly once; persistent
  conditions and field errors remain inline; the extension mounts no toaster,
  queue, portal, or notification CSS.

# Host Wire Contracts — Per-Seam Quick Reference

> ## This page is a digest, not a source of truth
>
> The authoritative contracts live in the owning docs:
> [`../07-wasm-server-backends.md`](../07-wasm-server-backends.md)
> is canonical for everything an extension backend executes; the database seam
> details live in [`../08-site-database.md`](../08-site-database.md);
> provider declarations in [`../10-host-providers.md`](../10-host-providers.md);
> the package archive contract in [`../22-packaging-and-upload.md`](../22-packaging-and-upload.md);
> and the field-level manifest shapes in
> [`../04-manifest-reference.md`](../04-manifest-reference.md). Those docs
> remain authoritative.
>
> This page collects **exact JSON in / exact JSON out / common wrong assumption**
> for every live host seam in one place, so an author hitting a wire-level
> question does not have to reread five docs. Every section back-links to its
> owning doc and ends with a `Source of truth:` footer pointing at the repo path.
> If a contract changes, **update the owning doc first**, then sync this digest.

## 1. Route context envelope (`context-json`)

Every `handle-route` call carries a host-populated context envelope as a JSON
string in `route-request.context-json`. Its **camelCase** fields include:

| Field | Type | Presence |
|---|---|---|
| `authenticated` | bool | always (default `false`) |
| `systemAdmin` | bool | always (default `false`) |
| `csrfVerified` | bool | always (default `false`) |
| `actorId` | string | omitted when unauthenticated — the "subject" |
| `permissionClaims` | string[] | omitted when empty — the RBAC surface |
| `orgId` | string | optional organization scope |
| `requestId` | string | optional |
| `clientIp` | string | optional authoritative address resolved at the host trusted-proxy boundary |
| `idempotencyKey` | string | optional |
| `siteId` | string | optional |
| `environment` | string | live HTTP path is always `"managed"` \| `"self-hosted"` |
| `authScheme` | string | optional host-verified credential transport |
| `principalId` | string | optional opaque host-verified principal id |
| `capabilityClaims` | string[] | omitted when empty — credential-bound route capabilities |

> **Common wrong assumption:** the envelope carries a `claims.sub` / `role` like
> a typical JWT. It does **not**. The subject is a flat `actorId` string, and
> authorization is a flat `permissionClaims[]` array (e.g. `manage_settings`,
> `manage_users`, `manage_extensions`, `data:settings:read`,
> `data:settings:write`, `*`) plus the `systemAdmin` bool. There is no nested
> claims object and no role enum.

**Fail closed.** Reject when `authenticated === false`; reject state-changing
writes when `csrfVerified === false`. Both default to `false` and the optionals
are omitted when absent, so never assume a field is present. (Public-IdP routes
that run in their own auth domain are the documented exception — see
`07-wasm-server-backends.md`.)

Use `clientIp` for IP-scoped security controls. Forwarding headers remain
transport metadata and are not an authority surface for extensions.

Source of truth: `server/src/extension_platform_host.rs` (matched into the
WIT `routes` interface). See [`../07-wasm-server-backends.md`](../07-wasm-server-backends.md).

## 2. Extension-services seam

`extension-services.invoke(service-request)` is linked when the consumer
declares either a capability owned by an extension in
`dependencies.extensions[]` or a published Cedros Data Core service capability.
The WIT record is shown below in JSON notation for readability; it is not an
HTTP or JSON authorization envelope.

```json
{
  "targetExtensionId": "cedros-balance",
  "routeId": "cedros-balance:rail-balance-transfer",
  "capabilityId": "cedros-balance:balance-transfer",
  "method": "POST",
  "path": "/extensions/cedros-balance/credits/rail/transfer",
  "query": [],
  "bodyJson": "{\"fromUserId\":\"player:7\",\"toUserId\":\"casino:main\",\"amountLamports\":1,\"idempotencyKey\":\"round:42:settle\"}"
}
```

Output is `{ status: u16, headers: [[name, value]], body: string }`; provider
status/body semantics are preserved. Credential and browser-policy response
headers are stripped. The request has **no headers field**. The host derives the
caller from the Wasm instance, validates both active manifests, dependency
versions, the declared/aligned grant, provider publication, and the bound route,
then injects `authenticated: true`, caller `actorId`/`principalId`,
`authScheme: "extension-service"`, and exactly one `permissionClaims[]` value.

> **Common wrong assumption:** a consumer calls the provider's public HTTP route
> and supplies its own `actorId`, claim, cookie, or bearer token. None authorize
> a service operation. Use this import; self-calls, cycles, missing grants, and
> unavailable providers fail closed.

### Cedros Data operational-wallet target

Cedros Data `0.1.62+` publishes two Core-owned calls through the same import.
They use target `cedros-data`, require no `dependencies.extensions[]` entry,
and still require the exact id in `dependencies.capabilities[]` and
`requiredCapabilities[]` when marked required:

```json
{
  "targetExtensionId": "cedros-data",
  "routeId": "cedros-data:site-operational-wallet-read-v1",
  "capabilityId": "cedros-data:site-operational-wallet-read-v1",
  "method": "POST",
  "path": "/runtime/site-operational-wallet/read-v1",
  "query": [],
  "bodyJson": "{\"contractId\":\"cedros-data:site-operational-wallet-v1\",\"contractVersion\":\"1.0.0\",\"correlationRef\":\"deposit-address-read\"}"
}
```

Activity uses route/capability
`cedros-data:site-operational-wallet-activity-read-v1`, path
`/runtime/site-operational-wallet/activity-read-v1`, and a body containing
`contractId`, `contractVersion`, `walletVersion`, optional finalized-signature
`cursor`, `direction: "inbound"`, optional `assetId`, `limit` `1..25`, and
`correlationRef`. The host derives the calling extension and site, reads wallet
version history from Vault, and returns finalized inbound chain facts only.
Outbound transfer is not published.

### Cedros Data abuse-budget target

Consumers declare required capability `cedros-data:abuse-budget-consume-v1`
and invoke target/route/capability `cedros-data` /
`cedros-data:abuse-budget-consume-v1` /
`cedros-data:abuse-budget-consume-v1` with `POST`, no query, and path
`/runtime/abuse-budget/consume-v1`. The body is:

```json
{
  "contractId": "cedros-data:abuse-budget-v1",
  "contractVersion": "1.0.0",
  "dimensions": [
    {
      "name": "client-ip",
      "value": "extension-opaque-value",
      "windows": [
        { "windowSeconds": 60, "limit": 10 },
        { "windowSeconds": 3600, "limit": 100 }
      ]
    }
  ]
}
```

One call may supply 1..16 dimensions and 1..4 continuous rolling windows per
dimension (64 budgets maximum). Names are lowercase ASCII identifiers; values
are non-empty and at most 512 bytes. Use stable values for `system`,
`tenant`/`installation`, `endpoint-family`, `client-ip`, `identity`, and
`ip-identity` as needed. The host namespaces every budget to the calling
extension and hashes every name/value before Redis; raw values are never stored.

The Redis script first checks every supplied budget, then increments all of
them only when all allow the request. A denial increments none and returns 429,
`Retry-After`, and `{ "allowed": false, "retryAfterSeconds": n,
"code": "rate_limited" }`. Success returns 200 and `allowed: true`. Missing,
timed-out, or pressured Redis returns 503 with `allowed: false`,
`code: "datastore_unavailable"`, and `Retry-After: 1`; consumers must fail
closed. Every budget is a single timestamp with an automatic TTL below twice
its window, so sustained traffic cannot create an unbounded event ledger.

Source of truth: `server/wit/cedros-extension.wit` (`extension-services`) and
`server/src/extension_service_routes.rs`, `server/src/extension_abuse_budget.rs`,
and `server/src/redis_cache.rs`. See
[`../07-wasm-server-backends.md`](../07-wasm-server-backends.md) and
[`../contracts/balance-rail.md`](../contracts/balance-rail.md).

## 3. Database seam

Each call is scope-checked against `databaseAccess[]` (access id, verb, content
model). Exact payloads in / shapes out:

| Op | `query-json` / args in | Out |
|---|---|---|
| `read` | `{ entryKeys?, contains?, filters?[{ field, op, value }], orderBy?{ field, direction }, limit?, offset? }` | `{ "entries": EntryRecord[] }` |
| `count` | same filters as `read` (ordering/pagination ignored) | `{ "count": number }` |
| `write` | `entry-key`, `data-json` | `{ "entry": EntryRecord }` |
| `delete` | `entry-key` | `{ "removed": boolean }` |
| `batch` | `{ "ops": [{ "op": "write"\|"delete", "contentModelId", "entryKey", "data"? }] }` | `{ "applied": number }` (one transaction, all-or-nothing) |
| `compare-and-set` | schema v1 `{ conditions: [...], ops: [...] }` with `absent` or opaque expected `version` preconditions | typed `applied(result-json)` or `conflict({ conditionIndex, contentModelId, entryKey, predicate })`; conflict commits nothing |
| `migrate` | `content-model-id`, `mode` (`"jsonb"` default; the host rejects `"typed"`) | `{ "collectionName": string }` |

`filters[].op` is one of `eq` \| `ne` \| `lt` \| `lte` \| `gt` \| `gte` \|
`like` (JSONB value comparison; ISO-8601 strings compare chronologically).
`read` with no `limit` defaults to **100** entries — sweeps must paginate.

`EntryRecord` = `{ "entry_key": string, "payload": object, "updated_at": rfc3339, "version": string|null }`.
Your data is under `payload`.

> **Common wrong assumption:** input and output use the same casing. They do
> not. Input is **camelCase** (`entryKey`); output is **snake_case**
> (`entry_key`, `updated_at`).

> **Common wrong assumption:** there is a per-call tenant id. There is not.
> Tenancy is per-site single-tenant. Isolation is **declared-name scoping** (the
> content model must be in *this* manifest's declared list) plus a
> reserved-collection blocklist — **not** a runtime owner column. Always
> namespace content-model ids `{extensionId}:...`.

Manifest content models in `surfaces.server.contentModels[]` **auto-provision at
install** as JSONB collections — you do **not** call `migrate` for ordinary
JSONB collections. An explicit Wasm `migrate` call can register that declared
content-model id as `jsonb` or `typed`; it has no migration-id or SQL input.

Source of truth: `server/src/extension_runtime_host.rs` (payload types),
`server/src/models.rs:101-165` (records). See
[`../08-site-database.md`](../08-site-database.md) and
[`../07-wasm-server-backends.md`](../07-wasm-server-backends.md).

## 4. Providers seam

`providers.execute(access-id, provider, operation, payload-json)` calls a
site-owned provider, scope-checked against the named `providerAccess[]` entry.
`providers.resolve-default(access-id, provider, operation)` applies the same
checks and returns the secret-free host-selected intelligence provider/model.

**Storage** — ops `put` / `get` / `delete` only. Scope `storage.write` grants
`put`/`delete`; `storage.read` grants `get`. Bytes are inline base64 in one
`put`. There is **no presign / public / signed-URL** operation; objects are
private under `extensions/{id}/...`. The local-fallback caps (10 MiB per `put`,
20 objects per namespace) only apply when no object storage is configured.

**Intelligence / imageGeneration / voice** — `providers.execute(provider="intelligence", operation=<scope label>, payload)`.

> **Common wrong assumption:** the WIT `operation` argument selects the AI
> operation. It does **not** — it is the scope label only. The real operation is
> `payload.operation.kind`, which is only `"chat"` \| `"structured_output"`.

`AiExecutionRequest` (the `payload-json`):

```json
{
  "provider": "openai | anthropic | gemini | xai | openrouter | venice | elevenlabs",
  "model": "<allowlisted model>",
  "operation": { "kind": "chat | structured_output", "messages": [], "schema": {} },
  "tool_envelope": null,
  "metadata": null
}
```

`provider` and `model` are **required** (`model` must be allowlisted).
`AiMessage` = `{ "role": string, "parts": [ text | json | asset ] }`.

`AiExecutionResponse`:

```json
{
  "provider": "...", "model": "...",
  "output": "messages | structured",
  "tool_calls": [],
  "usage": { "metrics": [] },
  "finish_reason": null,
  "audit": { "timeout_secs": 30, "max_retries": 1, "rate_limit_per_minute": 60, "usage_logging_enabled": true }
}
```

`finish_reason` is `Option<String>`. There is **no in-process tool loop** — the
seam passes `None` for the tool loop. Defaults are 30 s timeout / 1 retry / 60
rpm (`AI_TIMEOUT_SECS` / `AI_MAX_RETRIES` / `AI_RATE_LIMIT_PER_MINUTE`).
`InvalidRequest` and `RateLimited` never retry or fall back; fallback may change
the served provider/model. This hits the **CMS AI gateway**, not the assistant
registry.

Host-error codes (branch on `code` / `category`, not English text):

| Code | Category |
|---|---|
| `cedros.provider.not_configured` | `provider_not_configured` |
| `cedros.provider.unavailable` | `provider_unavailable` |
| `cedros.request.invalid` | `validation_failed` |
| `cedros.request.rate_limited` | `rate_limited` |
| `cedros.ai.execution_failed` | `downstream_failed` |

Paid/gated media flows go to [`../contracts/gated-media-content.md`](../contracts/gated-media-content.md),
**not** this seam.

Source of truth: `server/wit/cedros-extension.wit` (`providers`),
`server/src/ai/contracts.rs` (intelligence). See
[`../10-host-providers.md`](../10-host-providers.md),
[`../07-wasm-server-backends.md`](../07-wasm-server-backends.md),
and [`../contracts/gated-media-content.md`](../contracts/gated-media-content.md).

## 5. Native runtime status

What actually loads on mobile vs what is metadata-only:

| Native item | Status |
|---|---|
| `registerCedrosNativeSurface()` minimal bootstrap | **Required & consumed** — generated generic native registration checks identity/version at app startup and uses the installed manifest as authority. Cedros Login has a dedicated host binding. |
| `contentBlockRenderers` loaded by the private native host | **Self-serve / live** for custom mobile blocks |
| `surfaces.native.screenIds` / `stackIds` / `providerIds` | **Self-serve / live in hosted App Builder** — its build pipeline packages the compiled native export; the generated app validates contributions against installed declarations at startup, composes providers, and mounts configured screens/stacks. **Host-coordinated** in every other native host until it publishes an equivalent loader. |

> **Common wrong assumption:** the WIT world has a native export. It does not.
> The `cedros:extension` world is server/Wasm-only — it exports `routes` and
> `jobs`, never a native surface. `docs/native-raw-code-runtime.md` is a
> **separate, flag-gated** feature, not this contract.

Source of truth: `server/src/extension_platform_validation.rs`,
`ui/src/admin/mobileAppArchiveSource.ts`,
`react-native/src/nativeExtensionHost.tsx`, and
`react-native/src/register.ts`. See
[`../05-package-family-and-registration.md`](../05-package-family-and-registration.md),
[`../21-host-coordination-and-native.md`](../21-host-coordination-and-native.md),
and [`../06-runtime-sdk-reference.md`](../06-runtime-sdk-reference.md).

## 6. Package artifact facts

The canonical **entry names** are matched by base name anywhere in the zip:

```
cedros-extension.manifest.json
cedros-extension.bootstrap.json
cedros-extension.server.wasm
```

> **Common wrong assumption:** the ZIP filename matters. It does **not** — the
> installer defaults to `extension.zip` and the filename is advisory metadata
> only. Only the entry base names above are load-bearing.

`manifest` and `bootstrap` must be **deep-JSON-equal**. Two intake gates with
different limits:

| Gate | Endpoint | Body cap | wasm |
|---|---|---|---|
| Browser intake | `/admin/runtime/cedros-extension-manager/packages/intake` | 2 MB body, 2 MB per entry | **not exempt** |
| Server install | `/admin/runtime/wasm-extensions/install` | 64 MB body | **exempt** (non-wasm entries read as text) |

Declaring `routes`/`jobs` with no working component is a **hard install fail**.

Source of truth: `server/src/extension_platform_archive.rs`,
`server/src/http_wasm_extensions.rs`. See
[`../22-packaging-and-upload.md`](../22-packaging-and-upload.md) and
[`../05-package-family-and-registration.md`](../05-package-family-and-registration.md).

## 7. Admin runtime props

What the host passes each admin surface:

| Surface | Props |
|---|---|
| `AdminSectionProps` | `{ pluginContext, pageSize, refreshInterval }` |
| `DashboardCardContributionProps` | `{ hostContext, pluginContext, extensionId, refreshInterval, isLoading, analyticsSnapshot, analyticsError }` |
| web block `Component` | `{ props }` only |
| `contentBlockRenderers[].render` | `{ block, siteData, onNavigate, colorMode }` |

> **Common wrong assumption:** `requestJson` / `requestText` / `requestBlob` are
> importable host helpers. They are **host-internal** and **not** exported from
> `cedros:admin`. Fetch through `getHostService(...)`, or self-fetch
> `${pluginContext.serverUrl}/extensions/{id}/...` with `Authorization: Bearer ${pluginContext.getAccessToken()}`.

Source of truth: `ui/src/admin/adminPluginTypes.ts`,
`ui/src/admin/dashboardExtensions.ts`,
`ui/src/admin/extensionBlockRendererTypes.ts`. See
[`../12-admin-pages-and-dashboard-cards.md`](../12-admin-pages-and-dashboard-cards.md),
[`../06-runtime-sdk-reference.md`](../06-runtime-sdk-reference.md), and
[`../14-blocks-templates-and-styling.md`](../14-blocks-templates-and-styling.md).

## 7. Database compare-and-set

`database.read` returns JSONB entries with opaque `version` equality tokens.
`database.compare-and-set(access-id, request-json)` applies schema-v1
`absent`/`version` conditions and write/delete mutations in one transaction.
The WIT result is typed: `cas-outcome::applied(result-json)` or
`cas-outcome::conflict({ condition-index, content-model-id, entry-key,
predicate })`; conflict commits nothing and exposes no current payload/token.
Non-conflict failures use `cas-error { code, category, message }`:

| Code family | Category |
|---|---|
| request validation | `validation_failed` |
| missing model/resource | `not_found` |
| request rate/quota limit | `rate_limited` |
| other host concurrency invariant | `conflict` |
| database/storage failure | `storage_failed` |
| host unavailable/timeout | `host_runtime_failed` |

The v1 contract covers host-managed JSONB collections only and requires
`cedros-data:extension-storage-cas-v1`. See
[`../08-site-database.md`](../08-site-database.md) for the request schema,
authorization, transaction, recovery, and unconditional-write rules.

Source of truth: `server/wit/cedros-extension.wit` (`database`),
`server/src/extension_runtime_host.rs`, and
`server/src/store/extension_guarded_batch.rs`.

## 8. Settings, secrets & other capability seams

The remaining always-or-conditionally-linked host seams. All are scoped
per-extension and return a `host-error` `{ message }` on failure:

Infrastructure failure text is deliberately generic: database, migration, IO,
storage, provider availability/capacity, and AI execution diagnostics are not
returned to guests. Branch on typed `code`/`category` where available, not English
messages. The published database concurrency marker remains unchanged. Validation
messages remain actionable and must not contain private backend diagnostics.

| Seam | Ops | Wire semantics |
|---|---|---|
| `settings` | `get(key)` → `option<string>`, `set(key, value)`, `list-all()` → `string` | Values are **JSON strings** (`get` decodes one; `list-all` returns a JSON object of all). A non-JSON `set` value is stored as a JSON string. |
| `secrets` | `get(key)` → `option<string>`, `set(key, value)`, `delete(key)` → `bool` | **Always linked**, encrypted-at-rest, isolated to this extension. `set` seals before persistence; `get` returns the decrypted value; both fail closed without the operator passphrase. `delete` reports whether ciphertext existed and can remove it without a passphrase. |
| `telemetry` | `emit-event(event-id, label, metadata-json)`, `emit-record(category, title, text, payload-json)` | Linked for declared server events or site-brain write scopes. `emit-event` checks its exact event id and is analytics/best-effort only; `emit-record` needs its matching `site-brain-record:<category>` write capability. Durable notifications use the separate [publish/status service contract](../contracts/notification-event-publication-v1.md). |
| `customer-tags` | `assign` / `unassign` / `read` (all `access-id`-scoped) | CRM tag assignments through the host's validated bridge. |
| `crm-source-events` | `submit(access-id, source-kind, event-type, payload-json)` | Returns `{ attached, profileId, reason }`; purpose-specific grants may add durable `accepted`, `receiptId`, and `status` fields. |
| `http` | `fetch(request-json)` → `{ status, headers, body }` | Request: `{ method, url, headers?, body?, timeoutMs? }`; optional integer `timeoutMs` in 1..=50000 bounds DNS/header/body I/O (default 50000). Older hosts may ignore the hint. Always linked; requires **an operator allowlist** (`CEDROS_EXTENSION_HTTP_ALLOWLIST`); https-only, fails closed before network I/O. Except for the narrowly scoped UCP profile capability below, egress is operator-only, never manifest-declared. |

Pay's `cedros-data:ucp-platform-profiles-v1` host capability adds `ucpProfile: true`
to `http.fetch` for public platform profile discovery. Only Cedros Pay may use it:
HTTPS port 443, GET, no body/query/fragment/credentials, and only
`Accept: application/json`. No per-platform operator allowlist entry is needed.
DNS is pinned and all private/reserved addresses and redirects remain blocked,
including private self-origin exceptions. Responses are capped at 128 KiB and
must be UCP JSON with `ucp.version`, `ucp.capabilities`, and `signing_keys`;
only the `ucp` and `signing_keys` fields are returned. Other requests retain the
operator allowlist requirement. Pay also owns the public `/.well-known/ucp`
alias, which returns 404 until its `cedros-pay:ucp-profile` route is installed.
Core preserves UCP HTTP bodies byte-for-byte through the WIT request string
and rejects duplicate signature headers before constructing the guest header map.
UCP routes must be called over public HTTP; service calls with parsed JSON
cannot substitute for the signed HTTP body.

Source of truth: `server/wit/cedros-extension.wit` (`settings`, `secrets`,
`telemetry`, `customer-tags`, `crm-source-events`, `http`). See
[`../09-settings-secrets-and-state.md`](../09-settings-secrets-and-state.md),
[`../16-analytics-and-site-brain.md`](../16-analytics-and-site-brain.md),
[`../20-crm-tags-and-source-events.md`](../20-crm-tags-and-source-events.md), and
[`../07-wasm-server-backends.md`](../07-wasm-server-backends.md)
(canonical for `crm-source-events` and `http`).

## How to keep this current

This digest is downstream of the owning docs. If a contract changes:

1. Update the owning doc (`07-wasm-server-backends.md`, `10-host-providers.md`,
   `08-site-database.md`, `05-package-family-and-registration.md`,
   `22-packaging-and-upload.md`, `04-manifest-reference.md`, or
   `12-admin-pages-and-dashboard-cards.md`) **first** — that is the source of
   truth.
2. Then sync the matching section here and its `Source of truth:` footer.

Every section must keep its back-link and footer so this page can never silently
drift from the contract it summarizes.

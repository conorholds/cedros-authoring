# 20 · CRM Customer Tags and Source Events

Read this when an extension needs to add or remove **tags on CRM
customer profiles** based on activity in the extension (e.g. cedros-pay
tagging a customer `cedros-pay:vip-customer` after their third purchase).

Cedros extensions do not reach the CRM database directly. The supported
model is manifest-declared `customerTagAccess[]` plus host-mediated
assign / unassign / read operations against the active site CRM.

> **Implemented — wasm runtime.** A wasm server extension reaches this via the
> `customer-tags` import: `assign(access-id, profile-id, tag-slug, payload-json)`,
> `unassign(access-id, profile-id, tag-slug)`, `read(access-id, profile-id)`.
> Granted when the manifest declares any `customerTagAccess`; each call is
> verb- and slug-scoped by the validated host bridge, and assignments emit the
> `cedros:customer-tag-changed` host event. `profile-id` is a UUID; managed tag
> slugs must be namespaced `{extensionId}:`. Canonical contract:
> [`07-wasm-server-backends.md`](07-wasm-server-backends.md).

Status: **published**. Manifest validation, validated client, and host
bridge are available on compatible Cedros Data hosts. Server route/job hooks can
request the customer-tag bridge alongside the host-provider and
site-database clients.

## When To Use

Reach for the customer-tag bridge when the extension has business
activity that produces labels operators want to filter, search, or
report on across the CRM. Tags belong on customer profiles when:

- the label is meaningful to a human operator,
- the label is stable over time (not a transient session flag),
- and the label is something the admin would naturally want to filter
  the CRM list by.

Concrete examples:

- **cedros-pay** tagging customers `first-purchase`, `repeat-customer`,
  `vip-customer`, or `at-risk` based on order activity.
- **cedros-events** tagging attendees of a specific event run.
- **cedros-support** tagging frequent reporters or escalation-prone
  customers based on ticket counts.
- **cedros-loyalty** tagging tier transitions.

Do NOT use the customer-tag bridge for:

- transient session/visit state — use the analytics visitor tag system
  for that;
- per-order or per-record state — store it in the extension's own
  content models;
- secrets or PII — tag metadata is exposed to operators in the admin.

## Required Outputs

- `customerTagAccess[]` entries declaring each use case
- Scopes: at least one of `read`, `assign`, `unassign`
- `managedTagSlugs[]` listing every namespaced tag the extension may
  manage (each must start with `{extensionId}:`)
- Operator-facing `displayName` and `description` per access entry
- Optional observability `tags[]` (redacted reporting labels, no PII)

## Manifest Shape

```json
{
  "extensionId": "cedros-pay",
  "customerTagAccess": [
    {
      "id": "cedros-pay:customer-tags",
      "displayName": "Customer Tags",
      "description": "Tags customers based on ecommerce purchase activity.",
      "scopes": ["assign", "unassign", "read"],
      "managedTagSlugs": [
        "cedros-pay:first-purchase",
        "cedros-pay:repeat-customer",
        "cedros-pay:vip-customer",
        "cedros-pay:at-risk"
      ],
      "tags": ["commerce"]
    }
  ]
}
```

### Validation rules

- `id` must start with `{extensionId}:` (namespaced)
- `scopes` must declare at least one of `read`, `assign`, `unassign`
- `managedTagSlugs` must declare at least one slug; each slug must
  start with `{extensionId}:` and may only contain `a-z`, `0-9`, `-`,
  `_`, `:`
- Slugs are lowercased on insert/lookup; declaring `Cedros-Pay:VIP`
  resolves to `cedros-pay:vip`
- The same `id` may not appear twice in `customerTagAccess[]`
- `managedTagSlugs` must contain no duplicate entries
- `tags[]` must contain no duplicate entries

## Runtime Contract

The host publishes a `CedrosExtensionCustomerTagClient` trait. Server
route and job hooks request it the same way they request the validated
host-provider and site-database clients.

```rust
pub trait CedrosExtensionCustomerTagClient: Send + Sync {
    fn assign<'a>(
        &'a self,
        request: CedrosExtensionCustomerTagAssignRequest,
    ) -> CedrosExtensionCustomerTagFuture<'a, CedrosExtensionCustomerTagAssignResponse>;

    fn unassign<'a>(
        &'a self,
        request: CedrosExtensionCustomerTagUnassignRequest,
    ) -> CedrosExtensionCustomerTagFuture<'a, CedrosExtensionCustomerTagUnassignResponse>;

    fn read<'a>(
        &'a self,
        request: CedrosExtensionCustomerTagReadRequest,
    ) -> CedrosExtensionCustomerTagFuture<'a, CedrosExtensionCustomerTagReadResponse>;
}
```

Production hosts wrap the concrete client with
`CedrosExtensionValidatedCustomerTagClient::new(manifest, client)`,
which enforces manifest scopes and `managedTagSlugs[]` on every call.
Extension authors should request the wrapped client from the host —
never instantiate the raw bridge directly.

### Assign

```json
{
  "context": {
    "extensionId": "cedros-pay",
    "accessId": "cedros-pay:customer-tags",
    "feature": "repeat-purchaser",
    "description": "Customer placed a second order",
    "tags": ["commerce"]
  },
  "profileId": "00000000-0000-0000-0000-000000000000",
  "tagSlug": "cedros-pay:repeat-customer",
  "note": "orderId=ord_42",
  "metadata": { "orderCount": 2 }
}
```

Response:

```json
{
  "assignment": {
    "assignmentId": "…",
    "profileId": "…",
    "tagId": "…",
    "tagSlug": "cedros-pay:repeat-customer",
    "tagLabel": "Repeat customer",
    "tagColor": "slate",
    "assignedByExtensionId": "cedros-pay",
    "note": "orderId=ord_42",
    "metadata": {
      "orderCount": 2,
      "extensionId": "cedros-pay",
      "accessId": "cedros-pay:customer-tags",
      "feature": "repeat-purchaser",
      "description": "Customer placed a second order",
      "contextTags": ["commerce"]
    },
    "assignedAtMs": 1779804013000,
    "updatedAtMs": 1779804013000
  },
  "created": true
}
```

`created` is `true` if a new assignment row was inserted and `false` if
an existing assignment was refreshed. Assign is idempotent —
re-assigning an already-attached tag updates the note/metadata but does
not create a new row.

Context-field ceiling for wasm callers: the full `context` shape above
(`feature`, `description`, `tags`) is settable only by host-native or
CMS-proxy callers of the Rust client. Via the wasm `customer-tags`
import the host builds the context itself and stamps `feature: None`,
`description: None`, `tags: []` — the wasm payload carries only `note`
and `metadata`, so attribution from wasm is extension id + access id.

### Unassign

```json
{
  "context": { ... },
  "profileId": "00000000-0000-0000-0000-000000000000",
  "tagSlug": "cedros-pay:repeat-customer"
}
```

Response:

```json
{ "removed": true }
```

`removed` is `false` if no matching assignment existed. Treat this as
informational, not an error.

### Read

```json
{
  "context": { ... },
  "profileId": "00000000-0000-0000-0000-000000000000"
}
```

Returns the profile's assignments for slugs this extension declares in
`managedTagSlugs[]` only. The validated client applies least-privilege
filtering: admin-applied tags, first-party CRM tags, and other
extensions' tags are stripped from the response, so a read access
cannot enumerate CRM segmentation outside the extension's declared
slugs. (The underlying bridge returns the full set, but extension
authors always go through the validated wrapper.)

## Tag Definition Lifecycle

**Auto-bootstrap.** The bridge automatically creates the tag definition
the first time an extension assigns one of its declared `managedTagSlugs`.
No separate install hook is required. The auto-created row gets:

- `kind = "extension"`
- `ownerExtensionId = {your extension id}`
- `label` derived from the slug (e.g. `cedros-pay:vip-customer` →
  `Vip customer`) — operators can rename it later through the admin tag
  API without breaking the seam, since the bridge resolves by slug
- `color = "slate"` (default) — operators can recolor via the admin tag
  API

An extension cannot set a custom label or color at install time: the
wasm `customer-tags` interface exposes assign/unassign/read only, and
the internal auto-bootstrap hardcodes no color (default `slate`) with a
slug-derived label. See Future Work.

**Tag-definition UI.** People > Manage tags opens the CRM tag manager.
Operators can create custom definitions and rename, recolor, re-describe,
or delete existing definitions there. Settings > Analytics > Tags remains
the separate analytics *visitor* tag system — do not confuse the two.

**Operator deletions.** If the operator deletes the tag definition
(via `DELETE /admin/runtime/crm/tags/{tagId}`), the next extension
assign re-creates it with default label and color. This is intentional:
extensions remain functional even after a CRM purge. If you need
sticky deletion, gate the extension behind disable/uninstall.

**Cross-extension lockout.** A slug owned by one extension cannot be
adopted by another. The host rejects upsert calls when
`ownerExtensionId` doesn't match the caller. Admins must delete the
definition first before a new extension can re-create it.

## Operator Experience

Tags applied by an extension render in the admin CRM with:

- An `ext` badge on the chip
- A title attribute reading "Tagged by extension `{extensionId}`"
- Attribution metadata showing `feature` and `description` when the
  assignment came from a host-native/CMS-proxy caller; for wasm-driven
  assignments attribution is extension id + access id (plus the caller's
  `note`/`metadata`)

Operators can:

- unassign an extension-applied tag from a specific customer (e.g.
  after a refund) — the seam will not re-apply automatically; that
  requires another extension event
- filter the CRM list by any tag slug (extension-owned or otherwise)
- rename, recolor, or re-describe any tag definition — including
  extension-owned ones — through People > Manage tags or via
  `PATCH /admin/runtime/crm/tags/{tagId}`;
  there is no read-only enforcement for extension-owned rows, and
  renames do not break the seam because the bridge resolves by slug
- delete the tag definition through People > Manage tags or the admin API (which also
  unassigns it from every customer and lets the extension
  auto-recreate later)

Operators cannot:

- change an existing tag's slug (slugs are stable; create a new tag if
  you need a different machine name)

## Audit Attribution

Every assignment captures:

| Field | Source | Notes |
|---|---|---|
| `assignedByKind` | host | one of `admin`, `extension`, `automation`, `system` |
| `assignedById` | host | extension id for extension-driven calls; user id for admin-driven |
| `note` | caller | free-form short text (max 480 chars) — typically the business reason |
| `metadata` | caller + host | host augments caller-supplied JSON with `extensionId` and `accessId`; `feature`, `description`, and `contextTags` are added only when a host-native/CMS-proxy caller supplies them (the wasm seam stamps them empty) |
| `assignedAt` / `updatedAt` | host | timestamps |

Do not put PII into `note` or `metadata` — they appear in operator UIs
and downstream reporting. Use the order id, customer id, or other
internal references that won't leak.

## Approved Tag Color Palette

The host accepts 18 named tones; raw hex codes are rejected so the
admin shell can guarantee dark/light theme contrast. The palette is
operator/admin-API-settable only (`PATCH /admin/runtime/crm/tags/{tagId}`)
— extensions cannot set a color today; auto-bootstrap assigns the
default (`slate`).

```
slate · gray · red · orange · amber · yellow · lime · green · teal ·
cyan · sky · blue · indigo · violet · purple · fuchsia · pink · rose
```

## Admin-Facing HTTP Routes

For reference only — extensions do not call these. The admin UI binds
the same `CrmTagService` through HTTP and the bridge does so through
the validated client; both produce identical attribution.

| Method | Path | Purpose |
|---|---|---|
| GET | `/admin/runtime/crm/tags` | list all definitions |
| POST | `/admin/runtime/crm/tags` | create an admin-owned tag |
| PATCH | `/admin/runtime/crm/tags/{tagId}` | update label/color/description |
| DELETE | `/admin/runtime/crm/tags/{tagId}` | delete definition + all assignments |
| GET | `/admin/runtime/crm/profiles/{profileId}/tags` | list assignments for one profile |
| POST | `/admin/runtime/crm/profiles/{profileId}/tags` | admin-driven assign |
| DELETE | `/admin/runtime/crm/profiles/{profileId}/tags/{tagId}` | admin-driven unassign |

The profile list endpoint (`GET /admin/runtime/crm/profiles`) accepts a
`tagSlug` query parameter that filters to profiles carrying that tag.

## Failure Modes

| Error | HTTP-ish cause | Fix |
|---|---|---|
| `customer-tag access X is not declared` | Caller used an `accessId` not in the manifest | Add it to `customerTagAccess[]` |
| `customer-tag access X does not declare Y verb` | Scope not declared for the access | Add `Y` to that access's `scopes` |
| `customer-tag slug X is not declared in access Y` | Tag slug not in `managedTagSlugs[]` | Add it (namespaced) and re-publish |
| `customer-tag extensionId X must match manifest extensionId Y` | Tampered context | Use the extension's own context — never copy another extension's id |
| `CRM profile not found` | Stale profile id, or profile was merged/deleted | Re-resolve the profile id before retrying; merged profiles return the survivor id from `crm_profile_merges` |
| `tag slug X must be namespaced with {extensionId}:` | Upsert tried with a slug not owned by the extension | Use a namespaced slug |
| `tag slug X is owned by another extension` | Another extension already owns the slug | Pick a different slug; cross-extension takeover is not allowed |

## Disable, Remove, Re-enable, Rollback

| Event | Tag definitions | Assignments |
|---|---|---|
| Extension disabled | preserved | preserved; admin can manually unassign |
| Extension re-enabled | preserved | preserved; next assign call refreshes attribution |
| Extension uninstalled | preserved (admin can delete via `DELETE /admin/runtime/crm/tags/{tagId}`) | preserved; admin must clean up manually if desired |
| Operator deletes definition | row deleted | every assignment for that slug deleted |
| Operator unassigns one customer | preserved | only that assignment deleted; extension is free to re-apply |
| Manifest removes a slug from `managedTagSlugs[]` | preserved (orphaned but visible) | preserved; extension can no longer touch them via the seam |

For sticky removal, document the cleanup in the extension's
[`23-release-versioning-and-upgrades.md`](23-release-versioning-and-upgrades.md)
plan. The cleanup itself is an operator action — the delete endpoint is
an admin-permission HTTP route with no wasm path, so an extension cannot
call it during uninstall; instruct the operator to delete the
definitions after uninstall.

## Verification

Local checks:

- `cargo test --manifest-path server/Cargo.toml customer_tag` — unit
  tests for manifest validation and validated client scope enforcement
- `cargo test --manifest-path server/Cargo.toml crm_tag_db_tests` —
  DB-backed round-trip tests (requires
  `CEDROS_DATA_TEST_POSTGRES_URI`)
- `npx tsc -p ui/tsconfig.json --noEmit` — admin UI typecheck

Staging checks:

- Issue an assign via the extension's webhook and confirm the chip
  appears in the admin CRM with the `ext` badge
- Confirm the profile list `tagSlug` filter returns the tagged customer
- Confirm assign/reassign/unassign publish `cedros:customer-tag-changed`

## Related Surfaces

- [`08-site-database.md`](08-site-database.md)
  — extension-owned tables; do not write to `crm_*` tables directly
- [`09-settings-secrets-and-state.md`](09-settings-secrets-and-state.md)
  — for extension-private state that shouldn't be a customer tag
- [`10-host-providers.md`](10-host-providers.md) — same shape (manifest
  capability + per-call attribution) for intelligence/email/storage
  providers
- [`21-host-coordination-and-native.md`](21-host-coordination-and-native.md)
  — host binding ticket template (not required for customer-tag; it is
  already published)
- [`11-jobs-and-scheduling.md`](11-jobs-and-scheduling.md) — schedule a job
  that periodically reconciles tags from extension activity data

## Future Work (Not Yet Published)

- **Extension-settable label/color.** Custom label or color at install
  time is not currently possible from an extension: the wasm
  `customer-tags` interface exposes assign/unassign/read only, and the
  internal auto-bootstrap hardcodes no color (default `slate`) with a
  slug-derived label. A dedicated `setupSeeds.customerTags[]` block
  would let extensions declare definitions with explicit labels and
  colors at install time without waiting for the first assign call.
- **Bulk assign API.** Today each call is per-profile. A bulk path is
  on the roadmap for reconciliation jobs.

Both items will land additively without breaking the existing seam.

## CRM source events

CRM source-event submission
(`crm-source-events.submit(access-id, source-kind, event-type, payload-json)`)
follows the same declare-then-call pattern via `crmSourceAccess[]` — see
[`04-manifest-reference.md`](04-manifest-reference.md) for the fields and
[`07-wasm-server-backends.md`](07-wasm-server-backends.md) for the wasm seam.
Third-party payment attribution uses source kind `cedros_pay`; the
`cedros_login` kind is reserved for the bundled cedros-login extension's
`account.merged`/`identifier.linked`/`identifier.unlinked` events and the
dedicated `cedros-login:invite-gate-handoff` access. That access accepts only
`invite_gate.pending`; its non-PII payload is idempotent on `occurrenceId`, and
the host returns `accepted`, `receiptId`, and `status` only after the product
waitlist write commits. Other source-event calls retain the normal attribution
response. Payloads must include deterministic identity and no raw wallet
addresses, credentials, or session/invite tokens.

Next: [`21-host-coordination-and-native.md`](21-host-coordination-and-native.md).

## Visitor reference mapping

Resolve an extension-scoped visitor through
`cedros-data:visitor-reference-read-v1`. Core returns its CRM `profileId`
(or null while Login identity ingestion is pending) and an opaque
`recipientRef`. References resolve only within the declaring extension.
Customer tag writes still require their existing declared scopes. Personal
notification publication accepts this recipient reference and still requires
user-authorized event destinations. See
[extension visitors](contracts/extension-visitor-v1.md).

# 19 · Composability and Relying-Party Contracts

Read this when an extension should expose functionality for other extensions,
consume functionality from another extension, or both — including when one
extension must use another extension's **end-user identity** or **data**, e.g.
a compliance or gift-card extension keying records to a cedros-login user, or
crediting a balance owned by cedros-pay. Companion to
[`07-wasm-server-backends.md`](07-wasm-server-backends.md).

Composable extension behavior must be explicit. Do not assume that installed
extensions can see each other's private modules, tables, settings, or secrets.

## What you declare and build

- provided contracts the extension exposes to other extensions
- consumed contracts the extension requires or optionally uses
- capability ids, event ids, data references, and provider scopes
- version compatibility rules
- failure and degraded-mode behavior
- release notes for any new or changed public contract

## Composition surfaces

Extensions may compose through:

- `dependencies.extensions[]` for family/version dependencies
- `dependencies.capabilities[]` for consumed host/extension capabilities
- root `capabilities[]` for operator-reviewed capabilities or trust scopes
  this extension publishes
- `providerAccess[]` for site-owned intelligence, image, voice, storage,
  email, and blockchain providers (domain operations are Managed-API-only and
  cannot be requested as a `providerAccess[]` grant)
- `databaseAccess[]` for extension-owned site data operations
- `analytics.events[]` and `surfaces.server.events[]` for stable event names
- admin module links, dashboard cards, and content editor panels
- page seeds, content blocks, templates, and authored surfaces
- Wasm-backed server routes and job executors, or explicit sidecar handoffs

Extensions may not compose through:

- raw database credentials
- private package internals
- unversioned URLs
- shared mutable global browser state
- copied secrets or provider keys
- direct reads of another extension's private tables

## Provided contract plan

When exposing functionality, define:

- contract id
- owning extension id
- display name and summary
- minimum input shape
- output shape
- auth and permission expectations
- observability tags
- stability level: experimental, stable, or deprecated
- version introduced
- compatible versions

Prefer capability ids for user-visible powers, event ids for asynchronous
notifications, and documented host services for direct calls.

## Public contract status registry

| Contract ID | Type | Stability | Introduced | Status | Input | Output/Event | Auth | Notes |
|---|---|---|---|---|---|---|---|---|

Allowed status values are `published`, `draft`, `planned`,
`host-coordinated`, and `unavailable`. Anything not marked `published` must be
treated as handoff-only.

The owning extension's published manifest, release notes, or Cedros contract
registry is the source of truth for status. Do not infer published status from
examples in this document or from an installed package's private exports.

## Consumed contract plan

When consuming another extension, define:

- required or optional dependency
- minimum compatible version
- published status and source of truth for the consumed contract
- exact capability/event/data contract consumed
- user workflow that depends on it
- fallback if absent or disabled
- rollout risk if the provider extension is upgraded first
- rollback risk if the consumer extension is downgraded first

Required dependencies block install or enable when absent. Optional dependencies
must degrade without broken navigation, failed renders, or silent data loss.

Manifest dependency example:

```json
{
  "dependencies": {
    "extensions": [
      {
        "extensionId": "cedros-pay",
        "minVersion": "1.0.0",
        "required": true,
        "reason": "Checkout is owned by Cedros Pay."
      },
      {
        "extensionId": "cedros-shop",
        "minVersion": "1.0.0",
        "required": false,
        "reason": "Product lookup enriches optional recommendations."
      }
    ]
  }
}
```

Degraded modes:

- required dependency missing: install or enable is blocked
- optional dependency missing: show unavailable/connect state, hide dependent
  metrics, and avoid broken links

Analytics events and domain/server events are different contracts. Use
`analytics.events[]` for reporting declarations. Use
`surfaces.server.events[]` for Wasm telemetry grants/domain events or an explicit
host-coordinated dispatcher. If an extension also declares
`setupSeeds.notifications[]`, each notification seed's `eventId` must match one
of those server events. That seed makes the event configurable in Settings ->
Notifications for active installs; the server event declaration is still not a
dispatcher by itself.

When a public composability contract changes, document deprecation handling:
old contract id, replacement id, compatibility window, removal version, and
consumer impact.

## Database composition

An extension may expose its own data through documented Wasm-backed server
routes, events, or host services. It should not grant another extension direct
table access.

If cross-extension data access is needed:

- the owning extension declares its data model in `surfaces.server.contentModels[]`
- the owning extension declares its own database operations in `databaseAccess[]`
- consumers depend on a public capability, event, route, or SDK helper from the
  owning extension
- the owning extension enforces permissions and redaction
- both extensions document version and rollback behavior

The HTTP mechanics for those cross-extension routes are the relying-party
contracts below.

## UX requirements

- show missing optional dependencies as unavailable or connectable, not broken
- link to the provider extension's admin page when setup is required
- avoid duplicate settings screens when a provider extension already owns setup
- include dependency status in onboarding when it blocks activation
- keep dashboard cards self-contained and safe if provider data is unavailable

## Relying-party service contracts

Call another installed extension through **`extension-services.invoke`**, with
its extension and published capability declared in `dependencies`. The host
binds the caller identity, validates both manifests, and supplies only the
operation's service claim. The request has no credential or headers field.
Providers own their routes and data; consumers never read another extension's
collections. Version breaking contracts by path and retain older versions
until consumers migrate.

`http.fetch` is the operator-allowlisted HTTPS egress seam for external hosts.
A site's public domain is not a substitute for the installed-extension service
seam. The examples below describe provider-owned payloads carried through
`extension-services.invoke`, without static service credentials or hairpin
requests. Official buyer purchases use the narrowly bounded host bridge in
[the visitor contract](contracts/extension-visitor-v1.md).

## Official Cedros Login and Cedros Pay seams

Customer-facing consumers, including Cedros Portal, do **not** provision or
store static Cedros Login or Cedros Pay service credentials.

Cedros Login publishes the browser/session contract:

- `cedros-login:auth-response` defines the `cedros_access` session cookie and
  authenticated response shape.
- `cedros-login:user-context`, declared as a **required** capability together
  with a required `cedros-login` dependency, admits a first-party `cedros-*`
  consumer (or the reserved legacy first-party id `vinescribe`) to receive the end user's `cedros_access` cookie on its routes.
  Third-party extensions are never admitted: the cookie is a replayable
  session bearer. The host forwards the cookie;
  this legacy cookie-forwarding contract does not inject visitor identity.
- Third parties use `cedros-data:extension-visitor-v1` and per-route
  `routePolicies` to receive a verified, extension-scoped `context.visitor`.
  See [the visitor contract](contracts/extension-visitor-v1.md), including
  consent, page access, form submissions, references and buyer purchases.
- `/extensions/cedros-login/v1/.well-known/jwks.json` is public. A consumer that
  receives `cedros_access` on its own end-user request may verify that token
  locally without a Login service credential.

Cedros Pay owns buyer authentication for its customer routes:

- public reads such as `GET /paywall/v1/subscription/plans` need no credential;
- buyer routes under `/paywall/v1/*`, including selection, checkout, and
  purchase flows, receive the end user's Login session in the form required by
  the route contract;
- Pay validates that buyer through its own Login integration. The consumer does
  not configure a Pay shared secret or a second copy of a Login secret.

Admin/operator integrations use the published `cedros-login:admin-auth` and
Cedros Pay capability contracts. A consumer must never turn the specialized
service routes under `/subscription/v1/*`, `/credits/v1/*`, or
`/payments/v1/status` into a general Login/Pay credential setup screen. Those
routes are separate service-to-service contracts and are used only when a
consumer explicitly declares that exact contract.

## Capability-gated extension routes: Cedros Balance

Cedros Balance `0.5.0` is the canonical provider-side example for a route whose
authorization subject is the calling extension rather than an admin or end
user. Read the complete contract, consumer manifest, and installed-host matrix
in [`contracts/balance-rail.md`](contracts/balance-rail.md).

The publication pattern is:

1. The provider declares each operation in root `capabilities[]` for install
   review and the corresponding executable Wasm route id in
   `surfaces.server.routes[]`.
2. The consumer declares the provider and minimum version in
   `dependencies.extensions[]`, lists each consumed operation in
   `dependencies.capabilities[]`, and keeps `requiredCapabilities[]` aligned.
3. The host authenticates the calling extension, uses its stable extension id
   as `actorId`, and injects exactly one granted operation id into
   `permissionClaims[]`.
4. The provider rejects missing, wrong, duplicate, or multiple operation
   claims before reading or mutating its data.

Service identity and operation claims are host-owned. They cannot be supplied
or elevated through headers, cookies, bearer tokens, query parameters, or
request JSON, and these service routes are not browser-callable.

The Balance provider and consumer binding are published through the Wasm
`extension-services.invoke` import. Its typed request has no headers field; the
host derives the caller from the running component and performs step 3 only
after checking both active manifests, dependency version bounds, required grant
alignment, provider capability publication, and the bound route. Step 4 belongs
to the provider handler: the manifest does not bind a root capability id to a
particular route. A caller granted one published capability can address another
bound route on that provider, carrying only that one claim; the provider's
operation check is the authorization boundary. The public
extension router remains an end-user/admin surface and cannot be used to
simulate this service context. Financial production use still requires the
installed-host matrix.

This pattern does not grant cross-extension database access. Balance remains
the only owner of its ledger models. Its atomic transfer uses the provider's
own `cedros-data:extension-storage-cas-v1` grant to commit both ledger entries,
both balances, and the rollup as one guarded operation.

Cedros Data `0.1.62` adds one Core-owned target to the same import for
operational-wallet address discovery and finalized inbound activity. It uses
host capability dependencies rather than `dependencies.extensions[]`, exposes
no raw RPC/Vault payloads, and grants no outbound signing authority. See
[`contracts/operational-wallet-notification-seams.md`](contracts/operational-wallet-notification-seams.md).

## Service-to-service authentication

Installed providers authenticate the calling extension through the host-created
`extension-service` context and the exact operation capability claim. Both
manifests must declare the dependency and capability. The consumer cannot attach
an Authorization header or service token to `extension-services.invoke`.
Providers still enforce their own domain authorization and redaction.

External HTTPS services may require provider credentials through their published
contract and the reviewed `secrets`/`http.fetch` seams. That external egress
pattern does not apply to another extension installed on the same host.

## Generic identity contract

For Cedros Login visitors, use the host-verified visitor contract above; third
parties never receive its session token. A custom identity provider may publish
its own session protocol. These illustrative payloads do not grant access to
Login cookies or turn a caller-supplied user id into host authority. Retrieve an
installed provider's declared JWKS or introspection operation through
`extension-services.invoke`; the provider owns verification and any custom
session fields it explicitly accepts.

### JWKS (preferred — stateless, no per-request round-trip)

The IdP issues **JWT** sessions and publishes a JWKS:

```
GET /extensions/example-identity/v1/.well-known/jwks.json
→ 200 { "keys": [ { "kty": "EC", "crv": "P-256", "kid": "...", "x": "...", "y": "...", "use": "sig", "alg": "ES256" } ] }
```

JWT claims: `iss` (the IdP's stable issuer id), `sub` (the user id), `aud`
(intended audience), `exp`, `iat`, plus any `roles`/`scope` the IdP defines. The
relying party **fetches + caches** the JWKS (honor `Cache-Control`/`kid`
rotation), then verifies the request's JWT locally (signature, `exp`, `iss`,
`aud`). Verification crypto is pure-Rust and builds to `wasm32-wasip2`
(`p256`/`ed25519`/`rsa` + `coset`/`jsonwebtoken` with the rust_crypto backend — no
openssl/ring).

### Introspection (fallback — opaque sessions)

If sessions are opaque, the IdP publishes:

```
POST /extensions/example-identity/v1/session/introspect
   Host context: extension-service with the declared operation capability
   { "token": "<end-user session token>" }
→ 200 { "active": true, "userId": "...", "claims": { ... }, "expiresAt": "<rfc3339>" }
→ 200 { "active": false }   (expired/unknown — never 4xx for an inactive token)
```

The relying party calls this per request (cache briefly within the deadline if
hot). Prefer JWKS where the IdP can issue JWTs.

## Generic user-directory contract

For lookups and counts a relying party needs but must not store wholesale:

```
GET /extensions/example-identity/v1/users/{userId}
   Host context: extension-service with the declared operation capability
→ 200 { "userId": "...", "status": "active|suspended|...", "createdAt": "<rfc3339>", "email": "<optional, if the RP is authorized for PII>" }
→ 404 (unknown user)

GET /extensions/example-identity/v1/users/count?status=active&createdAfter=<rfc3339>
   Host context: extension-service with the declared operation capability
→ 200 { "count": 1234 }
```

Return the **minimum** fields the relying party is authorized for; gate PII
(email/phone) behind the calling extension's granted operation and consent. The relying party keeps its own
derived data (KYC status, accreditation) in **its own** content models, keyed by
`userId` — it does not mirror the user table.

## Generic payments / credits contract

This remains an illustrative pattern for a new provider. It is not a Cedros Pay
route family. Use the official registry and the credential-free buyer flow above
for Cedros Pay.

For balance and payment operations another extension drives:

```
POST /extensions/example-ledger/v1/credits
   Host context: extension-service with the declared operation capability
   { "userId": "...", "amount": 500, "currency": "usd", "reason": "giftcard:redeem:<id>", "idempotencyKey": "<unique>" }
→ 200 { "applied": true, "balanceAfter": 1500, "currency": "usd" }
→ 200 (idempotencyKey already applied — replay returns the original result body, not an error)

GET  /extensions/example-ledger/v1/credits/{userId}        → 200 { "balance": 1500, "currency": "usd" }
GET  /extensions/example-ledger/v1/payments/{paymentId}/status → 200 { "status": "succeeded|pending|failed", ... }
```

`idempotencyKey` is **required** on every mutating call — the relying party can be
killed mid-invocation (5 s deadline) and will retry, so credit application must be
exactly-once on the provider side.

## The relying-party flow (consumer side)

1. Opt the customer route into `routePolicies` and use its verified
   `context.visitor.userId` for Cedros Login accounts.
2. Call installed providers through `extension-services.invoke`, with declared
   dependencies and operation grants. External HTTPS services use `http.fetch`.
3. Let the provider enforce its own account and domain authorization. A visible
   visitor reference is not a session token; only the documented host Pay bridge
   carries live visitor authority to its buyer-history operation.
4. Store your own data keyed by the extension-scoped visitor reference; do not
   mirror the provider's records.

## Provider-owned protocols

The host brokers caller identity, dependency validation and operation grants;
providers own their payloads, versioning, domain rules and redaction. There is
no generic cross-extension database or arbitrary identity-claim forwarding.
The official visitor, Pay buyer-history and Core reference contracts above are
bounded host integrations, rather than permission to invent new claim bridges.

## Acceptance checks

- Every consumed extension contract is named by stable id.
- Required provider-extension dependencies appear in
  `dependencies.extensions[]`; published Core service dependencies instead pin
  the documented minimum Cedros Data version.
- Optional dependencies have tested degraded states.
- No private package import or raw table coupling is required.
- Upgrade and rollback plans cover both provider-first and consumer-first order.

Provider-side checks:

- [ ] Publish your contract under `/extensions/{id}/v1/…` following the pattern
      above.
- [ ] Authenticate every protected data route exactly as its published contract
      declares; validate the host-created calling extension and operation claim.
- [ ] Make mutating routes **idempotent** on `idempotencyKey` — replays return
      `200` with the original result body.
- [ ] Return inactive/expired states as `200 { active:false }` / `404`, not 5xx.
- [ ] Document every field of your published contract and keep it stable within
      a path version.

Next: [`20-crm-tags-and-source-events.md`](20-crm-tags-and-source-events.md).

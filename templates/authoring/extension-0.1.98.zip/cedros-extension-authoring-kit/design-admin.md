# Workbench — Admin Theme Overview & Implementation Standard

**Version 2.12 · 2026-09-09 · Status: canonical for the Workbench theme and every surface under `/admin`**

Workbench is Cedros' calm, precise theme for people who run the business. It turns dense
operations, configuration, and reporting into a workspace that feels quiet at rest and
immediate in use. Neutral surfaces carry the work; cedar appears only where it adds
meaning; compact rhythm makes information scannable without feeling compressed.

This Markdown file is the **machine-readable half of the Workbench theme overview**. It
is the implementation source of truth for agents, engineers, and extension authors:
tokens, scales, composition rules, component anatomy, state behavior, copy, motion,
accessibility, and integration contracts. The companion
[`design-admin.html`](./design-admin.html) is the **human-readable half**: a self-contained
theme story, brand guideline, and visual specimen page suitable for evaluating Workbench
as a theme. The pair is versioned together and must never disagree.

This pair is also the **reference implementation of the theme-overview format** (§12).
Every Cedros theme or design system ships the same two files: an HTML page that sells
and explains the theme to the person choosing it — and serves as the theme's marketplace
preview — and a Markdown standard that lets an agent style correctly inside it. Authors
copy this pair's structure, snapshot, narrative order, and conventions.

### Theme snapshot

| Attribute | Workbench |
|---|---|
| Surface | Cedros admin, operational extensions, and dashboard cards |
| Audience | Operators, site owners, editors, support teams, and extension authors |
| Promise | Dense work feels clear, dependable, and fast |
| Personality | Neutral · precise · quiet · durable · capable |
| Visual direction | shadcn-inspired restraint translated into Cedros tokens and portable BEM contracts |
| Signature | Hairline structure, compact rhythm, tabular data, neutral controls, cedar links/data |
| Modes | Light and dark are equal, first-class expressions |
| Avoid | Decorative gradients, glass, oversized type, ornamental color, per-section personality |

**Relationship to the brand standard.** [`design-cedros.md`](./design-cedros.md)
(Heartwood) owns the public-facing brand: marketing, public themes, onboarding moments,
and the shared voice, color anchors, and motion tokens. Workbench inherits all of that and
**overrides it wherever the two touch the admin** — this file wins inside `/admin`.

**The design promise.** Workbench has **one way per job**. Repeated patterns share the
same primitive, every value belongs to a named scale, and every state remains legible in
both modes. Familiarity is a feature: a page authored by Cedros, a private extension, or
a marketplace extension should feel like one coherent product.

**The doctrine: what would shadcn do?**
Cedros admin styling is heavily and deliberately inspired by shadcn/ui. When a decision is
ambiguous, contested, or unspecified here, resolve it with this procedure:

1. Does this document specify it? Follow it.
2. Does shadcn/ui have this component or pattern? Match shadcn's anatomy, naming,
   variants, and restraint (translated into `--cd-*` tokens and BEM classes — we don't
   ship Tailwind).
3. Still ambiguous? Choose the *quieter, denser, more neutral* option, and add it here
   by PR.

We diverge from shadcn only where an operational data tool earns it; every divergence is
listed in Appendix B with its reason. Any unlisted divergence requires an update to this
pair before implementation.

**How to use the pair.** Start here when writing code: apply the decision rules and the
stable class contract in §11. Open the HTML when choosing the theme, reviewing its visual
character, or matching a specimen. A note marked *host availability* describes whether a
specified capability is currently exported to extensions; it does not authorize a local
replacement. Extension authors never fill a host gap by shipping a second toaster,
dialog system, token set, or global primitive.

**Theme-system boundary.** Workbench documents an application design system using
`--cd-*` admin tokens. It is not a public-site `CedrosThemeManifest`, whose portable
runtime tokens use `--cedros-*`. The two-file overview format in §12 is designed for both
kinds of theme, but authors must map the shared narrative sections to the correct runtime
contract for their surface.

---

## 1. Scope and posture

**Scope.** The admin shell and every section inside it (Dashboard, Content, Media, Users,
Email, Grow, Assistant, Settings, Tools, Observability, Monetization), extension admin
pages (which bridge to these tokens), and admin-facing dialogs, toasts, and panels.
Not in scope: public sites, themes, checkout, marketing pages (see `design-cedros.md`).

**Posture.** Workbench is a professional tool used daily: it should feel like shadcn's
temperament applied to a dense workspace — neutral, precise, quiet, instantly responsive.
Decoration is functional, never ornamental. Here, restraint *is* the brand. Cedar
(`#2F6C7D` / dark `#7FB0BD`) appears only as: hyperlinks,
the first data-viz series, and Cedra's presence indicator. Not buttons, not nav, not
selection. Gold appears only at true milestone moments (launch, approve). Everything else
is the neutral ramp plus the four status hues.

---

## 2. Principles

**W1 — The primitive wins.** For every job there is exactly one component:
`cedros-data-btn`, `cedros-data-input`, `cedros-data-select`, `cedros-data-card`,
`cedros-data-table`, `cedros-data-dialog`, `cedros-toast`, the segmented Tabs, the
`⋯` row menu, the block Empty state. A section never rolls its own. If the primitive
cannot do the job, extend its documented anatomy in one place and update both overview
files in the same change.

**W2 — The scale is the law.** Type has 8 sizes, spacing has 7 steps, radius has 3,
elevation has 4, control heights have 2. A value not on a scale is out of character even
when it looks acceptable in isolation.

**W3 — Aligned at rest.** Ordinary action buttons share one 32px height and single-line
fields share one 36px height. Mixed button-field rows align their centers; labels sit on
one baseline grid; table numerics share one right edge; concentric radii stay parallel.
Alignment is the theme's quietest premium signal.

**W4 — Dense, calm, scannable.** 13–14px body, 32px buttons, 36px fields, ~40px rows. Density is
paid for with hierarchy: one page title, muted secondary text, uppercase micro-labels
*only* where the eye scans columns (table headers, stat labels, nav groups) — never on
forms or toolbars.

**W5 — State over chrome.** The only things allowed to attract attention are states that
need it: unsaved, running, failed, needs-review. Everything decorative is neutral. If you
squint and a border pops, the border is wrong.

**W6 — Instant, keyboard-first, both modes.** ≤100ms acknowledgment, skeletons within a
frame, `:focus-visible` rings everywhere and only on keyboard focus, full keyboard parity,
WCAG 2.2 AA in light and dark.

**W7 — Boring by design.** The admin should look barely different year over year. No
trends, no gradients, no glass, no per-section personality. A new section should be
visually indistinguishable in kind from an old one. The one gradient exception is
identity: the deterministic avatar gradients (profile fallbacks and the assistant
persona orb, §7 Furniture) — never surfaces, buttons, or chrome.

---

## 3. Tokens and theme

The token set is defined in `ui/src/admin/shell.css` (`--admin-*` base, `--motion-*`)
and consumed as `--cd-*` inside `.cedros-data` scopes. **These values are shadcn's
default neutral theme** — the mapping is exact and deliberate:

| Workbench token | shadcn equivalent | Light | Dark |
|---|---|---|---|
| `--cd-bg` | `background` | `oklch(1 0 0)` | `oklch(0.145 0 0)` |
| `--cd-fg` | `foreground` | `oklch(0.145 0 0)` | `oklch(0.985 0 0)` |
| `--cd-card-bg` | `card` | `oklch(1 0 0)` | `oklch(0.205 0 0)` |
| `--cd-muted` | `muted-foreground` | `oklch(0.556 0 0)` | `oklch(0.708 0 0)` |
| `--cd-muted-bg` | `muted` | `oklch(0.97 0 0)` | `oklch(0.269 0 0)` |
| `--cd-accent` | `accent` | `oklch(0.97 0 0)` | `oklch(0.269 0 0)` |
| `--cd-border` | `border` | `oklch(0.922 0 0)` | `oklch(1 0 0 / 10%)` |
| `--cd-primary` / `-fg` | `primary` / `-foreground` | `oklch(0.205 0 0)` / `0.985` | `oklch(0.922 0 0)` / `0.205` |
| `--cd-ring` | `ring` | `oklch(0.708 0 0)` | `oklch(0.556 0 0)` |
| `--cd-error` | status error | `oklch(0.577 0.245 27.325)` | `oklch(0.704 0.191 22.216)` |
| `--cd-danger-bg` / `-fg` | destructive button pair | `oklch(0.5 0.22 27.325)` / `0.985` | `oklch(0.704 0.191 22.216)` / `0.145` |
| `--cd-success` / `--cd-warning` / `--cd-info` | — | `shell.css` base status tokens | `shell.css` dark status overrides |

Standing rules inherited from Heartwood:
`--cd-accent` is a **surface**, never a text color; every admin root carries
`.cedros-data`; extensions bridge (`var(--cd-x, fallback)`) and never re-declare host
tokens; no hex/oklch literals in component CSS.

**Workbench semantic additions:**

```css
--cd-warning-fg: oklch(0.52 0.12 75);          /* dark: var(--cd-warning); readable warning text */
--cd-input-bg: transparent;                     /* dark: color-mix(in srgb, var(--cd-muted-bg) 30%, transparent)
                                                  — shadcn v4 input fill */
--cd-link: var(--cedros-link, #2F6C7D);         /* dark fallback #7FB0BD — the only cedar in the admin */
--cd-chart-1..6;                                /* chart/art only: cedar, gold, sage, clay, indigo, mist */
--cd-danger-bg / --cd-danger-fg;                /* paired solid destructive button tokens; brand overrides
                                                   must set both, never derive a button from --cd-error alone */
/* z-scale — preserves a predictable stacking order. No other z-index values. */
--z-dropdown: 50; --z-panel: 900; --z-modal: 1000; --z-drawer: 1200; --z-toast: 1300;
```

Component CSS consumes semantic tokens rather than literal colors: warning surfaces use
`--cd-warning*`, success uses `--cd-success`, and optical shadows mix with `--cd-bg`.

---

## 4. Scales

### 4.1 Type — eight sizes, four weights, no exceptions

Eight roles create the full Workbench hierarchy:

| Token | Size | Weight | Role |
|---|---|---|---|
| `2xs` | 0.6875rem | 600 | UPPERCASE +0.04–0.05em for scanning labels |
| `xs` | 0.75rem | 400–500 | captions, metadata, quiet help |
| `sm` | 0.8125rem | 400–500 | the workhorse: controls, cells, labels, help |
| `base` | 0.875rem | 400 | body; **600 = card/section titles** |
| `md` | 1rem | 600 | emphasized values |
| `lg` | 1.15rem | 600, −0.015em | page titles, dialog titles |
| `xl` | 1.5rem | 600–700 | stat values, setup headlines |
| `2xl` | 2rem | 600–700 | hero numbers only |

Where the eye scans columns — table headers, stat labels, nav group labels — use `2xs`
uppercase. **Everywhere else, sentence case**: form labels are `sm`/500 sentence case
(shadcn `Label`), never uppercase micro.

Line-heights: 1.5 body, 1.45 dense, 1.25 titles, 1 controls. Mono for ids, slugs, URLs,
keys, payloads. `font-variant-numeric: tabular-nums` on every numeric column and stat.

### 4.2 Spacing — seven steps

`0.25 / 0.5 / 0.75 / 1 / 1.5 / 2 / 3rem`. Anchors: control padding-x 0.75rem (sm 0.5rem);
card padding 0.9rem 1rem, compact 0.75rem, spacious 1.5rem (onboarding/celebration only);
grid gaps 0.5 /
0.75 / 1rem; section stack gap 1rem; page padding `clamp(1rem, 2vw, 1.5rem)`.

### 4.3 Radius — three, concentric

`--cd-radius` 8px (cards, tables, menus, and the component base) · `--admin-radius`
12px (shell, dialogs, panels) · 999px (pills, avatars, skeleton lines). Bordered
controls use the derived 7px `--cd-radius-control`; that derived value is not another
scale stop.

Nested rounded surfaces use the same construction Apple calls **concentric corners**:
their curves share a center point. For each corner,
`child radius = max(0px, parent radius − distance between outer edges)`. Measure the
real inset on that corner and include the parent's border. The common panel/list
relationship is 12px parent − (1px border + 4px padding) = 7px child. Never reuse a
nearby radius token when its geometry does not match the actual inset. Concentric
corners make nested surfaces feel cut from the same material.

Admin chrome is checked by `npm run lint:admin-corner-radii`. The check rejects
positive radius growth such as `calc(var(--cd-radius) + …)` and off-scale literal
corners in migrated feature styles. Authored/public preview surfaces require an
explicit reviewed exception because their geometry belongs to the rendered site,
not Workbench.

### 4.4 Elevation — four, borrowed light

e0 border-only · e1 card (`--cd-shadow`) · e2 overlay (menus/popovers) · e3 floating
(dialogs/palette/toasts) — runtime recipes in `ui/src/admin/styles.css` and `ui/src/admin/shell.css`; public elevation follows Heartwood §4.11. Shadows always mix from
`--cd-fg`. No colored glows, no backdrop-filter except the toaster's blur — the one
sanctioned blur in the theme.

### 4.5 Control heights — two

| | Height | Used by |
|---|---|---|
| **button** | **2rem (32px)** | ordinary boxed actions: page-header, dialog, card, toolbar, row, and icon actions |
| **field** | **2.25rem (36px)** | single-line inputs and selects, including toolbar fields |

Default and `sm` button variants share the same outer height; `sm` changes only compact
padding and type. Icon buttons are 32px square. When a button sits directly beside a
field, center-align the 32px button within the field's 36px row rather than stretching it.

### 4.6 Container widths — four, named

Four named widths keep reading and interaction lines comfortable:

| Token | Value | Use |
|---|---|---|
| `--cd-container-page` | `min(100%, 1360px)` | default page content |
| `--cd-container-settings` | `45rem` (720px) | settings/forms column — **fields never stretch wider** |
| `--cd-container-prose` | `60ch` | any explanatory text |
| Dialog widths | `420px` default · `560px` md · `680px` lg | §7 Dialogs |

### 4.7 Mono, numbers, and identifiers

The distinction is semantic, not decorative:

**Quantities are sans + `tabular-nums`.** Counts, money, percentages, durations, dates
and relative times, deltas, stats — always the UI sans with
`font-variant-numeric: tabular-nums`, right-aligned in table columns, never mono. Money
uses locale formatting ("$8,940.00"); counts abbreviate at five digits ("12.4k") with the
exact value on hover. Locale formatters only — never hand-built
strings.

**Identifiers are mono (`--cd-font-mono`).** Anything a user copies or compares
character-by-character: slugs and paths, URLs and domains, record refs (`#2214`,
`req_8f3a`), API keys and secrets, env vars, versions (`v2.4.1`), JSON/payloads/CLI
output, log lines, filenames. Mono renders optically large, so it sets one step smaller
than its context (0.75rem inside `sm` copy; 0.72rem muted in table cells — the
`.mono` cell convention) at normal line-height. Emails and human names are sans;
timestamps are sans (ISO timestamps in logs/technical tables may be mono).

The four identifier patterns:

- **Inline code chip** — mono on a `--cd-muted-bg` fill, hairline border, 4px radius,
  `0 0.3em` padding. For refs and terms inside sentences.
- **Slug chip** — mono inside a pill (hairline border, 8% wash); sits after titles in
  content lists (§6A).
- **Copyable identifier** — mono value + ghost icon-sm copy button that flips to
  "Copied" for a beat. Anything worth displaying as an id is worth a copy button.
- **Secret** — write-only. While being entered: a password input with an eye
  visibility toggle (`aria-pressed`, "Show/Hide {label}"). Once saved: a literal mask
  (`••••••••••••`) + "Saved · updated {date}" + Replace / Remove — the stored value is
  never re-shown, never copyable, never in tooltips, never logged (the API-keys
  `ProviderSecretField` is the reference). Copy buttons are for identifiers; secrets
  get a Replace button.

### 4.8 Icons

- **Lucide geometry**: stroke icons, stroke-width 2, round caps and joins,
  `fill="none"`, drawn on a 24 grid, rendered via `currentColor`.
- **Sizes**: 16px default (nav items, buttons, alerts, menu items may drop to 13–14px
  inside `sm` controls); nothing larger than 20px in chrome. Icons inherit their
  parent's color — muted at rest in nav (0.75 opacity), full strength on hover/active.
- **Meaning**: icons assist labels, never replace them; icon-only controls require
  `aria-label` + a tooltip (§7). Decorative icons are `aria-hidden="true"`.
- **No** filled icons (status dots and third-party logos excepted), no emoji as icons,
  no duotone or gradients, no custom brand glyphs in the sidebar — extension nav items
  supply a Lucide icon name via their manifest (`sections[].icon`) and render
  identically to core items.

### 4.9 Charts in the admin

Shared data conventions are Heartwood §4.12; the admin bindings:

- **Series 1 is always cedar**, then the fixed categorical order (gold, sage, clay,
  indigo, mist), exposed as `--cd-chart-1..6` for chart and art use only:
  `#2F6C7D` / dark `#7FB0BD`, `#E8BE75`, `#5B8C6E`, `#C2725A`, `#4C5DAE`, `#7FB0BD`.
  Semantic series may use status tokens — and only those. No gradients appear in chart
  fills; area fills are the series color at ≤12% opacity.
- Hairline horizontal gridlines only (`--cd-border`); axis labels `2xs` sans muted,
  tabular; no axis boxes, no vertical grid, no chart borders.
- Tooltips are e2 overlays; direct labels beat legends; values crossfade on refresh
  (160ms); one draw-in ≤500ms on first paint; nothing loops.
- Empty chart = flat hairline at zero + a micro empty line — never a fake sample
  without a "Sample" badge.
- In-page metrics use the `.cedros-data-metric` family inside
  `.cedros-data-summary-grid` (label/value/hint — §7 Furniture); sparklines are cedar
  hairlines with a dot on the last point only.
- Specialized visualizations (the visitor globe) are exempt from the categorical
  palette but their UI chrome (buttons, legends, tooltips) consumes tokens like
  everything else.

### 4.10 Truncation and overflow

Content adapts by truncating, wrapping, or scrolling **inside its own frame** — the
page never scrolls horizontally (§5 Mobile).

- Single-line slots (table cells, menu items, tile names, breadcrumb parents, select
  triggers) truncate with an ellipsis, and the full value stays recoverable: a
  `title`/tooltip on the truncated element or the detail surface one click away.
  Flex/grid children that hold truncating text carry `min-width: 0` — the missing
  `min-width` is the most common cause of clipped admin layouts.
- Prose slots (card descriptions, empty-state copy, notices) wrap; descriptions may
  clamp at two lines inside dense grids when the full text lives on the detail
  surface.
- Identifiers never truncate silently: a slug or ref either fits, middle-truncates
  beside its copy button, or moves to a copyable row (§4.7). Quantities never
  truncate — they abbreviate per §4.7.
- Localized labels get room to grow (+35%, §9 floor): a fixed pixel width that only
  fits the English string fails review.

---

## 5. The shell

One shell, `ui/src/admin/shell.css`, no per-page variation.

**Sidebar.** 264px expanded / 72px collapsed; collapse animates 220ms
standard-ease. Wordmark row: product name + 2rem collapse button (outline icon button).
Group label: `2xs` uppercase muted, padding 0.5rem 0.75rem 0.375rem. **Groups separate by
spacing alone (1.25rem)** — fewer lines, same scan.

**Nav items** — one treatment across every section:

| State | Recipe |
|---|---|
| Rest | transparent bg, `--cd-muted` text, 16px icon at 0.75 opacity; radius `--admin-radius − 2px`; padding 0.5rem 0.75rem |
| Hover | `--cd-accent` fill, `--cd-fg` text, icon opacity 1 — 160ms ease; **no border** |
| Active | `--cd-accent` fill, `--cd-fg` text, weight 500, icon opacity 1 — **no border, no inset ring, no shadow** |
| Focus | standard ring on `:focus-visible` only; pointer activation never leaves a focus halo |
| Disabled | opacity 0.48, not-allowed |

**Nav badges.** Counts on nav items use `.cedros-admin-shell__nav-badge`:
pill, min 1.25rem, `2xs`/600, `--cd-primary` fill + `--cd-primary-fg` text,
right-aligned (`margin-left: auto`). Badges carry *needs-attention* counts only — not
totals ("Inbox 3" unread, never "Pages 24"). Count changes pulse 220ms.
Collapsed sidebar shows a dot in place of the number.

**Disabled nav.** A section the user can't open stays visible at 0.48 opacity,
non-interactive, with its reason in the tooltip ("Install cedros-pay to enable
Products"). Hidden-vs-disabled: admin-only pages are
*hidden* from non-admins; capability-gated pages are *disabled* with the reason.

**Footer user card.** Border-top, 1.75rem avatar, name
`sm`/500 + email `2xs` muted, chevron; opens the profile dropdown (e2).

**Cedra.** The assistant's floating button: 3.5rem circle, fixed right 1.25rem / bottom
1.25rem, e3, the assistant persona orb (§7 Furniture), `z-panel`; press opens the
assistant panel; hidden below 768px (the mobile shell exposes it in the bottom bar).
While a run is in flight the orb plays the motion for the current phase, so the closed
launcher still reports activity.

**No topbar.** The admin is sidebar + content. Global search/command is ⌘K (§7 Command).

**Mobile (<768px).** The shell collapses to a single column: a
mobile header (menu button + `2xs` uppercase kicker + `sm`/600 section title, 10% accent
wash) and the sidebar as a **drawer** — fixed left, `min(320px, 100vw − 2.5rem)` wide,
slides in 240ms standard-ease from `translateX(-104%)`, over a `rgb(0 0 0 / 0.32)`
backdrop (200ms fade), `--z-drawer`, with safe-area insets honored. Esc and backdrop
close it. Touch targets grow to ≥44px, toolbars wrap, tables scroll horizontally inside
their own frame (never the page), and the Cedra button moves into the mobile header
row. Nothing else changes — mobile is the same admin, narrower.

The shell's breakpoint is the only one with a name: **768px**. In-page compositions
collapse where their own content demands it — two-column field grids and metric rows
typically fold between 640–760px — always by stacking, never by shrinking type or
control heights, and never by introducing horizontal page scroll.

**Navigation side effects.** Every section change sets the document title through the
shared metadata hook — `Cedros | {page name}` (host reference `useAdminDocumentMetadata`) —
and paints the route skeleton immediately (§9: no route-change motion). Keyboard focus
must land predictably on arrival: it moves to the new view's title or main region so
screen readers announce the page, and is never stranded on a control that no longer
exists. Scroll starts at the top on forward navigation and is restored on back
navigation (§7 Breadcrumbs).

---

## 6. Page templates

Every admin page is one of five templates. If a new page isn't one of these, that's a
design review, not a new template.

**Shared page frame.** The order is fixed: optional back navigation → page header →
optional page-level status → page content. The header contains one text block (title plus
one-sentence subtitle) and one action group; it does not contain tabs, breadcrumbs, status
notices, or filters. A page header gets at most one primary action at the far right on desktop; when
actions wrap, their DOM and visual order remain aligned. Repeating the active sidebar label
as a kicker, showing a count in the title, or putting a card around the page header adds
chrome without hierarchy and is not allowed.

**A · List page** (Pages, Posts, People, Orders…):
header (title `lg` + subtitle `sm` muted ≤60ch + **one** primary button, sentence case)
→ toolbar → table (or tile grid) → pagination. Choose the table when people compare
attributes across rows; choose the tile grid (§7 Tile grids) when a thumbnail
identifies the record faster than its name (media, themes) — toolbar, selection,
empty, and pagination rules are identical either way. Toolbar fields remain 36px and
toolbar buttons are 32px, center-aligned in one row: search input with leading icon and
placeholder (`Filter pages…`) at 14–18rem, then filter selects, spacer, and — only when the collection has real
alternate views — a view-mode icon-toggle group (§7 Tile grids). There are no column
pickers or density menus: a table's columns are a design decision, not a setting.
**No uppercase labels above toolbar controls**. Header anatomy is
the host contract: `.cedros-data__header` → `__header-text` (title + subtitle) +
`.cedros-data-actions` (the right-side slot that wraps below on narrow screens).

**Bulk selection.** When a list supports multi-row actions: a leading checkbox column
(~40px), a header select-all with the indeterminate state, and — while anything is
selected — the toolbar swaps to a **selection bar**: "N selected" (`sm`, tabular) +
bulk actions as `sm` buttons + a ghost "Clear"; Esc clears; destructive bulk actions
confirm in a dialog that repeats the count ("Delete 12 pages?"). Selection is a toolbar
state, not a per-section component.

**B · Settings page** (Settings→Site, per-extension settings…):
header → segmented tabs when the area has sub-sections (hug content, don't stretch) →
a single `--cd-container-settings` (45rem) column of cards, one card per concern: card
title `base`/600 + one-line description `sm` muted, then fields. Related short fields may
pair in a 2-column grid (never 3). Each card with mutable state ends in a footer row:
`Save` (primary, disabled until dirty) — or the surface autosaves and wears the autosave
chip instead; one mechanism per page, never both. Danger zone: last card, destructive
border, explicit consequences.

**C · Detail page** (one record: person, order, page):
back breadcrumb (`← Back to People`) → header (record title + status badge + actions: ≤1 primary,
rest in `⋯`) → two-zone body: main column of cards + optional 320px meta rail. Deep
sub-editing opens a panel, not a fourth level.

**D · Dashboard:** answer in order — anything wrong? · how's the business? · what
happened? · what's next? Stat cards (`2xs` uppercase label, `xl` tabular value, delta),
then evidence, activity, and queues. A chart appears only when direction, rate, or
composition changes the operator's decision; no decorative charts. Core and extension
dashboard contributions follow §6.1.

**E · Editor** (content, theme builder, page builder): full-width workspace, chrome
collapses to a slim header (back, title, autosave chip, preview + publish); tool rails
use the same primitives at `sm` size.

**F · Setup wizard** (guided first run inside a customer's admin): a Workbench surface,
not a brand-register moment. No imagery, video, or illustration — the same tokens,
scales, and primitives as every other page. Text step progress ("Step 1 of 2") in
sentence case, one question per screen, Choice tiles (§7) for the site type, `lg` step
titles with `xl` headlines only on the welcome, review, and launch screens, and every
step ends with the escape hatch: "You can change anything later."
The launch screen is the one sanctioned gold moment.

### 6.1 Dashboard contribution cards

A dashboard contribution is an **operational summary and doorway**, not a miniature
admin page. It earns dashboard space only when it answers one recurring question faster
than opening the extension page and either reports a changing condition, shows progress
toward an outcome, or exposes a next action. A static capability description, setup
manual, settings form, or inventory total with no decision attached belongs on the
extension page instead.

Before implementation, complete this sentence: **“This card helps {operator} decide
{action} by showing {signal} over {window}.”** If the action, signal, or window is
missing, the contribution is not ready for the dashboard. The visible card then answers,
in this order:

1. **What is this and does it need attention?** Header: stable title at `base`/600,
   optional one-line scope description only when the title is ambiguous, and at most one
   rule-backed Status badge. “Healthy”, “Degraded”, and “Unavailable” require documented
   thresholds; omit the badge when there is no honest aggregate state.
2. **What is true now?** A summary band of one–three decision-relevant metrics; four is
   the hard maximum for a wide card. The first metric is the primary outcome. Do not give
   five inventory counts equal weight or repeat the header badge as a metric.
3. **What changed, and why?** At most one evidence region: a trend/composition chart, a
   compact breakdown, or up to three activity/exception rows. Omit it when the current
   value and comparison already answer the question.
4. **How fresh is this, and what can I do?** Footer: “Updated {relative time}” (absolute
   time on hover), optional coverage/staleness note, and at most one destination link
   (“Review 22 affected sites”). A card is normally read-only; setup, retry, or sign-in
   may replace the destination when that action is the only way forward.

Use one outer `.cedros-data-card`; its header and footer are the card's only chrome.
Metric tiles may divide the summary band, but never nest another titled/elevated card.
Design for any host-assigned width from 320px upward: controls wrap, the metric band
folds 3→2→1, and the evidence region remains legible without horizontal scrolling. A
dashboard card contains one chart, no table longer than three rows, no tabs, no settings
form, and no workflow that needs a confirmation dialog. Link to the extension page for
the full investigation or task.

**Metric semantics come before chart choice.** Every metric has one declared kind even
when that word is not shown in the UI:

| Kind | Meaning | Dashboard treatment | Honest comparison |
|---|---|---|---|
| **Stock** | A level at a moment: open incidents, live sites, pending reviews | Value + “Right now”; line/step trend only when historical levels exist | Absolute change from the prior boundary (“+3 open”), not an activity count |
| **Flow** | Events inside a period: deployments, installs, publishes | Value names the period; bars when bucket timing matters | Equal-length preceding period, percent only when the baseline is meaningful |
| **Rate / ratio** | A numerator relative to a denominator: success rate, healthy sites | Percentage plus accessible numerator/denominator (“63 of 66”) | Percentage-point change; never hide a shrinking denominator |
| **Duration / percentile** | Time to an outcome: provision time, p95 latency | Locale-formatted duration with median/p95 named | Same statistic in the preceding period; never compare a median to an average |

The label names the measure (“Install failures”), while the hint names its scope or
comparison (“Last 30 days” · “▲ 2 pp vs prior period”). A geometric increase is not
automatically good: failures rising use the error meaning; resolved incidents rising use
success. Color follows domain outcome, not arrow direction, and the text/arrow carries
the meaning without color. Percent change is suppressed when the prior value is zero or
too small to support an honest ratio; state the absolute change instead.

`0` is measured data and `—` is unknown (§7 Metrics). Do not format counts as `00` or use
zero for unavailable data. Zero earns a headline only when the absence is itself an
operator outcome (“0 failed deployments”); multiple all-clear zeroes collapse into one
status sentence or stay off the dashboard until nonzero. Inventory totals such as
“52 published” are secondary unless their level or movement drives a decision.

**Choose the smallest evidence visual that answers the question:**

| Visual | Use it for | Card limits |
|---|---|---|
| **Sparkline** | Direction beside one headline metric | 8–30 ordered points; no axes or legend; cedar hairline + last dot; the value and delta remain visible text |
| **Line / step** | A stock, rate, or duration changing through time | One series preferred, two maximum; ≤60 rendered points per series; step for state/count snapshots, line for measured rates; direct labels |
| **Vertical bars** | Flow by discrete time bucket | 7–31 buckets; one series preferred, two maximum; muted prior-period bars may sit behind current bars |
| **Stacked bar** | Composition of one total | 2–4 stable categories; total and category values available in text; 100% stack only when share, not volume, is the question |
| **Progress bar** | Progress toward a real bounded target | Known numerator and denominator; never a proxy for health, confidence, or an unknown-duration job |
| **Breakdown / exception rows** | Ranking or the next items requiring action | 3 rows maximum, value right-aligned, one link to the full list |

Pie/donut, gauge/speedometer, radar, dual-axis, 3D, map, calendar heatmap, and decorative
area charts do not appear in dashboard cards. They consume space without improving the
glance decision, or demand interaction the card cannot support. Use the extension's
detail page when one of those specialized views is genuinely warranted. General chart
styling remains §4.9: cedar series one, fixed palette, hairline horizontal grid, direct
labels, e2 tooltip, flat fills, no gradients.

**Time, comparison, and controls.** Every metric and chart displays its time basis even
when no control is present. Business/outcome cards default to 30 days; fast operational
cards may default to 24 hours or 7 days when that matches the intervention cadence.
Comparisons use the immediately preceding equal-length window, the same timezone, and
the same bucket boundaries.

Card-owned controls stay deliberately narrow:

- **Time range:** optional, only when changing it supports a real decision. Use a compact
  segmented control for two–three choices (normally 7d / 30d / 90d); use one standard
  select when four or more supported presets are necessary. Custom dates and granularity
  belong on the detail page.
- **Series visibility:** optional for two–three related series, with every series named
  directly and never color-only. More series or a metric picker belongs on the detail
  page.
- **Never configurable in the card:** chart type, color, smoothing, axis bounds, bucket
  density, thresholds, alert policy, or export format. Those are design/domain decisions
  or extension settings, not dashboard preferences.
- **Host-owned when available:** reorder, show/hide, and card size. Extensions do not
  duplicate these controls inside their card. **Host availability:** dashboard
  contributions currently receive no size hint and do not participate in a public
  shared chart-component API; author responsive namespaced markup and do not import
  private core chart components.

Changing a time range or series is an immediate view change, not persisted business
configuration and not a save event. It acknowledges within 100ms, keeps the previous
plot while loading, marks the region `aria-busy`, and swaps data without replaying the
first-paint draw. Never flash the entire card back to a skeleton.

**Data and freshness.** A card reads one bounded aggregate snapshot, not one request per
metric or bucket. The response contract (names are extension-owned) carries: generated
time; window start/end, timezone, and granularity; current metric values; equal-window
comparison values; ordered series buckets; and coverage/partial-data state. The server
downsamples before returning the payload; the browser does not fetch raw events or PII
to construct a chart.

Use the host `refreshInterval` as a floor—never poll faster, and do not schedule polling
when it is `0`. Initial load uses a layout-matched skeleton. Background refresh retains
the last good values and plot,
crossfades changed values 160ms, and updates one polite freshness announcement. Mark the
snapshot **Stale** when it exceeds the domain's declared maximum age (default: two
expected refresh cycles). A refresh failure keeps the last good data, labels the failed
refresh, and offers Retry; it becomes **Stale** only when the maximum age is crossed.
Missing buckets render as gaps or explicitly incomplete coverage, never interpolated
values. “Updated” refers to source generation time, not the browser's fetch completion
time.

**Card states:**

| State | Required treatment |
|---|---|
| Initial loading | Card-shaped skeleton matching header, metric band, and optional plot; no spinner-only card |
| No observations yet | Keep the frame; plain micro empty naming why and when data will appear; no fake plot |
| Healthy / ordinary | Neutral surface; status color only in the badge, meaningful delta, or semantic series |
| Attention | Specific rule-backed badge, affected metric, and one action; never tint the whole card |
| Partial / stale | Last good data stays visible; “Partial data” / “Stale” plus coverage or timestamp |
| Refresh failed | Last good data stays visible; name the failed refresh and offer Retry; add “Stale” only after maximum age |
| First-load error | Error Status notice with redacted cause and Retry; no fabricated zeroes |
| Missing permission | Hide with `requiredPermission` when the user cannot act; otherwise a compact reason and permission doorway |
| Missing dependency / setup | Compact capability state + one setup/connect action; do not reserve chart-sized empty space |
| Expired session | “Sign in again” is the action; “Refresh” is not a remedy for expired credentials |

**Chart accessibility and interaction.** A chart is a `<figure>` with a visible
`<figcaption>` naming the measure and window. The same information exists without
vision: visible current value + delta, a concise accessible trend summary, and a
screen-reader data table or equivalent structured values. A non-interactive sparkline is
`aria-hidden="true"` because the adjacent text is its accessible twin. If a plot exposes
point tooltips, it is focusable and Left/Right/Home/End inspect the same points available
to pointer and touch; Escape clears inspection. Never put an exact value only on hover,
and never use `role="application"` unless the full keyboard interaction is implemented.
Color is never the only series distinction: use direct labels and, when series can
overlap, dash/marker differences. Reduced motion removes draw-in and crossfade while
preserving every value.

**Five-second acceptance gate.** At dashboard width, in light and dark, a reviewer must
be able to answer all five without opening the extension:

- What domain does this card own?
- Is anything wrong now?
- What is the primary value, and what period does it represent?
- Is the situation improving, worsening, or unchanged—and on what comparison basis?
- What single next action or detail destination is available?

If the reviewer cannot, simplify or remove the contribution. More data is not more
information; dashboard space is earned by decision density.

**Detail-view decision tree:**

- **Full page** — the object has a URL/identity users return to (a page, a person, a
  campaign).
- **Side panel** (420–480px, slides 220ms, e2 + left hairline) — inspect/edit *in the
  context of a list* you'll return to within seconds (email snippet, media detail,
  report history).
- **Dialog** — a decision or a short focused task (≤ ~6 fields), never browsing.
  Same task type → same pattern, everywhere.

**Route-level and permission states** — every page can fail to be a page; those states
are designed too:

- **Section render failure**: the shared boundary (host reference
  `AdminSectionErrorBoundary` → `.cedros-admin-shell__section-error`) — `role="alert"`, title + one-line
  description in the §8 error voice + an outline `sm` "Try again"; resets on navigation.
  Never a blank pane, never a stack trace.
- **Unknown route / removed section**: block empty — "This page doesn't exist or was
  moved." + [Go to dashboard].
- **Capability-locked page** (extension not installed, plan-gated): the **setup notice**
  (§7) — what this area does, what unlocks it, one CTA ("Install cedros-pay" /
  "View extensions"). Driven by the `requiredPermission` / `requiredExtensionId` /
  `disabledReason` section props; matches the §5 disabled-nav reason.
- **View-only access** (has read, lacks write): a single info `.cedros-data-status`
  under the header — "You have view-only access. Ask an owner to make changes." —
  and controls render disabled with that reason; never silently non-functional
  Host availability: verify the shared view-only banner before depending on it from an
  extension.
- **Signed-out / expired**: full-page state with the standard copy ("Sign in again.
  Your session expired for security reasons — your work is saved.").

---

## 7. Components — the one way per job

Specs below are binding. Each component earns its place through a distinct semantic job.

**Fast chooser.** A number that summarizes the page is a Metric; a persistent condition
that affects the page is a Status notice; a completed event that does not change the
current layout is a Toast. A collection with no records gets a Block empty; the same
collection with active filters gets a Filtered empty; a small optional region with no
content gets a Micro empty. Returning to a known parent uses the Back breadcrumb. A
visual collection is a Tile grid; picking one of a few illustrated options is Choice
tiles; user-controlled order is Reorder; a stream of events is Inbox rows; "is my work
saved" is the Autosave chip. This decision happens before styling—visual similarity is
not permission to swap jobs.

**Buttons** — `.cedros-data-btn`, five variants, two sizes.

| Variant | Recipe | shadcn |
|---|---|---|
| `primary` | solid `--cd-primary` / `--cd-primary-fg` | `default` |
| `outline` | 1px `--cd-border`, transparent bg; hover `--cd-accent` fill | `outline` |
| `ghost` | no border, transparent; hover `--cd-accent` | `ghost` |
| `destructive` | **solid `--cd-danger-bg` / `--cd-danger-fg`** — the confirming action for destructive work; `--cd-error` remains the status/tint color | `destructive` |
| `link` | link color, no box | `link` |

Sizes: every ordinary boxed action button is 32px high; icon buttons are 32×32. The `sm` modifier keeps
compact padding and type but does not change height. Radius `--cd-radius − 1px`.
Hover −1px lift + hairline shadow (160ms); press scale 0.98 (100ms); working state =
progressive verb + inline spinner, width stable; focus = ring recipe. One primary per
action cluster: at most one in the page header, dialog footer, card footer, or toolbar.
Independent settings cards may each own Save; they do not create a second page-level
primary. Labels use a sentence-case verb (+object), ≤3 words. Destructive row actions
live in the `⋯` menu as red items; a visible destructive button appears only at the final
confirmation step.

**Inputs** — `.cedros-data-input`: height 36px (single-line), padding 0 0.75rem, radius
`--cd-radius − 1px`, 1px `--cd-border`, **bg `--cd-input-bg`** (transparent light /
muted-30% dark — the shadcn v4 fill), `sm` text. Focus:
border-ring + 3px ring at 14%, instant. Error: border mixes 55% error; help line swaps to
error text, same slot, no layout jump. Affixes render inside the border, muted mono.
Textareas: min-height 5.5rem prose / taller mono for code (`--code` variant keeps
tab-size 2).

**Search inputs** — `type="search"` with a leading 16px magnifier; the placeholder does
the labeling in toolbars ("Filter pages…"). Local collections filter live as you type —
no artificial debounce, and no replay of row motion (§9). A trailing ✕ clear button
appears only while the field has text (host reference: the Extensions toolbar; specified
addition to the shared `SearchInput`); clearing restores the collection and keeps focus
in the field. An empty result is the Filtered empty (§7), never a blank pane.

**Validation** — errors surface at the field, in the help slot, on submit (or on blur
for format checks) — never keystroke-by-keystroke on first entry. The submit button
stays enabled and validates on activation — a disabled button explains nothing. A
failed submit moves focus to the first invalid control and scrolls it into view;
`aria-invalid` + `aria-describedby` bind the message. Server failures map to their
field when they name one, otherwise to one error Status notice above the form. Field
errors are never toasted (§7 Toasts).

**Specialized fields** — the field vocabulary beyond text. All share the input anatomy
above (36px, `--cd-input-bg`, label + help slots); none invents a new frame.

- **Date & time** — dates are picked, times are typed. The OS calendar popup is the one
  piece of foreign chrome a form would otherwise show, so native `type="date"` and
  `type="datetime-local"` popovers are retired in the admin. `DateInput`
  (`YYYY-MM-DD`) and `DateTimeInput` (`YYYY-MM-DDTHH:mm`, the `datetime-local` wire
  format) render a trigger wearing the standard input anatomy — 16px leading calendar
  glyph at 50% opacity, then the locale-formatted value (wall-clock faithful to the
  stored string) or a muted placeholder — that opens a **280px calendar popover**:
  `role="dialog"`, e2, radius `--cd-radius`, `z-dropdown`, anchored to its trigger and
  flipping above it on collision, the §9 menu motion (in 180ms, out 120ms),
  Escape/outside-click dismissal
  with focus return (the same popover-in-a-field contract as the Color swatch). Inside:
  month header (28px ghost prev/next chevrons around a semibold label **button** —
  pressing it swaps the grid for a 12-month year view whose chevrons and
  PageUp/PageDown step years, so a distant date is two presses away, never sixteen),
  Sunday-first six-week grid of day cells (radius `--cd-radius − 4px`, hover
  `--cd-accent` fill, today = hairline inset ring, selected = solid
  `--cd-primary`/`--cd-primary-fg`, outside days muted; out-of-range days are
  **`aria-disabled`, still focusable** — arrow traversal never dead-ends at a bound,
  the state is announced, activation is inert), full arrow / PageUp / PageDown /
  Home / End keyboard, and a footer of ghost **Clear** + **Today** (**Now** with
  time; disabled when today sits outside `min`/`max`).
  `DateTimeInput` adds a typed time row above the footer and stays open after a day
  pick so the time can be adjusted; picking a day in `DateInput` commits and closes.
  Scheduling moments (publish, send, boost) use `DateTimeInput`. Time of day alone is
  typed, never picked: native `type="time"` styled as `.cedros-data-input` with the OS
  popup chrome suppressed — the segments and arrow keys do the work. Recurring
  availability uses paired `time` inputs in a range row — day checkbox + start "to"
  end + a ghost "+ Add range" (the Settings→Site Hours pattern,
  `cedros-scheduling-weekly__window`). Displayed dates follow §8 (locale formatters,
  relative under 7 days). **Host availability:** the picker is a host primitive;
  extensions keep the styled-native date inputs until the host exports its anatomy.
- **Number** — native `type="number"` with `min`/`max`/`step` declared whenever the
  domain has bounds; the OS spinner is the stepper — no custom steppers. Units read as
  muted `sm` text after the field ("minutes", "retries"); currency prefixes render
  inside the border as affixes. Values right-align in table columns only — form fields
  stay left-aligned.
- **Color** — a swatch button + a mono hex input validated as 3- or 6-digit hex
  ("Enter a 3- or 6-digit hex like #0f172a."). The swatch opens a popover
  (`role="dialog"`) holding the native color input and a preset swatch row — the theme
  builder's `ColorField` is the reference. Never a bespoke color wheel; never a
  color-only control without a text twin.
- **Tags** — a chip strip plus one add control. Chips are `.cedros-data-chip--tag` in
  the 18-tone set (slate → rose; unknown tones fall back to slate), each with a ✕
  remove (`__remove`, "Remove tag {label}"); extension-managed tags carry the `ext`
  badge and are not hand-removable. Adding goes through the standard select/combobox
  ("Add tag…"), not freetext typed into the strip.
- **Media & file** — short form fields use the thumbnail-picker row: the current
  thumbnail (or the dashed "No image" well) + an outline "Choose image" (the
  Settings→Site pattern). Choosing opens a 680px picker dialog (§Dialogs) that embeds
  the media tile grid (§Tile grids) — pickers reuse the library's tiles, never a novel
  browser. Bulk ingestion is the upload dropzone (§Progress).

**Select** — `.cedros-data-select`, one trigger: single-line, 36px,
value + trailing chevron (16px, 50% opacity). Menus are the shared `DropdownMenu` (e2,
radius, 4px padding, item radius `--cd-radius − 4px`, check on selected, 180/120ms).
The trigger shows only the value; descriptions belong in help text below the field or on
menu items. **Host availability:** `.cedros-data-select` currently exposes a styled
native `<select>`, so its open menu follows OS chrome. Extensions use that documented
contract until the host exports the custom button-trigger/listbox anatomy; they do not
vend a second global primitive.

**Menus (`DropdownMenu`)** — one menu system behind every trigger: selects, the `⋯` row
menu, header overflow, the profile menu. Content: e2, radius `--cd-radius`, 4px padding,
min-width 11rem, **max-width 20rem, max-height 20rem** with internal scroll,
`z-dropdown`; opens bottom-start anchored to its trigger and flips/aligns on collision
(`--top`/`--end` variants); enter 180ms from `scale(0.97) translateY(-4px)`,
exit 120ms. Items: 2rem tall, 0.5rem padding-x, radius `--cd-radius − 4px`, `sm` text,
**single line** (truncate ~28ch — descriptions belong in help text, not menus), optional
16px leading icon, optional trailing slot for a `kbd` hint or state; hover/focus =
`--cd-accent` fill. Item types: action · link · **checkbox item** (leading 1rem check
slot) · **radio group** (under a `2xs` uppercase group label) · destructive (error text,
last, below a separator) · disabled (0.5 opacity, still focusable so its tooltip can
explain). Separators are hairlines bleeding to the 4px padding. Keyboard: ↓ ↑ Home End,
typeahead, Enter selects, Esc closes and returns focus to the trigger. **No nested
submenus in the admin** — one level; if a menu wants children, the IA wants a dialog or
a page. Menus opened from inside a scroll container (`.cedros-data-table-wrap`, panels)
**portal or position fixed** so the container never clips them (contract rule).

**Combobox (searchable select)** — required at ≥10 options. Trigger is
the standard select trigger; the open panel is a menu with a **pinned search input**
(2rem, borderless, hairline bottom divider, leading magnifier) above the filtered list.
Empty result is one muted row: "No matches — try a different term." Multi-select uses
checkbox items; the closed trigger summarizes ("3 selected" — chips only when ≤2), and
selected items float to the top on reopen.

**Toggles & selection controls** — five controls, chosen by decision table, not taste:

| Control | Use when | Semantics |
|---|---|---|
| **Switch** | The change applies immediately | `role="switch"`; never sits behind a Save button |
| **Checkbox** | Saved with a form, or multi-select in lists | batched; table header checkbox = select-all with an indeterminate state |
| **Radio group** | 2–5 mutually exclusive choices in a form | vertical stack, `sm` labels, help under the group |
| **Segmented** | 2–5 mutually exclusive *views/modes*, instant | the §Tabs control with radiogroup semantics |
| **Select / combobox** | more than 5 options | §Menus |

Checkbox: 16px, 4px radius, `--cd-primary` fill + white check; indeterminate = an 8px
primary bar. Radio: 16px circle, 8px `--cd-primary` dot, same focus ring. Switch:
2.35 × 1.3rem track, 160ms thumb, checked = `--cd-primary` — never cedar, never
success-green. **The labeled switch row** is the one composition:
`.cedros-form-switch`): label (`sm`/500) + one-line hint (`xs` muted) on the left,
switch right-aligned, 0.55rem block padding, hairline divider between rows. A disabled
toggle is 0.5 opacity with its reason nearby; a *working* switch shows 0.55 opacity +
wait cursor and must settle within ~1s or the action becomes an explicit button. **Icon toggles** (`aria-pressed`) cover compact tool states (editor marks, view
density): icon-sm anatomy; pressed = accent fill + fg + hairline inset — a standalone
segmented trigger. The Hours day-rows on Settings→Site are the checkbox + `sm` label +
muted state text composition.

**Choice tiles (option cards)** — radio semantics wearing a card, for picking a theme,
template, or mode where a picture or description carries the decision. Anatomy (host
reference `cedros-data-theme-option`): a card with preview or icon, `base`/600 title,
one `sm` muted line; the group has radio semantics (`role="radio"` + `aria-checked`,
arrow keys move). Selected = the **ring treatment** — `border-color: var(--cd-ring)` +
`box-shadow: 0 0 0 2px` ring at 24% — and nothing else: no checkmark overlay, no fill
change, no scale. When applying is a separate step, the applied option wears a
"Current" badge distinct from selection (the theme picker pattern). 2–6 options, equal
heights per row, whole surface clickable; more options than that is a tile grid inside
a picker dialog.

**Tabs / segmented** — **one** style, the shared `.cedros-data-tabs` primitive
(`__list` / `__tab` / `__panel` / `__tab-badge`; `role="tablist"`, roving tabindex,
Arrow/Home/End — the documented extension contract): track = inline-flex, hug content,
padding 3px, radius `--cd-radius`, bg `color-mix(in srgb, var(--cd-bg) 96%, var(--cd-accent) 4%)`
+ 1px border; trigger = 32px, `sm`/**500**, radius `--cd-radius − 3px`, muted → fg;
active = `--cd-bg` fill + hairline inset border + `--cd-shadow`; indicator may animate
220ms. Settings-area tabs (Site / Access / Domains / …) use exactly this, not a
full-width boxed bar. The same anatomy and 500 weight applies in settings, analytics,
media, editors, and onboarding.

**Table** — `.cedros-data-table`, the one table system.
Wrapper: 1px border, radius `--cd-radius − 1px`, clip. Header: `2xs` uppercase +0.04em
muted on the header wash (`color-mix(bg 90%, accent 10%)` ≈ shadcn `muted/50`),
height ~40px. Cells: `sm`, padding 0.55rem 0.75rem, hairline row dividers, hover
`color-mix(accent 52%, transparent)` 140ms, updated-row 800ms flash. Numerics
right-aligned tabular; ids/slugs mono. Status: pill badge in a Status column, **or** the
compact publish dot before the title in content libraries — one per table, never both.
Sort: header buttons with 2px outline focus + `aria-sort`. Sticky header past
one viewport. Two further table patterns: **summary cells**
(`.cedros-data-table-summary` + `__preview`) stack
a primary line over muted context when a cell needs both; **clickable rows**
(`--clickable`) still require a real first-cell button (`__row-activate`) so keyboards
get an activation target — a `tr` is never the only way in. Multi-row selection: §6A.

**Table states are structural, not afterthoughts.** First load keeps the column header and
renders 3–5 layout-matched skeleton rows. Refresh keeps the last good rows, marks the
wrapper `aria-busy="true"`, and never flashes back to a skeleton. A first-load failure puts
one error Status notice with Retry in the body slot; a refresh failure keeps the rows and
puts the notice above the frame. A genuinely empty collection renders the Block empty
inside the table frame, spanning every column; the frame supplies the border, so the empty
state uses the target `--in-table` modifier and does not draw a second dashed rectangle.
An empty result caused by filters keeps the header and uses the Filtered empty row described
below. Pagination is hidden only when the total is zero; filter controls remain available.
On narrow screens the wrapper scrolls horizontally, the first identifying column may be
sticky, and cells do not collapse into invented cards.

**Row actions** — one pattern: a **`⋯` overflow menu** (icon-sm ghost) at row end;
destructive items red, last, below a separator. A table may promote **at most one**
high-frequency action to an inline icon-sm button beside the `⋯`. Use the promoted action
plus overflow pattern consistently across all tables.

**Setup-locked row exception.** When one record cannot perform its primary job until
record-specific setup is complete, and exactly one in-product destination resolves it,
replace the unavailable control and row menu with a warning Badge labeled "Needs setup"
and one outline `sm` button labeled "Set up." The button opens that record's setup
surface. Hide the row's other actions, keep the table surface neutral, and mute only the
blocked data cells—never tint the whole row. Do not apply this exception to an active
record that can still be safely turned off. Page-wide dependencies use the single Setup
notice instead (§7 Setup notice).

**Tile grids** — the table's visual twin for collections identified by their image
(media, themes). One anatomy (host reference `cedros-media-grid`): each tile is a card
whose main surface is a single button (`__main`, accessible name = the record's name) —
thumbnail letterboxed per §7 Furniture, then a name row (`sm`/500, one line, truncated)
and muted `xs` meta (type · size · date). Selection is a `--selected` modifier wearing
the ring treatment (§Choice tiles); selection and activation never fight — in picker
contexts click selects, in library contexts click opens and selection uses the checkbox
surface. Row-action rules apply unchanged (⋯ overlay menu, ≤1 promoted). A collection
may offer gallery / grid / list views through a toolbar icon-toggle group
(`data-media-view`); the list view **is** the standard table. States follow §6A:
tile-shaped skeletons, the same three empties, the same pagination.

**Reorder** — one contract wherever the user controls order (nav menus, FAQ
categories, page sections, dashboard cards):

- **The handle**: a grip icon (icon-sm hit area, `cursor: grab`) at row start with
  `role="button"`, `aria-roledescription="Sortable item"`, and
  `aria-label="Reorder {label}"`. The handle drags — never the whole row, which keeps
  its own click meaning.
- **Keyboard parity is mandatory** (the `useSortableList` hook is the reference):
  Space/Enter picks up, ↑/↓ moves, Space/Enter drops, Esc cancels; a polite live
  region announces each stage ("Picked up {label}. Position 2 of 5." → "Moved…" →
  "Dropped…").
- **Drop feedback**: a 2px `--cd-primary` insertion line before/after the target (the
  page builder's drop-guide classes are the reference); the dragged row lifts to e2.
  No ghost trails, no tilt, no springy physics.
- **Short lists may use ↑/↓ move buttons instead** (icon-sm ghost pair, ends disabled
  — the dashboard customizer pattern); a decorative grip may sit beside them
  `aria-hidden`. Either way, order persists automatically and says so ("Changes save
  automatically.").

**Inbox & activity rows** — the quiet list for streams (form inbox, completed AI work,
notifications): host reference `cedros-inbox`. Row = optional unread dot (0.5rem,
`--cd-primary`) · primary line (`sm`, weight 500 while unread) · muted secondary line ·
optional one-line snippet · trailing relative time (`xs` muted, absolute on hover).
Hairline separators, accent hover, the whole row activates. Unread is the dot plus
weight — never a background tint. Feeds are the one surface where infinite scroll is
allowed (§Pagination); everything else stays a table.

**Cards** — `.cedros-data-card` and nothing else. Header (title `base`/600 + optional
`sm` muted description, border-b) + body (padding 0.9rem 1rem, gap 0.75rem); variants:
`--subtle` (4% wash, no shadow), `--interactive` (hover lift to e2), `--flush`, danger
(error-mix border) for danger zones. All feature surfaces compose these variants and the
spacing scale rather than creating a parallel container language.

**Badges, chips, dots** — three named jobs:
- **Badge** (`.cedros-data-pill`): read-only status. Pill, `2xs`/600, tinted per status
  (recipes in Workbench Appendix C), optional leading dot.
- **Chip** (`.cedros-data-chip`): interactive/removable (filters, and tags in the
  18-tone `--tag` set — §7 Specialized fields). Pill, `xs`, border, hover states.
- **Publish dot**: 0.5rem dot, `--cd-success`, only before titles in content lists.
Feature-specific statuses use named Badge variants rather than new pill anatomy.

**Dialogs** — `.cedros-data-dialog` is the only modal. Overlay `rgb(0 0 0 / 0.45)`,
**no backdrop blur**; panel radius `--admin-radius`, e3, `z-modal`.

*Anatomy.* Header: title `lg`/600 + optional one-line description (`sm` muted) + a ✕
close (icon-sm ghost, top-right) — the ✕ is always present and disabled while an
operation runs. Body: `sm`/`base` at 1.25rem padding. Footer: right-aligned, ghost
"Cancel" then the verb button; destructive confirms focus Cancel. Long content: the
panel becomes `grid-rows: auto 1fr auto` with a scrolling body and sticky header/footer
(host reference: the markdown-upload dialog), max-height `min(85dvh, 44rem)`.

*Widths — three, nothing else.* **420px** confirms and short forms (default) ·
**560px** standard forms and uploads · **680px** pickers and review surfaces.

*Behavior.* Enter 240ms (fade + scale 0.98 + y 8), exit 160ms ease-in; focus is
trapped, lands on the first interactive element (destructive confirms: Cancel), and
returns to the invoker on close; Esc cancels (blocked while running); backdrop-click closes only
when the dialog holds no user input; **a dialog with a dirty form confirms discard**
before closing. Enter submits single-input dialogs. Never stack dialogs — multi-step
work uses in-dialog steps (§Progress) or promotes to a page. Destructive confirms follow
Heartwood §5.12: impact list, explicit reversibility, and type-to-confirm ("Type ‹name›
to confirm", destructive button disabled until exact match) only for the catastrophic
tier. The three widths cover confirms, forms/uploads, and pickers/review surfaces.

**Side panels** — the list-context detail surface (§6 decision tree). Fixed right,
full-height, **420px default / 480px wide**, hairline left border + e2, `z-panel`;
slides in 220ms standard-ease over a light backdrop (`rgb(0 0 0 / 0.30)`) that
click-closes under the same dirty-form guard; Esc closes; the list's scroll position is
preserved. Header: close + record title + status badge; body scrolls; sticky footer for
actions. Panels never open panels — deeper work promotes to a page.

**Toasts** — the host-owned toaster is the only transient-feedback surface. Use it for a
completed cross-page outcome (saved, copied, queued, deleted with Undo) or a failure that
cannot stay beside its trigger. Do **not** toast field validation, an in-progress job, a
permission/capability condition, or information already shown inline. One event gets one
announcement: never an inline success plus a toast for the same save.

Anatomy: 16px tone icon · content (concise title outcome plus optional one-line
description) · trailing cluster (optional single action + close). Bottom-right, 356px,
`grid 1rem minmax(0, 1fr) auto`; the surface is the standard opaque card background,
hairline border, and quiet shadow—no liquid glass or backdrop blur. Entries rise from the
bottom and settle over 400ms (y 100% + scale 0.98); exit takes 200ms ease-out. Every tone
dismisses after 4s by default; one action extends the default to 8s; `duration: 0` is an
explicit persistent exception that must be replaced or dismissed. Hover/focus pauses the
remaining time. Reusing an id updates the existing toast instead of stacking retries. The
queue retains six; the newest three form the collapsed card stack, and hover, keyboard
focus, or touch intent expands all retained entries. The optional action is a verb ("Undo",
"View log"), never a second close. Batch work gets one summary toast, not one per item. The
title carries the outcome; descriptions add only consequence or next step.

Accessibility: the toaster is a named region; ordinary additions are polite, while each
error is assertive once. Focus never moves into a toast automatically; its action and close
are keyboard reachable in DOM stack order. Reduced motion removes toast and stack
transitions. Extensions import `toast` from `cedros:admin`; they use that
delivery seam and never render a local toaster, portal, queue, timer, or toast CSS. The full
author contract and decision table live in
`docs/extension-authoring/reference/admin-notifications.md`.

**Inline alerts / banners** — **`.cedros-data-status`** is the one notice component
(it's the documented extension contract): status-tinted panel, 16px icon, `sm` text,
tones `--neutral / --info / --success / --warning / --error`, actions in
`__actions`; `role="alert"` for errors, `role="status"` otherwise. Page banners sit
under the header and are rare. Warning text uses `--cd-warning-fg`, never a literal.

**Autosave, dirty state, and leaving** — one status language for "is my work safe":

- **The autosave chip** (`cedros-autosave-status`, `role="status"`,
  `aria-live="polite"`) renders exactly one of six states: "Unsaved changes"
  (dirty/queued) · "Saving…" (saving/retrying) · "Saved just now" · "Offline — changes
  will sync" · "Conflict — review changes" · "Save failed — retry". Text crossfades
  160ms (§9); no spinners, no bars. It sits in the settings-card footer (§6B) or the
  editor header (§6E) — one chip per save scope.
- **Failure escalates inline, not transiently**: a failed or offline autosave adds the
  retry banner (a status notice with "Retry" / "Discard") beside the work — never only
  a toast. A conflict opens the conflict dialog: "Conflict — review changes" · "This
  resource changed somewhere else. Review before saving again." · Review / Discard.
- **Leaving with unsaved changes** runs the same guard everywhere a dirty surface can
  be abandoned — dialog ✕/Esc, side panel, Back breadcrumb, nav, tab close: the
  unsaved-changes dialog, title "Save changes before leaving?", body "You have unsaved
  changes.", actions ghost "Keep editing" · outline "Exit without saving" · primary
  "Save and exit" (two actions when saving isn't possible). Browser `beforeunload`
  guards tab close while dirty. Autosaving surfaces never ask — they save.
- **One mechanism per page** (§6B): explicit Save *or* autosave, never both answering
  for the same fields.

**Empty states** — three contexts, two visual weights:

- **Block empty / first run**: the standard doorway for a genuinely empty collection.
  Inside a card or table slot it pairs the ambient glyph with a `base`/600 title,
  one `sm` muted sentence ≤38ch, and at most one primary action. The glyph is
  two-tone stroke art (reference: cedros-deploy's "No sites deployed yet"): a
  64-viewBox line drawing rendered at 4.5rem, base strokes in `--cd-muted` with
  exactly one accent detail — the folded corner, the arriving arrow, the signature —
  in `--cd-chart-5` (art tokens, §4.9); never a bespoke illustration, logo, or filled
  icon. The glyph enters once with the standard 220ms rise/scale, then drifts on the
  ambient float (§9): translateY 0 → −5px → 0 over 5s ease-in-out, transform only —
  the one decorative loop the admin allows. With reduced motion it is simply present.
  Hosts pick from the shared `EmptyStateArt` glyph set (one glyph per collection
  domain) so the same collection empties identically everywhere. Every Block empty
  uses the dashed doorway, including table/card slots. The target `--in-table` /
  `--in-card` modifiers adjust spacing and background without removing that frame.
- **Filtered empty**: the collection exists, but the current query has no matches. Keep
  the toolbar, filters, column header, and frame; render one centered `sm` line spanning
  all columns ("No pages match your filters.") plus a ghost-sm "Clear filters". No icon,
  illustration, or create action. Search-only empties say "No matches — try a different
  term" when clearing is not useful.
- **Micro empty**: one muted `sm` line inside a small optional region ("No links yet.")
  when the block would outweigh the content. It never carries an illustration; it may
  carry one adjacent link action.

Class contract: `.cedros-data-empty-state` + `__copy` and optional `__action` for Block
empty; `__art` (accent paths carry `__art-accent`), `--in-table`, and `--in-card` are
specified host additions.
`.cedros-data-empty` covers Filtered and Micro.
Apply `role="status"` to the state container when it replaces loaded content, not on first
server render. Decorative art is `aria-hidden="true"`; the title and sentence form the
accessible content. Empty is never used for loading, error, permission denial, or a
temporarily unavailable dependency.

**Setup notice** — the one primary setup callout (`.cedros-data-setup-notice` +
`__body`): a card-shaped section for first-run, connect, and
capability-locked moments — outcome headline (`base`/600), one–two sentences of what
this unlocks, CTA in `.cedros-data-actions`. **One per page, maximum**; if two things
need setup, the page starts with the one that unblocks the other. Warmer voice is
allowed here (§8) — this is a doorway, not an error.

**Loading** — route skeletons (`admin-route-skeletons.css`) are the only page-level
loading UI; they mirror real layout (skeleton-coverage gate) and shimmer 1.4s. In-card
actions use the 1s inline spinner or a working button. "Loading…" text only past 1s,
naming the work. Route skeletons share one system: `cedros-admin-route-skeleton`.

**Progress, steps, and uploads** — three shapes, all honest:

- **Determinate bar**: 0.5rem pill track (`--cd-muted-bg`) with a `--cd-primary` fill;
  label right in tabular sans ("62% · 148 of 240"). **No indeterminate bars, ever** —
  unknown duration uses a spinner or skeleton; a bar parked at 90% is a lie (Heartwood
  §5.13).
- **Step list** (multi-stage work — imports, deploys, agent runs; Heartwood §5.13): each
  row = state icon + verb phrase (`sm`) + optional muted detail. States: pending (hollow
  muted circle) · running (spinner) · done (success check) · failed (error ✕ with the
  §6.7 error formula expanded in place). Terminal state is explicit ("Done — 236
  products imported"), and long runs say leaving is safe.
- **Upload dropzone**: block-empty anatomy (dashed border, 4% wash) with "or browse";
  drag-over = solid `--cd-ring` border + accent wash + "Drop to upload". Queued files
  render as rows: 16px type icon · filename (mono) · size (sans) · trailing progress bar
  → success check / error retry · ✕ remove. Concurrent uploads report with **one**
  summary toast at the end, not one per file.

**Code blocks & logs** — technical surfaces read mono, but structured:

- **Read-only code block** (the MCP setup panel is the reference anatomy): a
  `--cd-muted-bg`-washed frame, hairline border, radius `--cd-radius`, `pre/code` mono
  at 0.72–0.75rem / 1.65 line-height, scrolling inside its own frame. Named snippets
  add a toolbar row: filename in mono, language tag `2xs` uppercase muted, and one sm
  copy button ("Copy" → "Copied", failure "Copy failed"). One copy control per block,
  never per line.
- **Editable JSON/code** is the `--code` textarea (`.cedros-data-textarea--code`,
  tab-size 2) with a "Format JSON" ghost action and inline validity in the help slot
  ("Valid JSON" / "Invalid JSON: …").
- **Logs are tables, not walls**: compact rows — status dot · time · area · message
  (host reference `cedros-history-log-table`) — relative time with absolute on hover,
  mono only for payload fragments. A `<pre>` dump is never a log viewer.

**Command palette (⌘K)** — the global fast path (host reference
`cedros-command-palette`): ⌘K / Ctrl+K opens it from anywhere — there is no topbar
search; the shortcut is the entry. e3 panel at ~20vh top-center over the standard
overlay, entering with the dialog recipe (§9). Anatomy: a search input
(`role="combobox"`, placeholder "Search sections, actions, and pages…", trailing Esc
`kbd`) above grouped results (`role="listbox"`, `2xs` uppercase group labels —
"Sections", "Actions", "Pages"); each result = 16px icon · name · muted context ·
trailing `kbd`; footer = ↑↓ Navigate · ↵ Select + a polite result count. Keyboard: ↑↓
move (`aria-selected` follows), Enter runs, Esc closes and returns focus to where you
were. Empty state: "No matches" + "Try a different search term.", zero decoration.
Every nav destination and primary page action is reachable here; extension sections
appear automatically from their manifest. Style per Heartwood §4, tokens per this doc.

**Tooltips & popovers** — tooltip: **inverted surface** (`--cd-primary` bg,
`--cd-primary-fg` text — shadcn), `xs` text, 0.35rem 0.55rem padding, radius `--r-sm`,
e2, max-width 16rem, no arrow; appears after ~300ms of hover or immediately on keyboard
focus; hides on press; may carry a trailing `kbd` hint. **Required on every icon-only
control** (paired with `aria-label`). Never put information *only* in a tooltip; never
secrets. Popover: the rich variant — light surface, hairline border, e2, ≤20rem, for
"?" help affordances a tooltip can't hold; dismisses on outside click/Esc. Prefer
visible help text over both.

**Pagination** — use the shared admin primitives; never hand-roll table pager markup.
Known-total tables use `Pagination`: `.cedros-data-pagination`, one row under tables:
left, "Showing 1–25 of 214" (`sm` muted, tabular); right, sm outline prev/next icon
buttons + up to 7 numbered sm ghost buttons with ellipsis (current page = accent fill
+ hairline). The optional page-size control (25 / 50 / 100) uses the standard custom
field dropdown. Cursor-backed collections whose total is unknown use
`CursorPagination`: left, "Page 2"; right, the same previous/next icon controls.
Omit the entire row only when neither direction is available; otherwise **disable
unavailable boundary controls, don't hide them**. Infinite scroll is allowed only in
feeds (activity, chat); data tables paginate.

**Breadcrumbs and back navigation** — the admin uses one subordinate Back breadcrumb,
not a website-style trail. It appears only on detail, add, edit, or review views whose
parent collection is useful context; top-level section pages and tab changes do not get
one. Anatomy: `← Back to {parent}` in `sm` muted text, above and left-aligned with the page
title, with 0.5rem separation. Use the parent's stable plural noun ("Back to People",
"Back to Themes"), never "Go back", a raw route, or the current record name.

Use a real link when the parent has a URL so open-in-new-tab and copied links work; use a
button only for an ephemeral in-page drill-in with no route. The destination is the
canonical parent, not blindly `history.back()`—direct entry and refreshed detail pages
must still work. Preserve the parent's query, filters, pagination, selection, and scroll
when the user arrived from that parent. A dirty editor runs the same discard guard as any
other exit. Never show both a Back breadcrumb and a multi-item trail; if a route routinely
needs more than one parent named, simplify the IA or request a design review. On mobile it
remains above the title and may truncate the parent at one line; the arrow never stands
alone. Class: `.cedros-back-breadcrumb`; `:focus-visible` uses the standard ring.

**Metrics / stat boxes** — `.cedros-data-summary-grid` contains one
`.cedros-data-metric` per decision-relevant quantity. Default anatomy is optional
`__icon` (specified host addition) → `__label` → `__value` → optional `__hint`; a compact
sparkline may share the hint row. Labels are `2xs` uppercase and name the measure, not
its status ("Install failures", not "Bad"). Values are `xl`/700, sans tabular, locale
formatted; abbreviations expose the exact value in accessible text and on hover. Hints
name the time window or comparison ("Last 7 days", "▲ 8% vs prior period"). Every tile
in a grid uses the same period and comparison basis unless the label says otherwise.

Layout: 1–4 equal-height tiles per row, `minmax(min(100%, 180px), 1fr)`, 0.75–0.9rem
gap; collapse 4→2→1 without horizontal scrolling. Three is the preferred overview set;
more than six means the page needs a table or chart. Tiles are neutral by default. Use a
semantic tone only when the value itself requires attention; tint the icon/delta, never
the whole card, and pair color with text or an icon. Zero is a real value, not an empty
state. Unknown is `—` plus a hint ("Not measured yet"); unavailable/error is an inline
Status notice or a muted tile with a specific hint, never `0`. First load uses
layout-matched skeleton tiles; refresh retains values and crossfades 160ms. A 500ms
count-up runs once on first reveal, announces only the final value, and is disabled for
money, negative values, exact compliance counts, and reduced motion.

Metrics are read-only unless the whole tile has a clear destination. Interactive metrics
render as one link/button with `--interactive`, a visible hover/focus state, and an
accessible name that includes destination ("View 12 pending reviews"); never nest a
second action. The dashboard's draggable square tiles may keep their drag handle but use
the same anatomy and state rules. Dashboard contribution cards also follow the tighter
information hierarchy, metric-kind, comparison, zero-suppression, and chart rules in
§6.1. (Host reference composition: the theme manager's three-tile summary.)

**Furniture** — the small parts, one way each:

- **Avatar**: circle; image or 2-letter initials (`2xs`/600) on `--cd-primary`. Sizes
  20px (table cells) / 24px (lists) / 28px (the shell's 1.75rem). Stacks overlap
  −6px with a 2px `--cd-bg` ring; overflow renders a "+4" chip. People without a
  picture get the deterministic profile gradient (`profileAvatarGradient`, seeded by
  name).
- **Assistant persona orb** (`AssistantPersonaOrb`, `.cedros-assistant-persona`): the
  assistant's identity and live-status mark — the same deterministic gradient as
  profile fallbacks (seeded by the persona name) under a slow-drifting sheen and a
  canvas dot layer. This is the admin's one sanctioned gradient (W7 note): identity
  avatars, never surfaces. One motion vocabulary, product-wide, one meaning each:
  slow globe = at rest / queued · wave = listening / waiting on the user (approvals,
  review) · rubik scramble = thinking · ribbon = responding / streaming · orbits =
  executing (tools, tasks, routine runs). Terminal states (completed, failed,
  cancelled, stopped) never animate — motion always means something is live. Sizes
  16–22px as an inline status icon (task cards, run rows), 20px in chat pending rows,
  40–52px as identity (launcher, heroes, empty states). Always `aria-hidden` beside a
  text label that carries the accessible state. Idle orbs render at half frame rate;
  all orbs pause offscreen and honor reduced motion with a static frame.
- **Disclosure ("Advanced")**: `details/summary` — summary `sm`/600 muted → fg, chevron
  rotates 90° in 160ms; 0.75rem top padding on content; closed by default; state
  persists per user per surface. Never hide *status* inside one — only configuration.
- **Links**: `--cd-link` (cedar), underline on hover/focus only; external links carry a
  12px ↗. Links inside table cells stay `fg` with underline-on-hover so columns read
  calm.
- **`kbd`**: `2xs` mono on `--cd-muted-bg`, hairline border with a 2px bottom edge, 4px
  radius — in tooltips, menu hints, and the palette.
- **Thumbnails** (media lists, pickers, link previews): radius `--r-sm`, 1px border,
  `--cd-muted-bg` letterbox; `object-fit: cover` for photos, `contain` for
  logos/screenshots; sizes 40px in table rows, 64px in cards, the dashed picker row in
  forms (§7 Specialized fields → Media). Broken/missing image = the muted image icon on
  `--cd-muted-bg` — never a raw broken-image glyph or alt-text soup.

---

## 8. Copy in the admin

This section is self-contained — extension authors follow it without reading anything
else. (The long-form voice standard, with the full terminology table and rewrite
gallery, is `design-cedros.md` §6; nothing here contradicts it.)

**The voice** — a capable colleague who respects your time: *plain* (everyday words,
active voice), *confident* (no hedging, no exclamation marks), *warm* (contractions
fine, never cute), *specific* (name the object, the count, the consequence), *calm*
(same temperature in success and failure). The user is "you"; the system is "Cedros"
or the feature name — never "I", and "we" only where humans plausibly stand behind the
words.

**Mechanics:**

- **Sentence case, everywhere, including buttons.** "New page", "Choose image", "Add
  step". Title Case fails copy review.
- Labels are sentence case (`Site title`, not `SITE TITLE`); optional fields say
  "(optional)" — required is the default and never gets an asterisk.
- Toolbars don't label; placeholders do ("Filter pages…", "All states").
- Buttons are verb (+ object), ≤3 words; they repeat the verb+noun of their dialog
  title; Cancel is always "Cancel". Working state = progressive verb ("Publishing…").
- Ellipsis `…` (the character) only on working verbs; counts in progress copy when
  known ("Importing 240 products…").
- Numerals always ("3 pages"); dates relative under 7 days, absolute after, absolute on
  hover — through locale formatters only.
- Jargon is allowed only on the technical surfaces (API keys, webhooks, deploy, logs) —
  a Settings page a shop owner visits is not one.

**Terminology (binding):** Delete = permanent · Archive = recoverable · Remove = taken
out of a place but exists elsewhere · Uninstall = extensions · Extension (never
"plugin") · Site (never "website") · Sign in/out (never "login") · Publish/Unpublish
for content ("deploy" is infrastructure only) · Enable/Disable acceptable on buttons,
"turn on/off" in prose · People/Customers follow the CRM's nouns.

**Page-text formulas** (the words on every page, standardized):

| Slot | Formula | Example |
|---|---|---|
| Document title | `Cedros \| {page name}` — set by the shared metadata hook, never by hand | "Cedros \| Pages" |
| Page title | Plural noun, 1–2 words | "Pages" |
| Page subtitle | One sentence: *verb + object + the capability that matters*, ≤60ch | "Manage site pages with revisions, preview, and publish state." |
| Card title | Noun phrase, 1–3 words | "Business info" |
| Card description | One sentence of consequence | "The public identity used in search results, link previews, and site metadata." |
| Field help | Present-tense consequence | "Visitors can switch between the languages you publish." |
| Empty state | What this is → what it's like working → one action | "No forms yet. Create a form to start collecting responses from your site." |
| Setup notice | Outcome headline + what it unlocks + verb CTA | "Take payments on your site. Install cedros-pay to add products, subscriptions, and checkout." |
| Error | What happened → your stuff is safe → next step (+ mono ref) | "Cedros couldn't publish this page. Your draft is safe. Try again — code `pub_4t2c`." (refs are short mono slugs, `area_4hex` — greppable, readable over the phone) |
| Destructive confirm | Object named, impact listed, reversibility explicit | "Delete this form? This deletes the form and its 214 responses. This can't be undone." |
| Success | Outcome, 1–6 words, no "successfully" | "Settings saved." · "Published to cabrillo.coffee" |

**Weak → standard** (admin-specific):

| Weak | Standard |
|---|---|
| "Manage Your Pages Here!" | "Pages — Manage site pages with revisions, preview, and publish state." |
| "An error occurred while fetching data." | "Cedros couldn't load your pages. Try again — code `pg_2f1c`." |
| "Successfully Created New Page!" | "Page created — Undo" |
| "Are you sure?" | "Delete this page? It's removed from your site and navigation. This can't be undone." |
| "Feature unavailable." | "Install cedros-pay to enable Products." + [View extensions] |
| "Loading data, please wait…" | (skeleton) then, past 1s: "Importing 240 products…" |

---

## 9. Motion and interaction

Base tokens align with Heartwood §7.2; this section owns workspace recipes (`--motion-duration-micro/fast/standard/
modal/counter/highlight`, expo-out entrances, ease-in exits at ~70%, transform+opacity
only, nothing loops but loading and the Block-empty glyph's ambient float (below),
reduced-motion collapses everything to 1ms and stops loops). Admin-specific bindings:

| Surface | Recipe |
|---|---|
| Nav hover/active | color/bg 160ms; sidebar expand 220ms; **no** motion on route change — skeleton immediately |
| Dropdown / select menu | in 180ms (scale 0.97, y −4), out 120ms |
| Dialog | in 240ms, out 160ms |
| Toast | rise/stack 400ms (y 100% + 0.98), out 200ms ease-out; none under reduced motion |
| Side panel | 220ms slide + backdrop fade |
| Tabs indicator | 220ms |
| Table | first resolved load: every row fades + rises 8px over 220ms, 45ms stagger, once per table per browser document; the stagger turns are budgeted across the rows **on screen** (never the full row count, which would squeeze a long table's visible cascade to a flash) and the cascade lands inside 500ms — rows below the fold share the last turn and settle before a reader can scroll to them; hover 140ms; update flash 800ms; **no replay** on back navigation/sort/filter/refresh |
| Empty glyph | one 220ms rise/scale on first appearance, then the ambient float: translateY 0 → −5px → 0, 5s ease-in-out loop; static under reduced motion |
| Metric value | one 500ms count-up only where §7 allows it; refresh crossfade 160ms |
| Autosave chip | text crossfade 160ms |
| Mobile drawer | slide 240ms standard-ease; backdrop fade 200ms |

Extensions consume the host `--motion-*` tokens (including
`--motion-stagger-list`) and these bindings — **never a hardcoded duration or
easing** (Appendix C has the copy-paste keyframes).

Interaction rules (Heartwood §5.13 applies; the admin-critical ones): every control has
distinct rest/hover/focus/active; disabled = 0.5 opacity + explanation of what unlocks
it; optimistic UI for undoable single-resource actions with Undo toast; confirmation
ladder (do-it+Undo → dialog+impact → type-to-confirm); typing latency is sacred.

**The keyboard scheme** (admin-wide): ⌘K opens the palette anywhere. Esc closes the
topmost layer only (menu → dialog/panel/palette), then clears selection, then clears
search — one layer per press. Enter activates and submits single-input dialogs; ⌘Enter
submits multiline editors. Arrows move within composites (menus, tabs, radio groups,
listboxes, sortable lists) per WAI-ARIA. Single-key shortcuts are allowed only where a
visible `kbd` hint teaches them (menu trailing slot, tooltip) and never fire while
focus is in a text field. Browser and OS text-editing shortcuts are never overridden.

Accessibility floor (Heartwood §9.9; workspace target sizes remain below): AA both modes, `:focus-visible` ring everywhere,
keyboard parity with WAI-ARIA patterns, targets ≥24px (≥32 in dense rows), color never
sole signal, 11-locale i18n through catalogs, +35% text growth survives.

**What gets announced** (screen readers hear state change, once): toasts are
`role="status"` — error toasts and error notices `role="alert"`; the autosave chip and
the bulk-selection count are `aria-live="polite"`; step-list transitions announce the
verb phrase; count-up stats expose the final value only (no per-frame chatter). One
announcement per event — never both a toast and an inline notice speaking the same
change.

---

## 10. What to build with (for engineers and agents)

- Tokens come from `shell.css`; strings from `ui/src/i18n/catalogs/en.ts` via `t()/tx()`;
  never hardcode colors, sizes, radii, shadows, durations, z-indexes, or strings.
- One primitive per job (§7). Extending a primitive = one PR to the primitive + this doc,
  not a local fork.
- Extension admin pages: root carries `cedros-data`, bridge tokens, self-inject styles,
  never re-declare `--cd-*`/`--admin-*` (var-cycle gate exists).
- Every new/touched surface ships: light+dark screenshots, all four interaction states,
  empty/error/loading, keyboard map, reduced-motion behavior, and passes the checklists
  (Heartwood §§9.5–9.6 apply; §8 above adds the sentence-case gate).

---

## 11. The extension author contract

Extensions ship admin pages and dashboard cards that must be **visually
indistinguishable in kind** from core sections (W7). This section is the whole
integration contract; the mechanics of registration live in
`docs/extension-authoring/12-admin-pages-and-dashboard-cards.md` and the class/ARIA
catalog in `docs/extension-authoring/reference/admin-ui-patterns.md` — both defer to
this document for every visual, motion, and voice decision.

The visual board doubles as the **snippet library**: every specimen in
`design-admin.html` is dependency-free HTML/CSS built on this contract — view source
and copy.

**The ground rules.**

1. You do not get Cedros' private React components (`ui/src/admin/components.tsx`,
   `primitives/*`). You mirror the **class + ARIA contract** below, use exported SDK
   primitives when Cedros publishes them, and write only the small component code you
   need.
2. **Your root carries both classes**:
   `<div class="my-ext-admin cedros-data" data-extension-id="my-ext">` — `cedros-data`
   is load-bearing; without it every `--cd-*` token silently falls back and your page
   is "themed but wrong". Dashboard card roots carry it too.
3. **Consume host tokens; never re-emit them.** Every custom property you declare is
   namespaced (`--myext-*`) and bridges `var(--cd-x, fallback)` using the §3 values as
   fallbacks. Re-declaring `--cd-*` / `--admin-*` on your subtree creates a CSS
   variable cycle that invalidates the whole chain (a `styleScoping` gate exists).
4. **Self-inject your CSS** (required — older hosts don't inject archive CSS): inline
   the stylesheet into your bundle (Vite `?inline` — mind the `@import` chain: inlining
   must resolve nested imports or you silently lose rules), and at module evaluation
   append one id-guarded tag: `<style id="my-ext-admin-styles">`. Newer hosts also
   inject archive CSS — the duplicate is harmless when the id guard holds.
5. **Scope everything** under your root (BEM: `myext-*__*--*`). No global rule may
   target a host class without your root as ancestor; never redefine
   `.cedros-data-btn`, `.cedros-data-table`, or any host class.
6. **Dark mode is host-driven.** Style with tokens; never `@media
   (prefers-color-scheme)`; never your own dark class. The host's `.cedros-dark` /
   `.cedros-admin--dark` resolve your tokens for you.
7. **Never `--cedros-runtime-*` in the admin** — those are public-block tokens.
8. Motion: host `--motion-*` tokens only (§9). Copy: §8, sentence case enforced.
   Icons: Lucide names via your manifest's `sections[].icon` (§4.8). Toasts: raise
   them through the host SDK — don't render your own toaster.
9. **Localize only through published runtime contracts.** Ship host-owned nav
   strings in manifest `i18nCatalogs[]` (locale = BCP 47; namespace must be your
   `extensionId`, `extensionId:*`, or `extensionId.*`; plural maps use
   `zero|one|two|few|many|other`) and use `labelKey`/`groupKey` for navigation.
   The current `cedros:admin` extension shim does not export the host's internal
   `useTranslation` or `LocaleProvider`. Extension-body translation therefore
   remains host-coordinated unless the target runtime publishes a translator or
   locale through `pluginContext`; do not import internal host hooks or silently
   substitute browser locale. Never hand-build plurals or dates or fix a width to
   the English string (§4.10).

**The class contract** (mirror these; the visual spec for each is §7):

| Job | Classes |
|---|---|
| Page header | `.cedros-data__header` · `__header-text` · `h2.cedros-data__title` · `p.cedros-data__subtitle` · actions in `.cedros-data-actions` |
| Back link | `.cedros-back-breadcrumb` — visible copy `← Back to {parent}`; link for routed parents, button only for ephemeral drill-ins |
| Layout | `.cedros-data-grid` · `.cedros-data-stack` |
| Card | `.cedros-data-card` (+ `__header` `__title` `__subtitle` `__body`) — never nest cards |
| Buttons | Exported: `.cedros-data-btn` + `--primary/--secondary/--ghost/--danger/--sm`; specified vocabulary: §7 |
| Fields | `.cedros-data-field` · `.cedros-data-label` · `.cedros-data-input` · `.cedros-data-select` · `.cedros-data-textarea` · `.cedros-data-field__description` · `.cedros-data-checkbox-row` |
| Toolbar | `.cedros-data-toolbar` (+ `__left` `__right`) |
| Tabs | `.cedros-data-tabs` (+ `__list` `__tab` `__panel` `__tab-badge`) |
| Menus | `.cedros-dropdown-menu` (+ `__content` `__item` `__item--danger` `__separator`) |
| Table | `.cedros-data-table-wrap` › `.cedros-data-table` · `__sort` · `__row--clickable` + `__row-activate` · `.cedros-data-row-actions` (+ `__icon`) · `.cedros-data-table-summary` |
| Status notice | `.cedros-data-status` + tone modifiers + `__actions` |
| Badges / chips | `.cedros-data-pill` (+ tones) · `.cedros-data-chip` (+ `--active` `--static`; tag chips add `--tag` + 18 tone modifiers + `__remove`) in `.cedros-data-chip-row` |
| Metrics | `.cedros-data-summary-grid` › `.cedros-data-metric` (+ `__label` `__value` `__hint`; specified additions `__icon` `--interactive`) |
| Empty | `.cedros-data-empty-state` (+ `__copy` `__action`; specified additions `__art` + `__art-accent` / `--in-table` / `--in-card`) · `.cedros-data-empty` |
| Setup notice | `.cedros-data-setup-notice` (+ `__body`) |
| Pagination | `.cedros-data-pagination` |
| Dialog | `.cedros-data-dialog__overlay` › `.cedros-data-dialog` (+ `__heading` `__title` `__description` `__body` `__close`) |

**Dashboard cards** follow §6.1 in full; registration does not lower the design bar.
They ship the complete state matrix or they are not done: layout-matched initial
skeleton, micro empty with no fake plot, refresh-stale retaining the last good values,
error (`.cedros-data-status--error` with Retry), permission/dependency handling, and
the happy/attention paths. Card `h3` = `base`/600, quantities are locale-formatted
tabular sans, and the component adapts to its host cell without horizontal overflow.
Every card has one operator question, one–three headline metrics (four maximum), one
evidence region maximum, an explicit time basis, source-generation freshness, and one
detail/setup/retry action maximum. Extension-specific charts use namespaced markup and
the §4.9 / §6.1 visual and ARIA contract; private core chart components are not an
extension API.

**Transient feedback is host-owned.** Use the host/SDK toast delivery surface where it is
available (`import { toast } from "cedros:admin"`); do not copy
`.cedros-toaster` markup, mount a portal, bundle another toast library, or ship a toast
queue, timer, or positioning/animation CSS. Apply the decision and testing contract in
`docs/extension-authoring/reference/admin-notifications.md`.

**Permission surfaces**: declare `requiredPermission` / `requiredExtensionId` /
`disabledReason` in your manifest — the host renders the §5 disabled-nav state and the
§6 capability-locked page from them; don't build your own lock screens.

**Ship checklist** (merge of the docs checklist + Workbench gates):

- [ ] Root carries `cedros-data` + your namespace + `data-extension-id`
- [ ] Light + dark verified through tokens only; zero literal colors
- [ ] All four control states + focus ring on `:focus-visible` only; full keyboard paths (tabs/menus/dialogs per ARIA contract)
- [ ] Host classes before custom CSS; no global selectors without your root ancestor; no token re-declaration
- [ ] Buttons 32px and single-line fields 36px; mixed rows center-align; sentence case everywhere; mono only for identifiers; motion via `--motion-*`
- [ ] Empty/error/loading/disabled designed for every surface incl. dashboard cards
- [ ] Metric grids share one period, distinguish `0` from `—`, and announce final values only
- [ ] Dashboard card passes the §6.1 five-second gate; 1–3 primary metrics, ≤1 evidence region, ≤1 action
- [ ] Dashboard comparisons use like-for-like windows and declared stock/flow/rate/duration semantics
- [ ] Dashboard charts expose freshness, gaps/partial coverage, keyboard/touch point inspection, and a non-visual data twin
- [ ] First-run, filtered, and micro empties use the correct context; table empties span all columns
- [ ] Transient outcomes use the host toaster once; persistent conditions stay inline
- [ ] Mobile (<768) doesn't clip toolbars, actions, tabs, or labels
- [ ] One primary per action cluster (page header ≤1); destructive actions follow §7 Dialogs
- [ ] Host-owned strings ship via `i18nCatalogs` namespaces; extension-body
      translation has a published runtime seam or an explicit host handoff; +35% growth survives; dirty
      surfaces run the §7 leave guard

---

## 12. The theme overview pair

Every Cedros theme or design system should ship a paired overview using Workbench as the
reference structure. The pair has one theme and two readers:

| Artifact | Primary reader | Job | Optimization |
|---|---|---|---|
| `{theme}.md` | Agents, engineers, extension authors | Normative implementation source | Explicit rules, tokens, semantics, edge cases, API availability, checklists |
| `{theme}.html` | Theme buyers, owners, designers, reviewers | Theme story and visual reference | Immediate character, realistic specimens, scan-friendly guidance, light/dark proof |

The Markdown is authoritative when prose and pixels conflict. The HTML must show the
same current version and render every claimed rule. Both files are self-contained enough
to remain useful outside repository context; links may deepen the contract, but may not
carry a rule required to interpret the page.

### 12.1 Required narrative order

Use this order so a person can understand the theme before evaluating its components and
an agent can retrieve the same concepts predictably:

1. **Identity** — name, one-line promise, surface, audience, personality, signature,
   modes, and explicit avoids.
2. **Principles** — 5–8 rules that resolve ambiguous choices.
3. **Foundations** — semantic color tokens, typography, spacing, radius, elevation,
   imagery/iconography, and data notation.
4. **Composition** — shell or canvas, page archetypes, density, containers, responsive
   behavior, and information hierarchy.
5. **Components** — actions, navigation, inputs, selection, data display, overlays,
   feedback, empty/loading/error states, and recurring furniture.
6. **Expression** — voice, imagery, motion, charts, accessibility, and mode behavior.
7. **Integration** — runtime boundary, stable classes or APIs, extension rules, host
   availability, and a ship checklist.
8. **Reference** — condensed scales, deliberate divergences, snippets, version, and
   change history.

Sections may be renamed to suit a theme, but none of these ideas may disappear. A public
editorial theme may spend more space on typography and media; an application theme may
spend more on states and controls. The shared order remains recognizable.

### 12.2 Markdown authoring contract

- Start with a snapshot table whose values are short enough for retrieval and comparison.
- Write normative decisions with **must / never / only / when**. Separate taste from
  behavior; give a decision rule wherever two components look similar.
- Name tokens, values, anatomy, allowed variants, states, responsive behavior, keyboard
  behavior, reduced motion, and accessible announcements. Include empty, loading, error,
  disabled, and permission-limited cases—not only the happy path.
- Mark runtime gaps as **Host availability**. Do not turn a desired class, manifest key,
  or SDK method into a current API by documenting it without that label.
- Keep implementation history and cleanup tasks in issues or engineering plans. The
  overview describes the theme as a coherent system, not the sequence used to adopt it.
- End with an implementation checklist and a brief changelog. Version the pair together;
  a visual or behavioral change increments both artifacts.

### 12.3 HTML authoring contract

- Open with the promise, audience, personality, and 6–10 memorable attributes, then a
  **cover composition** — one realistic screen rendered whole in the theme. A buyer
  should recognize the theme's character before the first component inventory, and the
  marketplace preview image is captured from this cover (§12.4).
- Tell a continuous story in the §12.1 order: identity → principles → foundations →
  composition → components → expression → integration → reference. Use realistic
  content that demonstrates the intended product context; avoid lorem ipsum and
  implementation backlog language.
- Show palette, type hierarchy, spacing/radius/elevation, buttons, fields, selection,
  menus, tables, cards, metrics, breadcrumbs, empty states, notices, toasts, dialogs,
  progress, charts, voice, motion, focus, and responsive intent when they exist in the
  theme. Workbench's board is the minimum application-theme coverage reference.
- Demonstrate light and dark in the same file. Remain legible without remote fonts,
  scripts, frameworks, or network access. Controls used only for the preview must be
  keyboard operable and must not imply product functionality that is not present.
- Favor specimens and short guidance over API tables. The HTML is a brand guideline and
  selection surface; the Markdown owns exhaustive implementation detail.
- Include version, link/name of the paired Markdown, theme-author attribution if
  applicable, and an explicit statement of the theme's supported surface.

### 12.4 Marketplace preview boundary

The overview HTML is the canonical **source preview** for future marketplace ingestion.
The current `CedrosThemeManifest.preview` field accepts only a root-relative static image
path (recommended 3:2). Until marketplace ingestion explicitly supports overview HTML:

1. keep the HTML beside the theme source or package documentation;
2. capture the representative 3:2 static preview from its opening composition;
3. point `manifest.preview` to that image using the documented manifest schema; and
4. do **not** invent `overview`, `previewHtml`, or another manifest key—the schema rejects
   unknown fields.

Workbench is an admin design-system theme rather than a portable public-site manifest,
so its pair demonstrates the authoring format and coverage rather than a package layout.

### 12.5 Pair acceptance checklist

- [ ] Same theme name, version, promise, audience, personality, modes, and supported surface
- [ ] Same semantic palette, type scale, spatial character, shape, elevation, and motion
- [ ] Same component variants, decision rules, state behavior, and voice examples
- [ ] HTML shows every major family specified by Markdown; Markdown explains every HTML specimen
- [ ] Light/dark, keyboard focus, reduced motion, loading, empty, error, and destructive paths covered
- [ ] No remote dependency is required to understand or render the HTML
- [ ] Runtime tokens/classes/manifest fields verified against the current platform contract
- [ ] Static marketplace preview generated separately while HTML ingestion is unavailable
- [ ] Both files updated in one review with a short changelog entry

---

## Appendix A — quick reference

```css
/* control heights */    32px buttons · 36px fields     /* radius */ 7 derived · 8 · 12 · 999px
/* type */ 11 12 13 14 16 18.4 24 32 (px) · weights 400/500/600(/700 stats)
/* space */ 4 8 12 16 24 32 48 (px)                    /* containers */ 1360 · 720 · 60ch
/* dialogs */ 420 · 560 · 680                          /* elevation */ e0–e3 (§4.4)
/* motion */ 100 160 200 220 240 400 500 800ms · list stagger 45ms, all items, turns budgeted on-screen, ≤500ms · expo-out in · ease-in out (~70%)
/* focus */ border: var(--cd-ring); box-shadow: 0 0 0 3px color-mix(in srgb, var(--cd-ring) 14%, transparent);
/* cedar in admin */ links · chart series 1 · Cedra presence — nothing else
/* charts/art */ --cd-chart-1..6 = cedar · gold · sage · clay · indigo · mist
/* empty */ first-run=floating two-tone glyph block · filtered=plain row+clear · optional region=micro line
/* feedback */ transient completed event=toast · persistent condition=status · field issue=inline error
/* fields */ date = calendar popover (DateInput/DateTimeInput) · time = typed segments · number/color = styled natives · tags = 18-tone chips · secrets = write-only
/* autosave chip */ Unsaved changes · Saving… · Saved just now · Offline — changes will sync · Conflict — review changes · Save failed — retry
/* leaving dirty */ "Save changes before leaving?" — Keep editing / Exit without saving / Save and exit
/* selected */ choice tiles & grid tiles = ring (border ring + 0 0 0 2px ring/24%)
/* document title */ Cedros | {page name}
```

## Appendix B — deliberate divergences from shadcn

| Divergence | shadcn does | Workbench does | Why |
|---|---|---|---|
| Table headers | `sm` sentence case | `2xs` uppercase +0.04em muted | Dense data tool; column scanning beats reading |
| Base density | 14px body, 36–40px controls | 13–14px, 32px buttons / 36px fields, ~40px rows | Operators live here hours a day; density is earned with hierarchy (W4) |
| Segmented track border | borderless `bg-muted` | hairline border + 4% wash | Hairline-structure language of the admin; keeps tracks visible on white cards |
| Toast ownership | App-local toaster/portal | One host-owned bottom-right viewport; extensions publish through the SDK | Prevents competing stacks, timing, motion, and accessibility behavior |
| Table header wash | transparent (or `muted/50`) | `color-mix(bg 90%, accent 10%)` | Optically ≈ `muted/50`; reinforces dense column scanning |
| BEM classes, no Tailwind | utility classes | `cedros-*__*--*` + tokens | Extension self-injection architecture requires portable CSS |

Everything else — variant names, anatomy, restraint, neutral palette, focus behavior,
label casing, input fill, destructive treatment — follows shadcn.

## Appendix C — the copy-paste CSS contract

For extension authors and hand-written CSS. Everything here consumes host tokens; paste
into your namespaced stylesheet and adjust selectors.

```css
/* Control metrics: buttons 2rem (32px) · fields 2.25rem (36px) · button padding-x 0.75rem (sm 0.5)
   Radius: controls var(--cd-radius-control) · cards var(--cd-radius) · shell/dialogs var(--admin-radius)
   Nested radius: max(0px, parent radius - actual outer-edge inset), including parent border
   Type: labels 0.8125rem/500 sentence case · cells 0.8125rem · card titles 0.875rem/600 */

/* Focus — :focus-visible ONLY, never :focus */
.myext-control:focus-visible {
  outline: none;
  border-color: var(--cd-ring);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--cd-ring) 14%, transparent);
}

/* The standard transition (color/border/shadow) */
.myext-control {
  transition: background-color var(--motion-duration-fast, 160ms) ease,
              border-color var(--motion-duration-fast, 160ms) ease,
              color var(--motion-duration-fast, 160ms) ease,
              box-shadow var(--motion-duration-fast, 160ms) ease;
}

/* Status tint recipe (bg / border / text) — success 14%, warning 18%, error 12%, info 12% */
.myext-notice--error {
  background: color-mix(in srgb, var(--cd-error) 12%, var(--cd-bg));
  border: 1px solid color-mix(in srgb, var(--cd-error) 32%, transparent);
}
.myext-warning-text { color: var(--cd-warning-fg); } /* never #8a5a00 */

/* Canonical keyframes */
@keyframes myext-menu-in   { from { opacity: 0; transform: scale(0.97) translateY(-4px); }
                             to   { opacity: 1; transform: scale(1) translateY(0); } }
@keyframes myext-dialog-in { from { opacity: 0; transform: scale(0.98) translateY(8px); }
                             to   { opacity: 1; transform: scale(1) translateY(0); } }
@keyframes myext-shimmer   { from { background-position: 120% 0; } to { background-position: -120% 0; } }
@keyframes myext-spin      { to { transform: rotate(360deg); } }
@keyframes myext-row-in    { from { opacity: 0; transform: translateY(8px); }
                             to   { opacity: 1; transform: translateY(0); } }
/* menu: in 180ms out 120ms · dialog: in var(--motion-duration-modal, 240ms) out 160ms
   shimmer 1.4s ease-in-out infinite
   easing for entrances: var(--motion-ease-standard, cubic-bezier(0.16, 1, 0.3, 1)) */

/* Initial table load only: add this class to every row. Never truncate the reveal
   to the first N rows — the rows you skip paint immediately, ahead of the rows
   above them still waiting their turn. Budget the turns across what the reader can
   see, then bound the cascade:
     turns = clamp(1, rowCount, ceil(visibleHeightBelowTableTop / rowHeight))
     --myext-row-index         = min(rowIndex, turns - 1)   (per row)
     --myext-row-stagger-scale = min(1, 500 / (45 * (turns - 1)))  (on the table)
   Budgeting across rowCount instead would squeeze a 500-row table's visible cascade
   into 10ms. Rows past the visible run share the last turn; they are off-screen and
   settle before a reader can scroll to them. Measure once, on the frame the reveal
   starts. A module-level Set keyed by stable page/table id must suppress it after
   its first run, so remounting on Back, sorting, filtering, and refetching is
   instant. */
.myext-row--initial-enter {
  animation: myext-row-in var(--motion-duration-standard, 220ms)
    var(--motion-ease-standard, cubic-bezier(0.16, 1, 0.3, 1)) backwards;
  animation-delay: calc(
    var(--myext-row-index, 0) * var(--motion-stagger-list, 45ms) *
      var(--myext-row-stagger-scale, 1)
  );
}

/* Reduced motion — durations collapse via host tokens; stop your loops too */
@media (prefers-reduced-motion: reduce) {
  .myext-skeleton { animation: none; }
  .myext-spinner  { animation: none; }
  .myext-row--initial-enter { animation: none; }
}
```

---

**Changelog.** v2.12 (2026-09-09): the setup wizard became a Workbench surface (§6 F) — the Heartwood hand-off is withdrawn; its painted looping media, category layer, sidebar stepper, uppercase kickers, and 2rem headlines are gone, the site type uses Choice tiles with Lucide icons, starter pages live on the review, and the logo moved to Settings › Site › Brand. v2.11 (2026-08-20): retired the native date/datetime popovers — dates are
picked through the `DateInput`/`DateTimeInput` calendar popover (trigger in the standard
input anatomy; 280px `role="dialog"` calendar with keyboard grid, month/year fast
navigation, aria-disabled range bounds, Clear/Today footer, typed
time row), time-of-day fields keep the segmented native input with the OS popup chrome
suppressed, and the styled-native contract remains only as the extension host-availability
fallback. v2.10 (2026-08-20): the table first-reveal now staggers every row instead
of stopping after six, so no table paints its lower rows before the rows above them have
animated in; its stagger turns are budgeted across the rows on screen rather than the full
row count, keeping the visible cascade perceptible and inside 500ms on a table of any
length, with rows below the fold sharing the last turn.
v2.9 (2026-08-19): established the opinionated dashboard contribution
standard for core and extension authors: admission test, fixed information hierarchy,
metric semantics, evidence-visual decision table, time/comparison controls, density,
freshness, state behavior, responsive and accessible chart interaction, and the
five-second acceptance gate; added the matching dashboard specimen to the HTML pair.
v2.8 (2026-08-15): standardized eligible first-reveal metric count-ups at
500ms and the first six table rows at 220ms with a 45ms stagger; both are one-shot,
reduced-motion safe, and table reveals never replay on return, sort, filter, or refetch;
added the extension copy contract. v2.7 (2026-07-22): standardized ordinary boxed admin action buttons at
32px while preserving 36px single-line fields; `sm` now changes only button padding and
type, and mixed button-field rows center-align without stretching either control. v2.6
(2026-07-18): aligned the toast standard with the shipped host-owned
bottom-right card stack, 4s/8s lifecycle, stable-id replacement, six-entry queue with
three collapsed cards, 400ms rise/stack and 200ms exit, and public extension SDK delivery;
removed the extension-local toast keyframe recipe and linked the complete authoring
contract. v2.5 (2026-07-13): added the setup-locked table-row exception: the
standard warning Badge, one labeled outline setup doorway, muted blocked data, no row
tint, and no competing row controls. v2.4 (2026-07-11): made the ambient two-tone glyph the standard
Block-empty visual (64-viewBox stroke art, `--cd-muted` base + one `--cd-chart-5`
accent detail, 220ms entrance then a 5s float loop, static under reduced motion) —
the admin's one decorative loop — fully replacing the static 40px icon well, whose
`__illustration` anatomy is removed; added the `__art` / `__art-accent` class contract
and the shared `EmptyStateArt` glyph set (24 domain glyphs), with every host block
empty migrated. v2.3 (2026-07-10): added chart/art tokens `--cd-chart-1..6`
(cedar, gold, sage, clay, indigo, mist) to remove decorative admin color literals while
keeping semantic/status colors separate. v2.2 (2026-07-09): positioned the pair as the reference implementation of
the theme-overview format — every theme ships this two-file pair, with the HTML serving
as its marketplace preview; rewrote remaining adoption-era annotations ("existing",
"canonized") as stable theme language using the host-reference convention; the HTML twin
gained a cover composition, a principles strip, staged narrative kickers, and do/don't
rule chips in the brand-guideline register. v2.1 (2026-07-09): clarification pass ahead of the admin alignment
sweep — specified the remaining live patterns: specialized fields (date/time, number,
color, tags, media picker), search behavior and form validation, choice tiles, tile
grids, reorder, inbox/activity rows, autosave + dirty-state + leave guard (exact host
strings), command palette anatomy, code blocks & logs, truncation/overflow rules, the
keyboard scheme, navigation side effects (document title, focus), and the extension
i18n rule; corrected the secret pattern (write-only — no copy, no re-show) and the tag
set (18 tones, not 16); resolved the dangling media-picker reference. v2.0
(2026-07-09): reframed Workbench as the reference Cedros theme
overview pair; added the theme snapshot, human/agent artifact roles, reusable narrative
order, Markdown and HTML authoring contracts, pair acceptance checklist, and explicit
marketplace preview boundary; rewrote adoption-oriented language as stable theme
guidance while preserving every component and state contract. v1.3 (2026-07-09): added
metrics, Back breadcrumbs, collection-state behavior, animated Block empty, and the
host-owned toast contract. v1.0–1.2 (2026-07-06): established the foundational Workbench
tokens, scales, compositions, components, voice, motion, accessibility, and extension
integration contract.

*Workbench v2.12 — maintained alongside `design-admin.html`. Changes update both files in
one review; the pair must never disagree. For brand surfaces, see `design-cedros.md`.*

# 00 · Cedros Platform Primer

Read this first if you have never worked with Cedros. It explains just enough
of the platform that the rest of the guide — which is entirely about themes —
makes sense. Nothing here requires access to Cedros source code.

## What Cedros is

Cedros is an AI-native website platform that enables businesses, agencies, and developers to create, manage, and operate websites using artificial intelligence.

Unlike traditional website builders that primarily use AI to generate designs or content, Cedros is designed for ongoing collaboration between website owners and AI agents. Websites become active business tools that agents can understand, modify, and operate through natural language instructions.

The platform combines website creation, hosting, content management, AI capabilities, and an extensible ecosystem of business functionality.

**Key capabilities include:**

- **AI Website Creation:** Build and customize websites using natural language, with control over design, structure, content, and functionality.
- **Agent-Native Management:** Enable authorized AI agents to manage website content, make changes, and interact with supported business operations.
- **Extensible Functionality:** Add capabilities such as online stores, payments, directories, events, and other business-specific workflows through extensions.
- **Integrated Intelligence:** Use AI to assist with content creation, ongoing website management, and operational tasks.
- **Business and Developer Tools:** Manage hosted websites, custom domains, permissions, and extensible functionality for different business requirements.

Cedros is designed for small and medium-sized businesses seeking to reduce the technical work involved in maintaining an online presence, as well as agencies and developers building websites for clients.

Its agent-native architecture allows websites to function as more than static destinations. Rather than relying entirely on manual administration, owners can delegate supported tasks to AI while maintaining control over their websites and business operations.

The goal of Cedros is to make websites an active part of running a business, combining the flexibility of modern web development with the accessibility and operational capabilities of AI agents.

**Websites that think, act, and work for you.**

Cedros is not offered for self-hosting.

### How a Cedros site fits together

A Cedros site has three main pieces:

- **The server** — stores all site configuration and content, and serves both
  the public site and the admin APIs.
- **The public site** — server-rendered React pages built from private host
  frontend source (internal native previews use `react-native/src`). Neither is
  an author-installable package.
- **The admin** — the owner console where site settings, content, pages,
  extensions, and **themes** are managed.

Everything a visitor sees on the public site is rendered by shared templates
reading site data. A theme re-skins those templates; it never replaces them.

## How pages come to be

A Cedros site serves two kinds of public pages, and a theme styles both:

**1. Built-in route templates.** The platform ships templates for the standard
pages every site has: home, about, contact, legal, the docs index and docs
articles, the blog index and blog posts, plus supporting pages (errors, search,
newsletter, checkout, and so on). Owners fill these with content; the template
decides structure.

**2. Authored pages (the page builder).** Owners compose custom pages in the
admin page builder. An authored page is stored as a small document:

```jsonc
{
  "version": 1,
  "template": "default",          // which zone layout the page uses
  "zones": {
    "main": [                      // each zone holds an ordered list of blocks
      { "id": "b1", "type": "hero-banner", "props": { "title": "…" } },
      { "id": "b2", "type": "rich-text",   "props": { "body": "…" } }
    ]
  }
}
```

A **block** is one unit of page content — a hero, a text section, a feature
grid, a form embed. Blocks carry `props` (their content), and the runtime
renders each block type with a shared renderer. Themes restyle blocks by
**type**, never by instance — see [`07`](./07-block-variants.md) and
[`08`](./08-page-builder-and-blocks.md).

## Route surfaces

Every public page a theme can style resolves to exactly one of **nine route
surfaces**:

| Surface id | What it covers |
| --- | --- |
| `home` | The home page |
| `about` | The about page |
| `contact` | The contact page |
| `legal` | Legal/policy pages (privacy, terms, …) |
| `docsIndex` | The documentation landing/index |
| `docsArticle` | Every individual docs article |
| `blogIndex` | The blog landing/index |
| `blogPost` | Every individual blog post |
| `authoredPage` | Every owner-built custom page (and anything else) |

Surfaces are how a theme says "docs articles read narrow and calm; the home
page is wide and loud" without knowing any URLs. Pages that don't match a more
specific surface behave as `authoredPage`.

## Extensions

Extensions add **behavior** to a site — new features, admin sections, public
routes, and new page-builder blocks (a shop's product grid, an analytics
chart). Extension blocks carry namespaced types like `commerce/product-grid`.
Themes can restyle extension blocks through the same block-variant mechanism
using namespaced keys and wildcard fallbacks (`07`), but a theme can never ship
an extension's behavior. If your goal is a new feature rather than a new look,
you want the [`extension-authoring`](../extension-authoring) guide.

## Who controls what

The clean separation below is what makes themes safe to install and trivially
reversible. When authoring, stay in your column.

| Concern | Owner (site data & settings) | Theme | Extension |
| --- | --- | --- | --- |
| Page copy, products, posts, media | ✅ | — | — |
| Which pages/routes exist | ✅ | — | ✅ (adds) |
| Navigation menu items and links | ✅ | — | ✅ (adds) |
| Footer column count, business info, copyright text | ✅ | — | — |
| Colors, typography, spacing, radius, shadows | — | ✅ | — |
| Nav/footer/page chrome *style* (minimal, prominent, framed, …) | — | ✅ | — |
| Per-surface width, tone, presentation | — | ✅ | — |
| Visual variant of each block type | — | ✅ | — |
| Per-section backgrounds on authored pages | ✅ | — | — |
| Block behavior, data loading, new block types | — | — | ✅ |
| Brand voice/asset metadata for the AI assistant | — | ✅ (`brandKit`) | — |

Two rows trip people up:

- **Navigation content vs. navigation style.** The owner decides *what links
  exist*; the theme decides *how the nav looks* (variant, width, link position
  and style).
- **Footer layout vs. footer style.** Footer columns, business info, and
  copyright text are owner layout settings. The theme controls footer variant,
  width, and whether the color-mode toggle shows.

## Glossary

| Term | Meaning |
| --- | --- |
| **Manifest** | The single declarative document that *is* the theme: a `CedrosThemeManifest`. |
| **Token** | One named design value (`tokens.colors.primary`, `tokens.radius.md`). Compiles to a `--cedros-*` CSS variable. |
| **Route surface** | One of the nine page categories a theme can address (`home`, `docsArticle`, …). |
| **Shell** | The site chrome around page content: top nav, footer, and the page frame/width. |
| **Block** | One unit of rendered page content (hero, prose, card grid, paywall, …), identified by a type string. |
| **Block variant** | The named visual treatment a theme picks for a block type (`hero: "spotlight"`). |
| **Core block types** | The 16 shared block keys every Cedros site renders; the stable styling vocabulary (`07`). |
| **Brand kit** | Brand guidance (voice, audience, assets) that travels with the theme; required for portable themes. |
| **Routine-safe** | The default authoring policy: the full declarative contract minus external stylesheets and raw `customCss`. |
| **Portable theme / library package** | A theme distributed outside the repo as a `cedros-theme-library-package` JSON envelope (optionally an archive with font files). |
| **Compiled theme** | The output of compiling a manifest: provider config, class maps, per-surface plans, runtime styles. Hosts may cache and pass this instead of the raw manifest. |
| **Runtime plan** | The per-request, per-surface resolution of a compiled theme that web/native hosts render from. |
| **Owner** | The person operating the site through the admin. |
| **Host** | Any app embedding the shared templates/runtime (the public site itself, a React Native app, a preview surface). |

Next: [`01-theming-system-overview.md`](./01-theming-system-overview.md).

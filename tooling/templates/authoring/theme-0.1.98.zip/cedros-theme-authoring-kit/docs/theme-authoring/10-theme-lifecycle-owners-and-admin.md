# 10 · Theme Lifecycle: Owners, Admin, and Storage

This document follows a theme through a real site: where it is stored, how an
owner picks/builds/imports one in the admin, how the public site consumes it,
and how upgrades and rollback work. Theme authors should understand this
lifecycle because it defines the constraints their manifest lives under —
especially the silent-fallback rules.

## Where a site's theme state lives

The server keeps all theme state in one site-settings entry. Its shape:

| Key | What it holds |
| --- | --- |
| `themeId` | The applied selection — a built-in id or a custom theme's id |
| `customTheme` | The applied custom theme's full manifest (present only when `themeId` is custom) |
| `customThemes` | The owner's saved custom-theme **library** (routine-safe manifests) |
| `customThemeDraft` | The last saved owner edit — a compatibility seam for the intake flow |

The public site never sees the library or drafts. The public config exposes
only the active selection — `{ themeId }` for a built-in, or
`{ themeId, customTheme }` for an applied custom theme — which the runtime
reads as the saved payload (`11`):

```jsonc
{ "themeId": "commerce" }
{ "themeId": "studio-aurora", "manifest": { /* CedrosThemeManifest */ } }
```

### The fail-safe rules

Theme resolution is deliberately paranoid so a bad theme can never take a site
down:

- A built-in `themeId` **always wins**, even if stale custom data is present.
- A custom selection is used only when the persisted manifest passes
  **routine-safe** validation *and* its `theme.id` matches the selected
  `themeId`.
- Custom theme ids that collide with built-in ids are rejected at save/intake.
- Anything else — unknown id, invalid manifest, mismatched id — silently falls
  back to `minimalist`. If a site unexpectedly renders minimalist, that is the
  signal to re-validate the theme (`14`).

## The owner workflow (admin → Appearance)

Everything below runs through the same shared runtime as the public site — the
previews are real renders, not mocks.

1. **Browse and apply.** The Appearance catalog lists the four built-ins, the
   site's saved custom themes, and (when the host runs a Theme Manager) the
   marketplace catalog. Applying writes `themeId` (+ `customTheme` for custom
   themes). Applying is instant and reversible.
2. **Build.** The guided theme editor creates or edits routine-safe custom
   themes: metadata, light + dark palettes, typography — including a Google
   Fonts catalog and uploaded font files, which land in `assets.fonts` — shell
   chrome, and route surfaces. Raw JSON is a secondary review output, not the
   primary editing surface.
3. **Save to the library.** Drafts save into `customThemes`; a saved theme can
   be previewed beside the built-ins, duplicated into a new library item, or
   retired once another theme is live.
4. **Import / export.** Portable packages (`12`) import into the library and
   export back out, so themes move between sites. Intake validation runs on
   import; a package that fails reports path-scoped issues instead of
   installing.
5. **Assistant authoring.** The site's AI assistant has first-class
   theme-building tools that operate on the same routine-safe manifest and the
   same library — assistant-built themes are ordinary custom themes.

## Marketplace distribution

A host can run the **Cedros Theme Manager**, an optional service that publishes
an approved-themes catalog to its sites. The catalog snapshot is normalized
before anything is shown:

```jsonc
{
  "themes": [                       // or "entries"
    {
      "themeId": "studio-aurora",
      "version": "1.0.0",
      "label": "Aurora",
      "manifest": { /* … */ },      // or "themePackage": { "manifest": { … } }
      "packageUrl": "/theme-packages/studio-aurora-1.0.0.zip",
      "packageDigest": "sha256-…"
    }
  ],
  "sourceLabel": "Cedros Theme Manager",
  "refreshedAt": "2026-05-30T00:00:00Z"
}
```

Rules enforced per listing:

- The manifest must pass routine-safe validation **and** the full brand-kit
  requirement (`09`).
- `theme.id` must not reuse a built-in id and must be unique in the catalog.
- `packageUrl` must be root-relative (absolute/external URLs are rejected).
- Invalid listings are dropped with path-scoped issues; the built-ins always
  remain available even when the catalog is missing or broken.

Installing a marketplace theme downloads the package archive, installs any
bundled font files (the `./fonts/…` sources from `09`), and saves the manifest
into the site's library with font URLs resolved — after which it behaves
exactly like any owner custom theme.

## Versioning, upgrade, and rollback

- Keep `theme.id` **stable** across releases — selection, the owner library,
  and the marketplace all key on it.
- Bump `theme.version` (semver) on every published change so operators can see
  and reason about updates.
- A theme change is presentation-only and reversible: roll back by reapplying a
  prior selection (`themeId` + the previous manifest) or switching to a
  built-in id. There is no data migration tied to a theme.
- Re-run validation + review (`12`) on every version before publishing.

Next: [`11-runtime-application-hosts.md`](./11-runtime-application-hosts.md).

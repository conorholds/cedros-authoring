# 07 · Block Variants

`blockVariants` lets a theme pick the visual treatment of each content block —
heroes, cards, article shells, sidebars, and so on — globally and per surface.
Themes stay declarative: you name a variant, and the shared runtime resolves it
into a class for web and a variant token for React Native. No block-specific
components or render hooks.

## Shape

```ts
blockVariants?: Record<string /* block key */, {
  default: string;                                  // required
  surfaces?: Partial<Record<RouteSurface, string>>; // optional per-surface overrides
}>;
```

- `default` (required, non-empty string) — the variant used on every surface
  unless overridden.
- `surfaces` (optional) — override the variant on specific route surfaces
  (`06`), keyed by surface id.

```ts
blockVariants: {
  hero: {
    default: "feature",
    surfaces: { home: "spotlight", docsIndex: "feature" },
  },
  contentCard: { default: "shadcn-grid" },
  article: { default: "shadcn-surface" },
}
```

## The 16 core block types

`entryHeader`, `entryActions`, `hero`, `contentCard`, `contentMedia`,
`relatedContent`, `support`, `article`, `paywall`, `sidebar`, `toc`,
`controls`, `breadcrumbs`, `pagination`, `prose`, `codeBlock`.

These are the canonical building blocks the shared templates render across the
surfaces — and the styling vocabulary that page-builder blocks map onto through
theme aliases (`08`). Each surface uses a characteristic subset:

| Surface | Core blocks it typically renders |
| --- | --- |
| `home` | `hero`, `contentCard`, `relatedContent`, `contentMedia` |
| `about` | `hero`, `prose`, `relatedContent`, `contentMedia` |
| `contact` | `hero`, `support`, `relatedContent`, `contentMedia` |
| `authoredPage` | `hero`, `prose`, `contentCard`, `support`, `relatedContent`, `contentMedia` (plus whatever the page's blocks alias to) |
| `legal` | `prose`, `contentMedia` |
| `docsIndex` | `hero`, `contentCard`, `controls`, `sidebar`, `pagination`, `contentMedia` |
| `docsArticle` | `breadcrumbs`, `entryActions`, `sidebar`, `entryHeader`, `article`, `prose`, `relatedContent`, `contentMedia`, `contentCard`, `toc` |
| `blogIndex` | `hero`, `contentCard`, `controls`, `pagination`, `contentMedia`, `entryActions` |
| `blogPost` | `breadcrumbs`, `entryActions`, `entryHeader`, `article`, `prose`, `paywall`, `support`, `relatedContent`, `contentMedia`, `contentCard` |

Use the table to prioritize: if the brief is docs-heavy, `article`, `prose`,
`sidebar`, and `toc` carry most of the impression.

## Block keys: core, extension, and fallbacks

A block key may be any of:

| Key form | Example | Meaning |
| --- | --- | --- |
| Core key | `hero` | One of the 16 core blocks |
| Exact extension block | `commerce/product/card` | A specific namespaced block |
| Namespace family | `commerce/product/*` | All blocks under a prefix |
| Namespace root | `commerce/*` | All blocks in a namespace |
| Reserved extension fallback | `extension/*` | Any namespaced extension block |
| Reserved unknown fallback | `unknown/*` | Any non-core, non-namespaced key |

Namespaced keys are `/`-separated segments; each segment matches
`[A-Za-z0-9][A-Za-z0-9._-]*`, with at most 16 segments and 256 characters
total. `isCedrosThemeBlockSelectorKey(key)` checks a key; the validator
rejects malformed keys.

### Resolution order

When the runtime resolves a block's presentation, it checks selectors from most
to least specific and uses the first key **the theme actually defines**:

1. Exact block key
2. Namespaced family selectors, most specific first
3. `extension/*` (for namespaced extension blocks)
4. `unknown/*` (for non-core, non-namespaced keys)

Examples:

- `commerce/product/card` → `commerce/product/card` → `commerce/product/*` →
  `commerce/*` → `extension/*`
- `analytics/chart` → `analytics/chart` → `analytics/*` → `extension/*`
- `legacyWidget` → `legacyWidget` → `unknown/*`

Authoring rules: prefer exact keys for high-value extension blocks, prefer
`namespace/family/*` for scalable coverage, and keep `extension/*` /
`unknown/*` as safety nets — not your primary styling mechanism.

> **Extension-key variants have no built-in CSS.** The emitted class embeds
> the *selector* (`commerce/product/card` + `grid` →
> `cedros-theme-block-variant--commerce-product-card-grid`), and the kernel
> stylesheets only cover the core block types below. An extension variant
> value is a contract read by the extension's own styles, by native renderers,
> and by advanced `customCss` — it does not borrow the core catalog's styling
> even when the value string matches a catalogued one.

## What a variant value renders

Each block variant compiles to classes on the block element:

- `cedros-theme-block--<blockType>` (always)
- `cedros-theme-block-variant--<blockType>-<value>` (the `default` value)
- `cedros-theme-block-surface--<blockType>-<surface>-<value>` (on surfaces with
  an override)

Class slugs are kebab-cased (`contentCard` → `content-card`), and wildcard
selectors slug with a `-wildcard` suffix (`commerce/*` →
`cedros-theme-block--commerce-wildcard`).

**The variant value is a free string.** The validator only checks it is a
non-empty string. A value renders a built-in *web* treatment only when the
shared kernel CSS has a rule for
`cedros-theme-block-variant--<blockType>-<value>`. A made-up value (e.g.
`hero: { default: "big" }`) validates and is applied as a class — and still
flows to React Native as the block's variant token and remains a `customCss`
hook — but produces **no built-in web styling**. Prefer a catalogued value
below unless you intend to style it yourself with `customCss` (`09`).

## Built-in styled variant catalog

These are the variant values that ship with dedicated web CSS in the kernel
stylesheets. Pick from these for predictable cross-theme results.

| Block type | Built-in styled `default` values |
| --- | --- |
| `entryHeader` | `detail-header`, `offer-header`, `product-header`, `story-header` |
| `entryActions` | `actions-row`, `byline-actions`, `conversion-actions`, `detail-actions`, `toolbar-actions` |
| `hero` | `feature`, `spotlight`, `essay-lead`, `launchpad`, `shadcn-section`, `catalog`, `featured-deal` |
| `contentCard` | `grid`, `shadcn-grid`, `column`, `panel`, `offer` |
| `contentMedia` | `media-stack`, `media-frame`, `gallery-stack`, `catalog-media` |
| `relatedContent` | `related-grid`, `reading-list`, `resource-grid`, `offer-grid`, `shadcn-list` |
| `support` | `support-card`, `assist-card`, `note-card`, `offer-support`, `shadcn-card` |
| `article` | `article-shell`, `blog-shell`, `essay`, `guide`, `detail`, `preview-doc-shell`, `shadcn-surface` |
| `paywall` | `pay-gate`, `reader-gate`, `purchase-gate`, `access-gate` |
| `sidebar` | `rail`, `section-list`, `detail-sidebar`, `catalog-rail`, `product-rail` |
| `toc` | `outline`, `outline-panel`, `margin-notes`, `detail-toc`, `offer-summary` |
| `controls` | `toolbar`, `filters`, `refine` |
| `breadcrumbs` | `trail`, `detail-breadcrumbs`, `capsules`, `shop-trail` |
| `pagination` | `pager`, `folio`, `steps` |
| `prose` | `docs`, `longform`, `detail`, `guide`, `preview-doc-body`, `shadcn-prose` |
| `codeBlock` | `terminal`, `annotated`, `recipe` |

Character notes for the most load-bearing choices:

- The **shadcn-aligned** values (`hero: shadcn-section`,
  `contentCard: shadcn-grid`, `article: shadcn-surface`, `prose: shadcn-prose`,
  `support: shadcn-card`, `relatedContent: shadcn-list`) give the cleanest
  modern result and are what the `minimalist` default theme uses.
  `hero: shadcn-section` in particular removes the hero's card chrome entirely
  (borderless, transparent, oversized title).
- The **offer/catalog/deal** values (`offer-header`, `conversion-actions`,
  `featured-deal`, `catalog`, `offer`, `offer-grid`, `offer-support`,
  `purchase-gate`, `shop-trail`, `product-rail`, `catalog-rail`) add
  link-tinted gradients and dashed merchandising accents — the commerce look.
- The **editorial** values (`story-header`, `essay-lead`, `essay`,
  `reading-list`, `margin-notes`, `longform`, `folio`) trade panels for
  typographic emphasis.
- `codeBlock: "terminal"` pins code panels dark in **both** color modes by
  design.

> A theme does not have to list every block. Unlisted blocks render their
> shared default treatment. List a block only to change it.

Every variant referenced by the shipped default themes and the starter
manifest is guaranteed to have kernel CSS by a regression test
(`ui/tests/theme-kernel-variant-css-coverage.test.ts`). If you add a variant to
a shipped manifest, add its CSS (or a block-level base rule) in the same change
or that gate fails. Custom themes are not covered by that gate — stick to the
catalog or bring `customCss`.

### Verifying a value is styled

For external theme pipelines (marketplaces, theme repos, CI), don't trust the
catalog table by eye — check the shipped CSS the same way the in-repo gate
does. Compile the theme (the compiled class map is exactly what the runtime
emits) and look each variant class up in the published stylesheet bundle,
which inlines the kernel CSS:

```ts
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { compileCedrosRoutineThemeManifest } from "../../ui/src/site-templates";

const require = createRequire(import.meta.url);
const css = readFileSync(
  require.resolve("../../ui/src/site-templates/styles.css"),
  "utf8"
);

const compiled = compileCedrosRoutineThemeManifest(manifest);
for (const [key, block] of Object.entries(compiled.blockVariants)) {
  // className = "cedros-theme-block--<block> cedros-theme-block-variant--<block>-<value>"
  const [blockClass, variantClass] = block.className.split(" ");
  const basePrefix = `${blockClass.replace("block--", "block-variant--")}-`;
  const styled =
    css.includes(`.${variantClass}`) ||          // exact variant selector
    css.includes(`${variantClass}"`) ||          // exact match inside [class*="…"]
    css.includes(`[class*="${basePrefix}"`) ||   // block-level base rule
    css.includes(`[class*=${basePrefix}`);       // …minified without quotes
  if (!styled) console.warn(`${key} -> ${block.defaultVariant}: no kernel CSS`);
}
```

`block.className` covers each key's `default`; check `surfaces` overrides the
same way via `block.surfaceClassNames` (the middle class of each entry is that
surface's variant class).

Two nuances that make eyeballing unreliable:

- **`hero`, `contentCard`, and `article` have block-level base rules**
  (`[class*="cedros-theme-block-variant--hero-"]` …), so *any* value on those
  three gets generic base layout — an invented value there looks "half
  styled", which masks the mistake. The other 13 core blocks get nothing.
- **Some catalogued values share one rule** (`hero: feature`, `spotlight`,
  and `essay-lead` are currently identical on web). Sharing is legal and can
  change over time; if two of your choices must look different today, verify
  with a render, not the catalog listing.

## How blocks receive their classes

Hosts and the shared templates apply these automatically. A block component
calls `useCedrosThemeBlockClassName(blockType, baseClassName)` (or the runtime
helpers in `11`), which runs the selector/fallback chain and returns the right
`cedros-theme-block-*` classes. Page-builder blocks pass their **theme block
type** (their registry alias, `08`) rather than their raw type; extension
blocks use the exact same hook — there is no separate path for them.

Next: [`08-page-builder-and-blocks.md`](./08-page-builder-and-blocks.md).

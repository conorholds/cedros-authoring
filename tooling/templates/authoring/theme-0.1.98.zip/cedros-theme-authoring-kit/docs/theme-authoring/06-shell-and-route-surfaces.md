# 06 · Shell and Route Surfaces

Tokens set the palette and rhythm. `shell` and `routeSurfaces` decide the
*chrome* (nav, footer, page frame) and the *per-page presentation* (width,
tone, variant). Every value here compiles to a stable `cedros-theme-*` class or
a `data-theme-*` attribute on the rendered output, and the shared site CSS
styles those classes.

## `shell` — site chrome defaults

```ts
interface CedrosThemeShellManifest {
  mode?: "inherit" | "default" | "none";
  nav?: CedrosThemeNavManifest;
  footer?: CedrosThemeFooterManifest;
  page?: CedrosThemePageShellManifest;
}
```

`shell.mode` decides whether the theme renders the shared chrome:

- `"default"` — render the Cedros nav + footer (typical for a public site).
- `"inherit"` — defer to the host's shell decision (the common default when the
  host embeds content).
- `"none"` — render no shell (headless/embedded).

### `shell.nav`

| Field | Allowed values | Default | Class / effect |
| --- | --- | --- | --- |
| `variant` | `default`, `minimal`, `prominent`, `overlay` | `default` | `cedros-theme-shell-nav--<variant>` |
| `width` | `contained`, `full` | `contained` | nav inner width |
| `linkPosition` | `center`, `right` | `right` | link alignment |
| `linkStyle` | `text`, `pill` | `pill` | link chrome |

Styled variants: `minimal` drops the nav shadow/backdrop, hides the brand mark,
and uses smaller text links; `prominent` adds a strong link-tinted shadow;
`overlay` fixes the header over the opening scene — transparent, set in the
overlay foreground (`--cedros-nav-overlay-foreground`, default bone) — and
settles onto the ordinary translucent surface once the visitor scrolls past the
top of the page (an inline script keys `data-cedros-nav-scrolled`; opening the
mobile menu also forces the solid state). Use it per surface (typically `home`)
together with a `canvas` page whose opening section is dark enough to carry
light text; native borrows the `minimal` treatment.
`linkPosition` deliberately offers only `center` and `right` — the brand sits
at the start, links go center or right. (`left` and per-item `linkDisplay`
belong to the owner's layout settings, not to themes; both the TypeScript type
and the validator reject them.)

### `shell.footer`

| Field | Allowed values | Default | Class / effect |
| --- | --- | --- | --- |
| `variant` | `default`, `minimal`, `stacked`, `inverse` | `default` | `cedros-theme-shell-footer--<variant>` |
| `width` | `contained`, `full` | `contained` | footer inner width |
| `showThemeToggle` | `true`, `false` | `true` | shows the light/dark/system color-mode toggle |

`minimal` makes the footer transparent, hides the brand mark, and shortens the
footer; `stacked` arranges the footer contents in a column; `inverse` closes the
page on a band in the foreground color with inverse text (ink on a light page,
bone on a dark one), swapping link, border, and panel tokens to match. Routine-safe themes
ship meaningful light and dark palettes, so leave `showThemeToggle` enabled.
Advanced hosts may disable it for a constrained experience they own (`05`).

> Footer column count, business-info display, and copyright text are **owner
> layout settings**, not theme fields. A theme controls footer `variant`,
> `width`, and `showThemeToggle` only.

### `shell.page`

| Field | Allowed values | Default | Effect |
| --- | --- | --- | --- |
| `variant` | `default`, `framed`, `immersive`, `canvas` | `default` | page-frame treatment |
| `containerWidth` | `content`, `wide`, `full` | `content` | base content max-width |

The page renders as `cedros-theme-shell-page--<variant>-<containerWidth>`,
which drives the width of the page's main container:

- `default` — no extra frame.
- `framed` — a subtle gradient + inline hairline border overlay around the
  content column.
- `immersive` — extra top padding for a more open feel.
- `canvas` — hands the whole viewport to the page: no main padding, no page
  inset on the container (`full` renders 100% wide), no gap between authored
  blocks, and raw-code blocks render without the runtime card frame. Sections
  own their own containment, so full-bleed media and dark bands run edge to
  edge. Meant for art-directed marketing surfaces such as a parent brand home;
  ordinary reading pages keep `default`.

## The nine route surfaces

Themes map presentation onto these surface ids (and only these):

| Surface | Pages it styles |
| --- | --- |
| `home` | The home page |
| `about` | The about page |
| `contact` | The contact page |
| `legal` | Legal/policy pages |
| `docsIndex` | The docs landing/index |
| `docsArticle` | Every docs article |
| `blogIndex` | The blog landing/index |
| `blogPost` | Every blog post |
| `authoredPage` | Every owner-built custom page — and the fallback for anything else |

(Hosts may pass kebab-case aliases — `docs-article`, `blog-index`, … — which
normalize to these ids; unknown surface strings resolve to `authoredPage`.)

```ts
routeSurfaces?: Partial<Record<RouteSurface, CedrosThemeRouteSurfaceManifest>>;

interface CedrosThemeRouteSurfaceManifest {
  variant?: "default" | "editorial" | "product" | "commerce" | "minimal" | "hero";
  accentTone?: "default" | "muted" | "emphasis";
  containerWidth?: "content" | "wide" | "full";
  shell?: Partial<CedrosThemeShellManifest>; // per-surface chrome override
}
```

Every field is optional; omit a surface entirely to inherit the base shell and
the defaults. Each surface compiles to classes and data attributes on the page
root:

| Field | Class emitted | Data attribute | Styled in kernel CSS? |
| --- | --- | --- | --- |
| `variant` | `cedros-theme-surface-variant--<surface>-<variant>` | `data-theme-surface-variant` | No — selection + hook only |
| `accentTone` | `cedros-theme-surface-tone--<tone>` | `data-theme-surface-tone` | `muted`, `emphasis` styled |
| `containerWidth` | `cedros-theme-surface-width--<width>` + the page class | `data-theme-surface-width` | via the page class |
| (surface id) | `cedros-theme-surface--<surface>` | `data-theme-surface` | hook |

### `variant` — what it does (and doesn't)

The surface `variant` (`editorial`, `product`, …) emits a class and data
attribute but has **no direct kernel-CSS rule of its own**. Its real jobs are:

1. It expresses per-surface intent that pairs with **per-surface block-variant
   selection** (`07`): a block's `surfaces` map and the surface drive which
   variant a block renders.
2. It is a stable targeting hook (`data-theme-surface-variant`,
   `cedros-theme-surface-variant--<surface>-<variant>`) for `customCss` or
   host-level styling.

So choosing `variant: "editorial"` for `docsArticle` does not by itself change
pixels; it expresses intent and steers block variants. Use `accentTone`,
`containerWidth`, and block variants for visible per-surface differences.

### `accentTone` — panel emphasis

- `muted` — dims panels toward the page background (calmer reading surfaces).
- `emphasis` — brightens panels, tints muted panels with the link color, and
  strengthens borders (louder marketing surfaces).
- `default` — no change.

Because panels are derived rather than tokenized (`05`), `accentTone` is the
supported way to shift panel presence per surface.

### `containerWidth` — page width per surface

A surface's `containerWidth` sets that surface's content max-width and **flows
into the styled page class** even without re-declaring `shell.page`. For
example, a base shell of `page: { variant: "default", containerWidth: "wide" }`
with `routeSurfaces.docsArticle.containerWidth: "content"` renders the docs
article main region as `cedros-theme-shell-page--default-content` — narrow for
readability — while the home surface stays wide.

Width precedence (most to least specific):

1. `routeSurfaces.<surface>.shell.page.containerWidth` (explicit per-surface shell)
2. `routeSurfaces.<surface>.containerWidth` (the surface's primary knob)
3. `shell.page.containerWidth` (base)
4. `content` (default)

The same resolved width populates the `containerWidth` field, the
`surface-width--*` class, the `data-theme-surface-width` attribute, and the
styled page class, so web and React Native agree.

> Reading surfaces (`docsArticle`, `blogPost`, `legal`, often `about`/`contact`)
> almost always want `content`. Marketing/index surfaces (`home`, `docsIndex`,
> `blogIndex`, `authoredPage`) want `wide` or `full`.

### Per-surface `shell` override

A surface may override base chrome — for example, center the nav and use a full
footer only on `home`:

```ts
routeSurfaces: {
  home: {
    containerWidth: "full",
    accentTone: "emphasis",
    shell: { nav: { linkPosition: "center" }, footer: { width: "full" } },
  },
  docsArticle: { variant: "editorial", containerWidth: "content", accentTone: "muted" },
  legal: { variant: "minimal", containerWidth: "content" },
}
```

A surface `shell` override merges over the base shell (nav/footer/page each
shallow-merge). You only set the fields you want to change.

## Worked shell + surfaces block

```ts
shell: {
  mode: "default",
  nav: { variant: "minimal", width: "full", linkPosition: "right", linkStyle: "text" },
  footer: { variant: "minimal", width: "full" },
  page: { variant: "default", containerWidth: "wide" },
},
routeSurfaces: {
  home:        { containerWidth: "full", accentTone: "emphasis" },
  about:       { containerWidth: "content" },
  contact:     { containerWidth: "content" },
  docsIndex:   { containerWidth: "wide", accentTone: "muted" },
  docsArticle: { containerWidth: "content", accentTone: "muted" },
  blogIndex:   { containerWidth: "wide", accentTone: "muted" },
  blogPost:    { containerWidth: "content", accentTone: "muted" },
  legal:       { variant: "minimal", containerWidth: "content" },
  authoredPage:{ containerWidth: "wide" },
},
```

Next: [`07-block-variants.md`](./07-block-variants.md).

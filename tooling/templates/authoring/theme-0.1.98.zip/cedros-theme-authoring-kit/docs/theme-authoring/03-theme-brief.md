# 03 · Theme Brief

Before touching the manifest, convert the product/brand goal into a concrete
plan. A good brief makes the rest of the work mechanical: every later field has
a reason. Capture the brief as a short structured object you carry through the
remaining documents.

## Theme Brief object

```jsonc
{
  "identity": {
    "id": "studio-aurora",         // stable, kebab-case, not a built-in id
    "label": "Aurora",
    "version": "1.0.0",            // semver; theme release, not schema version
    "mode": "light"                // required for routine-safe themes
  },
  "voice": {
    "summary": "Calm, editorial product site for a design studio.",
    "audience": "Studios and founders evaluating a partner.",
    "personality": ["calm", "editorial", "precise"]
  },
  "palette": {
    "background": "#fbfaf7",
    "foreground": "#1b1a17",
    "primary": "#3b5bdb",
    "accent": "#e9efff",
    "neutrals": "warm | cool | true",
    "dark": {                       // the SAME theme's dark-mode palette
      "background": "#121110",
      "foreground": "#f2f0ea",
      "primary": "#8da4f5"
      // …fill the same keys as the light palette
    }
  },
  "type": {
    "headingFamily": "\"Fraunces\", Georgia, serif",
    "bodyFamily": "\"Inter\", system-ui, sans-serif",
    "density": "comfortable | compact | spacious"
  },
  "surfaces": {
    "home": { "width": "full", "tone": "emphasis", "feel": "launch" },
    "docsArticle": { "width": "content", "tone": "muted", "feel": "reading" },
    "blogPost": { "width": "content", "tone": "muted", "feel": "reading" }
    // …one line of intent per surface you care about
  },
  "blocks": {
    "hero": "shadcn-section",
    "contentCard": "shadcn-grid",
    "article": "shadcn-surface"
    // …only the blocks whose default treatment you want to change
  },
  "distribution": "default | portable | marketplace"
}
```

You do not need every field up front. Fill what the goal proves, then let
`04`–`09` turn each line into validated manifest fields.

## Decisions that shape everything else

### 1. The dark palette is part of this theme

Every routine-safe theme carries **both complete palettes**: `tokens.colors`
for light mode and `tokens.darkColors` for dark mode. Set `mode: "light"` and
define the same 12 keys in both palettes. Visitors switch between light, dark,
and system at runtime, so design the palettes together and keep their
relationships coherent (see `05`). Light-only and always-dark manifests remain
available only through the general/advanced compatibility path; they are not
packageable routine-safe themes.

### 2. Neutrals temperature

Pick warm, cool, or true-neutral grays and keep `background`, `muted`,
`border`, and `mutedForeground` consistent with that choice — in **both**
palettes. Mixed-temperature neutrals are the most common reason a palette
looks "off", and a warm light palette with a cool dark palette reads as two
different brands.

### 3. Density

Density is spacing + radius + line-height working together, not one knob:

- **Compact**: smaller `spacing.contentGap`/`pageInset`, tighter radii.
- **Comfortable**: the starter defaults.
- **Spacious**: larger `spacing.sectionGap`/`pageInset`, softer/larger radii.

### 4. Per-surface reading width

The nine route surfaces (`06`) split naturally:

- **Reading surfaces** (`docsArticle`, `blogPost`, `legal`, often `about`):
  prefer `containerWidth: "content"` for line length.
- **Marketing/index surfaces** (`home`, `blogIndex`, `docsIndex`,
  `authoredPage`): `wide` or `full`.

Decide width and accent tone per surface in the brief so `06` is a
transcription step.

### 5. Which blocks to restyle

Every core block has a sensible default treatment. Only list a block in the
brief if you want to change it. Prefer the built-in styled variant values
catalogued in `07` — a made-up variant string validates but renders no
built-in styling on web. Remember that page-builder blocks inherit these
treatments through their theme aliases (`08`): styling `hero` also styles
`hero-banner` and `cta-banner` sections on owner-built pages.

## Accessibility quality bar

Bake contrast into the brief, not into a review afterthought — and check it in
**both** palettes. WCAG relative-luminance math is ten lines of code; run it
on every pairing you ship:

- `foreground` on `background`: aim ≥ 7:1 (body text everywhere).
- `mutedForeground` on `background` **and** on `muted`: ≥ 4.5:1 (it's normal-
  size secondary text, not decoration).
- `link` on `background`: ≥ 4.5:1 — and remember many kernel treatments tint
  panels and rules from `link`, so it must also *work* as a tint source.
- `primaryForeground` on `primary`: ≥ 4.5:1. Saturated mid-tone primaries
  (golds, corals, teals) usually fail with white text — test dark-on-color
  before assuming white-on-color.
- `success`/`error` on `background`: ≥ 4.5:1, and give `success` a clearly
  different hue from `primary` so confirmations never read as CTAs.

Dark palettes need the same pass with their own values; lightening the light
palette mechanically almost never clears the bar.

## "What would shadcn do?"

The packaged `minimalist` theme is shadcn-aligned and is the best reference for
restrained, modern defaults. When a decision is unclear, prefer the
shadcn-style variant values (`hero: "shadcn-section"`,
`contentCard: "shadcn-grid"`, `article: "shadcn-surface"`,
`prose: "shadcn-prose"`, `support: "shadcn-card"`,
`relatedContent: "shadcn-list"`) and a clean neutral palette.

## Output of this step

A filled Theme Brief object and, for portable/marketplace themes, a
one-paragraph brand summary, audience, voice, and at least one brand asset URL
(`09`). Carry both into [`04-manifest-reference.md`](./04-manifest-reference.md).

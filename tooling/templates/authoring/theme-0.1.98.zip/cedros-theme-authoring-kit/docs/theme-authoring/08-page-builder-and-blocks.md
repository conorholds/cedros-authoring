# 08 · Themes and the Page Builder

Owners build custom pages in the admin page builder. This document explains
how those pages are structured and — the part theme authors need — exactly how
builder blocks pick up theme styling. If you only style the 16 core block keys
(`07`), builder pages inherit your theme automatically; this document explains
why, and where the boundaries are.

## The authored document model

An authored page is a small document; the page builder edits it and the shared
runtime renders it:

```jsonc
{
  "version": 1,
  "template": "default",     // which zone layout the page uses
  "zones": {
    "main": [                 // ordered blocks per zone
      { "id": "b1", "type": "hero-banner", "props": { "title": "…" } },
      { "id": "b2", "type": "rich-text",   "props": { "body": "…" } }
    ]
  }
}
```

- **Templates own zones.** The default template has a single `main` zone;
  richer templates add zones like `hero`, `intro`, `body`, `proof`, and `cta`.
  Themes do not define or rename zones.
- **Blocks are `{ id, type, props }`.** Content lives in `props`; the shared
  block registry maps each `type` to a renderer.
- Authored pages render on the **`authoredPage` route surface** (`06`), so that
  surface's width/tone/variant and per-surface block overrides apply to every
  builder page.

## How a builder block gets theme styling

Themes never style block *instances* — they style block *types*, and every
builder block type maps onto one of the 16 core theme keys. The registry entry
for each block type carries an optional `themeBlockType`; the renderer asks the
theme for classes using that key (falling back to the raw type):

```
block.type = "hero-banner"
  → registry themeBlockType = "hero"
  → theme lookup: blockVariants.hero
  → classes: cedros-theme-block--hero cedros-theme-block-variant--hero-<value>
```

So `blockVariants.hero.default: "spotlight"` styles the built-in home hero
**and** every `hero-banner` / `cta-banner` section owners drop onto builder
pages. You do not (and should not) write `blockVariants["hero-banner"]`.

### The builder → theme key map

Composer insert-catalog blocks and their theme keys (the source of truth is
`platform-contracts/authored.ts` + `authoredBuilderRuntimeAliases.ts` in
the private host source in `ui/src/site-templates`):

| Theme key | Builder block types that inherit it |
| --- | --- |
| `hero` | `hero-banner`, `cta-banner` |
| `prose` | `rich-text`, `raw-code` (its markdown/source fallback) |
| `contentCard` | `content-card`, `feature-grid`, `section-heading`, `chart`, `table` |
| `contentMedia` | `image-media`, `media-content`, `video-embed`, `aspect-ratio`, `cedros/media` |
| `relatedContent` | `link-list`, `accordion-group`, `tabs-section`, `carousel`, `stat-grid` |
| `support` | `callout`, `testimonial-quote`, `avatar`, `badge`, `kbd`, `label`, `progress`, `separator`, `spacer`, `skeleton`, and the shadcn overlay/feedback primitives (`dialog`, `tooltip`, `toast`, `popover`, `hover-card`, `sheet`, `drawer`, `collapsible`, `alert-dialog`, `dropdown-menu`, `calendar`, `empty`, `spinner`) |
| `controls` | `form-embed`, `newsletter-signup`, and the shadcn form primitives (`input`, `select`, `checkbox`, `radio-group`, `switch`, `slider`, `textarea`, `toggle`, `toggle-group`, `combobox`, `date-picker`, `field`, `input-group`, `input-otp`, `native-select`) |
| `entryActions` | `button-group` |

Practical consequence: **styling the core keys gives full builder coverage.**
When you want a specific treatment for testimonials but not for other support
blocks, that is a limitation to accept (or a `customCss` case targeting the
block's runtime attributes) — the alias map is fixed by the platform, not by
themes.

> One subtlety: a block's *renderer* alias and its *theme* alias can differ.
> `callout` renders with card-like structure but themes as `support` — the
> alias tables are curated so blocks group with the styling family they read
> as, not the renderer they borrow.

## Section styling vs. theme styling — who wins

Builder sections carry their own owner-chosen presentation: background
(color/gradient/image, overlay, parallax), width, and height. These are
**owner content decisions** stored with the page, and they render as inline
styles on the `<section>` element.

The division of labor:

- **The section element (owner wins).** Section backgrounds and sizing are
  applied inline; a theme cannot and should not override an owner's explicit
  section background. Inline styles beat theme classes by design.
- **The blocks inside (theme wins).** Theme block-variant classes land on each
  block's wrapper (the card, prose, or media element inside the section), so
  block chrome — panel treatment, borders, gradients, type rhythm — is theme
  territory regardless of the section backdrop.
- **The page frame (theme wins).** The `authoredPage` surface's
  `containerWidth`, `accentTone`, and shell config come from the theme (`06`).

If a theme's hero gradient seems to "disappear" on one page, check whether the
owner set a section background there — that is working as intended.

## Extension blocks

Extensions register additional block types under a namespace
(`commerce/product-grid`, `analytics/chart`). On the public site they render
through a hydration pipeline (the server emits a placeholder; the extension's
runtime hydrates it), but for theming they are ordinary blocks:

- The theme lookup uses the namespaced type through the selector chain in
  `07`: exact key → family wildcards → `extension/*`.
- Extension variant values are **hooks, not kernel styling** (`07`): the
  resolved variant reaches the extension's renderer and lands as a class on
  the block wrapper, and the extension's own styles (or an advanced theme's
  `customCss`) interpret it. Declare the reserved fallback when an extension
  documents the variant values it understands:

  ```ts
  blockVariants: {
    "extension/*": { default: "quiet" },   // a value the extension documents
  }
  ```

- An extension's own documentation is the source of truth for its block keys
  and supported variant values; prefer `namespace/*` family selectors over
  guessing exact keys.

Raw-code blocks (owner-authored live code) resolve their theme block variant as
`prose`. Their live React output owns its markup and styles, but renders inside
the same themed runtime as registered blocks. Custom code must consume the
inherited `--cedros-runtime-*` tokens to follow the active theme and visitor
color mode; a hard-coded palette remains intentionally isolated from theming.

## Reviewing a theme against builder pages

The admin page builder previews blocks through the same runtime and theme
context as the public site, so the builder's preview *is* a theme review
surface. When finishing a theme:

1. Apply (or preview) the theme on a site with at least one authored page that
   uses `hero-banner`, `rich-text`, `feature-grid`, and a media block.
2. Check the page at `authoredPage`'s configured width — builder pages are the
   surface owners touch most.
3. If the site runs extensions, check one page with extension blocks and
   confirm your `extension/*` (or namespace) fallback reads correctly.

Next: [`09-brand-kit-assets-and-preview.md`](./09-brand-kit-assets-and-preview.md).

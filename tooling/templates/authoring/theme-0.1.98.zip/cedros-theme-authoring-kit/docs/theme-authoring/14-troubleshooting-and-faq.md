# 14 · Troubleshooting and FAQ

Symptom-first. Each entry names the cause and the fix, with a pointer to the
document that owns the full contract.

## The theme doesn't apply at all (site renders `minimalist`)

Theme resolution **silently falls back to `minimalist`** whenever the saved
selection is unusable (`10`). Check, in order:

1. **Does the manifest validate?** Run `validateCedrosRoutineThemeManifest`
   and print `formatCedrosThemeValidationIssues(issues)`. Persisted custom
   themes must pass the **routine-safe** policy — a manifest with `customCss`
   or `assets.stylesheets` is valid under the general contract but invalid as
   a saved site theme.
2. **Does `theme.id` match the selection?** The saved payload only wins when
   `manifest.theme.id === themeId`.
3. **Is the id a built-in?** `minimalist`, `editorial`, `product`, `commerce`
   are reserved; a custom theme reusing one is rejected and the built-in wins.
4. **Unknown keys anywhere?** The validator rejects unknown keys at every
   level (`04`) — a single stray field invalidates the whole manifest.

## A block variant renders no styling

- **Custom value on a core key.** Variant values are free strings; only the
  catalogued values in `07` have kernel CSS. A made-up value validates,
  becomes a class, and styles nothing. Pick a catalogued value, or style your
  value with `customCss` (advanced themes only). Beware the masking case:
  `hero`, `contentCard`, and `article` have block-level base rules, so
  invented values on those three still get generic layout and look "half
  styled" — check the other 13 blocks to spot the mistake (`07` shows a
  programmatic check).
- **Extension key.** Extension-key variants (exact, `namespace/*`,
  `extension/*`) never have kernel CSS — the value is interpreted by the
  extension's own styles or your `customCss` (`07`, `08`).
- **Wrong key for a builder block.** Builder blocks use *aliases*: style
  `hero`, not `hero-banner`; `prose`, not `rich-text`. Full table in `08`.
  Keys like `hero-banner` aren't valid theme keys at all (no `/`, not core)
  and would only match a `unknown/*` fallback.

## The nav/footer/page chrome didn't change

- `shell.mode` may be `"inherit"` and the host may not render the shared
  shell. Set `shell.mode: "default"` for a public site look (`06`).
- Check the field actually belongs to themes. Footer columns, business info,
  copyright text, and nav `linkPosition: "left"` / `linkDisplay` are **owner
  layout settings**; both the manifest type and the validator reject them
  (`06`).
- A per-surface `shell` override beats the base `shell` on that surface —
  check `routeSurfaces.<surface>.shell` before concluding the base is broken.

## Page width doesn't change

Width resolves through a precedence chain (`06`):
`routeSurfaces.<s>.shell.page.containerWidth` →
`routeSurfaces.<s>.containerWidth` → `shell.page.containerWidth` → `content`.
A more-specific level may be pinning the value. Also remember:

- `containerWidth: "full"` is full-bleed and ignores `container.full`; the
  gutter comes from `spacing.pageInset` (`05`).
- `content`/`wide` read `container.content` / `container.wide` tokens.

## Dark mode looks wrong

- **Routine-safe validation says a color token is missing.** Routine-safe
  themes must define every supported key in both `tokens.colors` and
  `tokens.darkColors`; neutral fallback is only a general/advanced
  compatibility behavior. Fill both palettes (`05`).
- **Dark shows my light palette.** Not possible through tokens (`colors`
  fills only the base bucket); if you see this, a `customCss` rule or host
  override is setting unsuffixed variables with higher precedence than the
  mode chains.
- **The site should always be dark.** That is an advanced compatibility shape,
  not a routine-safe distributable theme. Routine-safe themes must let visitors
  use both modes (`04`, `05`, `06`).
- **No toggle in the footer.** `showThemeToggle` defaults to `true` but the
  footer must be rendered (`shell.mode`), and the owner's layout also has to
  include the footer.

## Fonts don't load

- The **family name** in `tokens.typography.*` must match
  `assets.fonts[].family` exactly; tokens reference families, never file
  paths (`05`, `09`).
- Package-relative sources (`./fonts/…`) resolve only when the host passes
  `assetRoot` (`11`); without it the browser requests the literal `./…` path.
  Root-relative (`/fonts/…`) and `https://` sources need no `assetRoot`.
- Traversal segments (`./../…`) are rejected by validation.
- `weight` accepts `normal`, `bold`, or `100`–`900`; `style` accepts
  `normal`, `italic`, `oblique`; `sources[].format` accepts
  `woff2|woff|truetype|opentype` (`04`).
- Routine-safe themes cannot load fonts via `assets.stylesheets` (e.g. a
  Google Fonts `<link>`); ship font **files** through `assets.fonts` instead.

## Panels/cards ignore my background color

Panel background is intentionally **not a token** — it derives from internal
variables that default to white (light) / neutral dark gray (dark). Shape
panels with `muted`, `border`, `link` (many variants tint panels from the link
color), and per-surface `accentTone`; advanced themes can set
`--cedros-panel` via `customCss` (`05`).

## Shadows don't change

`tokens.shadow.sm/md/lg` are all honored. (In versions before July 2026 a
stylesheet-cascade bug pinned `sm`/`lg` to their defaults; if you see this,
update the private host source.) Note `md` falls back to the resolved `sm` when
unset, and the shipped defaults are deliberately subtle (`05`).

## A surface `variant` changes nothing

Working as designed: surface `variant` is a selection input and styling hook,
not a styled treatment. It steers per-surface block variants and labels the
DOM (`data-theme-surface-variant`); visible differences come from
`accentTone`, `containerWidth`, and block variants (`06`).

## My hero gradient disappears on one authored page

The owner set an explicit section background on that page. Section backgrounds
are owner content, applied inline, and intentionally beat theme classes; the
blocks inside still take theme styling (`08`).

## `customCss` / `assets.stylesheets` seem ignored

They're not ignored — they're **rejected**: under the routine-safe policy the
whole manifest fails validation, and as a saved site theme it then falls back
to `minimalist`. Those two fields work only for advanced first-party themes
applied through the general contract (`09`, and the fallback rules in `10`).

## TypeScript accepted my manifest but validation fails

The manifest types mirror the validator's structure, but **value-level** rules
(CSS color validity, font source shapes, block-key grammar, root-relative
`preview`) only run in the validator. Always run
`validateCedrosRoutineThemeManifest` before shipping (`04`).

## Where do I see validation errors on a live site?

The admin Appearance flows surface path-scoped issues on save/import, and
marketplace intake reports them per listing. At runtime nothing errors — the
fail-safe fallback applies (`10`) — so validate at authoring time, not by
watching the site.

---

## FAQ

**Can a theme add pages, nav items, or footer links?**
No. Content and information architecture belong to the owner; behavior belongs
to extensions (`00`). A theme only restyles what exists.

**Can a site run two themes, or different themes per page?**
One theme is active per site. Per-page differences are what `routeSurfaces`
and per-surface block overrides are for (`06`, `07`).

**Does a theme style the admin?**
No. Themes style the public site (and its native rendering). The admin has its
own visual system.

**Do I ship separate light and dark themes?**
No — one routine-safe theme carries complete light and dark palettes
(`tokens.colors` + `tokens.darkColors`). The host selects between them; a
separate always-dark package does not pass routine-safe validation (`03`, `05`).

**Is the React Native rendering really the same theme?**
Yes — same manifest, same compiled plan, same variant resolution; only token
delivery differs (values instead of CSS variables) (`11`).

**How do I preview without a Cedros site?**
Portable themes require a Cedros site for the authoritative Appearance preview.
Repository contributors can render through the checked-in host review workflow
in `12`; there is no public Cedros npm scaffold or validator.

**What's the difference between `theme.version` and `schemaVersion`?**
`schemaVersion` is the manifest format (always `1` today). `theme.version` is
your release version — bump it every publish (`04`, `12`).

**Can I use any CSS color syntax?**
Anything the browser accepts as a color (`hex`, `rgb()`, `hsl()`, `oklch()`,
`color-mix()`, named colors). `url()` and image functions are rejected (`05`).

**My question isn't here.**
Re-check the owning document (`04`–`12`); if the behavior contradicts these
docs, treat it as a platform bug and file it with the manifest + the observed
DOM.

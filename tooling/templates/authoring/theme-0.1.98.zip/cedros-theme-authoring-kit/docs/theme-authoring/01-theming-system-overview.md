# 01 · Theming System Overview

This document is the mental model. Everything later in the guide is a
field-by-field elaboration of what you read here.

## One declarative document

A theme is one `CedrosThemeManifest` object:

```ts
{
  kind: "cedros-theme",
  schemaVersion: 1,
  theme: { id, label, version },   // identity
  mode,                            // "light" for routine-safe themes
  unstyled,                        // advanced/headless switch
  brandKit,                        // brand guidance (required for portable themes)
  tokens,                          // design tokens → CSS variables
  shell,                           // nav / footer / page chrome
  routeSurfaces,                   // per-surface presentation
  blockVariants,                   // per-block-type visual treatments
  assets,                          // fonts (routine-safe) + stylesheets (advanced)
  preview,                         // marketplace/admin preview image
  customCss                        // advanced escape hatch
}
```

A theme controls **presentation only**:

| Concern | Field |
| --- | --- |
| Palette, type, spacing, radius, shadow, container widths | `tokens` |
| Dark-mode palette (visitors can switch light/dark/system) | `tokens.darkColors` |
| Base mode hint | `mode` |
| Site chrome: nav style, footer style, page frame | `shell` |
| Per-route presentation: variant, accent tone, width, per-surface chrome | `routeSurfaces` |
| Visual variant of each content block | `blockVariants` |
| Brand identity + AI guidance metadata | `brandKit` |
| Web fonts; advanced stylesheets/CSS | `assets`, `customCss` |

A theme never controls content or data, routes or information architecture,
block semantics or behavior, or components and runtime logic. If a goal needs
any of those, it is not a theme change (see the ownership table in
[`00`](./00-cedros-platform-primer.md)).

## The pipeline

Every host — the public website, a React Native app, the admin preview — runs
the same theme through the same four stages:

```
manifest
  │  validateCedrosThemeManifest / validateCedrosRoutineThemeManifest
  ▼
validated manifest
  │  compileCedrosThemeManifest / compileCedrosRoutineThemeManifest
  ▼
CedrosCompiledTheme            (site-wide; cacheable)
  │  resolveCedrosThemeRuntimePlan(options, routeSurface)
  ▼
CedrosResolvedThemeRuntimePlan (one page render, one surface)
  │  web: resolveCedrosThemeWebPlan / shared templates
  │  native & other hosts: host adapters (theme-runtime boundary)
  ▼
rendered output
```

1. **Validate.** The validator checks shape, enums, colors, font sources, and
   block keys, and rejects **any unknown key at every level**. It returns
   `{ path, message }` issues; compiling asserts validity first, so a
   successful compile is also a validation gate.
2. **Compile.** `compileCedrosThemeManifest` turns the manifest into
   renderer-ready primitives:
   - `provider` — color mode, `unstyled`, and the full CSS-variable override
     map;
   - `shell` — class names + layout options for nav/footer/page;
   - `routeSurfaces` — a fully resolved entry for **all nine** surfaces
     (defaults filled in), each with classes, tone, width, and per-surface
     block variants;
   - `blockVariants` — class maps per block key;
   - `runtimeStyles` — the theme's `@font-face` blocks, external stylesheets,
     and `customCss`, each with a dedupe key and a placement of
     `before-first-themed-surface`.
3. **Plan.** For one page render, the runtime resolves the plan for that page's
   route surface: which shell config applies (base merged with the surface's
   overrides), which surface presentation applies, and which block variants are
   in force.
4. **Render.** Web derives class names and inline CSS variables; React Native
   derives token values and variant names from the *same plan* through host
   adapters. The admin/builder preview is the same runtime — what you see there
   is what ships.

## What the theme actually does to the page (web DOM contract)

The runtime emits **stable class names and data attributes**; the shared
stylesheet bundle styles them. Class names follow one rule:
`cedros-theme-<scope>--<slug>`, where the slug is kebab-cased
(`contentCard` → `content-card`, `docsArticle` → `docs-article`).

| Where | What is emitted | Example |
| --- | --- | --- |
| Provider wrapper | Inline `style` with every `--cedros-*` token override; `cedros-dark` class when the theme's base mode is dark | `style="--cedros-primary-light:#3b5bdb; …"` |
| Nav | `cedros-theme-shell-nav--<variant>` | `cedros-theme-shell-nav--minimal` |
| Footer | `cedros-theme-shell-footer--<variant>` | `cedros-theme-shell-footer--stacked` |
| Page frame | `cedros-theme-shell-page--<variant>-<width>` | `cedros-theme-shell-page--framed-content` |
| Surface root | `cedros-theme-surface--<surface>`, `cedros-theme-surface-variant--<surface>-<variant>`, `cedros-theme-surface-tone--<tone>`, `cedros-theme-surface-width--<width>` | `cedros-theme-surface-tone--muted` |
| Surface root (attributes) | `data-theme-surface`, `data-theme-surface-variant`, `data-theme-surface-tone`, `data-theme-surface-width` | `data-theme-surface="blogPost"` |
| Each themed block | `cedros-theme-block--<type>` + `cedros-theme-block-variant--<type>-<value>` (+ `cedros-theme-block-surface--<type>-<surface>-<value>` where a surface override applies) | `cedros-theme-block-variant--hero-spotlight` |
| Theme fonts / CSS | `<style data-cedros-theme-fonts="<themeId>">`, `<link data-cedros-theme-stylesheet>`, `<style data-cedros-theme-custom-css>` | injected before the first themed surface, deduped per render |

These classes and attributes are the **stable public hooks** — kernel CSS
styles them, and advanced `customCss` may target them. Anything else in the
DOM (`cedros-site__*` internals) is private and may change.

## The two CSS variable layers

Web styling flows through two prefixes, and the distinction matters:

- **`--cedros-*` — the authoring layer.** Your tokens compile to these. Color
  tokens additionally emit mode-suffixed variables
  (`--cedros-background-light` / `--cedros-background-dark`).
- **`--cds-*` — the internal derived layer.** The shared site CSS resolves each
  color per mode, adds fallbacks, and computes derived values
  (`--cds-link-soft`, `--cds-border-strong`, …). You never set `--cds-*` from
  a manifest; you only need to know it exists when writing advanced
  `customCss`.

```css
.cedros-site {
  --cds-bg: var(--cedros-background-light, var(--cedros-background, oklch(1 0 0)));
  --cds-radius: var(--cedros-radius-md, var(--cedros-radius, 0.5rem));
}
.cedros-dark .cedros-site,
.cedros-site.cedros-dark {
  /* dark reads ONLY the -dark bucket, so a light palette never leaks */
  --cds-bg: var(--cedros-background-dark, oklch(0.145 0 0));
}
```

## Light and dark mode

Visitors choose the site's color mode; a theme supplies both palettes:

- Routine-safe themes use `mode: "light"`: `tokens.colors` paints light mode
  and `tokens.darkColors` paints dark mode. Both palettes must define every
  supported color token. One theme, two palettes — you do not ship a separate
  "night" theme.
- The footer ships a toggle cycling **light → dark → system** (default:
  system). The resolved preference is stored in the browser
  (`localStorage["cedros-color-mode"]`) and applied as a `cedros-dark` class on
  `<html>` by an inline script **before first paint**, so there is no flash.
- The general/advanced validator remains backward-compatible with partial or
  always-dark manifests and fills omitted values from built-in neutral
  fallbacks. The routine-safe validator rejects those shapes so imported,
  packaged, and marketplace themes always ship designed light and dark modes.

Details and the full token list: [`05-design-tokens.md`](./05-design-tokens.md).

## One shared engine

There is exactly one theme engine. Web, React Native, and previews all resolve
a theme through the same renderer-neutral plan and the same block
selector/fallback logic (the stable boundary is
`../../ui/src/site-templates/theme-runtime`). Practical consequences:

- A correct manifest renders consistently across web and native; you do not
  author per-platform variants. (Web delivers tokens as CSS variables; native
  delivers them as values — same plan either way.)
- The admin preview is the real runtime, not a mock.
- Block-variant selection — including extension blocks — follows one resolution
  order everywhere ([`07`](./07-block-variants.md)).

## Where a theme lives on a real site

The server stores the site's theme state in one settings entry. The public
site receives only the active selection:

```jsonc
// saved payload shapes the runtime accepts (siteData.theme)
{ "themeId": "commerce" }                                   // built-in
{ "themeId": "studio-aurora", "manifest": { /* manifest */ } } // custom
```

Built-in ids (`minimalist`, `editorial`, `product`, `commerce`) always win over
any extra manifest payload, and **anything invalid falls back to `minimalist`**
rather than erroring — a broken theme can never take a site down. The full
storage model, admin workflow, and marketplace path are in
[`10-theme-lifecycle-owners-and-admin.md`](./10-theme-lifecycle-owners-and-admin.md).

## The two authoring paths and the routine-safe policy

Both paths share one contract (`04`–`09`); they differ in where the theme lives
and which policy applies.

- **Default / built-in themes** ship inside cedros-data
  (`ui/src/site-templates/themes/<theme-id>.ts`, registered in
  `themes/index.ts`) and are proven by the in-repo theme tests. See
  [the in-repo review workflow](./12-validation-review-and-distribution.md#in-repo-review-default-themes)
  for the canonical commands and evidence.
- **Portable / marketplace themes** are authored anywhere as a
  `cedros-theme-library-package` JSON document, must include a **brand kit**,
  and are validated at intake. This is the path most third parties use
  ([`09`](./09-brand-kit-assets-and-preview.md),
  [`12`](./12-validation-review-and-distribution.md)).

**Routine-safe** is the default policy for agent-authored, packaged, and
portable themes: the full declarative contract **minus two escape hatches** —
`assets.stylesheets` (external CSS files) and `customCss` (raw CSS strings)
are forbidden. `assets.fonts` **is** allowed, so routine-safe themes can ship
Google Fonts, uploaded fonts, or bundled font files through the shared
`@font-face` compiler.

| Path | Validate | Compile |
| --- | --- | --- |
| Routine-safe (default) | `validateCedrosRoutineThemeManifest` | `compileCedrosRoutineThemeManifest` |
| General / advanced | `validateCedrosThemeManifest` | `compileCedrosThemeManifest` |

Reach for the general contract only when tokens + shell + surfaces + blocks
genuinely cannot express the design ([`09`](./09-brand-kit-assets-and-preview.md)).

## Readiness checklist

Before authoring, confirm:

- [ ] The goal is presentation, not content/routes/behavior.
- [ ] You know which path you are on (default vs. portable) and therefore which
      policy applies.
- [ ] You will stay inside `tokens` → `shell` → `routeSurfaces` →
      `blockVariants`, reaching for `assets.stylesheets`/`customCss` only with
      cause.
- [ ] If custom fonts are part of the brief, you have family/weight/style
      metadata and will ship WOFF2, WOFF, then a raw fallback ([`09`](./09-brand-kit-assets-and-preview.md)).
- [ ] You will validate and review through the shared runtime ([`12`](./12-validation-review-and-distribution.md))
      before shipping.

Next: [`02-quickstart.md`](./02-quickstart.md).

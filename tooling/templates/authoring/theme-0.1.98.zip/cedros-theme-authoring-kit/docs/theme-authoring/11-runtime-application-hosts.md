# 11 · Runtime Application (Hosts)

This document is for the **host** side: how a site or app applies a theme.
There is one shared theme engine, so web, React Native, and previews all
consume the same manifest through the same plan. You never build a second,
preview-only theme path.

## The two theme inputs

Every entry point accepts `theme?: CedrosSiteTemplateThemeInput`, which is
either:

- a raw `CedrosThemeManifest`, or
- a pre-compiled `CedrosCompiledTheme` (from `compileCedrosThemeManifest`).

Both resolve identically; passing a manifest just compiles it on the way in.
When `theme` is omitted, the runtime falls back to the saved site selection in
`siteData` (see *Saved-theme payloads*).

## CSS bundles

| Bundle | When to import |
| --- | --- |
| `../../ui/src/site-templates/styles.css` | Always, once, on any web host rendering themed templates. Includes the theme-kernel and block-variant CSS. |
| `../../ui/src/site-templates/content-runtime.css` | Hosts rendering authored/content runtime blocks outside the full template shell. |
| `…/styles.public.css`, `…/content-runtime.public.css` | Public-render variants for the bootstrap/public hosting path. |

> Without the stylesheet bundle, the `cedros-theme-*` classes emitted by the
> runtime have nothing to style — the page renders unthemed HTML.

The theme's **own** runtime styles (its `@font-face` blocks, external
stylesheets, `customCss`) are not part of the bundle; the runtime injects them
per render with dedupe keys, placed before the first themed surface. Rendering
multiple themed templates under one `CedrosThemeRuntimeRoot` dedupes those
assets across the page.

## Web: the simplest path

Import the stylesheet bundle once, then pass `theme` to any shared template:

```ts
import "../../ui/src/site-templates/styles.css";
import {
  DocArticleTemplate,
  getDefaultCedrosThemeManifest,
} from "../../ui/src/site-templates";

<DocArticleTemplate
  standalone
  theme={getDefaultCedrosThemeManifest("minimalist")}
  /* …page props… */
/>;
```

The shared template shell does the rest: it applies the provider
(mode + token overrides), the shell class maps and layout, the route-surface
classes and `data-theme-*` attributes, the block classes, and the theme's
runtime styles (fonts/stylesheets/customCss).

## Web: composing manually

When you render your own content (not a packaged template), resolve once and
wrap:

```ts
import {
  resolveCedrosSiteTemplateTheme,
  applyCedrosThemeSurface,
  wrapWithCedrosSiteTemplateTheme,
  useCedrosThemeBlockClassName,
} from "../../ui/src/site-templates";

const resolved = resolveCedrosSiteTemplateTheme(
  { theme, standalone: true },
  "authoredPage", // the route surface
);

const surfaced = applyCedrosThemeSurface(
  myContent,
  resolved.surface,
  resolved.webPlan.surface,
);

return wrapWithCedrosSiteTemplateTheme(surfaced, resolved);
```

`wrapWithCedrosSiteTemplateTheme` provides the theme context, mounts the
provider (mode + inline CSS variables), and renders the theme's runtime assets.
`applyCedrosThemeSurface` stamps the surface classes and `data-theme-*`
attributes onto your content root.

Inside the wrapped tree, a custom block component picks up its theme classes
with the hook (it runs the selector/fallback chain from `07`):

```ts
function MyBlock({ className }: { className?: string }) {
  const themed = useCedrosThemeBlockClassName("commerce/product/card", className);
  return <div className={themed}>…</div>;
}
```

### Resolution options

`resolveCedrosSiteTemplateTheme(options, routeSurface)` options:

| Option | Effect |
| --- | --- |
| `theme` | The manifest or compiled theme to apply |
| `siteData` | Saved site config used when `theme` is omitted |
| `assetRoot` | Host-published asset URL used to resolve `assets.fonts[].source` and `sources[].source` values like `./fonts/display.woff2` |
| `themeOverrides` | Extra `--cedros-*` overrides merged over the theme's |
| `layout` | Host layout overrides merged into the shell layout |
| `standalone` | `true` ⇒ render shell (`default`); `false` ⇒ `inherit` |
| `shellMode` | Explicit shell mode (`inherit`/`default`/`none`) |
| `headless` | `true` ⇒ shell mode `none` (wins over everything) |

Hosts rendering a third-party theme package should pass the extracted package's
public asset root when the manifest references bundled files:

```ts
const plan = resolveCedrosThemeRuntimePlan(
  {
    theme,
    assetRoot: "/theme-packages/studio-aurora/v1",
    standalone: true,
  },
  "blogPost",
);
```

That turns font sources such as `./fonts/display-700.woff2` into package
public URLs before web `@font-face` injection or host-specific font
registration. On web, a font with `sources[]` emits the ordered fallback list
exactly as declared by the manifest.

## Saved-theme payloads

A site stores its selection in `siteData.theme`. Two shapes are supported:

- **Built-in:** `{ themeId: "commerce" }`
- **Persisted custom:** `{ themeId: "studio-aurora", manifest: { /* CedrosThemeManifest */ } }`

Built-in ids always win over any extra `manifest` field, so an owner can switch
back to a packaged default without clearing stale custom data. Persisted custom
manifests must pass **routine-safe** validation or the payload falls back to
`minimalist` (`10`). Templates that auto-load `siteData` follow this selection
when you omit `theme`.

Read helpers (from `../../ui/src/site-templates/theme-runtime`):
`readCedrosSavedSiteThemeSelection`, `resolveCedrosSiteThemeManifestFromSiteData`,
`resolveCedrosSiteThemeId`.

## Color mode on web

The saved theme decides palettes; the **visitor** decides the active mode.
Hosts rendering full pages should include the shared color-mode bootstrap
(`SiteColorModeScript` — the shared templates and public host do this), which
applies the persisted preference (`localStorage["cedros-color-mode"]`,
light/dark/system, default system) as a `cedros-dark` class on `<html>` before
first paint. The dark `--cds-*` chains key off that class (`05`).

## The renderer-neutral plan

For lower-level or non-template integration, resolve the plan and derive
web/native specifics from it:

```ts
import {
  resolveCedrosThemeRuntimePlan,
  resolveCedrosThemeWebPlan,
  resolveCedrosThemeWebBlockClassName,
} from "../../ui/src/site-templates";

const plan = resolveCedrosThemeRuntimePlan({ theme, standalone: true }, "blogPost");
const webPlan = resolveCedrosThemeWebPlan(plan); // shell + surface class maps
const heroClass = resolveCedrosThemeWebBlockClassName(plan, "hero", webPlan);
```

The plan contains: provider data (mode, `unstyled`, merged token overrides),
shell data (mode, nav/footer/page, merged layout), surface data (variant, tone,
container width), block selection, and asset/style data with placement + dedupe
metadata.

## React Native and other hosts

Use the stable cross-platform boundary
`../../ui/src/site-templates/theme-runtime`, which exposes the same
engine plus host adapters:

```ts
import {
  resolveCedrosThemeHostSurfaceAdapterBundle,
  resolveCedrosThemeHostRuntimeAdapter,
  resolveCedrosThemeHostBlockAdapter,
  type CedrosThemeRuntimeInput,
  type CedrosThemeRuntimeOptions,
} from "../../ui/src/site-templates/theme-runtime";

const bundle = resolveCedrosThemeHostSurfaceAdapterBundle(
  { theme, standalone: true },
  "blogPost",
);
// bundle.runtime → shell/surface/asset/runtime-style data for the host
// bundle.blocks  → exact/fallback block adapters for that surface's blocks
```

`resolveCedrosThemeHostSurfaceAdapterBundle` pre-resolves the block types each
surface typically renders (the table in `07`); pass extra block types — e.g.
the block types found in an authored document — as the third argument. Each
block adapter reports its matched selector, resolved variant, and whether the
match was a fallback (`isFallback`) or an extension block (`isExtensionBlock`).

`../../react-native/src` components (`SiteLayout`, `DocsSidebar`,
`Breadcrumbs`, `MarkdownContent`, `CodeBlock`, `ContentPaywall`, …) consume
these adapters, so the same saved theme drives nav/footer/page chrome, surface
presentation, and block variants on native exactly as on web — the only
difference is token delivery (values through the provider instead of CSS
variables). Hosts register the plan's fonts/runtime styles with their own
font/style mechanism.

Prefer `CedrosThemeRuntimeInput` / `CedrosThemeRuntimeOptions` for
cross-platform code; `CedrosSiteTemplateThemeInput` / `…Options` are
compatibility aliases of the same types.

## The full pipeline on a live site

For orientation, the end-to-end path a saved theme travels on the public
website:

1. The server merges the active selection (`themeId` + `customTheme`) into the
   public site config.
2. The web host reads `siteData.theme` through
   `readCedrosSavedSiteThemeSelection` and compiles the winning manifest.
3. Each page render resolves the runtime plan for its route surface and wraps
   the page: provider (inline `--cedros-*` variables, `cedros-dark` when the
   base mode is dark) → theme context → runtime assets → surface classes.
4. The shared stylesheet bundle turns those classes and variables into pixels;
   the visitor's color mode flips the `-light`/`-dark` chains.

Next: [`12-validation-review-and-distribution.md`](./12-validation-review-and-distribution.md).

# 13 · Worked Example

A small, complete, valid portable theme assembled end to end. It is
routine-safe (no `customCss`, no external stylesheets), ships one font,
includes a full brand kit, restyles surfaces and blocks with catalogued values
— including an extension fallback — and passes validation.

## The manifest

```ts
import type { CedrosThemeManifest } from "../../ui/src/site-templates";

export const auroraThemeManifest = {
  kind: "cedros-theme",
  schemaVersion: 1,
  theme: {
    id: "studio-aurora",
    label: "Aurora",
    version: "1.0.0",
    description: "Calm, editorial product site for a design studio.",
  },
  mode: "light",

  brandKit: {
    summary: "Aurora is a calm, editorial site for a design studio.",
    audience: "Studios and founders evaluating a design partner.",
    voice: "Clear and confident; practical over hype.",
    personalityKeywords: ["calm", "editorial", "precise"],
    visualDirection:
      "Generous whitespace, restrained accent color, serif headings over a clean sans body.",
    logoUsage:
      "Full wordmark in primary nav; icon for favicon and compact UI. Keep clear space around the mark.",
    assistantGuidance:
      "Match the calm, editorial voice. Prefer clarity over hype and reference the supplied brand assets instead of inventing marks or colors.",
    assets: {
      primaryLogoUrl: "/media/brand/aurora-logo.svg",
      iconUrl: "/media/brand/aurora-icon.svg",
    },
  },

  tokens: {
    colors: {
      background: "#fbfaf7",
      foreground: "#1b1a17",
      muted: "#f1efe9",
      mutedForeground: "#6b675f",
      border: "#e4e1d8",
      link: "#3b5bdb",
      primary: "#3b5bdb",
      primaryForeground: "#ffffff",
      accent: "#e9efff",
      ring: "#3b5bdb",
      success: "#16a34a",
      error: "#dc2626",
    },
    darkColors: {
      background: "#121110",
      foreground: "#f2f0ea",
      muted: "#211f1c",
      mutedForeground: "#a8a294",
      border: "#2e2b26",
      link: "#8da4f5",
      primary: "#8da4f5",
      primaryForeground: "#10131f",
      accent: "#1d2435",
      ring: "#8da4f5",
      success: "#22c55e",
      error: "#ef4444",
    },
    typography: {
      fontBody: "\"Inter\", system-ui, sans-serif",
      fontHeading: "\"Fraunces\", Georgia, serif",
      fontMono: "ui-monospace, SFMono-Regular, Menlo, monospace",
      baseSize: "16px",
      lineHeightBody: "1.6",
      lineHeightHeading: "1.1",
    },
    spacing: { sectionGap: "4rem", contentGap: "1.25rem", pageInset: "1.5rem" },
    radius: { sm: "0.375rem", md: "0.625rem", lg: "1rem", pill: "999px" },
    shadow: {
      sm: "0 1px 2px rgb(0 0 0 / 5%)",
      md: "0 4px 12px rgb(0 0 0 / 8%)",
      lg: "0 12px 32px rgb(0 0 0 / 12%)",
    },
    container: { content: "46rem", wide: "72rem" },
  },

  shell: {
    mode: "default",
    nav: { variant: "minimal", width: "full", linkPosition: "right", linkStyle: "text" },
    footer: { variant: "minimal", width: "full" },
    page: { variant: "default", containerWidth: "wide" },
  },

  routeSurfaces: {
    home:        { containerWidth: "full", accentTone: "emphasis" },
    about:       { containerWidth: "content" },
    contact:     { containerWidth: "content" },
    docsIndex:   { variant: "editorial", containerWidth: "wide", accentTone: "muted" },
    docsArticle: { variant: "editorial", containerWidth: "content", accentTone: "muted" },
    blogIndex:   { variant: "editorial", containerWidth: "wide", accentTone: "muted" },
    blogPost:    { variant: "editorial", containerWidth: "content", accentTone: "muted" },
    legal:       { variant: "minimal", containerWidth: "content" },
    authoredPage:{ containerWidth: "wide" },
  },

  blockVariants: {
    entryHeader:    { default: "detail-header", surfaces: { blogPost: "story-header" } },
    entryActions:   { default: "actions-row" },
    hero:           { default: "shadcn-section", surfaces: { home: "spotlight" } },
    contentCard:    { default: "shadcn-grid" },
    contentMedia:   { default: "media-stack" },
    relatedContent: { default: "shadcn-list" },
    support:        { default: "shadcn-card" },
    article:        { default: "shadcn-surface" },
    paywall:        { default: "reader-gate" },
    sidebar:        { default: "section-list" },
    toc:            { default: "outline-panel" },
    controls:       { default: "toolbar" },
    breadcrumbs:    { default: "detail-breadcrumbs" },
    pagination:     { default: "pager" },
    prose:          { default: "shadcn-prose" },
    codeBlock:      { default: "terminal" },
    // Fallback variant name handed to any extension-contributed block; the
    // extension's own styles interpret it (07) — kernel CSS does not.
    "extension/*":  { default: "quiet" },
  },

  assets: {
    fonts: [
      {
        id: "fraunces-700",
        family: "Fraunces",
        source: "./fonts/fraunces-700.woff2",
        sources: [
          { source: "./fonts/fraunces-700.woff2", format: "woff2" },
          { source: "./fonts/fraunces-700.woff", format: "woff" },
          { source: "./fonts/fraunces-700.otf", format: "opentype" },
        ],
        weight: "700",
        style: "normal",
      },
    ],
  },

  preview: "/themes/aurora.png",
} satisfies CedrosThemeManifest;
```

## Validate, compile, review

```ts
import {
  validateCedrosRoutineThemeManifest,
  compileCedrosRoutineThemeManifest,
  formatCedrosThemeValidationIssues,
} from "../../ui/src/site-templates";
import { auroraThemeManifest } from "./aurora-theme";

const issues = validateCedrosRoutineThemeManifest(auroraThemeManifest);
if (issues.length > 0) {
  throw new Error(formatCedrosThemeValidationIssues(issues));
}

const compiled = compileCedrosRoutineThemeManifest(auroraThemeManifest);
// pass `auroraThemeManifest` or `compiled` to any shared template's `theme` prop
```

Render it through the shared templates to review (the scaffold from `12`
automates this):

```ts
import { DocArticleTemplate } from "../../ui/src/site-templates";
import "../../ui/src/site-templates/styles.css";

<DocArticleTemplate standalone theme={auroraThemeManifest} /* …page props… */ />;
```

## Package for distribution

Wrap the validated manifest in the portable envelope (`12`), with the font
files alongside, and zip the directory for marketplace upload:

```
studio-aurora-1.0.0/
├── manifest.json   ← the envelope below (ranked first by marketplace intake)
└── fonts/
    ├── fraunces-700.woff2
    ├── fraunces-700.woff
    └── fraunces-700.otf
studio-aurora-1.0.0.zip   ← zip of the directory (≤ 6 MB)
```

```jsonc
{
  "kind": "cedros-theme-library-package",
  "schemaVersion": 1,
  "manifest": { /* the auroraThemeManifest object above */ }
}
```

Upload `studio-aurora-1.0.0.zip` to a Cedros Theme Manager (this theme ships
fonts, so the zip is its real distribution form), or import `manifest.json`
directly into a site's Appearance library — noting that the JSON-only path
cannot carry the font binaries (`12`). Intake re-runs routine-safe validation
and the brand-kit check, so a theme that compiles and reviews cleanly here
installs cleanly there.

## What this example demonstrates

- A non-built-in `theme.id` with semver `version`.
- A complete, portable-ready `brandKit`.
- A full light **and** dark palette, a type system, and a container scale.
- Minimal nav/footer chrome with a wide base page.
- Reading surfaces narrowed to `content`, marketing surfaces `wide`/`full`,
  with `muted`/`emphasis` tones — each width reflected in the rendered page.
- Catalogued, shadcn-aligned block variants for every core block, per-surface
  overrides (`story-header` on blog posts, `spotlight` on the home hero), and
  an `extension/*` fallback variant name for extension blocks to interpret.
- One self-hosted font through the routine-safe `assets.fonts` path, with
  WOFF2/WOFF/OpenType fallbacks for broader browser support.

That is a complete theme. Adjust the tokens, surfaces, and block variants to
your brief (`03`) and you have a shippable Cedros theme.

Next: [`14-troubleshooting-and-faq.md`](./14-troubleshooting-and-faq.md).

# 09 · Brand Kit, Assets, and Preview

These fields turn a manifest into a shippable, brandable package. The brand kit
is **required for portable/marketplace themes**; assets and `customCss` are
optional (and partly advanced-only); the preview image is optional but
recommended for marketplace listings.

## `brandKit`

The brand kit travels with the theme so Cedros — and especially the AI
assistant — has explicit brand guidance instead of guessing. It is optional for
in-repo default themes but **required and fully validated for portable/
marketplace themes**.

```ts
interface CedrosThemeBrandKitManifest {
  summary?: string;
  audience?: string;
  voice?: string;
  personalityKeywords?: string[];
  visualDirection?: string;
  logoUsage?: string;
  assistantGuidance?: string;
  assets?: {
    primaryLogoUrl?: string;
    wordmarkLogoUrl?: string;
    iconUrl?: string;
    socialShareImageUrl?: string;
  };
}
```

| Field | Purpose |
| --- | --- |
| `summary` | One or two sentences on the theme's identity |
| `audience` | Who the site serves |
| `voice` | Tone for copy (clear/confident/playful/…) |
| `personalityKeywords` | A few adjectives that anchor the brand |
| `visualDirection` | The look: surfaces, spacing, accent usage |
| `logoUsage` | When to use the full logo vs. icon/mark |
| `assistantGuidance` | Instructions for the AI assistant when it writes copy, design guidance, or media prompts for this theme |
| `assets.*` | Brand asset URLs (logo, wordmark, icon, social share) |

The starter manifest ships a sensible generic brand kit (built by
`buildCedrosThemeBrandKit`); replace its text and asset URLs with your brand's
before packaging.

### Portable requirement

Portable/marketplace intake runs `validateRequiredCedrosThemeBrandKit`, which
requires:

- non-empty `summary`, `audience`, `voice`, `visualDirection`, `logoUsage`,
  and `assistantGuidance`;
- at least one entry in `personalityKeywords`;
- at least one non-empty URL in `assets` (`primaryLogoUrl`, `wordmarkLogoUrl`,
  `iconUrl`, or `socialShareImageUrl`).

A portable theme missing any of these is rejected at install.

```ts
brandKit: {
  summary: "Aurora is a calm, editorial site for a design studio.",
  audience: "Studios and founders evaluating a design partner.",
  voice: "Clear and confident; practical over hype.",
  personalityKeywords: ["calm", "editorial", "precise"],
  visualDirection:
    "Generous whitespace, restrained accent color, serif headings over a clean sans body.",
  logoUsage:
    "Full wordmark in primary nav; icon for favicon and compact UI. Keep clear space around the mark.",
  assistantGuidance:
    "Match the calm, editorial voice. Prefer clarity over hype and reference the supplied brand assets instead of inventing alternate marks or colors.",
  assets: {
    primaryLogoUrl: "/media/brand/aurora-logo.svg",
    iconUrl: "/media/brand/aurora-icon.svg",
  },
}
```

## `assets`

```ts
interface CedrosThemeAssetsManifest {
  fonts?: CedrosThemeFontAsset[];
  stylesheets?: string[]; // ADVANCED: forbidden under routine-safe
}
```

### `assets.fonts` (allowed under routine-safe)

Ship custom web fonts and have the runtime generate `@font-face` rules:

```ts
interface CedrosThemeFontAsset {
  id: string;       // required, unique within the theme
  family: string;   // required, the font-family name your tokens reference
  source: string;   // required primary source: https://, /..., ./..., or local("Family")
  sources?: CedrosThemeFontSource[]; // ordered web fallbacks, preferred when present
  weight?: string;  // "normal" | "bold" | "100".."900"
  style?: string;   // "normal" | "italic" | "oblique"
}

type CedrosThemeFontSourceFormat =
  | "woff2"
  | "woff"
  | "truetype"
  | "opentype";

interface CedrosThemeFontSource {
  source: string;
  format?: CedrosThemeFontSourceFormat;
}
```

Source rules: `source` must be an `https://` URL, a root-relative `/…` path, a
package-relative `./…` path, or a `local("Family Name")` reference. Use
`./fonts/name.woff2` for font files bundled inside a third-party theme package;
the host resolves it against the package's public `assetRoot` during runtime
planning. Traversal paths such as `./../secret.woff2` are rejected. Each
`sources[]` entry follows the same source rules and may declare one of the
documented CSS formats.

When `sources` is present, the runtime emits a single `@font-face src:` list in
array order. Use WOFF2 first, WOFF second, then the original raw fallback
(`opentype` for `.otf`, `truetype` for `.ttf`). The admin custom-font upload
accepts `.woff2`, `.woff`, `.ttf`, or `.otf` and stores those three web
fallbacks automatically. If a theme package preserves one designer-source file,
prefer `.otf` as the raw fallback when available; WOFF2 should still be the
first served source. The runtime compiles each font into a deduped `@font-face`
block injected as a `<style>` before the first themed surface. Reference the
family from `tokens.typography.fontBody` / `fontHeading` / `fontMono` (`05`).

| Provided/uploaded file | Recommended served `sources[]` order |
| --- | --- |
| `.otf` | `.woff2`, `.woff`, `.otf` with `format: "opentype"` |
| `.ttf` | `.woff2`, `.woff`, `.ttf` with `format: "truetype"` |
| `.woff2` | original `.woff2`, generated `.woff`, detected raw fallback |
| `.woff` | generated `.woff2`, original `.woff`, detected raw fallback |

```ts
assets: {
  fonts: [
    {
      id: "fraunces-700",
      family: "Fraunces",
      source: "./fonts/fraunces-700.woff2",
      sources: [
        { source: "./fonts/fraunces-700.woff2", format: "woff2" },
        { source: "./fonts/fraunces-700.woff", format: "woff" },
        { source: "./fonts/fraunces-700.otf", format: "opentype" },
      ],
      weight: "700",
      style: "normal",
    },
  ],
},
tokens: {
  typography: { fontHeading: "\"Fraunces\", Georgia, serif" },
},
```

### `assets.stylesheets` (advanced only)

An array of external stylesheet URLs rendered as `<link rel="stylesheet">`.
**Forbidden under routine-safe**, so it is not available to portable/marketplace
or packaged default themes. Use it only for explicitly-advanced first-party
themes, and prefer tokens/shell/surfaces/blocks first.

## `customCss` (advanced escape hatch)

A raw CSS string injected as a deduped `<style>` block. **Forbidden under
routine-safe.** It is the last resort, not the first tool.

When you do use it (advanced first-party themes), target the stable hooks the
runtime emits rather than fragile internal class names:

- Token variables: `--cedros-*` (and the derived `--cds-*`, `05`).
- Surface hooks: `data-theme-surface`, `data-theme-surface-variant`,
  `data-theme-surface-tone`, `data-theme-surface-width`, and
  `cedros-theme-surface-variant--<surface>-<variant>`.
- Block hooks: `cedros-theme-block--<type>` and
  `cedros-theme-block-variant--<type>-<value>`.

```ts
customCss: `
  [data-theme-surface="home"] .cedros-site__title { letter-spacing: -0.02em; }
`,
```

This is the intended way to style a **custom (non-catalogued) block variant
value** (`07`) on web: pick your own value and write the matching
`cedros-theme-block-variant--<type>-<value>` rule here.

## `preview`

```ts
preview?: string; // root-relative static image path, e.g. "/themes/aurora.png"
```

The marketplace/admin preview image. Must be a root-relative path (a `3:2`
ratio image is recommended). When unset or invalid, tooling falls back to a
shared placeholder, so a theme without a preview still lists cleanly.

Next: [`10-theme-lifecycle-owners-and-admin.md`](./10-theme-lifecycle-owners-and-admin.md).

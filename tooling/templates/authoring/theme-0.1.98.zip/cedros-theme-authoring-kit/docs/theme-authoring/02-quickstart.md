# 02 · Quickstart

Two tracks. Track A needs no code and takes minutes in the admin. Track B is
the file-based path this guide mostly documents — author a manifest, validate
it, see it render, and package it.

## Track A — in the admin (no code)

From the site's admin, open **Appearance**:

1. **Pick a packaged theme.** The catalog shows the four built-ins
   (`minimalist`, `editorial`, `product`, `commerce`), any marketplace themes
   the host publishes, and your site's saved custom themes. Preview, then
   apply. Applying is instant and fully reversible.
2. **Build a custom theme.** Start a new theme from scratch or derive one from
   whatever you are previewing. The guided editor edits routine-safe fields —
   metadata, palette (light and dark), typography (including Google Fonts and
   uploaded font files), shell chrome, and route surfaces — and saves the
   generated manifest into your site's theme library. Raw JSON stays available
   as a review output.
3. **Import / export.** A theme authored elsewhere arrives as a portable
   package (a JSON document, `12`); import it into the library, preview it
   next to the built-ins through the same runtime, then apply. Export works
   the same way in reverse, so themes move between sites.

The AI assistant can also drive this flow — it has first-class "build theme"
tools that edit the same routine-safe manifest.

Everything Track A saves and applies is exactly the manifest format the rest
of this guide documents. When the guided editor feels limiting, switch to
Track B and import the result.

## Track B — as a file

### 1. Add the authoring kit

In Admin, open **Theme builder**, download the versioned theme authoring kit,
and unzip it at the target repository root. The kit is documentation and
contracts, not an npm-installed scaffold. Create a JSON manifest/envelope in
your project, then use the kit's field reference and worked example. Portable
theme intake performs the authoritative validation and preview.

### 2. Edit the starter manifest

Export an existing routine-safe theme from **Appearance**, or copy the complete
worked example from `13`. Change the identity and palette while preserving the
rest of the valid object — do not start from an empty object. At minimum, give
the portable theme its own id, label, version, description, light palette,
dark palette, and complete brand kit.

### 3. Validate

Import the draft JSON envelope into **Appearance**. Validation issues come back
as `path: message` lines
(`tokens.colors.primary: Expected a valid CSS color string.`). An empty issue
list means the theme will compile and apply cleanly.

> **Valid ≠ styled.** The one thing validation does *not* check is block
> variant **values** — they are free strings, and only the catalogued values
> in [`07`](./07-block-variants.md) have CSS behind them. An invented value
> like `hero: { default: "gilded-stage" }` validates, applies as a class, and
> renders nothing. The starter's values are all catalogued; when you change
> one, pick from the catalog.

Portable authors store the object as JSON inside the package envelope shown in
step 5. Repository host developers can use the TypeScript validator/compiler
examples in `04` and `12` against checked-in private source.

### 4. See it render

For portable work, import the draft into **Appearance** and preview it through
the real site templates before applying it.

Repository host developers can also render directly — any shared template
accepts the manifest:

```tsx
import "../../ui/src/site-templates/styles.css"; // required
import { DocArticleTemplate } from "../../ui/src/site-templates";
import { myThemeManifest } from "./my-theme";

<DocArticleTemplate standalone theme={myThemeManifest} /* …page props… */ />;
```

> The CSS bundle import is required. Without
> `../../ui/src/site-templates/styles.css`, the `cedros-theme-*` classes
> the runtime emits have nothing to style.

### 5. Package and install

Wrap the manifest in the portable envelope. Portable themes require a complete
`brandKit` — the starter ships a generic one, so replace its text and assets
with your brand's before packaging
(see [`09`](./09-brand-kit-assets-and-preview.md)):

```jsonc
{
  "kind": "cedros-theme-library-package",
  "schemaVersion": 1,
  "manifest": { /* your manifest, with brandKit */ }
}
```

Save it as JSON and import it in **Appearance** on any Cedros site (Track A,
step 3). Intake re-runs the same validation, so a theme that validated in step
3 installs cleanly — except for the brand-kit requirement, which is enforced
at intake for portable themes.

Save a JSON-only theme as the envelope itself. For marketplace delivery with
font assets, place that envelope at `manifest.json` in the ZIP and follow the
layout in `12`.

## Where to go next

- Plan a real theme deliberately: [`03-theme-brief.md`](./03-theme-brief.md).
- Field-by-field reference: [`04`](./04-manifest-reference.md)–[`09`](./09-brand-kit-assets-and-preview.md).
- The full validate → review → distribute path: [`12-validation-review-and-distribution.md`](./12-validation-review-and-distribution.md).
- Something didn't render the way you expected: [`14-troubleshooting-and-faq.md`](./14-troubleshooting-and-faq.md).

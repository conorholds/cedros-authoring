# 12 · Validation, Review, and Distribution

This is the path from a finished manifest to a shipped, installable theme:
validate → compile → review through the real runtime → package → distribute.

## Validate and compile

Run the policy that matches your path (`01`):

```ts
import {
  validateCedrosRoutineThemeManifest,
  compileCedrosRoutineThemeManifest,
  formatCedrosThemeValidationIssues,
} from "../../ui/src/site-templates";

const issues = validateCedrosRoutineThemeManifest(manifest);
if (issues.length > 0) {
  throw new Error(formatCedrosThemeValidationIssues(issues));
}
const compiled = compileCedrosRoutineThemeManifest(manifest);
```

Use the `validateCedrosThemeManifest` / `compileCedrosThemeManifest` pair only
for advanced first-party themes that genuinely need `assets.stylesheets` or
`customCss`. Compiling always asserts validity first, so a successful compile
is also a validation gate.

Routine-safe validation also requires `mode: "light"` and complete, matching
12-token `tokens.colors` and `tokens.darkColors` palettes. Missing or partial
palettes are release blockers for site-library imports, packaged defaults, and
marketplace themes.

## Review through the real runtime

Never eyeball a theme in isolation — render it through the shared templates so
you see exactly what ships.

### Non-installing authoring scan

When no local Cedros host or MCP-connected test site is available, use the
[centralized Forge authoring scan](https://cedros.ai/extensions/cedros-forge/skill.md).
Submit the final portable theme JSON or ZIP using only a profile, endpoint, and
exact contract ID advertised by that live guide, and do not attach site
credentials. A missing scanner discovery endpoint is not scan evidence.

The service applies the canonical routine-safe manifest policy, archive and
packaged-font signature and bounded-header checks, rejects duplicate JSON keys and ambiguous
multi-manifest archives, and produces a deterministic route/mode application
plan. It never imports or applies the theme.

CedrosCloud performs the scan in a killable subprocess with a
thread-synchronized seccomp-BPF policy denying filesystem opens/mutations,
socket creation, cross-process access, mounts, and further exec. It receives no
database handle or site credentials. Discovery publishes the hard timeout and
report/finding bounds. Anonymous bytes are destroyed with the request; queued
authenticated jobs delete artifact bytes on completion or failure. Public
quota exhaustion returns `429` plus `Retry-After`, and unavailable shared quota
enforcement fails closed with a retryable `503`. Waitlist, maintenance, or
other HTML is a route failure and never scan evidence.

Retain the artifact, contract, and report SHA-256 values as preliminary release
evidence. The scan does not render pixels, run interaction or accessibility
checks, or resolve a target site's installed extension blocks and content, so
the real-runtime review below remains required.

### Authoring kit (empty-sandbox bootstrap)

Download the versioned theme authoring kit from Admin Theme builder and unzip
it at the target repository root. The kit contains the canonical guide and
checksums; it deliberately does not install a Cedros npm package or claim a
standalone registry-backed validator. Author the portable
`cedros-theme-library-package` JSON envelope described below, then validate and
preview it through **Appearance** before release.

For in-repository host work, the TypeScript review example below reads the
private `ui/src/site-templates` source directly and stays on the same
manifest-only path (`validateCedrosRoutineThemeManifest` →
`compileCedrosRoutineThemeManifest` → shared templates with
`theme={…}`). It does not create a second review engine.

The older `cedros-copy-theme-host-scaffold` helper remains available for
in-repository host work that needs to copy the review helper into an existing
test suite.

### Review against real pages

Round out a review by applying (or previewing) the theme on a site and checking:

- the **home** surface at its configured width/tone;
- one **docs article** and one **blog post** (reading rhythm, sidebar/toc,
  code blocks);
- one **authored page** with builder blocks (`08`);
- **dark mode** (toggle in the footer) on all of the above;
- if extensions run on the site, one page with extension blocks.

### In-repo review (default themes)

Contributors editing the packaged defaults use the in-repo loops:

```bash
cd ui
npm run test:theme-authoring   # routine-safe validation + shared preview proofs
npm run review:themes          # exports a preview gallery HTML for visual review
```

`review:themes` writes `ui/.theme-review/default-theme-preview-catalog.html`
from the preview-catalog snapshot — a thin wrapper, not a separate renderer.
Default manifests live in `ui/src/site-templates/themes/`; update the focused
theme tests and snapshots listed below whenever a manifest or runtime contract
changes.

The relevant proof suites, for orientation:

| Suite | Proves |
| --- | --- |
| `theme-kernel` | Validator + compiler contract (schema, enums, block keys, class maps) |
| `default-themes` (+ `.snapshot`) | Built-ins stay routine-safe valid and render distinctly |
| `theme-kernel-variant-css-coverage` | Every variant a shipped manifest references has kernel CSS |
| `site-theme-mode-css` | The `--cedros-*` → `--cds-*` light/dark chains stay wired |
| `theme-host-review-template` / `theme-host-routine-ci` / `theme-host-scaffold-copy-cli` | The host scaffold keeps working against checked-in private host source |
| `theme-owner-workflow` / `custom-theme-library` | The admin library/apply flow |
| `theme-marketplace-catalog` / `theme-marketplace-install` | Catalog normalization + package install |

## The portable theme package

A portable/marketplace theme is distributed as a routine-safe manifest
envelope:

```jsonc
{
  "kind": "cedros-theme-library-package",
  "schemaVersion": 1,
  "manifest": { /* a full, routine-safe CedrosThemeManifest with a brandKit */ }
}
```

The envelope may be distributed as a JSON-only package, or inside a marketplace
archive with bundled files. When a theme ships font files in the archive, put
them under a package path such as `fonts/display-700.woff2` and reference them
from the manifest as `assets.fonts[].source: "./fonts/display-700.woff2"`. For
browser redundancy, include `assets.fonts[].sources` in WOFF2, WOFF, then raw
fallback order. The admin custom-font upload produces that set from `.woff2`,
`.woff`, `.ttf`, or `.otf`; package authors can include the same generated
files directly. The installing host publishes the extracted assets and passes
that host asset-root URL as `assetRoot` when resolving the theme runtime.

### The two upload targets

One build should emit both artifacts from the same source:

| Target | Artifact | Contract |
| --- | --- | --- |
| Site admin (Appearance → import) | The envelope as a **`.json` file** | The import accepts JSON only (envelope or bare manifest). Because no archive travels with it, this path cannot carry font binaries — a JSON-imported theme must use system font stacks, fonts uploaded through the admin font panel, or absolute/root-relative font URLs. `./fonts/…` sources will not resolve here. |
| Cedros Theme Manager (marketplace) | A **`.zip`** package, ≤ 6 MB | The manifest is located *inside* the archive by ranked filename — `manifest.json`, then `theme.json`, `cedros-theme.json`, `cedros-theme-package.json` / `cedros-theme-library-package.json`, then any `*.theme.json` (shallowest path wins ties). The entry may be the envelope or a bare manifest and must carry `theme.id` and `theme.version`. Use ordinary stored/deflate zip entries. Bundled fonts go at `fonts/<file>` matching the manifest's `./fonts/<file>` sources; site install verifies the catalog digest, extracts the fonts, and rewrites the sources — a referenced font missing from the archive fails the install. |

Recommended package layout (works for both targets — upload `manifest.json`
directly to a site, upload the zip to a marketplace):

```
dist/<theme-id>-<version>/
├── manifest.json    ← the cedros-theme-library-package envelope
└── fonts/           ← only when the theme ships font files
    └── display-700.woff2 …
dist/<theme-id>-<version>.zip   ← zip of the directory above
```

Rules enforced at intake:

- `kind` must be `"cedros-theme-library-package"` and `schemaVersion` must be `1`.
- `manifest` must pass `validateCedrosRoutineThemeManifest` (no `customCss`, no
  `assets.stylesheets`; fonts allowed).
- `manifest.brandKit` must be complete (`09`).
- `manifest.theme.id` must not reuse a built-in id (`minimalist`, `editorial`,
  `product`, `commerce`).

A bare routine-safe `CedrosThemeManifest` (without the package envelope) is
also accepted by the owner-library importer; the envelope is the canonical
distribution form. Either way the same validation runs.

## Distribution targets

- **Owner theme library.** Import the package in the admin (Appearance). The
  theme lands in `customThemes`, previews beside the built-ins, and applies
  through `themeId` + `customTheme` (`10`).
- **Marketplace.** Submit to a host's Cedros Theme Manager. Each catalog
  listing is validated exactly like a portable package (routine-safe + brand
  kit), rejected if it reuses a built-in id or duplicates another listing's
  `theme.id`, and must reference its package by root-relative URL + digest
  (`10`). Invalid listings are dropped with path-scoped issues; built-in
  themes always remain available even when the catalog is missing or errors.

## Versioning, upgrade, and rollback

- Keep `theme.id` **stable** across releases — selection, the owner library,
  and the marketplace key on it.
- Bump `theme.version` (semver) on every published change so operators can see
  and reason about updates.
- A theme change is presentation-only and reversible: roll back by reapplying a
  prior selection (`themeId` + the previous manifest) or switching to a
  built-in id. There is no data migration tied to a theme.
- Re-run validation + review on every version before publishing.

Next: [`13-worked-example.md`](./13-worked-example.md).

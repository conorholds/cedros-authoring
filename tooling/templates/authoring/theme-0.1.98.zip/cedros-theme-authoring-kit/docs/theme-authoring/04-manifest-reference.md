# 04 · Manifest Reference

This is the field-level source of truth for `CedrosThemeManifest`. The
validator enforces every rule here and **rejects any unknown key at every
level** — themes may only use the documented declarative fields. Sub-objects
(`tokens`, `shell`, `routeSurfaces`, `blockVariants`, `brandKit`, `assets`)
have their own references in `05`–`09`; this document locks the top-level shape
and the rules shared across them.

## Top-level shape

```ts
interface CedrosThemeManifest {
  kind: "cedros-theme";          // required, literal
  schemaVersion: 1;              // required, literal
  theme: CedrosThemeMetadata;    // required
  mode?: "light" | "dark";       // routine-safe requires "light"
  unstyled?: boolean;            // default false; see below
  brandKit?: CedrosThemeBrandKitManifest;   // see 09 (required for portable)
  tokens?: CedrosThemeTokenManifest;        // see 05
  shell?: CedrosThemeShellManifest;         // see 06
  routeSurfaces?: Partial<Record<RouteSurface, RouteSurfaceManifest>>; // see 06
  blockVariants?: Record<string, BlockVariantManifest>;                // see 07
  assets?: CedrosThemeAssetsManifest;       // see 09 (fonts / advanced)
  preview?: string;              // marketplace preview image path; see 09
  customCss?: string;            // advanced escape hatch; see 09
}
```

Allowed root keys, exactly: `kind`, `schemaVersion`, `theme`, `mode`,
`unstyled`, `brandKit`, `tokens`, `shell`, `routeSurfaces`, `blockVariants`,
`assets`, `preview`, `customCss`. Anything else is a validation error.

## Required envelope

| Field | Rule |
| --- | --- |
| `kind` | Must be exactly `"cedros-theme"`. |
| `schemaVersion` | Must be exactly `1` (number). |
| `theme` | Required object — see below. |

Author the manifest in TypeScript with `satisfies CedrosThemeManifest` so the
literal `kind`/`schemaVersion` are checked at compile time:

```ts
import type { CedrosThemeManifest } from "../../ui/src/site-templates";

export const auroraThemeManifest = {
  kind: "cedros-theme",
  schemaVersion: 1,
  theme: { id: "studio-aurora", label: "Aurora", version: "1.0.0" },
  mode: "light",
  // tokens, shell, routeSurfaces, blockVariants, …
} satisfies CedrosThemeManifest;
```

The manifest TypeScript types intentionally mirror the runtime validator
field-for-field (including the nav/footer shell fields in `06`), so a manifest
that satisfies the type also passes the structural checks. Value-level rules —
CSS color validity, font source shapes, block-key grammar — still only run in
the validator, so always run it before shipping.

## `theme` — metadata

```ts
interface CedrosThemeMetadata {
  id: string;          // required, non-empty
  label: string;       // required, non-empty
  version: string;     // required, non-empty (semver recommended)
  description?: string;
}
```

Allowed keys: `id`, `label`, `version`, `description`.

- `id` is the stable theme identifier used by selection, previews, and the
  saved payload. **Custom theme ids must not reuse a built-in id**
  (`minimalist`, `editorial`, `product`, `commerce`); intake rejects that. Use
  a namespaced, kebab-case id such as `studio-aurora` or `acme-aurora`.
- `version` is the **theme release version** and is independent of
  `schemaVersion`. Bump it on every published change (`12`).
- `label` is shown in tooling and the theme picker.

## `mode` and `unstyled`

- `mode`: `"light"` or `"dark"`, default `"light"`. Routine-safe themes must
  use `"light"` and provide complete `tokens.colors` and
  `tokens.darkColors` palettes so visitors can switch between light, dark, and
  system. `"dark"` remains supported only by the general/advanced
  compatibility path. See `05`.
- `unstyled`: when `true`, the provider applies no default class or inline
  style. This is an advanced/headless switch for hosts that deliver tokens
  through their own mechanism; leave it unset (or `false`) for normal themes.

## Validation model

Two entry points, same shape, different policy:

| Function | Policy |
| --- | --- |
| `validateCedrosThemeManifest(m)` | General contract — allows `assets.stylesheets` and `customCss`. |
| `validateCedrosRoutineThemeManifest(m)` | Routine-safe — forbids `assets.stylesheets` and `customCss`; allows `assets.fonts`. |

Both return `CedrosThemeValidationIssue[]` (`{ path, message }`). Empty array =
valid. `assertValidCedrosThemeManifest` / `assertValidCedrosRoutineThemeManifest`
throw a formatted error instead. Use
`formatCedrosThemeValidationIssues(issues)` to render `path: message` lines.

```ts
import {
  validateCedrosRoutineThemeManifest,
  formatCedrosThemeValidationIssues,
} from "../../ui/src/site-templates";

const issues = validateCedrosRoutineThemeManifest(auroraThemeManifest);
if (issues.length > 0) {
  throw new Error(formatCedrosThemeValidationIssues(issues));
}
```

### What the validator checks

- **Unknown keys** are rejected at every object level.
- **Enums** (`mode`, surface `variant`/`accentTone`/`containerWidth`, shell
  variants, nav/footer options) must be one of the documented values — see
  `05`–`07` for each set.
- **Colors** in `tokens.colors` and `tokens.darkColors` must be valid CSS
  color strings (validated with `CSS.supports` where available;
  `url()`/image functions are rejected).
- **Fonts** in `assets.fonts` require `id`, `family`, `source`, where `source`
  is an `https://`/root-relative URL, package-relative `./…` file path, or a
  `local("Family")` value; optional `sources[]` entries use the same source
  rules and optional `format` (`woff2|woff|truetype|opentype`). Optional
  `weight` (`normal|bold|100–900`) and `style` (`normal|italic|oblique`) are
  validated. Package-relative paths reject traversal segments and are resolved
  by the host's runtime `assetRoot`.
- **Block keys** must be a core key, an exact namespaced extension key, a
  `namespace/*` family selector, or a reserved `extension/*` / `unknown/*`
  fallback (`07`).
- **`preview`** must be a root-relative static image path (e.g. `/themes/x.png`).

### What the validator does NOT check

Block variant **values** are free non-empty strings — the validator never
compares them against the styled catalog. A manifest full of invented variant
names passes validation and compiles, then renders every block with its plain
default treatment. Validation success proves the manifest is *applicable*, not
that every choice is *styled*; cross-check variant values against the catalog
in `07` (or programmatically — `07` shows how).

### Routine-safe deltas

`validateCedrosRoutineThemeManifest` adds two rejections on top of the general
rules:

- `assets.stylesheets` present → error.
- `customCss` present → error.

Portable/marketplace intake additionally requires a complete `brandKit` (`09`)
and re-checks the no-built-in-id rule.

## Compilation

A validated manifest compiles to a `CedrosCompiledTheme` (provider config,
shell runtime, per-surface class maps, block variants, runtime styles):

```ts
import {
  compileCedrosThemeManifest,         // general
  compileCedrosRoutineThemeManifest,  // routine-safe (asserts the policy)
} from "../../ui/src/site-templates";

const compiled = compileCedrosRoutineThemeManifest(auroraThemeManifest);
```

Both compilers assert validity first and throw on failure, so a compile is also
a validation gate. Hosts can pass either the raw manifest or the compiled
object to the runtime (`11`).

## Defaults at a glance

| Field | Default when omitted |
| --- | --- |
| `mode` | `"light"` |
| `unstyled` | `false` |
| `shell.mode` | `"default"` |
| `shell.nav.variant` / `shell.footer.variant` / `shell.page.variant` | `"default"` |
| `shell.page.containerWidth` | `"content"` |
| Each route surface | `variant: "default"`, `accentTone: "default"`, width inherited from the shell (`06`) |
| Every token | The shared site defaults baked into the CSS (`05`) |

Next: [`05-design-tokens.md`](./05-design-tokens.md).

# Cedros Theme Authoring

This folder is the complete guide to building **Cedros themes**. A Cedros theme
is a single declarative JSON/TS document — a `CedrosThemeManifest` — that
re-skins an entire Cedros site: colors, typography, spacing, site chrome,
per-page presentation, and the visual treatment of every content block. A theme
contains no React components, no CSS files, and no runtime code.

The guide assumes **zero prior knowledge of Cedros**. Someone who has never
seen the platform can start at `00`, walk forward in order, and end with a
valid, reviewable, distributable theme. Every contract described here is backed
by private host source in `ui/src/site-templates` and verified in this
repository. No Cedros npm package is required or available.

The stable public orientation is `/skills/cedros-theme-authoring.md`, linked
directly from `/skill.md`. It routes authors into this version-matched guide
while leaving current site tools, schemas, and permissions in the authenticated
MCP registry.

## Reading paths

- **Never seen Cedros before?** Read `00` → `01` → `02` in order, then keep
  going. `00` explains the platform, `01` explains how theming works, and `02`
  gets a first theme rendering in minutes.
- **Designing a theme (human or agent)?** Skim `00`–`01`, work through
  `03`–`09`, then validate and ship with `12`. Keep `07`/`08` open while
  choosing block treatments and `14` open when something looks wrong.
- **Site owner / operator?** `02` (Track A) and `10` cover picking, building,
  importing, and applying themes from the admin, with no code.
- **Host developer embedding themes in an app?** `01` for the model, then `11`
  for the runtime APIs on web and React Native.
- **Editing the packaged default themes inside this repo?** Use the
  [in-repo review workflow](./12-validation-review-and-distribution.md#in-repo-review-default-themes)
  for the files, tests, snapshots, and preview commands; this folder is the
  platform-neutral contract that workflow builds on.

## The documents

| # | Document | What it covers |
| --- | --- | --- |
| 00 | [`00-cedros-platform-primer.md`](./00-cedros-platform-primer.md) | What Cedros is, how a site is put together, pages and blocks, route surfaces, extensions, who controls what, and a glossary. |
| 01 | [`01-theming-system-overview.md`](./01-theming-system-overview.md) | The theming mental model: manifest → validate → compile → per-route plan → DOM classes and CSS variables; light/dark; the one shared engine; the two authoring paths and the routine-safe policy. |
| 02 | [`02-quickstart.md`](./02-quickstart.md) | First theme fast — Track A in the admin with no code, Track B as a file with validation, preview, and packaging. |
| 03 | [`03-theme-brief.md`](./03-theme-brief.md) | Turning a brand/design goal into a concrete plan before touching fields: palette (light **and** dark), type, density, per-surface intent, block treatments. |
| 04 | [`04-manifest-reference.md`](./04-manifest-reference.md) | Field-level source of truth for `CedrosThemeManifest`: envelope, metadata, validation model, compilation. |
| 05 | [`05-design-tokens.md`](./05-design-tokens.md) | Color/typography/spacing/radius/shadow/container tokens, the `--cedros-*` variables they compile to, the internal `--cds-*` layer, and light/dark buckets. |
| 06 | [`06-shell-and-route-surfaces.md`](./06-shell-and-route-surfaces.md) | Site chrome (nav, footer, page frame), the nine route surfaces, what `variant`/`accentTone`/`containerWidth` actually render, and per-surface chrome overrides. |
| 07 | [`07-block-variants.md`](./07-block-variants.md) | The block-variant model: the 16 core block keys, extension/namespace selectors and fallback resolution, and the complete catalog of built-in styled variant values. |
| 08 | [`08-page-builder-and-blocks.md`](./08-page-builder-and-blocks.md) | How themes meet the page builder: the authored-document model, how builder blocks map onto theme block keys, section styling vs. theme styling, and extension blocks. |
| 09 | [`09-brand-kit-assets-and-preview.md`](./09-brand-kit-assets-and-preview.md) | The brand kit (required for portable themes), self-hosted fonts, the advanced `stylesheets`/`customCss` escape hatches, and the preview image. |
| 10 | [`10-theme-lifecycle-owners-and-admin.md`](./10-theme-lifecycle-owners-and-admin.md) | A theme's life on a real site: storage, the admin Appearance workflow, the owner theme library, marketplace install, applying, rollback. |
| 11 | [`11-runtime-application-hosts.md`](./11-runtime-application-hosts.md) | Host-side application: CSS bundles, template props, manual composition, the renderer-neutral plan, host adapters, and React Native. |
| 12 | [`12-validation-review-and-distribution.md`](./12-validation-review-and-distribution.md) | Validate → compile → review through the real runtime → package → distribute; the scaffold CLI, the portable package, the marketplace catalog contract, versioning. |
| 13 | [`13-worked-example.md`](./13-worked-example.md) | A small, complete, valid portable theme assembled end to end. |
| 14 | [`14-troubleshooting-and-faq.md`](./14-troubleshooting-and-faq.md) | Symptom → cause → fix for everything that commonly goes wrong, plus a FAQ. |

## The theme contract in one paragraph

One theme is one `CedrosThemeManifest` (`kind: "cedros-theme"`,
`schemaVersion: 1`). It controls **presentation only** — design tokens, site
chrome, per-surface presentation, block variants, brand metadata, fonts — and
never defines data, routes, navigation content, or block behavior. The same
manifest drives the public website, React Native apps, and every admin/builder
preview through one shared runtime; there is no preview-only theme engine. A
theme can be consumed raw or pre-compiled, and both resolve through the same
path.

Two authoring paths share that contract:

- **Default / built-in themes** ship inside cedros-data
  (`ui/src/site-templates/themes/<id>.ts`) and follow the **routine-safe**
  policy: complete light and dark palettes, no external stylesheets, and no
  `customCss` (self-hosted fonts are allowed).
- **Portable / marketplace themes** are authored outside the repo as a
  `cedros-theme-library-package` JSON document, must include a **brand kit**,
  and are validated against the same two-mode routine-safe policy at install.

The general (advanced) contract additionally supports external stylesheets and
`customCss` for first-party or explicitly-advanced cases. Prefer tokens, shell,
route surfaces, and block variants first — they cover the overwhelming majority
of real themes.

## Conventions used throughout

- Portable themes start as JSON manifests and are validated during admin or
  marketplace import; they contain no JavaScript dependency. Repository
  contributors use the checked-in validation and review scripts.
- TypeScript imports shown in this guide target the private
  `ui/src/site-templates` source tree and are for in-repository host work only.
  Do not copy those imports into a portable theme project.
- **Do not invent token names, route surfaces, shell values, or block keys.**
  The validator rejects unknown keys at every level. The allowed sets are
  enumerated in `04`–`07`.
- If you think you need to edit anything outside the manifest to make a theme
  work, you are changing the platform, not authoring a theme. Re-read `01` and
  check `14`; if the goal is behavior, you want the
  [`extension-authoring`](../extension-authoring) guide instead.

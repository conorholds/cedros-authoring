# 05 · Design Tokens

`tokens` is the heart of a theme. Each token compiles to a `--cedros-*` CSS
variable that the provider applies as an inline style, and the shared site CSS
reads those variables (directly or through derived `--cds-*` variables) to
paint every surface. Tokens are the highest-leverage, lowest-risk way to make a
theme distinct — prefer token changes before shell, surface, or block work.

```ts
interface CedrosThemeTokenManifest {
  colors?: CedrosThemeColorTokens;      // palette for the theme's base mode
  darkColors?: CedrosThemeColorTokens;  // dark-mode palette (same keys as colors)
  typography?: CedrosThemeTypographyTokens;
  spacing?: CedrosThemeSpacingTokens;
  radius?: CedrosThemeRadiusTokens;
  shadow?: CedrosThemeShadowTokens;
  container?: CedrosThemeContainerTokens;
}
```

All groups and all fields are optional. Anything you omit falls back to the
shared site defaults baked into the CSS. Unknown group names or field names are
rejected.

## Colors → `--cedros-*`

Every value must be a **valid CSS color string** (hex, `rgb()`, `hsl()`,
`oklch()`, `color-mix()`, named colors, …). `url()`/image functions are
rejected. The same rules apply to `darkColors`.

`colors` paints the theme's base mode (light, unless `mode: "dark"`).
`darkColors` paints dark mode when the visitor switches to it — see *Light and
dark mode* below. Each color token compiles to the unsuffixed variable in the
table plus mode-suffixed variants (`--cedros-background-light` /
`--cedros-background-dark`) that the site CSS resolves per mode.

| Token | CSS variable | Use |
| --- | --- | --- |
| `background` | `--cedros-background` | Page canvas |
| `foreground` | `--cedros-foreground` | Headings, body, default text |
| `muted` | `--cedros-muted` | Secondary canvas, muted panels, dividers |
| `mutedForeground` | `--cedros-muted-foreground` | Eyebrows, helper text |
| `border` | `--cedros-border` | Rules, outlines, separators |
| `link` | `--cedros-link` | Inline links, interactive text, link-tinted accents |
| `primary` | `--cedros-primary` | Buttons, key accents |
| `primaryForeground` | `--cedros-primary-foreground` | Text on primary fills |
| `accent` | `--cedros-accent` | Subtle chips, emphasis fills |
| `ring` | `--cedros-ring` | Focus/selection ring |
| `success` | `--cedros-success` | Positive/confirmation states |
| `error` | `--cedros-error` | Errors, destructive actions |

Two colors are deliberately **not** tokens:

- **Panel/card background.** Cards read an internal `--cds-panel` chain that
  derives from `--cedros-panel`/`--cedros-card` — variables no token maps to —
  so panels default to white (light) and a neutral dark gray (dark). Themes
  shape panels indirectly: through `muted`, `border`, `link` (many built-in
  block variants tint panels with `color-mix` against the link color), and
  through each surface's `accentTone` (`06`). Advanced first-party themes can
  set `--cedros-panel` via `customCss` or host `themeOverrides`.
- **Warning/info.** `--cedros-warning` / `--cedros-info` exist in the CSS with
  fixed defaults but are not part of the theme token schema.

## Typography → `--cedros-*`

| Token | CSS variable | Notes |
| --- | --- | --- |
| `fontBody` | `--cedros-font-body` | Also aliased to `--cedros-font-sans` |
| `fontHeading` | `--cedros-font-heading` | Also aliased to `--cedros-font-display` |
| `fontMono` | `--cedros-font-mono` | Code and technical UI |
| `baseSize` | `--cedros-font-size-base` | Root text size, e.g. `16px` |
| `lineHeightBody` | `--cedros-line-height-body` | Reading rhythm |
| `lineHeightHeading` | `--cedros-line-height-heading` | Display rhythm |

Provide full CSS font stacks (`"Inter", system-ui, sans-serif`). The aliases
mean cedros-login/cedros-pay surfaces that read `--cedros-font-sans` /
`--cedros-font-display` stay aligned with your theme automatically. To load a
non-system family, declare it in `assets.fonts` (`09`) so the `@font-face` rule
ships with the theme. A token should reference the family name, not a file
path; the file paths live in `assets.fonts[].source` / `sources[]`. For custom
designer fonts, Cedros accepts `.woff2`, `.woff`, `.ttf`, or `.otf` uploads and
serves WOFF2, WOFF, then the raw OpenType/TrueType fallback.

## Spacing → `--cedros-*`

| Token | CSS variable | Use |
| --- | --- | --- |
| `sectionGap` | `--cedros-space-section` | Gap between major sections |
| `contentGap` | `--cedros-space-content` | Gap inside content/cards |
| `pageInset` | `--cedros-space-page-inset` | Horizontal page padding |
| `unit` | `--cedros-space-unit` | **Legacy.** Accepted for backward-compatible custom themes; prefer the three semantic tokens above. |

## Radius → `--cedros-*`

| Token | CSS variable |
| --- | --- |
| `sm` | `--cedros-radius-sm` |
| `md` | `--cedros-radius-md` (also aliased to `--cedros-radius`) |
| `lg` | `--cedros-radius-lg` |
| `pill` | `--cedros-radius-pill` |

`radius.md` doubles as the global `--cedros-radius`, which the derived
`--cds-radius` reads, so it sets the default rounding for buttons, inputs, and
nav links (default `0.5rem`). When `sm`/`lg` are unset they derive from the
resolved base radius (`calc(--cds-radius − 0.3rem)` / `+ 0.25rem`), so setting
only `md` keeps the whole scale coherent.

## Shadow → `--cedros-*`

| Token | CSS variable | Use |
| --- | --- | --- |
| `sm` | `--cedros-shadow-sm` | Low-elevation panels (blog cards, primitives) |
| `md` | `--cedros-shadow-md` | Default card elevation (`.cedros-site__card`); falls back to the resolved `sm` when unset |
| `lg` | `--cedros-shadow-lg` | High-elevation overlays (popovers, sticky panels) |

The shipped defaults are deliberately subtle (hairline shadcn-style shadows).
Multi-layer values are fine: `"0 1px 2px rgb(0 0 0 / 5%), 0 8px 24px rgb(0 0 0 / 6%)"`.

## Container → `--cedros-*`

| Token | CSS variable | Default | Read by web kernel? |
| --- | --- | --- | --- |
| `content` | `--cedros-container-content` | `48rem` | Yes — `containerWidth: "content"` max-width |
| `wide` | `--cedros-container-wide` | `75rem` | Yes — `containerWidth: "wide"` max-width |
| `full` | `--cedros-container-full` | — | No — see below |

`content` and `wide` are the actual max-widths a route surface's
`containerWidth` selects between (`06`). Tune `content` for comfortable reading
measure (≈45–75rem) and `wide` for marketing layouts.

`containerWidth: "full"` renders **full-bleed** — the content spans the
viewport minus the page inset (`calc(100% − 2 × pageInset)`) — and does **not**
read `--cedros-container-full`. The token is reserved (accepted by the schema,
ignored by the current web kernel); set `pageInset` to control the full-bleed
gutter.

## How tokens reach the DOM

1. The compiler walks `tokens` and produces a map of `--cedros-*` → value
   (only non-empty values are emitted). Color tokens additionally emit
   `-light`/`-dark` suffixed variables: `colors` fills the theme's base-mode
   bucket and `darkColors` fills the dark bucket.
2. `CedrosDataProvider` applies that map as an **inline `style`** on its
   wrapper element, and adds the `cedros-dark` class when `mode` is `"dark"`.
   Inline styles win over class-based variable declarations for non-color
   tokens; colors go through the mode-suffixed variables precisely so the
   dark-mode class can still flip them.
3. The shared site CSS (`.cedros-site` and friends) defines a derived layer
   (`--cds-*`) that resolves each color per mode and adds fallbacks and
   computed values. For example:

   ```css
   .cedros-site {
     --cds-bg: var(--cedros-background-light, var(--cedros-background, oklch(1 0 0)));
     --cds-radius: var(--cedros-radius-md, var(--cedros-radius, 0.5rem));
     --cds-container-content: var(--cedros-container-content, 48rem);
   }
   .cedros-dark .cedros-site {
     /* dark reads only the -dark bucket, so a light palette never leaks */
     --cds-bg: var(--cedros-background-dark, oklch(0.145 0 0));
   }
   ```

You author `--cedros-*` (via tokens). The `--cds-*` variables are internal
plumbing — useful to know when writing `customCss` (`09`), but you do not set
them from a manifest.

## Light and dark mode

Visitors choose the site's color mode: the footer ships a toggle (cycling
light → dark → system; the default preference is **system**, which follows the
OS). The choice persists in the browser (`localStorage["cedros-color-mode"]`),
and an inline script applies the resolved mode as a `cedros-dark` class on
`<html>` **before first paint**, so there is no mode flash.

- Routine-safe themes use `mode: "light"`. `tokens.colors` paints light mode
  and `tokens.darkColors` paints dark mode; both must define all 12 supported
  color keys.
- The general/advanced compatibility path still allows omitted tokens. Those
  values fall back to the built-in neutral palettes, never across from the
  other mode. It also retains `mode: "dark"` for legacy always-dark manifests,
  but those manifests do not pass routine-safe validation or packaging.

## Minimal token block

```ts
tokens: {
  colors: {
    background: "#fbfaf7",
    foreground: "#1b1a17",
    muted: "#f1efe9",
    mutedForeground: "#6b675f",
    border: "#e4e1d8",
    link: "#3b5bdb",
    primary: "#3b5bdb",
    primaryForeground: "#ffffff",
    accent: "#e9efff",
    ring: "#3b5bdb",
    success: "#16a34a",
    error: "#dc2626",
  },
  darkColors: {
    background: "#121110",
    foreground: "#f2f0ea",
    muted: "#211f1c",
    mutedForeground: "#a8a294",
    border: "#2e2b26",
    link: "#8da4f5",
    primary: "#8da4f5",
    primaryForeground: "#10131f",
    accent: "#1d2435",
    ring: "#8da4f5",
    success: "#22c55e",
    error: "#ef4444",
  },
  typography: {
    fontBody: "\"Inter\", system-ui, sans-serif",
    fontHeading: "\"Fraunces\", Georgia, serif",
    baseSize: "16px",
    lineHeightBody: "1.6",
    lineHeightHeading: "1.1",
  },
  spacing: { sectionGap: "4rem", contentGap: "1.25rem", pageInset: "1.5rem" },
  radius: { sm: "0.375rem", md: "0.625rem", lg: "1rem", pill: "999px" },
  container: { content: "46rem", wide: "72rem" },
}
```

Next: [`06-shell-and-route-surfaces.md`](./06-shell-and-route-surfaces.md).
